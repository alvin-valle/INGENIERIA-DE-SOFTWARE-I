'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');

const raiz = path.resolve(__dirname, '..');

const cambios = new Map();

const comprobar =
    process.argv.includes('--comprobar');

const paginas = [
    'dashboard',
    'pos',
    'impresiones',
    'recargas',
    'caja-chica',
    'inventario',
    'reportes',
    'seguridad',
    'usuarios',
    'finanzas'
];

const leer = archivo =>
    fs.readFileSync(
        path.join(raiz, archivo),
        'utf8'
    );

function preparar(archivo, contenido) {
    const destino =
        path.join(raiz, archivo);

    const actual = fs.existsSync(destino)
        ? fs.readFileSync(destino)
        : null;

    const nuevo = Buffer.isBuffer(contenido)
        ? contenido
        : Buffer.from(contenido);

    if (!actual || !actual.equals(nuevo)) {
        cambios.set(archivo, nuevo);
    }
}

function validar(archivo, contenido) {
    if (/\.(?:js|cjs)$/.test(archivo)) {
        new vm.Script(
            contenido,
            { filename: archivo }
        );
    }

    if (/\.html$/.test(archivo)) {
        let numero = 0;

        const scripts = contenido.matchAll(
            /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi
        );

        for (const coincidencia of scripts) {
            const atributos = coincidencia[1];

            if (
                /\bsrc\s*=/.test(atributos) ||
                /\btype\s*=\s*['"](?:application\/ld\+json|application\/json|module)['"]/
                    .test(atributos)
            ) {
                continue;
            }

            new vm.Script(
                coincidencia[2],
                {
                    filename:
                        archivo +
                        ':script-' +
                        (++numero)
                }
            );
        }
    }
}

function construir() {
    for (const archivo of [
        'public/js/graficos-erp.js',
        'public/js/diseno-modulos.js',
        'public/css/diseno-modulos.css'
    ]) {
        if (
            !fs.existsSync(
                path.join(raiz, archivo)
            )
        ) {
            throw new Error(
                'Primero crea ' + archivo + '.'
            );
        }
    }

    const dashboard =
        leer('public/dashboard.html');

    for (const modulo of [
        'inicio',
        'produccion',
        'proveedores',
        'contabilidad',
        'finanzas',
        'inventario',
        'rrhh'
    ]) {
        const existe =
            dashboard.includes(
                'id="dash-' + modulo + '"'
            ) ||
            dashboard.includes(
                "id='dash-" + modulo + "'"
            );

        if (!existe) {
            throw new Error(
                'No se encontró el módulo ' +
                modulo +
                ' en el dashboard. ' +
                'No se aplicaron cambios.'
            );
        }
    }

    if (
        /\bstartOperationsDashboard\s*\(/
            .test(dashboard)
    ) {
        throw new Error(
            'Este dashboard todavía inicia la versión ' +
            'que sustituía los módulos. Usa tu dashboard ' +
            'restaurado y vuelve a ejecutar este comando.'
        );
    }

    const graficaLocal = path.join(
        raiz,
        'node_modules/chart.js/dist/chart.umd.js'
    );

    if (!fs.existsSync(graficaLocal)) {
        throw new Error(
            'Falta Chart.js local. Ejecuta npm install ' +
            'antes de continuar.'
        );
    }

    preparar(
        'public/vendor/chartjs/chart.umd.js',
        fs.readFileSync(graficaLocal)
    );

    for (const pagina of paginas) {
        const archivo =
            'public/' + pagina + '.html';

        let contenido = leer(archivo);

        const salto = contenido.includes('\r\n')
            ? '\r\n'
            : '\n';

        const esGrafica = origen =>
            /\/chart\.js(?:@|\/|$)|\/chart(?:\.umd)?(?:\.min)?\.js(?:\?|$)/i
                .test(origen);

        const origenes = [
            ...contenido.matchAll(
                /<script\b[^>]*\bsrc\s*=\s*(['"])([^'"]+)\1[^>]*>/gi
            )
        ].map(coincidencia => coincidencia[2]);

        const instalado =
            origenes.filter(esGrafica).length === 1 &&
            origenes.includes(
                '/vendor/chartjs/chart.umd.js'
            ) &&
            origenes.filter(
                origen =>
                    origen === '/js/graficos-erp.js'
            ).length === 1 &&
            origenes.filter(
                origen =>
                    origen === '/js/diseno-modulos.js'
            ).length === 1 &&
            contenido.includes(
                '<link rel="stylesheet" href="/css/diseno-modulos.css">'
            );

        if (!instalado) {
            contenido = contenido.replace(
                /<script\b[^>]*\bsrc\s*=\s*(['"])([^'"]+)\1[^>]*>\s*<\/script\s*>/gi,
                (etiqueta, comilla, origen) => {
                    const esComplemento =
                        /\/js\/(?:graficos-erp|diseno-modulos)\.js(?:\?|$)/
                            .test(origen);

                    return (
                        esGrafica(origen) ||
                        esComplemento
                    )
                        ? ''
                        : etiqueta;
                }
            );

            contenido = contenido.replace(
                /<link\b[^>]*\bhref\s*=\s*(['"])[^'"]*\/css\/diseno-modulos\.css(?:\?[^'"]*)?\1[^>]*>/gi,
                ''
            );

            if (
                !/<\/head\s*>/i.test(contenido) ||
                !/<\/body\s*>/i.test(contenido)
            ) {
                throw new Error(
                    'Revisa las etiquetas head y body de ' +
                    archivo
                );
            }

            contenido = contenido.replace(
                /<\/head\s*>/i,

                '<link rel="stylesheet" ' +
                'href="/css/diseno-modulos.css">' +
                salto +

                '<script ' +
                'src="/vendor/chartjs/chart.umd.js">' +
                '</script>' +
                salto +

                '<script src="/js/graficos-erp.js">' +
                '</script>' +
                salto +

                '</head>'
            );

            contenido = contenido.replace(
                /<\/body\s*>/i,

                '<script src="/js/diseno-modulos.js">' +
                '</script>' +
                salto +

                '</body>'
            );
        }

        contenido = contenido.replace(
            /\bnew\s+(?:window\.)?Chart\s*\(/g,
            'window.crearGraficoERP('
        );

        validar(archivo, contenido);
        preparar(archivo, contenido);
    }

    const directorio = path.join(
        raiz,
        'public/js'
    );

    const entradas = fs.readdirSync(
        directorio,
        { withFileTypes: true }
    );

    for (const entrada of entradas) {
        if (
            !entrada.isFile() ||
            !entrada.name.endsWith('.js') ||
            [
                'graficos-erp.js',
                'diseno-modulos.js'
            ].includes(entrada.name)
        ) {
            continue;
        }

        const archivo =
            'public/js/' + entrada.name;

        const contenido = leer(archivo).replace(
            /\bnew\s+(?:window\.)?Chart\s*\(/g,
            'window.crearGraficoERP('
        );

        validar(archivo, contenido);
        preparar(archivo, contenido);
    }
}

try {
    construir();

    console.log(
        'Archivos que requieren actualización: ' +
        cambios.size
    );

    for (const archivo of cambios.keys()) {
        console.log('  ' + archivo);
    }

    if (comprobar) {
        console.log(
            'Comprobación terminada. ' +
            'No se modificó ningún archivo.'
        );

        process.exit(0);
    }

    if (!cambios.size) {
        console.log(
            'El diseño ya está actualizado.'
        );

        process.exit(0);
    }

    const sello =
        new Date()
            .toISOString()
            .replace(/[:.]/g, '-') +
        '-' +
        crypto.randomBytes(3).toString('hex');

    const respaldo = path.join(
        raiz,
        'backups',
        'diseno-' + sello
    );

    const anteriores = new Map();

    for (const archivo of cambios.keys()) {
        const destino =
            path.join(raiz, archivo);

        const existe =
            fs.existsSync(destino);

        anteriores.set(archivo, existe);

        if (existe) {
            const copia =
                path.join(respaldo, archivo);

            fs.mkdirSync(
                path.dirname(copia),
                { recursive: true }
            );

            fs.copyFileSync(
                destino,
                copia,
                fs.constants.COPYFILE_EXCL
            );
        }
    }

    const escritos = [];

    try {
        for (
            const [archivo, contenido] of
            cambios
        ) {
            const destino =
                path.join(raiz, archivo);

            fs.mkdirSync(
                path.dirname(destino),
                { recursive: true }
            );

            const temporal =
                destino + '.diseno-' + sello;

            try {
                fs.writeFileSync(
                    temporal,
                    contenido,
                    { flag: 'wx' }
                );

                fs.renameSync(
                    temporal,
                    destino
                );

                escritos.push(archivo);
            } finally {
                if (fs.existsSync(temporal)) {
                    fs.unlinkSync(temporal);
                }
            }
        }
    } catch (error) {
        for (
            const archivo of
            escritos.reverse()
        ) {
            const destino =
                path.join(raiz, archivo);

            if (anteriores.get(archivo)) {
                fs.copyFileSync(
                    path.join(respaldo, archivo),
                    destino
                );
            } else {
                fs.unlinkSync(destino);
            }
        }

        throw error;
    }

    console.log(
        'Diseño aplicado. Copias de los archivos ' +
        'anteriores en: ' +
        respaldo
    );

    console.log(
        'Reinicia el servidor y recarga el navegador ' +
        'con Ctrl + F5.'
    );
} catch (error) {
    console.error(error.message);
    process.exitCode = 1;
}