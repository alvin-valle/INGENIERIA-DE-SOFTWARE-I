'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const raiz = path.resolve(__dirname, '..');
const cambios = new Map();

const comprobar = process.argv.includes('--comprobar');

function leer(nombre) {
    return cambios.get(nombre) ??
        fs.readFileSync(
            path.join(raiz, nombre),
            'utf8'
        ).replace(/\r\n/g, '\n');
}

function guardar(nombre, codigo) {
    if (codigo !== leer(nombre)) {
        cambios.set(nombre, codigo);
    }
}

function existe(nombre) {
    return fs.existsSync(path.join(raiz, nombre));
}

function registrar(
    nombre,
    funcion,
    operacion = funcion + '()'
) {
    if (!existe(nombre)) return;

    let codigo = leer(nombre);

    const marca = '/* ERP_RECARGA_' + funcion + ' */';

    if (codigo.includes(marca)) return;

    const patron = new RegExp(
        '(^[ \\t]*)async function ' +
        funcion +
        '\\s*\\(',
        'm'
    );

    if (!patron.test(codigo)) {
        throw new Error(
            'No se encontró ' + funcion +
            ' en ' + nombre +
            '. No se modificó ningún archivo.'
        );
    }

    codigo = codigo.replace(
        patron,
        (_, espacios) => {
            return (
                espacios + marca + '\n' +
                espacios +
                "window.addEventListener('erp:solicitar-recarga', evento => {\n" +
                espacios +
                '    evento.detail.promesas.push(' +
                    'Promise.resolve().then(() => ' +
                    operacion +
                    '));\n' +
                espacios + '});\n' +
                espacios + 'async function ' + funcion + '('
            );
        }
    );

    guardar(nombre, codigo);
}

const nuevaAPI = `async function api(path, { method = 'GET', body, isForm = false } = {}) {
  try {
    const cabeceras = {};
    const token = Auth.getToken();

    if (token) {
      cabeceras.Authorization = 'Bearer ' + token;
    }

    const formulario = isForm || body instanceof FormData;

    if (!formulario) {
      cabeceras['Content-Type'] = 'application/json';
    }

    const respuesta = await fetch(API_BASE + path, {
      method,
      headers: cabeceras,
      credentials: 'same-origin',
      cache: 'no-store',
      body: body === undefined
        ? undefined
        : formulario
          ? body
          : JSON.stringify(body)
    });

    if (respuesta.status === 401) {
      Auth.clear();
      window.location.href = '/index.html';

      throw Object.assign(
        new Error('Sesión expirada.'),
        { status: 401 }
      );
    }

    if (respuesta.status === 204) return null;

    const esJSON = (
      respuesta.headers.get('content-type') || ''
    ).includes('application/json');

    const datos = esJSON
      ? await respuesta.json()
      : await respuesta.blob();

    if (!respuesta.ok) {
      const error = new Error(
        esJSON && datos.error
          ? datos.error
          : 'No se completó la consulta.'
      );

      error.status = respuesta.status;
      error.code = esJSON
        ? datos.code || datos.codigo
        : null;

      throw error;
    }

    return datos;

  } catch (error) {
    window.dispatchEvent(
      new CustomEvent('erp:error-api', {
        detail: {
          ruta: path,
          mensaje: error.message || 'Error de conexión'
        }
      })
    );

    throw error;
  }
}`;

function preparar() {
    const archivosNecesarios = [
        'src/routes/sincronizacion.routes.js',
        'public/js/sincronizacion-erp.js',
        'public/css/sincronizacion-erp.css'
    ];

    for (const archivo of archivosNecesarios) {
        if (!existe(archivo)) {
            throw new Error(
                'Primero crea el archivo ' + archivo
            );
        }
    }

    let codigo = leer('public/js/app.js');

    const patronAPI = /async function api\([\s\S]*?\n}\n/;

    if (!patronAPI.test(codigo)) {
        throw new Error(
            'La función api de app.js no coincide ' +
            'con la versión revisada.'
        );
    }

    guardar(
        'public/js/app.js',
        codigo.replace(patronAPI, nuevaAPI + '\n')
    );

    codigo = leer('src/routes/dashboard.routes.js');

    guardar(
        'src/routes/dashboard.routes.js',
        codigo.replace(
            /ce\.created_at/g,
            'ce.date'
        )
    );

    codigo = leer('src/routes/operations.routes.js');

    guardar(
        'src/routes/operations.routes.js',
        codigo.replace(
            /SELECT\s+a\.id\s*,\s*a\.date\s*,/g,
            'SELECT a.id,a.created_at AS date,'
        )
    );

    codigo = leer('src/server.js');

    if (!codigo.includes('/api/sincronizacion')) {
        const corte = /app\.use\(\s*['"]\/api['"]\s*,/;

        if (!corte.test(codigo)) {
            throw new Error(
                'No se encontró el manejador final ' +
                'de la API en server.js.'
            );
        }

        guardar(
            'src/server.js',
            codigo.replace(
                corte,
                "app.use('/api/sincronizacion', " +
                "require('./routes/sincronizacion.routes'));\n\n$&"
            )
        );
    }

    const vistas = [
        'dashboard',
        'pos',
        'impresiones',
        'recargas',
        'caja-chica',
        'inventario',
        'reportes',
        'seguridad',
        'usuarios',
        'finanzas'
    ];

    for (const vista of vistas) {
        const archivo = 'public/' + vista + '.html';

        if (!existe(archivo)) continue;

        codigo = leer(archivo);

        if (!codigo.includes('/css/sincronizacion-erp.css')) {
            codigo = codigo.replace(
                '</head>',
                '    <link rel="stylesheet" ' +
                'href="/css/sincronizacion-erp.css">\n</head>'
            );
        }

        if (!codigo.includes('/js/sincronizacion-erp.js')) {
            codigo = codigo.replace(
                '</body>',
                '    <script src="/js/sincronizacion-erp.js">' +
                '</script>\n</body>'
            );
        }

        guardar(archivo, codigo);
    }

    registrar(
        'public/pos.html',
        'refresh'
    );

    registrar(
        'public/recargas.html',
        'loadShift',
        'Promise.all([loadShift(), loadHistory()])'
    );

    registrar(
        'public/caja-chica.html',
        'loadData'
    );

    registrar(
        'public/impresiones.html',
        'loadRates',
        'Promise.all([loadRates(), loadOrders()])'
    );

    registrar(
        'public/reportes.html',
        'loadMargins'
    );

    if (
        existe('public/reportes.html') &&
        leer('public/reportes.html').includes(
            'async function loadIntegrated'
        )
    ) {
        registrar(
            'public/reportes.html',
            'loadIntegrated'
        );
    }

    registrar(
        'public/usuarios.html',
        'loadUsers'
    );

    registrar(
        'public/seguridad.html',
        'refresh'
    );

    if (
        existe('public/seguridad.html') &&
        leer('public/seguridad.html').includes(
            'async function loadAudit'
        )
    ) {
        registrar(
            'public/seguridad.html',
            'loadAudit'
        );
    }

    registrar(
        'public/finanzas.html',
        'cargarDatosFinancieros'
    );

    registrar(
        'public/js/inventory-page.js',
        'load'
    );

    registrar(
        'public/js/dashboard-business.js',
        'refresh'
    );

    codigo = leer('public/dashboard.html');

    if (codigo.includes('startOperationsDashboard')) {
        throw new Error(
            'dashboard.html todavía carga el controlador reducido. ' +
            'Usa como base tu dashboard completo aprobado ' +
            'antes de aplicar esta actualización.'
        );
    }

    if (!codigo.includes('dashboard-business.js')) {
        const inicio = codigo.indexOf(
            '            async function inicializarERP() {'
        );

        const fin = codigo.indexOf(
            '            function llenarSelects()',
            inicio
        );

        if (inicio < 0 || fin < 0) {
            throw new Error(
                'No se reconoció el inicializador ' +
                'del dashboard original.'
            );
        }

        if (!codigo.includes('ERP_DATOS_ANTERIORES')) {
            const reemplazo = `            /* ERP_DATOS_ANTERIORES */
            async function inicializarERP() {
                return window.sincronizarERP();
            }

            window.addEventListener('erp:datos', evento => {
                const datos = window.datosAnterioresERP(evento.detail);

                if (datos.ordenes) ordenesDB = datos.ordenes;
                if (datos.proveedores) provDB = datos.proveedores;
                if (datos.compras) comprasDB = datos.compras;
                if (datos.empleados) empDB = datos.empleados;
                if (datos.nomina) nominaDB = datos.nomina;
                if (datos.contratos) conDB = datos.contratos;
                if (datos.permisos) perDB = datos.permisos;
                if (datos.facturas) facturasDB = datos.facturas;
                if (datos.caja) cajaDB = datos.caja;
                if (datos.mercadotecnia) mktDB = datos.mercadotecnia;
                if (datos.liquidaciones) liquidacionesDB = datos.liquidaciones;

                for (const nombre of [
                    'renderTablaProduccion',
                    'renderProv',
                    'renderCompras',
                    'renderFacturas',
                    'renderRRHH',
                    'renderNomina',
                    'renderMkt',
                    'renderPermisos'
                ]) {
                    if (typeof window[nombre] === 'function') {
                        try {
                            window[nombre]();
                        } catch (error) {
                            evento.detail.errores_interfaz.push(
                                nombre + ': ' + error.message
                            );
                        }
                    }
                }

                llenarSelects();

                window.prepararFactura = indice => {
                    window.verFacturaRealERP(indice);
                };

                window.renderCaja = () => {
                    window.pintarCajaRealERP(evento.detail);
                };

                window.pintarCajaRealERP(evento.detail);

                activate(location.hash.slice(1));
            });

`;

            codigo =
                codigo.slice(0, inicio) +
                reemplazo +
                codigo.slice(fin);
        }

        codigo = codigo.replace(
            'setTimeout(inicializarERP, 300);',
            '/* La sincronización inicial la coordina ' +
            'sincronizacion-erp.js. */'
        );

        codigo = codigo.replace(
            'RUC Oficial: J0310000123456',
            'Comprobante interno · Datos fiscales pendientes de configurar'
        );

        codigo = codigo.replace(
            /parseFloat\(([^()\n]+)\)\.toLocaleString\('es-NI',\s*\{minimumFractionDigits:2\}\)/g,
            'formatearImporteERP($1)'
        );
    }

    const auxiliares = {
        fetchGet:
            'async function fetchGet(endpoint) ' +
            '{ return api(endpoint); }',

        fetchPost:
            'async function fetchPost(endpoint, data) ' +
            "{ return api(endpoint, {method:'POST',body:data}); }",

        fetchPut:
            'async function fetchPut(endpoint, data) ' +
            "{ return api(endpoint, {method:'PUT',body:data}); }",

        fetchDelete:
            'async function fetchDelete(endpoint) ' +
            "{ return api(endpoint, {method:'DELETE'}); }"
    };

    for (const [nombre, funcion] of Object.entries(auxiliares)) {
        const patron = new RegExp(
            'async function ' +
            nombre +
            '\\([^\\n]*\\) \\{[^\\n]*\\}[ \\t]*$',
            'gm'
        );

        codigo = codigo.replace(
            patron,
            () => funcion
        );
    }

    codigo = codigo.replace(
        "const API_URL = 'http://localhost:3000/api';",
        "const API_URL = '/api';"
    );

    guardar('public/dashboard.html', codigo);
}

try {
    preparar();

    console.log(
        'Archivos que requieren actualización: ' +
        cambios.size
    );

    for (const archivo of cambios.keys()) {
        console.log('  ' + archivo);
    }

    if (comprobar) {
        console.log(
            'Comprobación terminada. ' +
            'No se escribió ningún archivo.'
        );

        process.exit(0);
    }

    const sello =
        new Date().toISOString().replace(/[:.]/g, '-') +
        '-' +
        crypto.randomBytes(3).toString('hex');

    const respaldo = path.join(
        raiz,
        'backups',
        'sincronizacion-' + sello
    );

    for (const archivo of cambios.keys()) {
        const destino = path.join(
            respaldo,
            archivo
        );

        fs.mkdirSync(
            path.dirname(destino),
            { recursive: true }
        );

        fs.copyFileSync(
            path.join(raiz, archivo),
            destino,
            fs.constants.COPYFILE_EXCL
        );
    }

    const escritos = [];

    try {
        for (const [archivo, contenido] of cambios) {
            const destino = path.join(raiz, archivo);

            const temporal =
                destino + '.erp-' + sello;

            fs.writeFileSync(
                temporal,
                contenido,
                {
                    encoding: 'utf8',
                    flag: 'wx'
                }
            );

            fs.renameSync(
                temporal,
                destino
            );

            escritos.push(archivo);
        }
    } catch (error) {
        for (const archivo of escritos) {
            fs.copyFileSync(
                path.join(respaldo, archivo),
                path.join(raiz, archivo)
            );
        }

        throw error;
    }

    console.log(
        'Actualización aplicada. Respaldo: ' +
        respaldo
    );

} catch (error) {
    console.error(error.message);
    process.exitCode = 1;
}