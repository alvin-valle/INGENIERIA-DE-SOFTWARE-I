'use strict';

require('dotenv').config();

const fs = require('node:fs');
const path = require('node:path');

const {
    spawnSync
} = require('node:child_process');

const pool = require('../src/db/connection');

const raiz = path.resolve(__dirname, '..');

let fallos = 0;

function registrar(correcto, mensaje) {
    console.log(
        (correcto ? 'CORRECTO: ' : 'PENDIENTE: ') +
        mensaje
    );

    if (!correcto) fallos++;
}

const archivos = [
    'src/routes/sincronizacion.routes.js',
    'src/routes/expedientes.routes.js',
    'src/routes/analitica.routes.js',
    'src/routes/control-empresarial.routes.js',
    'src/services/archivos-privados.js',
    'src/integraciones/banpro-billetera.js',
    'public/js/sincronizacion-erp.js',
    'public/js/complementos-erp.js',
    'public/js/iniciar-complementos-erp.js',
    'public/js/finanzas-reales.js',
    'public/js/control-empresarial.js',
    'public/css/tema-empresarial.css',
    'public/css/sincronizacion-erp.css',
    'public/css/finanzas-reales.css',
    'public/css/control-empresarial.css'
];

const tablas = {
    audit_log: [
        'created_at'
    ],

    cash_expenses: [
        'date',
        'request_hash'
    ],

    caja: [
        'print_payment_id',
        'metodo_pago',
        'registrado_en'
    ],

    products: [
        'stock',
        'avg_cost'
    ],

    kc_accounts: [
        'code',
        'kind'
    ],

    kc_journals: [
        'movement_id'
    ],

    kc_journal_lines: [
        'journal_id',
        'debit',
        'credit'
    ],

    kc_employees: [
        'hired_on'
    ],

    kc_business_records: [
        'data',
        'version'
    ],

    kc_rrhh_expedientes: [
        'reservados'
    ],

    kc_rrhh_vinculos: [
        'empleado_anterior_id'
    ],

    kc_rrhh_incidencias: [
        'estado',
        'activo'
    ],

    kc_archivos_privados: [
        'huella'
    ],

    kc_rrhh_capacitaciones: [
        'request_key',
        'request_hash',
        'version'
    ],

    kc_rrhh_capacitacion_participantes: [
        'capacitacion_id',
        'empleado_id',
        'asistencia'
    ]
};

function comprobarSintaxis(directorio) {
    if (!fs.existsSync(directorio)) return;

    const entradas = fs.readdirSync(
        directorio,
        { withFileTypes: true }
    );

    for (const entrada of entradas) {
        const archivo = path.join(
            directorio,
            entrada.name
        );

        if (entrada.isDirectory()) {
            comprobarSintaxis(archivo);
        } else if (/\.(?:js|cjs)$/.test(entrada.name)) {
            const resultado = spawnSync(
                process.execPath,
                ['--check', archivo],
                {
                    encoding: 'utf8',
                    timeout: 10000
                }
            );

            if (resultado.status !== 0) {
                registrar(
                    false,
                    'Sintaxis de ' +
                    path.relative(raiz, archivo) +
                    ': ' +
                    (
                        resultado.stderr ||
                        resultado.error?.message ||
                        'Error de comprobación'
                    )
                );
            }
        }
    }
}

(async () => {
    const [mayor, menor] =
        process.versions.node.split('.').map(Number);

    registrar(
        mayor > 22 || (mayor === 22 && menor >= 5),
        'Node.js 22.5 o superior.'
    );

    registrar(
        typeof process.env.JWT_SECRET === 'string' &&
        process.env.JWT_SECRET.length >= 32,
        'Clave de autenticación configurada.'
    );

    const clave =
        process.env.ERP_CLAVE_DATOS ?? '';

    const decodificada =
        Buffer.from(clave, 'base64');

    registrar(
        decodificada.length === 32 &&
        decodificada.toString('base64') === clave,
        'Clave de cifrado de 32 bytes configurada.'
    );

    for (const archivo of archivos) {
        registrar(
            fs.existsSync(path.join(raiz, archivo)),
            archivo
        );
    }

    const antes = fallos;

    comprobarSintaxis(
        path.join(raiz, 'src')
    );

    comprobarSintaxis(
        path.join(raiz, 'public/js')
    );

    if (antes === fallos) {
        console.log(
            'CORRECTO: sintaxis de los archivos ' +
            'JavaScript comprobados.'
        );
    }

    const paginas = [
        'dashboard',
        'pos',
        'impresiones',
        'recargas',
        'caja-chica',
        'inventario',
        'reportes',
        'seguridad',
        'usuarios',
        'finanzas'
    ];

    for (const pagina of paginas) {
        const archivo = path.join(
            raiz,
            'public',
            pagina + '.html'
        );

        const contenido = fs.existsSync(archivo)
            ? fs.readFileSync(archivo, 'utf8')
            : '';

        const scripts = [
            'sincronizacion-erp.js',
            'iniciar-complementos-erp.js',

            ...(
                ['dashboard', 'reportes'].includes(pagina)
                    ? ['control-empresarial.js']
                    : []
            ),

            ...(
                pagina === 'dashboard'
                    ? ['finanzas-reales.js']
                    : []
            )
        ];

        for (const script of scripts) {
            const patron = new RegExp(
                '<script\\b[^>]*\\bsrc=["\'][^"\']*/' +
                script.replaceAll('.', '\\.') +
                '["\']',
                'i'
            );

            registrar(
                patron.test(contenido),
                pagina + '.html carga ' + script
            );
        }
    }

    const conexion = await pool.connect();

    try {
        await conexion.query(
            'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY'
        );

        await conexion.query(
            "SET LOCAL statement_timeout = '15s'"
        );

        const columnas = (
            await conexion.query(
                `
                SELECT table_name, column_name
                FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND table_name = ANY($1::text[])
                `,
                [Object.keys(tablas)]
            )
        ).rows;

        for (const [tabla, campos] of Object.entries(tablas)) {
            for (const campo of campos) {
                registrar(
                    columnas.some(columna =>
                        columna.table_name === tabla &&
                        columna.column_name === campo
                    ),
                    tabla + '.' + campo
                );
            }
        }

        const resultado = (
            await conexion.query(
                `
                SELECT COUNT(*)::text AS cantidad
                FROM (
                    SELECT journal_id
                    FROM public.kc_journal_lines
                    GROUP BY journal_id
                    HAVING SUM(debit - credit) <> 0
                ) q
                `
            )
        ).rows[0];

        registrar(
            resultado.cantidad === '0',
            'Asientos con líneas cuadradas. ' +
            'Registros por revisar: ' +
            resultado.cantidad
        );

        await conexion.query('COMMIT');
    } catch (error) {
        await conexion.query('ROLLBACK').catch(() => {});
        throw error;
    } finally {
        conexion.release();
    }
})()
    .catch(error => {
        registrar(
            false,
            'No se completó la verificación de PostgreSQL: ' +
            (error.code || error.message)
        );
    })
    .finally(async () => {
        await pool.end();

        console.log(
            'Comprobación terminada. Pendientes detectados: ' +
            fallos + '.'
        );

        console.log(
            'Comprueba también el flujo completo en el ' +
            'navegador y una restauración de respaldo ' +
            'en un entorno de prueba.'
        );

        if (fallos) {
            process.exitCode = 1;
        }
    });