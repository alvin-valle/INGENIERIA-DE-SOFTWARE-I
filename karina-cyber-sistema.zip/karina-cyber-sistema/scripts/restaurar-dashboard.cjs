'use strict';

const fs = require('node:fs');
const path = require('node:path');

function fail(message) {
    console.error(message);
    process.exit(1);
}

const projectRoot = path.resolve(__dirname, '..');
const sourceArgument = process.argv[2];

if (!sourceArgument) {
    fail(
        'Uso: node scripts/restaurar-dashboard.cjs ' +
        '"ruta/al/dashboard.html/original"'
    );
}

const sourcePath = path.resolve(sourceArgument);
const destinationPath = path.join(
    projectRoot,
    'public',
    'dashboard.html'
);

if (sourcePath === destinationPath) {
    fail(
        'La fuente debe ser el dashboard de la copia original, ' +
        'no el archivo actual del proyecto.'
    );
}

if (!fs.existsSync(sourcePath)) {
    fail('No existe el archivo original: ' + sourcePath);
}

const requiredFiles = [
    'public/css/dashboard-mejoras.css',
    'public/js/dashboard-mejoras.js'
];

for (const file of requiredFiles) {
    if (!fs.existsSync(path.join(projectRoot, file))) {
        fail('Primero crea este archivo: ' + file);
    }
}

let html = fs.readFileSync(sourcePath, 'utf8');

const requiredIds = [
    'dash-inicio',
    'dash-produccion',
    'dash-proveedores',
    'dash-contabilidad',
    'dash-finanzas',
    'dash-inventario',
    'dash-rrhh',

    'conta-nomina',
    'conta-compras',
    'conta-balance',
    'conta-resultados',
    'conta-flujo',

    'finanzas-caja',
    'finanzas-facturas',
    'finanzas-estadistica',
    'finanzas-mkt',

    'rh-empleados',
    'rh-contratos',
    'rh-permisos',
    'rh-seguridad',
    'rh-cumplimiento',

    'form-orden',
    'form-proveedor',
    'form-emp',
    'form-nomina',
    'form-compra',
    'form-caja',
    'form-factura',
    'form-liquidacion',
    'form-mkt-api',
    'form-contrato',
    'form-permiso',
    'form-incidente',
    'form-epp',

    'modal-preview',
    'preview-content',
    'ticket-contenido'
];

for (const id of requiredIds) {
    const expression = new RegExp(
        '\\bid\\s*=\\s*["\\\']' + id + '["\\\']'
    );

    if (!expression.test(html)) {
        fail(
            'El archivo seleccionado no contiene "' + id + '". ' +
            'Selecciona el dashboard del ZIP original completo.'
        );
    }
}

if (html.includes('startOperationsDashboard')) {
    fail(
        'El archivo seleccionado contiene el renderizador que ' +
        'sustituye las secciones. Usa el dashboard del ZIP original.'
    );
}

if (
    !html.includes('</head>') ||
    !html.includes('</body>')
) {
    fail('El HTML original está incompleto.');
}

/*
 * Mantiene las funciones que utiliza el dashboard, pero conecta
 * sus peticiones al auxiliar autenticado de app.js.
 *
 * Los errores se muestran y se propagan. No se devuelve un éxito
 * ficticio ni se utilizan los datos de ejemplo como fallback.
 */
const replacements = {
    fetchGet: `
            async function fetchGet(endpoint) {
                try {
                    return await api(endpoint);
                } catch (error) {
                    alert(
                        'No se pudo consultar ' + endpoint + ': ' +
                        (error.message || 'Error de conexión')
                    );
                    throw error;
                }
            }`,

    fetchPost: `
            async function fetchPost(endpoint, data) {
                try {
                    return await api(endpoint, {
                        method: 'POST',
                        body: data
                    });
                } catch (error) {
                    alert(
                        'La operación no se guardó: ' +
                        (error.message || 'Error de conexión')
                    );
                    throw error;
                }
            }`,

    fetchPut: `
            async function fetchPut(endpoint, data) {
                try {
                    return await api(endpoint, {
                        method: 'PUT',
                        body: data
                    });
                } catch (error) {
                    alert(
                        'La operación no se actualizó: ' +
                        (error.message || 'Error de conexión')
                    );
                    throw error;
                }
            }`,

    fetchDelete: `
            async function fetchDelete(endpoint) {
                try {
                    return await api(endpoint, {
                        method: 'DELETE'
                    });
                } catch (error) {
                    alert(
                        'La operación no se eliminó: ' +
                        (error.message || 'Error de conexión')
                    );
                    throw error;
                }
            }`
};

for (const [name, replacement] of Object.entries(replacements)) {
    /*
     * En el original revisado cada auxiliar ocupa una línea.
     * Se exige una coincidencia exacta en cantidad para no
     * modificar accidentalmente una versión diferente.
     */
    const expression = new RegExp(
        '^[\\t ]*async function ' + name +
        '\\([^\\r\\n]*\\)[\\t ]*\\{[^\\r\\n]*\\}[\\t ]*$',
        'gm'
    );

    const matches = html.match(expression) || [];

    if (matches.length !== 1) {
        fail(
            'La función ' + name + ' no coincide con el original ' +
            'revisado. No se modificó el dashboard actual.'
        );
    }

    html = html.replace(expression, () => replacement);
}

/* Conserva todos los estilos originales y agrega la mejora al final. */
html = html.replace(
    '</head>',
    '    <link rel="stylesheet" ' +
    'href="/css/dashboard-mejoras.css">\n</head>'
);

/* Conserva el JavaScript original y carga la mejora después. */
html = html.replace(
    '</body>',
    '    <script src="/js/dashboard-mejoras.js"></script>\n</body>'
);

const stamp = new Date()
    .toISOString()
    .replace(/[:.]/g, '-');

const backupDirectory = path.join(
    projectRoot,
    'backups',
    'dashboard'
);

fs.mkdirSync(backupDirectory, { recursive: true });

if (fs.existsSync(destinationPath)) {
    const backupPath = path.join(
        backupDirectory,
        'dashboard-antes-de-restaurar-' + stamp + '.html'
    );

    fs.copyFileSync(
        destinationPath,
        backupPath,
        fs.constants.COPYFILE_EXCL
    );

    console.log('Respaldo creado: ' + backupPath);
}

const temporaryPath = destinationPath + '.restaurando-' + stamp;

fs.writeFileSync(temporaryPath, html, {
    encoding: 'utf8',
    flag: 'wx'
});

fs.renameSync(temporaryPath, destinationPath);

console.log('Dashboard original restaurado.');
console.log('Conservadas las 7 secciones principales.');
console.log('Conservadas las 14 subsecciones.');
console.log('Conservados los 13 formularios.');
console.log('Agregadas las mejoras visuales y de navegación.');
console.log('No se modificó la base de datos.');