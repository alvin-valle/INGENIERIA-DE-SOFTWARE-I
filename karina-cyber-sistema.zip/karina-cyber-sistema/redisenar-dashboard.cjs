'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const raiz = process.cwd();
const marca = 'DASHBOARD-REDISENADO-2026-01';

const rutas = [
    'public/dashboard.html',
    'public/css/diseno-modulos.css',
    'public/js/dashboard-business.js',
    'public/js/control-empresarial.js',
    'public/js/sincronizacion-erp.js',
    'public/js/dashboard-ampliacion.js'
];

function reemplazar(texto, patron, nuevo, nombre) {
    const coincidencias = [
        ...texto.matchAll(
            new RegExp(patron.source, 'g')
        )
    ];

    if (coincidencias.length !== 1) {
        throw new Error(
            'No se reconoce el bloque: ' + nombre +
            '. No se modificó ningún archivo.'
        );
    }

    return texto.replace(patron, () => nuevo);
}

function funcion(texto, nombre, siguiente, nueva) {
    const patron = new RegExp(
        '    (?:async )?function ' +
        nombre +
        '\\([^]*?(?=    (?:async )?function ' +
        siguiente +
        '\\()'
    );

    return reemplazar(
        texto,
        patron,
        '    ' + nueva.toString() + '\n\n',
        nombre
    );
}

/*
 * Sustituye la portada existente.
 * Conserva los destinos de los seis módulos.
 */
const portada = `
                <section class="dash-panel" id="dash-inicio">
                    <div class="dash-portada">
                        <div>
                            <span class="dash-etiqueta">
                                PANEL GERENCIAL
                            </span>

                            <h2>K@rin@ Cyber</h2>

                            <p>Operación, finanzas y equipo.</p>
                        </div>

                        <i
                            class="bi bi-buildings"
                            aria-hidden="true"
                        ></i>
                    </div>

                    <div id="payroll-alert-container"></div>

                    <div
                        id="biz-overview"
                        class="biz-overview"
                        aria-label="Resumen del negocio"
                    >
                        <div class="power-bi-card">
                            <p>Órdenes pendientes</p>
                            <strong>—</strong>
                        </div>

                        <div class="power-bi-card">
                            <p>Proveedores activos</p>
                            <strong>—</strong>
                        </div>

                        <div class="power-bi-card">
                            <p>Empleados activos</p>
                            <strong>—</strong>
                        </div>

                        <div class="power-bi-card">
                            <p>Inversión en inventario</p>
                            <strong>—</strong>
                        </div>
                    </div>

                    <div class="dash-titulo-area">
                        <h3>Áreas del negocio</h3>
                        <span>6 módulos</span>
                    </div>

                    <div id="main-menu-container">
                        <button
                            type="button"
                            class="menu-btn"
                            data-target="produccion"
                            onclick="location.hash='#produccion'"
                        >
                            <i
                                class="bi bi-box-seam"
                                aria-hidden="true"
                            ></i>

                            <span>Producción</span>

                            <span
                                class="dash-flecha"
                                aria-hidden="true"
                            >↗</span>
                        </button>

                        <button
                            type="button"
                            class="menu-btn"
                            data-target="proveedores"
                            onclick="location.hash='#proveedores'"
                        >
                            <i
                                class="bi bi-truck"
                                aria-hidden="true"
                            ></i>

                            <span>Proveedores</span>

                            <span
                                class="dash-flecha"
                                aria-hidden="true"
                            >↗</span>
                        </button>

                        <button
                            type="button"
                            class="menu-btn"
                            data-target="contabilidad"
                            onclick="location.hash='#contabilidad'"
                        >
                            <i
                                class="bi bi-journal-text"
                                aria-hidden="true"
                            ></i>

                            <span>Contabilidad</span>

                            <span
                                class="dash-flecha"
                                aria-hidden="true"
                            >↗</span>
                        </button>

                        <button
                            type="button"
                            class="menu-btn"
                            data-target="finanzas"
                            onclick="location.hash='#finanzas'"
                        >
                            <i
                                class="bi bi-bank"
                                aria-hidden="true"
                            ></i>

                            <span>Finanzas y MKT</span>

                            <span
                                class="dash-flecha"
                                aria-hidden="true"
                            >↗</span>
                        </button>

                        <button
                            type="button"
                            class="menu-btn"
                            data-target="inventario"
                            onclick="location.hash='#inventario'"
                        >
                            <i
                                class="bi bi-boxes"
                                aria-hidden="true"
                            ></i>

                            <span>Inventario</span>

                            <span
                                class="dash-flecha"
                                aria-hidden="true"
                            >↗</span>
                        </button>

                        <button
                            type="button"
                            class="menu-btn"
                            data-target="rrhh"
                            onclick="location.hash='#rrhh'"
                        >
                            <i
                                class="bi bi-people"
                                aria-hidden="true"
                            ></i>

                            <span>Recursos Humanos</span>

                            <span
                                class="dash-flecha"
                                aria-hidden="true"
                            >↗</span>
                        </button>
                    </div>

                    <div id="ce-diagnostico" class="ce-panel">
                        <h3>Comprobación del sistema</h3>

                        <p data-ce-diagnostico-estado>
                            Consultando…
                        </p>
                    </div>

                    <details id="biz-notices">
                        <summary>
                            Detalle de actualización
                        </summary>
                    </details>
                </section>
`;

const estilos = `
/* Portada y accesos del dashboard rediseñados. */

body.erp-vista-profesional #dash-inicio .erp-hero-inicio {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    min-height: 145px;
    padding: 26px 30px;
    margin-bottom: 20px;
    overflow: hidden;
    border: 1px solid #244968;
    border-radius: 18px;
    position: relative;
    background: linear-gradient(
        115deg,
        #142b49,
        #1f4f66
    ) !important;
    box-shadow: 0 10px 28px #173b5b12;
}

body.erp-vista-profesional #dash-inicio .dash-etiqueta {
    display: block;
    color: #9ed7d2;
    font-size: 10px;
    font-weight: 750;
    letter-spacing: .16em;
    margin-bottom: 7px;
}

body.erp-vista-profesional #dash-inicio .erp-hero-inicio h2 {
    color: #fff !important;
    font-size: clamp(25px, 3vw, 34px);
    font-weight: 800;
    letter-spacing: -.035em;
    line-height: 1.2;
    margin: 0;
}

body.erp-vista-profesional #dash-inicio .erp-hero-inicio p {
    color: #d2e4ed !important;
    font-size: 13px;
    margin: 8px 0 0;
}

body.erp-vista-profesional #dash-inicio .erp-hero-inicio > i {
    color: #a5d7dc;
    font-size: 54px;
    opacity: .6;
}

body.erp-vista-profesional #dash-inicio #biz-overview {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 14px;
    margin: 0 0 24px;
}

body.erp-vista-profesional #dash-inicio #biz-overview > div {
    padding: 18px 20px;
    border: 1px solid #dee7ee;
    border-top: 3px solid #198b83;
    border-radius: 14px;
    background: linear-gradient(
        145deg,
        #fff,
        #f5fafb
    );
    box-shadow: 0 4px 14px #173b5b05;
    transform: none;
}

body.erp-vista-profesional
#dash-inicio #biz-overview > div:nth-child(2) {
    border-top-color: #4c79b6;
}

body.erp-vista-profesional
#dash-inicio #biz-overview > div:nth-child(3) {
    border-top-color: #8a68b1;
}

body.erp-vista-profesional
#dash-inicio #biz-overview > div:nth-child(4) {
    border-top-color: #b58c43;
}

body.erp-vista-profesional #dash-inicio #biz-overview p {
    margin: 0 0 9px;
    color: #62748b;
    font-size: 11px;
    font-weight: 600;
    text-transform: none;
    letter-spacing: 0;
}

body.erp-vista-profesional #dash-inicio #biz-overview strong {
    display: block;
    color: #18334c;
    font-size: clamp(20px, 2vw, 27px);
    font-weight: 750;
    font-variant-numeric: tabular-nums;
    overflow-wrap: anywhere;
}

body.erp-vista-profesional #dash-inicio .dash-titulo-area {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 0 0 12px;
}

body.erp-vista-profesional #dash-inicio .dash-titulo-area h3 {
    margin: 0;
    color: #233b52;
    font-size: 14px;
    font-weight: 750;
}

body.erp-vista-profesional #dash-inicio .dash-titulo-area > span {
    color: #789;
    font-size: 11px;
}

body.erp-vista-profesional #dash-inicio #main-menu-container {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 12px;
    margin-bottom: 22px;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container .menu-btn {
    --acento: #2678b8;
    --suave: #edf5ff;

    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 13px;
    width: 100%;
    min-height: 88px;
    padding: 18px;
    text-align: left;
    border: 1px solid #dce5ef !important;
    border-radius: 14px;
    background: #fff !important;
    color: #31485f !important;
    font: inherit;
    font-size: 13px;
    font-weight: 650;
    line-height: 1.4;
    box-shadow: 0 3px 12px #193a5c04 !important;
    transform: none !important;
    cursor: pointer;

    transition:
        background .18s,
        border-color .18s;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container [data-target="proveedores"] {
    --acento: #53718a;
    --suave: #edf3f7;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container [data-target="contabilidad"] {
    --acento: #138779;
    --suave: #eaf8f3;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container [data-target="finanzas"] {
    --acento: #6254b5;
    --suave: #f0edfc;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container [data-target="inventario"] {
    --acento: #a9782d;
    --suave: #fcf5e8;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container [data-target="rrhh"] {
    --acento: #9362a3;
    --suave: #f7edf9;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container .menu-btn > i {
    display: grid;
    place-items: center;
    flex: 0 0 44px;
    width: 44px;
    height: 44px;
    border-radius: 12px;
    margin: 0;
    color: var(--acento) !important;
    background: var(--suave);
    font-size: 22px;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container .dash-flecha {
    margin-left: auto;
    color: #94a3b8;
    font-size: 17px;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container .menu-btn:hover {
    border-color: var(--acento) !important;
    background: var(--suave) !important;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container .menu-btn:focus-visible {
    outline: 3px solid var(--acento);
    outline-offset: 3px;
}

body.erp-vista-profesional
#dash-inicio #main-menu-container .menu-btn.erp-modulo-elegido {
    background: var(--suave) !important;
    border-color: var(--acento) !important;
    color: var(--acento) !important;
}

body.erp-vista-profesional #dash-inicio #ce-diagnostico {
    margin: 0 0 12px;
    padding: 18px 20px;
    border-radius: 14px;
    box-shadow: none;
}

body.erp-vista-profesional #ce-diagnostico .ce-cabecera {
    margin-bottom: 10px;
}

body.erp-vista-profesional #ce-diagnostico h3 {
    margin: 0;
    font-size: 14px;
    color: #233b52;
}

body.erp-vista-profesional
#ce-diagnostico [data-ce-diagnostico-estado] {
    margin: 4px 0 0;
    font-size: 11px;
    color: #73849a;
}

body.erp-vista-profesional
#ce-diagnostico .dash-comprobacion-resumen {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
    margin-bottom: 10px;
}

body.erp-vista-profesional
#ce-diagnostico .dash-comprobacion-resumen span {
    padding: 5px 9px;
    border-radius: 6px;
    background: #f1f5f9;
    color: #52677e;
    font-size: 11px;
}

body.erp-vista-profesional
#ce-diagnostico .dash-comprobacion-resumen .correcto {
    background: #e9f7f1;
    color: #166448;
}

body.erp-vista-profesional
#ce-diagnostico .dash-comprobacion-resumen .revisar {
    background: #fff5dd;
    color: #8e5e0b;
}

body.erp-vista-profesional
#ce-diagnostico .dash-comprobacion-resumen .error {
    background: #fff0f2;
    color: #9b2743;
}

body.erp-vista-profesional #ce-diagnostico summary {
    font-size: 12px;
    color: #49647d;
    cursor: pointer;
    font-weight: 600;
}

body.erp-vista-profesional
#ce-diagnostico details[open] > summary {
    margin-bottom: 12px;
}

body.erp-vista-profesional
#ce-diagnostico .dash-control-estado {
    color: #64748b;
    font-size: 11px;
    font-weight: 600;
}

body.erp-vista-profesional
#ce-diagnostico[data-consulta="error"] .dash-control-estado {
    color: #9b2743;
}

body.erp-vista-profesional #dash-inicio #biz-notices {
    margin: 0;
    padding: 12px 16px;
    border: 1px solid #e0e8ef;
    border-radius: 12px;
    box-shadow: none;
    background: #f8fafc;
}

body.erp-vista-profesional #dash-inicio #biz-notices > summary {
    padding: 0;
    color: #64748b;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
}

body.erp-vista-profesional
#dash-inicio #biz-notices[data-avisos="true"] > summary {
    color: #9b2743;
}

body.erp-vista-profesional #dash-sync-detalles {
    margin: 0 0 16px;
    padding: 10px 14px;
    background: #eef8f7;
    border: 1px solid #cce5e1;
    border-radius: 10px;
    color: #27645e;
}

body.erp-vista-profesional #dash-sync-detalles > summary {
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
}

body.erp-vista-profesional
#dash-sync-detalles[data-error="true"] {
    background: #fff2f3;
    border-color: #f1c5cc;
    color: #9b2743;
}

body.erp-vista-profesional
#dash-sync-detalles #erp-estado-sincronizacion {
    margin: 8px 0 0;
    padding: 0;
    border: 0;
    background: transparent;
    color: inherit;
    box-shadow: none;
    overflow-wrap: anywhere;
}

@media (max-width: 1000px) {
    body.erp-vista-profesional #dash-inicio #biz-overview {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    body.erp-vista-profesional
    #dash-inicio #main-menu-container {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 520px) {
    body.erp-vista-profesional
    #dash-inicio #main-menu-container .menu-btn {
        min-height: 100px;
        flex-direction: column;
        justify-content: center;
        gap: 8px;
        padding: 14px 9px;
        text-align: center;
        font-size: 12px;
    }

    body.erp-vista-profesional
    #dash-inicio #main-menu-container .dash-flecha {
        display: none;
    }

    body.erp-vista-profesional
    #dash-inicio #biz-overview > div {
        padding: 14px 12px;
    }
}

`;

/*
 * Mantiene el historial completo dentro del bloque desplegable.
 * Los errores se señalan en su encabezado.
 */
function status(key, message, bad = false) {
    const bloque = $('biz-notices');

    let node = $('biz-status-' + key);

    if (!node) {
        node = document.createElement('p');
        node.id = 'biz-status-' + key;
        node.setAttribute('role', 'status');

        bloque.append(node);
    }

    node.className = 'biz-notice' + (
        bad ? ' biz-error' : ''
    );

    node.textContent = message;

    const errores = bloque.querySelectorAll(
        '.biz-error'
    ).length;

    bloque.dataset.avisos = String(errores > 0);

    bloque.querySelector('summary').textContent = errores
        ? 'Detalle de actualización · ' +
            errores + ' aviso(s)'
        : 'Detalle de actualización';
}

/*
 * Resume el estado visible de sincronización.
 * El mensaje completo permanece disponible al desplegarlo.
 */
function aviso(texto, esError = false) {
    let elemento = document.getElementById(
        'erp-estado-sincronizacion'
    );

    let bloque = document.getElementById(
        'dash-sync-detalles'
    );

    if (!bloque) {
        bloque = document.createElement('details');
        bloque.id = 'dash-sync-detalles';

        bloque.append(
            document.createElement('summary')
        );

        (
            document.getElementById('page-content') ||
            document.body
        ).prepend(bloque);
    }

    if (!elemento) {
        elemento = document.createElement('p');
        elemento.id = 'erp-estado-sincronizacion';

        elemento.setAttribute('role', 'status');
        elemento.setAttribute('aria-live', 'polite');
    }

    if (elemento.parentElement !== bloque) {
        bloque.append(elemento);
    }

    elemento.textContent = texto;

    elemento.className = 'erp-aviso' + (
        esError ? ' erp-aviso-error' : ''
    );

    bloque.dataset.error = String(esError);

    const hora = texto.match(
        /\d{1,2}:\d{2}(?::\d{2})?.*$/
    )?.[0];

    bloque.querySelector('summary').textContent = esError
        ? 'Actualización incompleta · Ver detalle'
        : texto.startsWith('Consultando')
            ? 'Actualizando datos…'
            : texto.startsWith('Datos actualizados')
                ? 'Actualizado' + (
                    hora ? ' · ' + hora : ''
                )
                : 'Estado de actualización';
}

/*
 * Presenta las comprobaciones existentes de forma compacta.
 * Conserva el alcance, las advertencias y la tabla detallada.
 */
async function cargarDiagnostico() {
    const panel = $('ce-diagnostico');

    if (!panel) return;

    const abierto = panel.querySelector(
        'details'
    )?.open || false;

    panel.setAttribute('aria-busy', 'true');

    const anterior = panel.querySelector(
        '[data-ce-diagnostico-estado]'
    );

    if (anterior) {
        anterior.textContent = 'Comprobando…';
    }

    panel.querySelector(
        '[data-ce-diagnostico-aviso]'
    )?.remove();

    try {
        const datos = await api(
            ruta + '/diagnostico'
        );

        if (
            !Array.isArray(datos.controles) ||
            !Array.isArray(datos.faltantes)
        ) {
            throw new Error(
                'Respuesta de comprobación no válida.'
            );
        }

        const etiquetas = {
            correcto: 'Sin diferencias detectadas',
            revisar: 'Por revisar',
            no_evaluado: 'Sin evaluar',
            error: 'Error de consulta'
        };

        const cantidades = {
            correcto: 0,
            revisar: 0,
            no_evaluado: 0,
            error: 0
        };

        const filas = datos.controles.map(control => {
            const estado = Object.hasOwn(
                etiquetas,
                control.estado
            )
                ? control.estado
                : 'no_evaluado';

            cantidades[estado]++;

            return (
                '<tr>' +
                    '<td>' +
                        escapar(control.nombre) +
                    '</td>' +
                    '<td>' +
                        escapar(etiquetas[estado]) +
                        (
                            control.codigo
                                ? ' · ' + escapar(control.codigo)
                                : ''
                        ) +
                    '</td>' +
                    '<td>' +
                        escapar(control.cantidad ?? '—') +
                    '</td>' +
                '</tr>'
            );
        }).join('');

        const incompleto =
            datos.faltantes.length > 0 ||
            cantidades.error > 0 ||
            cantidades.no_evaluado > 0;

        const revisar =
            incompleto ||
            cantidades.revisar > 0;

        const fecha = new Date(
            datos.generado_en
        );

        const hora = Number.isNaN(fecha.getTime())
            ? 'Hora no disponible'
            : fecha.toLocaleString('es-NI', {
                timeZone: 'America/Managua'
            });

        const estado = revisar
            ? 'Requiere revisión'
            : !datos.controles.length
                ? 'Sin comprobaciones'
                : 'Sin diferencias detectadas';

        panel.dataset.consulta = 'actualizada';

        panel.innerHTML =
            '<div class="ce-cabecera">' +
                '<div>' +
                    '<h3>Comprobación del sistema</h3>' +
                    '<p data-ce-diagnostico-estado>' +
                        escapar(hora) +
                    '</p>' +
                '</div>' +

                '<button ' +
                    'type="button" ' +
                    'class="ce-boton ce-secundario" ' +
                    'data-ce-diagnostico>' +
                    'Comprobar' +
                '</button>' +
            '</div>' +

            '<div class="dash-comprobacion-resumen">' +
                '<span class="correcto">' +
                    cantidades.correcto +
                    ' correctas' +
                '</span>' +

                '<span class="revisar">' +
                    cantidades.revisar +
                    ' por revisar' +
                '</span>' +

                '<span>' +
                    cantidades.no_evaluado +
                    ' sin evaluar' +
                '</span>' +

                '<span class="error">' +
                    cantidades.error +
                    ' errores' +
                '</span>' +

                '<strong class="dash-control-estado">' +
                    estado +
                '</strong>' +
            '</div>' +

            '<details' + (
                abierto ? ' open' : ''
            ) + '>' +
                '<summary>Ver comprobaciones</summary>' +

                '<p>' +
                    escapar(datos.alcance) +
                '</p>' +

                (
                    datos.faltantes.length
                        ? '<p class="ce-aviso ce-error">' +
                            'Estructura pendiente: ' +
                            datos.faltantes
                                .map(escapar)
                                .join(' · ') +
                          '</p>'
                        : ''
                ) +

                '<div class="ce-desplazamiento">' +
                    '<table class="ce-tabla">' +
                        '<thead>' +
                            '<tr>' +
                                '<th>Comprobación</th>' +
                                '<th>Estado</th>' +
                                '<th>Registros</th>' +
                            '</tr>' +
                        '</thead>' +

                        '<tbody>' +
                            (
                                filas ||
                                '<tr>' +
                                    '<td colspan="3">' +
                                        'No se recibieron comprobaciones.' +
                                    '</td>' +
                                '</tr>'
                            ) +
                        '</tbody>' +
                    '</table>' +
                '</div>' +

                '<p>' +
                    '<a href="/finanzas.html">' +
                        'Abrir control de caja' +
                    '</a>' +
                '</p>' +
            '</details>';

        if (incompleto) {
            throw Object.assign(
                new Error(
                    'Hay comprobaciones pendientes. ' +
                    'Revisa su detalle.'
                ),
                { mostrado: true }
            );
        }
    } catch (error) {
        if (!error.mostrado) {
            panel.dataset.consulta = 'error';

            const estado = panel.querySelector(
                '.dash-control-estado'
            );

            if (estado) {
                estado.textContent = 'Sin actualizar';
            }

            const fecha = panel.querySelector(
                '[data-ce-diagnostico-estado]'
            );

            if (fecha) {
                fecha.textContent = 'Consulta fallida';
            }

            const nota = document.createElement('p');

            nota.dataset.ceDiagnosticoAviso = '';
            nota.className = 'ce-aviso ce-error';

            nota.setAttribute('role', 'alert');

            nota.textContent =
                'No se pudo comprobar: ' +
                error.message;

            panel.prepend(nota);
        }

        throw error;
    } finally {
        panel.removeAttribute('aria-busy');
    }
}

try {
    const originales = new Map(
        rutas.map(ruta => {
            const archivo = path.join(
                raiz,
                ruta
            );

            if (!fs.existsSync(archivo)) {
                throw new Error(
                    'Falta ' + ruta +
                    '. Ejecuta este archivo desde ' +
                    'la raíz del proyecto.'
                );
            }

            return [
                ruta,
                fs.readFileSync(
                    archivo,
                    'utf8'
                )
                    .replace(/^\uFEFF/, '')
                    .replace(/\r\n/g, '\n')
            ];
        })
    );

    const aplicados = [
        ...originales.values()
    ].filter(texto => texto.includes(marca)).length;

    if (aplicados === rutas.length) {
        console.log(
            'Este rediseño ya está aplicado.'
        );

        process.exit(0);
    }

    if (aplicados) {
        throw new Error(
            'Se encontró una revisión parcial. ' +
            'Restaura el respaldo antes de aplicar nuevamente.'
        );
    }

    const nuevos = new Map(originales);

    /*
     * Rediseña únicamente el inicio del dashboard.
     * Las demás secciones permanecen en el archivo.
     */
    let html = originales.get(rutas[0]);

    html = reemplazar(
        html,
        /<section class="dash-panel" id="dash-inicio">[\s\S]*?<\/section>/,
        portada.trim(),
        'portada'
    );

    /*
     * Retira las referencias de la propuesta anterior.
     * El rediseño se incorpora a los archivos existentes.
     */
    html = html.replace(
        /[ \t]*<link\b[^>]*href=["']\/css\/dashboard-resumen\.css["'][^>]*>[ \t]*(?:\n)?/g,
        ''
    );

    html = html.replace(
        /[ \t]*<script\b[^>]*src=["']\/js\/dashboard-resumen\.js["'][^>]*><\/script>[ \t]*(?:\n)?/g,
        ''
    );

    /*
     * Conserva una sola carga de dashboard-ampliacion.js.
     */
    let primeraCarga = true;

    html = html.replace(
        /^[ \t]*<script src="\/js\/dashboard-ampliacion\.js"><\/script>[ \t]*\n/gm,
        linea => {
            if (primeraCarga) {
                primeraCarga = false;
                return '';
            }

            return linea;
        }
    );

    if (
        !html.includes(
            'src="/js/dashboard-ampliacion.js"'
        )
    ) {
        html = html.replace(
            '</body>',
            '    <script ' +
                'src="/js/dashboard-ampliacion.js">' +
            '</script>\n</body>'
        );
    }

    nuevos.set(
        rutas[0],
        '<!-- ' + marca + ' -->\n' + html
    );

    /*
     * Reemplaza los estilos anteriores del inicio.
     */
    let css = originales.get(rutas[1]);

    css = reemplazar(
        css,
        /\/\* Portada original con contraste corregido\. \*\/[\s\S]*?(?=\/\* Encabezados interiores de los módulos\. \*\/)/,
        estilos,
        'estilos del inicio'
    );

    nuevos.set(
        rutas[1],
        '/* ' + marca + ' */\n' + css
    );

    /*
     * Reutiliza el historial de actualización existente.
     */
    let negocio = funcion(
        originales.get(rutas[2]),
        'status',
        'badge',
        status
    );

    negocio = reemplazar(
        negocio,
        /const notices = document\.createElement\('details'\);/,
        "const notices = $('biz-notices') || " +
            "document.createElement('details');",
        'actividad'
    );

    negocio = reemplazar(
        negocio,
        /notices\.innerHTML = '<summary>Estado de actualización<\/summary>';/,
        "notices.innerHTML = " +
            "'<summary>Detalle de actualización</summary>';",
        'título de actividad'
    );

    nuevos.set(
        rutas[2],
        '// ' + marca + '\n' + negocio
    );

    /*
     * Rediseña la presentación de las comprobaciones.
     */
    let control = funcion(
        originales.get(rutas[3]),
        'cargarDiagnostico',
        'recargar',
        cargarDiagnostico
    );

    nuevos.set(
        rutas[3],
        '// ' + marca + '\n' + control
    );

    /*
     * Resume los mensajes de sincronización.
     */
    let sincronizacion = funcion(
        originales.get(rutas[4]),
        'aviso',
        'pintarFuentes',
        aviso
    );

    nuevos.set(
        rutas[4],
        '// ' + marca + '\n' + sincronizacion
    );

    /*
     * El inicio se muestra cuando corresponde a su ruta.
     */
    let ampliacion = originales.get(rutas[5]);

    ampliacion = reemplazar(
        ampliacion,
        /const hidden = name !== 'inicio' && name !== key;/,
        'const hidden = name !== key;',
        'visibilidad del inicio'
    );

    nuevos.set(
        rutas[5],
        '// ' + marca + '\n' + ampliacion
    );

    /*
     * Comprueba la sintaxis antes de escribir.
     */
    for (const [ruta, texto] of nuevos) {
        if (ruta.endsWith('.js')) {
            new vm.Script(texto, {
                filename: ruta
            });
        }

        if (ruta.endsWith('.html')) {
            const bloques = texto.matchAll(
                /<script\b([^>]*)>([\s\S]*?)<\/script>/gi
            );

            for (const bloque of bloques) {
                if (!/\bsrc\s*=/.test(bloque[1])) {
                    new vm.Script(bloque[2], {
                        filename: ruta
                    });
                }
            }
        }
    }

    /*
     * Guarda los archivos originales antes de aplicar.
     */
    const respaldo = path.join(
        raiz,
        'backups',
        'dashboard-' +
            new Date()
                .toISOString()
                .replace(/[:.]/g, '-')
    );

    for (const ruta of rutas) {
        const destino = path.join(
            respaldo,
            ruta
        );

        fs.mkdirSync(
            path.dirname(destino),
            { recursive: true }
        );

        fs.copyFileSync(
            path.join(raiz, ruta),
            destino
        );
    }

    /*
     * Escribe cada archivo mediante un reemplazo temporal.
     * Si ocurre un fallo, restaura los archivos ya escritos.
     */
    const escritos = [];

    try {
        for (const [ruta, texto] of nuevos) {
            const archivo = path.join(
                raiz,
                ruta
            );

            const temporal =
                archivo + '.redisenando';

            fs.writeFileSync(
                temporal,
                texto,
                'utf8'
            );

            fs.renameSync(
                temporal,
                archivo
            );

            escritos.push(ruta);
        }
    } catch (error) {
        for (const ruta of escritos.reverse()) {
            fs.copyFileSync(
                path.join(respaldo, ruta),
                path.join(raiz, ruta)
            );
        }

        throw error;
    }

    console.log(
        'Dashboard rediseñado. ' +
        'Se conservaron los módulos, formularios y consultas.'
    );

    console.log(
        'Respaldo: ' + respaldo
    );

    console.log(
        'Recarga el navegador con Ctrl + F5.'
    );
} catch (error) {
    console.error(
        'No se aplicó el rediseño: ' +
        error.message
    );

    process.exitCode = 1;
}