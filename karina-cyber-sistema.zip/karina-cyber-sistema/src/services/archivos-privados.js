'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');

const directorio = path.resolve(
    __dirname,
    '../../data/archivos_privados'
);

function clave() {
    const texto = process.env.ERP_CLAVE_DATOS || '';
    const resultado = Buffer.from(texto, 'base64');

    if (
        resultado.length !== 32 ||
        resultado.toString('base64') !== texto
    ) {
        throw Object.assign(
            new Error(
                'Configura ERP_CLAVE_DATOS con una clave ' +
                'base64 de 32 bytes.'
            ),
            { status: 503 }
        );
    }

    return resultado;
}

function cifrar(contenido) {
    const vector = crypto.randomBytes(12);

    const cifrador = crypto.createCipheriv(
        'aes-256-gcm',
        clave(),
        vector
    );

    const datos = Buffer.concat([
        cifrador.update(contenido),
        cifrador.final()
    ]);

    return Buffer.concat([
        vector,
        cifrador.getAuthTag(),
        datos
    ]);
}

function descifrar(contenido) {
    if (
        !Buffer.isBuffer(contenido) ||
        contenido.length < 28
    ) {
        throw new Error('Contenido cifrado inválido.');
    }

    const descifrador = crypto.createDecipheriv(
        'aes-256-gcm',
        clave(),
        contenido.subarray(0, 12)
    );

    descifrador.setAuthTag(
        contenido.subarray(12, 28)
    );

    return Buffer.concat([
        descifrador.update(contenido.subarray(28)),
        descifrador.final()
    ]);
}

function tipoArchivo(contenido) {
    if (
        contenido.subarray(0, 5).toString() === '%PDF-'
    ) {
        return 'application/pdf';
    }

    if (
        contenido.subarray(0, 8).equals(
            Buffer.from([
                137, 80, 78, 71, 13, 10, 26, 10
            ])
        )
    ) {
        return 'image/png';
    }

    if (
        contenido.subarray(0, 3).equals(
            Buffer.from([255, 216, 255])
        )
    ) {
        return 'image/jpeg';
    }

    if (
        contenido.length >= 12 &&
        contenido.subarray(4, 8).toString() === 'ftyp'
    ) {
        return 'video/mp4';
    }

    throw Object.assign(
        new Error(
            'El formato del archivo no está permitido.'
        ),
        { status: 400 }
    );
}

function ruta(id) {
    const formato =
        /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    if (!formato.test(id)) {
        throw Object.assign(
            new Error(
                'Identificador de archivo inválido.'
            ),
            { status: 400 }
        );
    }

    return path.join(directorio, id + '.bin');
}

async function guardar(id, contenido) {
    const cifrado = cifrar(contenido);

    await fs.mkdir(
        directorio,
        { recursive: true }
    );

    await fs.writeFile(
        ruta(id),
        cifrado,
        {
            flag: 'wx',
            mode: 0o600
        }
    );

    return crypto
        .createHash('sha256')
        .update(contenido)
        .digest('hex');
}

async function leer(id, huella) {
    const contenido = descifrar(
        await fs.readFile(ruta(id))
    );

    const actual = crypto
        .createHash('sha256')
        .update(contenido)
        .digest('hex');

    if (actual !== huella) {
        throw new Error(
            'La integridad del archivo no coincide.'
        );
    }

    return contenido;
}

async function eliminarHuerfano(id) {
    await fs.unlink(ruta(id)).catch(error => {
        if (error.code !== 'ENOENT') {
            console.error(
                '[Archivo pendiente de limpieza]',
                id,
                error.code
            );
        }
    });
}

module.exports = {
    cifrar,
    descifrar,
    tipoArchivo,
    guardar,
    leer,
    eliminarHuerfano
};