'use strict';

const crypto = require('node:crypto');
const pool = require('../db/connection');

const MIGRATION = '001_integracion_caja_ventas_recargas';

const WRITE_ROLES = new Set([
  'superadmin',
  'admin',
  'cajero'
]);

const MAX_CENTS = 9999999999n;

const contexts = new WeakMap();

// Solo se interpolan identificadores definidos aquí,
// nunca nombres de tablas o columnas enviados por el navegador.
const SOURCES = Object.freeze({
  sale: {
    table: 'sales',
    owner: 'cashier_id',
    amount: 'total',
    method: 'payment_method',
    reference: 'payment_reference',
    link: 'sale_id',
    direction: 'Entrada',
    label: 'Venta'
  },

  recarga: {
    table: 'recargas',
    owner: 'cashier_id',
    amount: 'monto',
    method: 'metodo_pago',
    reference: 'payment_reference',
    link: 'recarga_id',
    direction: 'Entrada',
    label: 'Recarga'
  },
    printing: {
    table: 'print_job_payments',
    owner: 'cashier_id',
    amount: 'amount',
    method: 'payment_method',
    reference: 'payment_reference',
    link: 'print_payment_id',
    direction: 'Entrada',
    label: 'Impresión'
  },

  expense: {
    table: 'cash_expenses',
    owner: 'user_id',
    amount: 'amount',
    method: 'payment_method',
    reference: 'payment_reference',
    link: 'expense_id',
    direction: 'Salida',
    label: 'Gasto'
  }

  
});

// ============================================================
// VALIDACIONES
// ============================================================

function fail(
  message,
  code = 'CAJA_VALIDACION',
  status = 400
) {
  const error = new Error(message);

  error.code = code;
  error.status = status;

  throw error;
}

function positiveId(value, label = 'Identificador') {
  if (
    !['number', 'string'].includes(typeof value) ||
    !/^[1-9]\d{0,9}$/.test(String(value))
  ) {
    fail(`${label}: identificador inválido.`);
  }

  const result = Number(value);

  if (
    !Number.isInteger(result) ||
    result > 2147483647
  ) {
    fail(`${label}: identificador inválido.`);
  }

  return result;
}

// Importe decimal exacto.
// No redondea silenciosamente entradas inválidas.
function toCents(
  value,
  { allowZero = false } = {}
) {
  if (!['number', 'string'].includes(typeof value)) {
    fail('Indica un importe válido.');
  }

  const input = String(value).trim();

  if (!/^\d{1,8}(?:\.\d{1,2})?$/.test(input)) {
    fail(
      'El importe debe ser positivo y tener hasta dos decimales.'
    );
  }

  const [whole, fraction = ''] = input.split('.');

  const cents =
    BigInt(whole) * 100n +
    BigInt(fraction.padEnd(2, '0'));

  if (
    cents > MAX_CENTS ||
    (!allowZero && cents === 0n)
  ) {
    fail(
      'El importe debe estar entre 0.01 y 99,999,999.99.'
    );
  }

  return cents;
}

function fromCents(value) {
  if (typeof value !== 'bigint') {
    fail(
      'El cálculo monetario requiere centavos enteros.',
      'CAJA_PROGRAMACION',
      500
    );
  }

  const sign = value < 0n ? '-' : '';
  const absolute = value < 0n ? -value : value;

  const whole = absolute / 100n;
  const fraction = String(absolute % 100n).padStart(2, '0');

  return `${sign}${whole}.${fraction}`;
}

function money(value, options) {
  return fromCents(toCents(value, options));
}

function paymentMethod(value) {
  if (typeof value !== 'string') {
    fail('Selecciona el método de pago.');
  }

  const method = value.trim().toLowerCase();

  if (
    !['efectivo', 'tarjeta', 'transferencia'].includes(method)
  ) {
    fail(
      'El método debe ser efectivo, tarjeta o transferencia.'
    );
  }

  return method;
}

function paymentReference(value, method) {
  method = paymentMethod(method);

  if (value == null) {
    value = '';
  }

  if (typeof value !== 'string') {
    fail('La referencia de pago es inválida.');
  }

  const reference = value.trim();

  if (
    reference.length > 120 ||
    /[\u0000-\u001f\u007f]/.test(reference)
  ) {
    fail(
      'La referencia debe tener hasta 120 caracteres, ' +
      'sin saltos de línea.'
    );
  }

  if (method !== 'efectivo' && !reference) {
    fail(
      'Indica la referencia del comprobante o autorización del pago.'
    );
  }

  // Guardar la referencia, nunca el número completo
  // de tarjeta ni el CVV.
  return reference || null;
}

function requestKey(value) {
  const pattern =
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

  if (
    typeof value !== 'string' ||
    !pattern.test(value)
  ) {
    fail(
      'La operación necesita una clave UUID v4 válida.'
    );
  }

  return value.toLowerCase();
}

// Genera una representación estable del contenido.
// Cambiar el orden de las propiedades no cambia el hash.
function canonical(value, depth = 0) {
  if (depth > 12) {
    fail('La solicitud es demasiado compleja.');
  }

  if (value === null) {
    return 'null';
  }

  if (
    typeof value === 'string' ||
    typeof value === 'boolean'
  ) {
    return JSON.stringify(value);
  }

  if (
    typeof value === 'number' &&
    Number.isFinite(value)
  ) {
    return JSON.stringify(value);
  }

  if (Array.isArray(value)) {
    if (value.length > 500) {
      fail('La solicitud contiene demasiados elementos.');
    }

    return (
      '[' +
      value
        .map(item => canonical(item, depth + 1))
        .join(',') +
      ']'
    );
  }

  if (
    value &&
    Object.getPrototypeOf(value) === Object.prototype
  ) {
    return (
      '{' +
      Object.keys(value)
        .sort()
        .map(key => {
          return (
            JSON.stringify(key) +
            ':' +
            canonical(value[key], depth + 1)
          );
        })
        .join(',') +
      '}'
    );
  }

  fail('La solicitud contiene un valor no admitido.');
}

function stateOf(context) {
  const state = contexts.get(context);

  if (!state) {
    fail(
      'Utiliza estas funciones dentro de withCashTransaction().',
      'CAJA_TRANSACCION',
      500
    );
  }

  return state;
}

// ============================================================
// TRANSACCIÓN COMPARTIDA
// ============================================================

// La ruta usa context.db para TODAS las consultas de la operación.
//
// Dentro de work:
// - Ejecutar las consultas secuencialmente con await.
// - No ejecutar COMMIT, ROLLBACK ni release.
// - No efectuar llamadas a operadoras, bancos o redes sociales.
// - Dejar que los errores se propaguen para revertir la operación.
//
// La identidad se recibe de req.user.id, nunca del cuerpo enviado
// por el navegador.
async function withCashTransaction(userId, work) {
  userId = positiveId(userId, 'Usuario');

  if (typeof work !== 'function') {
    fail(
      'Falta la operación de caja.',
      'CAJA_PROGRAMACION',
      500
    );
  }

  let db;

  try {
    db = await pool.connect();
  } catch (cause) {
    const error = new Error(
      'No se pudo conectar con la base de datos.'
    );

    error.code = 'CAJA_BD_NO_DISPONIBLE';
    error.status = 503;
    error.cause = cause;

    throw error;
  }

  let context;
  let committing = false;
  let discard;

  try {
    await db.query(
      'BEGIN ISOLATION LEVEL READ COMMITTED'
    );

    await db.query(
      "SET LOCAL lock_timeout = '5s'"
    );

    await db.query(
      "SET LOCAL statement_timeout = '30s'"
    );

    await db.query(
      "SET LOCAL idle_in_transaction_session_timeout = '30s'"
    );

    // Las fechas nuevas sin zona se escribirán en UTC.
    // No convierte ni reinterpreta las fechas históricas.
    await db.query(
      "SET LOCAL TIME ZONE 'UTC'"
    );

    const migration = await db.query(
      `
      SELECT version
      FROM public.kc_schema_migrations
      WHERE version = $1
      `,
      [MIGRATION]
    );

    if (!migration.rows.length) {
      fail(
        'Aplica primero la migración 001 de caja.',
        'CAJA_MIGRACION_PENDIENTE',
        503
      );
    }

    // Mantiene estable el estado y rol del usuario mientras
    // se completa esta operación.
    const userResult = await db.query(
      `
      SELECT
        id,
        username,
        full_name,
        role,
        active
      FROM public.users
      WHERE id = $1
      FOR SHARE
      `,
      [userId]
    );

    const user = userResult.rows[0];

    if (
      !user ||
      user.active !== true ||
      !WRITE_ROLES.has(user.role)
    ) {
      fail(
        'Tu usuario no tiene permiso para registrar operaciones de caja.',
        'CAJA_SIN_PERMISO',
        403
      );
    }

    context = Object.freeze({
      db,
      user: Object.freeze(user)
    });

    contexts.set(context, {
      request: null,
      shift: null
    });

    const result = await work(context);

    committing = true;

    const committed = await db.query('COMMIT');

    committing = false;

    // Si algún código atrapó un error SQL sin propagarlo,
    // PostgreSQL puede terminar revirtiendo la transacción.
    if (committed.command !== 'COMMIT') {
      fail(
        'La transacción fue revertida y no se confirmó.',
        'CAJA_NO_CONFIRMADA',
        409
      );
    }

    return result;
  } catch (error) {
    if (committing) {
      discard = error;
    }

    try {
      await db.query('ROLLBACK');
    } catch (rollbackError) {
      discard = rollbackError;
    }

    // Si la conexión falla durante COMMIT, no podemos afirmar
    // si el servidor llegó a confirmar la operación.
    // El cliente debe conservar su misma clave al reintentar.
    if (committing) {
      const uncertain = new Error(
        'No se pudo confirmar la respuesta de la base de datos. ' +
        'Consulta o reintenta usando la misma clave de operación.'
      );

      uncertain.code = 'CAJA_RESULTADO_INCIERTO';
      uncertain.status = 503;
      uncertain.cause = error;

      throw uncertain;
    }

    if (
      ['55P03', '57014', '40P01', '40001'].includes(error.code)
    ) {
      const busy = new Error(
        'La operación está ocupada. ' +
        'Reintenta conservando la misma clave.'
      );

      busy.code = 'CAJA_REINTENTAR';
      busy.status = 409;
      busy.cause = error;

      throw busy;
    }

    if (['42P01', '42703'].includes(error.code)) {
      const schema = new Error(
        'La estructura de caja está incompleta. ' +
        'Revisa la migración 001.'
      );

      schema.code = 'CAJA_ESQUEMA_INCOMPLETO';
      schema.status = 503;
      schema.cause = error;

      throw schema;
    }

    throw error;
  } finally {
    if (context) {
      contexts.delete(context);
    }

    db.release(discard);
  }
}

// ============================================================
// CONTROL DE SOLICITUDES REPETIDAS
// ============================================================

// Orden obligatorio:
// 1. prepareRequest()
// 2. Si replayed === true, devolver la operación existente.
// 3. Si es nueva, lockOpenShift().
// 4. Guardar el documento y su movimiento.
//
// payload debe contener los datos validados y normalizados
// por la ruta, incluyendo los campos que definen la operación.
async function prepareRequest(
  context,
  { scope, key, payload }
) {
  const state = stateOf(context);

  if (state.request || state.shift) {
    fail(
      'Prepara una única solicitud antes de bloquear el turno.',
      'CAJA_PROGRAMACION',
      500
    );
  }

  const source = Object.hasOwn(SOURCES, scope)
    ? SOURCES[scope]
    : null;

  if (
    !source &&
    !['open', 'close'].includes(scope)
  ) {
    fail('Tipo de operación no admitido.');
  }

  key = requestKey(key);

  const content = canonical({
    scope,
    userId: context.user.id,
    payload
  });

  if (Buffer.byteLength(content, 'utf8') > 65536) {
    fail('La solicitud supera el tamaño permitido.');
  }

  const hash = crypto
    .createHash('sha256')
    .update(content)
    .digest('hex');

  const lock = crypto
    .createHash('sha256')
    .update(`kc:cash:${scope}:${key}`)
    .digest();

  // Serializa las solicitudes concurrentes con la misma clave.
  // PostgreSQL libera este bloqueo al terminar la transacción.
  await context.db.query(
    `
    SELECT pg_advisory_xact_lock(
      $1::int,
      $2::int
    )
    `,
    [
      lock.readInt32BE(0),
      lock.readInt32BE(4)
    ]
  );

  const table = source
    ? source.table
    : 'cash_shifts';

  const keyColumn = scope === 'close'
    ? 'close_request_key'
    : 'request_key';

  const hashColumn = scope === 'close'
    ? 'close_request_hash'
    : 'request_hash';

  const ownerColumn = source
    ? source.owner
    : scope === 'close'
      ? 'closed_by'
      : 'cashier_id';

  const result = await context.db.query(
    `
    SELECT *
    FROM public.${table}
    WHERE ${keyColumn} = $1
    `,
    [key]
  );

  const record = result.rows[0] || null;

  if (
    record &&
    (
      Number(record[ownerColumn]) !== context.user.id ||
      record[hashColumn] !== hash
    )
  ) {
    fail(
      'Esta clave ya se utilizó para una operación diferente.',
      'CAJA_CLAVE_REUTILIZADA',
      409
    );
  }

  state.request = Object.freeze({
    scope,
    key,
    hash,
    replayed: Boolean(record)
  });

  return {
    ...state.request,
    record
  };
}

// ============================================================
// BLOQUEO DEL TURNO
// ============================================================

// Solo opera sobre el turno del usuario autenticado.
// El cierre debe utilizar este mismo bloqueo.
//
// Así, cuando las rutas estén integradas, un cobro y un cierre
// del mismo turno no podrán ejecutarse simultáneamente.
async function lockOpenShift(
  context,
  shiftId = null
) {
  const state = stateOf(context);

  if (
    !state.request ||
    state.request.replayed
  ) {
    fail(
      'Prepara una solicitud nueva antes de bloquear el turno.',
      'CAJA_PROGRAMACION',
      500
    );
  }

  if (shiftId != null) {
    shiftId = positiveId(shiftId, 'Turno');
  }

  if (state.shift) {
    if (
      shiftId != null &&
      state.shift.id !== shiftId
    ) {
      fail(
        'No mezcles turnos en una misma operación.',
        'CAJA_PROGRAMACION',
        500
      );
    }

    return state.shift;
  }

  const result = await context.db.query(
    `
    SELECT *
    FROM public.cash_shifts
    WHERE cashier_id = $1
      AND LOWER(BTRIM(status)) = 'abierto'
      AND (
        $2::int IS NULL
        OR id = $2
      )
    ORDER BY id
    LIMIT 2
    FOR UPDATE
    `,
    [
      context.user.id,
      shiftId
    ]
  );

  const rows = result.rows;

  if (rows.length === 0) {
    fail(
      'Necesitas un turno de caja abierto.',
      'CAJA_TURNO_NO_ABIERTO',
      409
    );
  }

  if (
    rows.length !== 1 ||
    rows[0].closed_at != null
  ) {
    fail(
      'El turno tiene información inconsistente. Revisa su historial.',
      'CAJA_TURNO_INCONSISTENTE',
      409
    );
  }

  money(
    rows[0].opening_amount,
    { allowZero: true }
  );

  state.shift = Object.freeze(rows[0]);

  return state.shift;
}

// ============================================================
// REGISTRO DEL MOVIMIENTO Y AUDITORÍA
// ============================================================

// El documento de origen debe haberse insertado con:
// - context.db
// - request_key
// - request_hash
//
// Todo dentro de esta misma transacción.
//
// El importe, método de pago, usuario y turno se leen del
// documento guardado; no se toman nuevamente del navegador.
async function recordMovement(
  context,
  { sourceId }
) {
  const state = stateOf(context);
  const request = state.request;

  const source =
    request && Object.hasOwn(SOURCES, request.scope)
      ? SOURCES[request.scope]
      : null;

  if (
    !source ||
    request.replayed ||
    !state.shift
  ) {
    fail(
      'Falta preparar la operación y bloquear su turno.',
      'CAJA_PROGRAMACION',
      500
    );
  }

  sourceId = positiveId(sourceId, 'Documento');

  const documentResult = await context.db.query(
    `
    SELECT
      id,
      shift_id,
      ${source.owner} AS actor_id,
      ${source.amount} AS amount,
      ${source.method} AS method,
      ${source.reference} AS reference,
      request_key,
      request_hash
    FROM public.${source.table}
    WHERE id = $1
    FOR UPDATE
    `,
    [sourceId]
  );

  const document = documentResult.rows[0];

  if (
    !document ||
    Number(document.shift_id) !== state.shift.id ||
    Number(document.actor_id) !== context.user.id ||
    document.request_key !== request.key ||
    document.request_hash !== request.hash
  ) {
    fail(
      'El documento no corresponde al turno, usuario o solicitud.',
      'CAJA_DOCUMENTO_INCONSISTENTE',
      409
    );
  }

  const amount = money(document.amount);
  const method = paymentMethod(document.method);

  const reference = paymentReference(
    document.reference,
    method
  );

  const previousResult = await context.db.query(
    `
    SELECT *
    FROM public.caja
    WHERE ${source.link} = $1
       OR request_key = $2
    FOR UPDATE
    `,
    [
      sourceId,
      request.key
    ]
  );

  const previous = previousResult.rows;

  // Permite reconocer una segunda llamada interna al mismo
  // registro sin generar otro movimiento.
  if (previous.length) {
    const row = previous[0];

    if (
      previous.length !== 1 ||
      Number(row[source.link]) !== sourceId ||
      Number(row.shift_id) !== state.shift.id ||
      Number(row.user_id) !== context.user.id ||
      row.request_key !== request.key ||
      row.registrado_en == null ||
      row.tip !== source.direction ||
      money(row.mon) !== amount ||
      paymentMethod(row.metodo_pago) !== method ||
      paymentReference(row.referencia_pago, method) !== reference
    ) {
      fail(
        'Existe un movimiento incompatible con este documento.',
        'CAJA_MOVIMIENTO_INCONSISTENTE',
        409
      );
    }

    return {
      movement: row,
      replayed: true
    };
  }

    const links = {
    sale_id: null,
    recarga_id: null,
    expense_id: null,
    print_payment_id: null
  };

  links[source.link] = sourceId;

  const movementResult = await context.db.query(
    `
    INSERT INTO public.caja (
      fec,
      con,
      tip,
      mon,
      metodo_pago,
      shift_id,
      user_id,
      sale_id,
      recarga_id,
      expense_id,
      print_payment_id,
      referencia_pago,
      registrado_en,
      request_key
    )
    VALUES (
      (
        clock_timestamp()
        AT TIME ZONE 'America/Managua'
      )::date,
      $1,
      $2,
      $3,
      $4,
      $5,
      $6,
      $7,
      $8,
      $9,
      $10,
      $11,
      clock_timestamp(),
      $12
    )
    RETURNING *
    `,
    [
      `${source.label} #${sourceId}`,
      source.direction,
      amount,
      method,
      state.shift.id,
      context.user.id,
      links.sale_id,
      links.recarga_id,
      links.expense_id,
      links.print_payment_id,
      reference,
      request.key
    ]
  );

  const movement = movementResult.rows[0];

  // Si falla la auditoría, el error se propaga y se revierte
  // también el movimiento y el documento de origen.
  await context.db.query(
    `
    INSERT INTO public.audit_log (
      user_id,
      action,
      entity,
      details
    )
    VALUES (
      $1,
      $2,
      'caja',
      $3
    )
    `,
    [
      context.user.id,

      source.direction === 'Entrada'
        ? 'CAJA_ENTRADA'
        : 'CAJA_SALIDA',

      JSON.stringify({
        movement_id: movement.id,
        shift_id: state.shift.id,
        source: request.scope,
        source_id: sourceId,
        amount,
        payment_method: method,
        request_key: request.key
      })
    ]
  );

  return {
    movement,
    replayed: false
  };
}

// ============================================================
// EXPORTACIONES
// ============================================================

module.exports = {
  withCashTransaction,
  prepareRequest,
  lockOpenShift,
  recordMovement,
  positiveId,
  toCents,
  fromCents,
  money,
  paymentMethod,
  paymentReference,
  requestKey
};