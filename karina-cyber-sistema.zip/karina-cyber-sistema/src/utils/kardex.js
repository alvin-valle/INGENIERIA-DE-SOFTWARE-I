'use strict';

// Kardex por costo promedio ponderado.
// db debe ser el cliente obtenido con pool.connect(), después de BEGIN.
// La ruta que llama estas funciones conserva COMMIT, ROLLBACK y release().
// Ejecuta los movimientos de una misma transacción uno por uno, con await.

function fail(message, code = 'KARDEX_VALIDACION', status = 400) {
  const error = new Error(message);
  error.code = code;
  error.status = status;
  throw error;
}

function number(value, label) {
  if (
    !['number', 'string'].includes(typeof value) ||
    (typeof value === 'string' && !value.trim())
  ) {
    fail(`${label}: indica un número válido.`);
  }

  const result = Number(value);

  if (!Number.isFinite(result)) {
    fail(`${label}: indica un número finito.`);
  }

  return result;
}

function rounded(value, decimals) {
  const n = number(value, 'Valor');

  const [base, exponent = '0'] = Math.abs(n)
    .toString()
    .split('e');

  const shifted = Number(
    `${base}e${Number(exponent) + decimals}`
  );

  const integer = Math.round(shifted);

  if (!Number.isSafeInteger(integer)) {
    fail(
      'El número es demasiado grande para calcularlo con precisión.'
    );
  }

  const result = Number(`${integer}e-${decimals}`);

  return result === 0
    ? 0
    : Math.sign(n) * result;
}

function round2(value) {
  return rounded(value, 2);
}

function positiveId(value, label) {
  const id = number(value, label);

  if (
    !Number.isInteger(id) ||
    id < 1 ||
    id > 2147483647
  ) {
    fail(`${label}: identificador inválido.`);
  }

  return id;
}

function movementData(options = {}) {
  const productId = positiveId(
    options.productId,
    'Producto'
  );

  const qty = number(options.qty, 'Cantidad');

  if (qty <= 0 || rounded(qty, 6) !== qty) {
    fail(
      'La cantidad debe ser mayor que cero y tener hasta seis decimales.'
    );
  }

  const userId = options.userId == null
    ? null
    : positiveId(options.userId, 'Usuario');

  const reference = options.reference == null
    ? null
    : String(options.reference).trim() || null;

  if (reference && reference.length > 100) {
    fail(
      'La referencia no puede superar 100 caracteres.'
    );
  }

  return {
    productId,
    qty,
    userId,
    reference
  };
}

async function movementTransaction(db, operation) {
  if (
    !db ||
    typeof db.query !== 'function' ||
    typeof db.release !== 'function'
  ) {
    fail(
      'Kardex requiere un cliente de pool.connect() con BEGIN.',
      'KARDEX_TRANSACCION',
      500
    );
  }

  try {
    // SAVEPOINT exige una transacción activa.
    // No confirma la venta completa.
    await db.query(
      'SAVEPOINT kc_kardex_movimiento'
    );
  } catch (error) {
    if (error.code === '25P01') {
      fail(
        'Ejecuta BEGIN antes de registrar movimientos de Kardex.',
        'KARDEX_TRANSACCION',
        500
      );
    }

    throw error;
  }

  try {
    const result = await operation();

    await db.query(
      'RELEASE SAVEPOINT kc_kardex_movimiento'
    );

    return result;
  } catch (error) {
    try {
      await db.query(
        'ROLLBACK TO SAVEPOINT kc_kardex_movimiento'
      );

      await db.query(
        'RELEASE SAVEPOINT kc_kardex_movimiento'
      );
    } catch (rollbackError) {
      error.rollbackError = rollbackError;
    }

    throw error;
  }
}

async function lockedProduct(db, productId) {
  const result = await db.query(
    `
    SELECT id, name, unit, stock, avg_cost
    FROM public.products
    WHERE id = $1
    FOR UPDATE
    `,
    [productId]
  );

  const product = result.rows[0];

  if (!product) {
    fail(
      'Producto no encontrado.',
      'PRODUCTO_NO_ENCONTRADO',
      404
    );
  }

  product.stock = number(
    product.stock,
    'Existencias del producto'
  );

  product.avg_cost = number(
    product.avg_cost,
    'Costo promedio del producto'
  );

  if (product.avg_cost < 0) {
    fail(
      'El producto tiene un costo promedio negativo.'
    );
  }

  return product;
}

function checkStored(row, expected) {
  for (const [column, value] of Object.entries(expected)) {
    if (
      !row ||
      row[column] == null ||
      Number(row[column]) !== value
    ) {
      fail(
        'La base de datos redondeó o modificó una cantidad o costo. ' +
        'Revisa los tipos de las columnas de products y kardex_movements.',
        'KARDEX_PRECISION',
        409
      );
    }
  }
}

async function insertMovement(
  db,
  data,
  type,
  unitCost,
  newStock,
  newAvg
) {
  const result = await db.query(
    `
    INSERT INTO public.kardex_movements (
      product_id,
      type,
      qty,
      unit_cost,
      balance_qty,
      balance_avg_cost,
      reference,
      user_id
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    RETURNING
      id,
      qty,
      unit_cost,
      balance_qty,
      balance_avg_cost
    `,
    [
      data.productId,
      type,
      data.qty,
      unitCost,
      newStock,
      newAvg,
      data.reference,
      data.userId
    ]
  );

  checkStored(result.rows[0], {
    qty: data.qty,
    unit_cost: unitCost,
    balance_qty: newStock,
    balance_avg_cost: newAvg
  });

  return result.rows[0].id;
}

// Registra una compra o entrada y recalcula el costo promedio.
async function recordEntrada(db, options = {}) {
  const data = movementData(options);

  const rawCost = number(
    options.unitCost,
    'Costo unitario'
  );

  if (rawCost < 0) {
    fail(
      'El costo unitario no puede ser negativo.'
    );
  }

  const unitCost = round2(rawCost);

  return movementTransaction(db, async () => {
    const product = await lockedProduct(
      db,
      data.productId
    );

    const newStock = rounded(
      product.stock + data.qty,
      6
    );

    const newAvg = newStock > 0
      ? round2(
          (
            product.stock * product.avg_cost +
            data.qty * unitCost
          ) / newStock
        )
      : 0;

    if (newAvg < 0) {
      fail(
        'Revisa el saldo negativo del producto antes de recalcular su costo.'
      );
    }

    const result = await db.query(
      `
      UPDATE public.products
      SET stock = $1, avg_cost = $2
      WHERE id = $3
      RETURNING stock, avg_cost
      `,
      [newStock, newAvg, data.productId]
    );

    checkStored(result.rows[0], {
      stock: newStock,
      avg_cost: newAvg
    });

    const movementId = await insertMovement(
      db,
      data,
      'entrada',
      unitCost,
      newStock,
      newAvg
    );

    return {
      newStock,
      newAvg,
      movementId
    };
  });
}

// Registra una venta o consumo conservando el costo promedio.
async function recordSalida(db, options = {}) {
  const data = movementData(options);

  const allowNegative = options.allowNegative ?? false;

  if (typeof allowNegative !== 'boolean') {
    fail(
      'allowNegative debe ser true o false.'
    );
  }

  return movementTransaction(db, async () => {
    const product = await lockedProduct(
      db,
      data.productId
    );

    if (!allowNegative && product.stock < data.qty) {
      fail(
        `Stock insuficiente para "${product.name}" ` +
        `(disponible: ${product.stock} ${product.unit || 'unidad'}).`,
        'STOCK_INSUFICIENTE',
        409
      );
    }

    const newStock = rounded(
      product.stock - data.qty,
      6
    );

    const unitCost = product.avg_cost;

    const result = await db.query(
      `
      UPDATE public.products
      SET stock = $1
      WHERE id = $2
      RETURNING stock, avg_cost
      `,
      [newStock, data.productId]
    );

    checkStored(result.rows[0], {
      stock: newStock,
      avg_cost: unitCost
    });

    const movementId = await insertMovement(
      db,
      data,
      'salida',
      unitCost,
      newStock,
      unitCost
    );

    return {
      newStock,
      unitCost,
      movementId
    };
  });
}

module.exports = {
  recordEntrada,
  recordSalida,
  round2
};