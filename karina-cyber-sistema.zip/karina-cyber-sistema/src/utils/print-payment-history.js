'use strict';

/**
 * Consulta y evalúa los pagos de impresiones.
 *
 * Solo realiza lecturas.
 * No completa hashes históricos.
 * No crea pagos ni movimientos de caja.
 */

const READ_ALL_ROLES = new Set([
  'superadmin',
  'admin',
  'auditor',
  'invitado'
]);

function sameIdentifier(first, second) {
  return (
    first != null &&
    second != null &&
    String(first) === String(second)
  );
}

function normalize(value) {
  return String(value ?? '').trim().toLowerCase();
}

function normalizeReference(value) {
  return String(value ?? '').trim();
}

/**
 * Evalúa un pago y sus movimientos de caja.
 *
 * Las diferencias se presentan como pendientes de conciliación.
 * Nunca se corrigen automáticamente.
 */
function summarize(row) {
  if (row.restricted) {
    return {
      status: 'restricted'
    };
  }

  const issues = new Set();

  const movements = Array.isArray(row.movements)
    ? row.movements
    : [];

  const amount = Number(row.amount);
  const method = normalize(row.payment_method);

  if (movements.length === 0) {
    issues.add('Sin movimiento de caja');
  }

  if (movements.length > 1) {
    issues.add('Múltiples movimientos de caja');
  }

  if (!/^[0-9a-f]{64}$/.test(row.request_hash || '')) {
    issues.add('Hash de solicitud ausente o inválido');
  }

  if (!row.request_key) {
    issues.add('Clave de solicitud ausente');
  }

  if (!Number.isFinite(amount) || amount <= 0) {
    issues.add('Importe de pago inválido');
  }

  if (
    ![
      'efectivo',
      'tarjeta',
      'transferencia'
    ].includes(method)
  ) {
    issues.add('Método de pago inválido');
  }

  if (
    ['tarjeta', 'transferencia'].includes(method) &&
    !normalizeReference(row.payment_reference)
  ) {
    issues.add('Referencia de pago ausente');
  }

  if (
    !sameIdentifier(
      row.shift_cashier_id,
      row.cashier_id
    )
  ) {
    issues.add('Cajero del turno diferente');
  }

  for (const movement of movements) {
    if (
      !sameIdentifier(
        movement.shift_id,
        row.shift_id
      )
    ) {
      issues.add('Turno diferente');
    }

    if (
      !sameIdentifier(
        movement.user_id,
        row.cashier_id
      )
    ) {
      issues.add('Cajero diferente');
    }

    const movementAmount = Number(movement.mon);

    if (
      movement.mon == null ||
      !Number.isFinite(movementAmount) ||
      movementAmount !== amount
    ) {
      issues.add('Importe diferente');
    }

    if (
      normalize(movement.metodo_pago) !== method
    ) {
      issues.add('Método diferente');
    }

    if (
      normalizeReference(movement.referencia_pago) !==
      normalizeReference(row.payment_reference)
    ) {
      issues.add('Referencia diferente');
    }

    if (
      !sameIdentifier(
        movement.request_key,
        row.request_key
      )
    ) {
      issues.add('Clave de solicitud diferente');
    }

    if (movement.tip !== 'Entrada') {
      issues.add('Tipo de movimiento diferente');
    }

    if (!movement.registrado_en) {
      issues.add('Fecha de movimiento ausente');
    }

    const documentLinks = [
      movement.sale_id,
      movement.recarga_id,
      movement.print_payment_id,
      movement.expense_id
    ];

    const linkedDocuments = documentLinks.filter(
      value => value != null
    ).length;

    if (linkedDocuments !== 1) {
      issues.add('Enlaces de movimiento inconsistentes');
    }
  }

  const reconciled = issues.size === 0;

  return {
    id: row.id,
    print_job_id: row.print_job_id,

    amount: row.amount,
    payment_method: row.payment_method,
    payment_reference: row.payment_reference,
    paid_at: row.paid_at,

    cashier_id: row.cashier_id,
    cashier_name: row.cashier_name,
    shift_id: row.shift_id,

    reconciled,

    status: reconciled
      ? 'reconciled'
      : 'pending_reconciliation',

    issues: [...issues]
  };
}

/**
 * Consulta todos los pagos de una página del historial
 * mediante una sola consulta.
 *
 * Conserva el alcance de lectura existente:
 * el cajero consulta los detalles de sus propios pagos.
 */
async function readPayments(db, jobIds, user) {
  if (!jobIds.length) {
    return new Map();
  }

  const canReadAll = READ_ALL_ROLES.has(user.role);

  const result = await db.query(
    `
    SELECT
      p.*,

      u.full_name AS cashier_name,

      s.cashier_id AS shift_cashier_id,

      NOT (
        $2::boolean
        OR p.cashier_id = $3
      ) AS restricted,

      COALESCE(
        (
          SELECT jsonb_agg(
            jsonb_build_object(
              'shift_id',
              c.shift_id,

              'user_id',
              c.user_id,

              'mon',
              c.mon::text,

              'metodo_pago',
              c.metodo_pago,

              'referencia_pago',
              c.referencia_pago,

              'request_key',
              c.request_key,

              'tip',
              c.tip,

              'registrado_en',
              c.registrado_en,

              'sale_id',
              c.sale_id,

              'recarga_id',
              c.recarga_id,

              'print_payment_id',
              c.print_payment_id,

              'expense_id',
              c.expense_id
            )
          )

          FROM public.caja c

          WHERE c.print_payment_id = p.id
        ),

        '[]'::jsonb
      ) AS movements

    FROM public.print_job_payments p

    LEFT JOIN public.users u
      ON u.id = p.cashier_id

    LEFT JOIN public.cash_shifts s
      ON s.id = p.shift_id

    WHERE p.print_job_id = ANY($1::bigint[])
    `,
    [
      jobIds,
      canReadAll,
      user.id
    ]
  );

  return new Map(
    result.rows.map(row => [
      String(row.print_job_id),
      summarize(row)
    ])
  );
}

module.exports = {
  summarize,
  readPayments
};