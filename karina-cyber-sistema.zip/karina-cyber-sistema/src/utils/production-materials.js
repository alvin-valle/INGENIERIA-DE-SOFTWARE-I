'use strict';

const { recordSalida } = require('./kardex');

const BASES = ['hoja', 'cara', 'ejemplar', 'orden'];
const SCALE = 1000000n;
const MAX_SCALED = BigInt(Number.MAX_SAFE_INTEGER);

function fail(message, status = 400) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function positiveInteger(value, label, max = 2147483647) {
  if (
    !['string', 'number'].includes(typeof value) ||
    !/^\d+$/.test(String(value))
  ) {
    fail(label + ': entero positivo requerido.');
  }

  const n = Number(value);

  if (!Number.isSafeInteger(n) || n < 1 || n > max) {
    fail(label + ': fuera del límite.');
  }

  return n;
}

// Cálculos exactos con seis decimales.
// No redondea consumos silenciosamente.
function micros(value) {
  if (!['string', 'number'].includes(typeof value)) {
    fail('Cantidad de material inválida.');
  }

  const s = String(value).trim();

  if (!/^\d{1,12}(\.\d{1,6})?$/.test(s)) {
    fail(
      'La cantidad debe ser positiva y tener hasta seis decimales.'
    );
  }

  const [whole, decimals = ''] = s.split('.');

  const n =
    BigInt(whole) * SCALE +
    BigInt(decimals.padEnd(6, '0'));

  if (n <= 0n || n > MAX_SCALED) {
    fail('Cantidad fuera del límite de precisión.');
  }

  return n;
}

function decimal(n) {
  if (n <= 0n || n > MAX_SCALED) {
    fail('El consumo supera el límite de precisión.');
  }

  return (
    String(n / SCALE) +
    '.' +
    String(n % SCALE).padStart(6, '0')
  );
}

function kardexQuantity(value) {
  const exact = micros(value);
  const n = Number(decimal(exact));

  if (micros(n) !== exact) {
    fail(
      'La cantidad pierde precisión al enviarla al Kardex.'
    );
  }

  return n;
}

// qty_per_unit se expresa en la unidad del producto de inventario.
// Ejemplo: si el papel se controla por resma de 500 hojas,
// usar 0.002 por hoja.
function normalizeRules(rules) {
  if (!Array.isArray(rules) || rules.length > 50) {
    fail('Envía una lista de hasta 50 materiales.');
  }

  const seen = new Set();

  return rules
    .map(rule => {
      if (!rule || typeof rule !== 'object') {
        fail('Material inválido.');
      }

      const product_id = positiveInteger(
        rule.product_id,
        'Producto'
      );

      if (seen.has(product_id)) {
        fail('Hay un producto repetido en los materiales.');
      }

      seen.add(product_id);

      if (!BASES.includes(rule.basis)) {
        fail(
          'Base inválida: hoja, cara, ejemplar u orden.'
        );
      }

      return {
        product_id,
        basis: rule.basis,
        qty_per_unit: decimal(micros(rule.qty_per_unit))
      };
    })
    .sort((a, b) => a.product_id - b.product_id);
}

function calculateMaterials(rules, details) {
  const normalized = normalizeRules(rules);

  if (!details || typeof details !== 'object') {
    fail(
      'La orden no tiene configuración de producción.',
      409
    );
  }

  const pages = positiveInteger(
    details.pages,
    'Páginas',
    100000
  );

  const copies = positiveInteger(
    details.copies,
    'Ejemplares',
    100000
  );

  const sides = positiveInteger(
    details.sides,
    'Caras por hoja',
    2
  );

  const printable = [
    'Impresión',
    'Fotocopia'
  ].includes(details.service);

  const counts = {
    // Cada ejemplar impar requiere su propia última hoja.
    hoja: printable
      ? Math.ceil(pages / sides) * copies
      : null,

    cara: pages * copies,
    ejemplar: copies,
    orden: 1
  };

  const metadata = new Map(
    rules.map(rule => [
      Number(rule.product_id),
      rule
    ])
  );

  return normalized.map(rule => {
    const units = counts[rule.basis];

    if (units === null) {
      fail(
        'Este servicio no calcula hojas; configura el material ' +
        'por ejemplar u orden.'
      );
    }

    const qty = decimal(
      micros(rule.qty_per_unit) * BigInt(units)
    );

    kardexQuantity(qty);

    const source = metadata.get(rule.product_id);

    return {
      ...rule,
      product_name: String(source.product_name || ''),
      unit: String(source.unit || ''),
      units,
      qty
    };
  });
}

// La ruta conserva BEGIN, COMMIT, ROLLBACK y release().
// Usar secuencialmente: no ejecutar estas operaciones con Promise.all.
async function inSavepoint(db, operation) {
  if (
    !db ||
    typeof db.query !== 'function' ||
    typeof db.release !== 'function'
  ) {
    fail(
      'Producción requiere un cliente de pool.connect() ' +
      'y una transacción activa.',
      500
    );
  }

  try {
    await db.query(
      'SAVEPOINT kc_production_materials'
    );
  } catch (error) {
    if (error.code === '25P01') {
      fail(
        'Ejecuta BEGIN antes de procesar materiales.',
        500
      );
    }

    throw error;
  }

  try {
    const result = await operation();

    await db.query(
      'RELEASE SAVEPOINT kc_production_materials'
    );

    return result;
  } catch (error) {
    try {
      await db.query(
        'ROLLBACK TO SAVEPOINT kc_production_materials'
      );

      await db.query(
        'RELEASE SAVEPOINT kc_production_materials'
      );
    } catch (rollbackError) {
      error.rollbackError = rollbackError;
    }

    throw error;
  }
}

// Congela la receta al crear la orden.
// Los cambios futuros de la tarifa no deben modificar
// los materiales de las órdenes ya registradas.
//
// Al editar una receta, la ruta debe bloquear primero
// su tarifa con FOR UPDATE.
async function loadMaterialSnapshot(db, rateId, details) {
  const id = positiveInteger(rateId, 'Tarifa');

  if (!details || Number(details.tariff_id) !== id) {
    fail('La cotización no corresponde a la tarifa.');
  }

  return inSavepoint(db, async () => {
    const rateResult = await db.query(
      `
      SELECT id, active, materials_configured
      FROM public.production_rates
      WHERE id = $1
      FOR SHARE
      `,
      [id]
    );

    const rate = rateResult.rows[0];

    if (!rate || !rate.active) {
      fail('Selecciona una tarifa activa.', 409);
    }

    if (!rate.materials_configured) {
      fail(
        'Configura los materiales de esta tarifa ' +
        'antes de crear la orden.',
        409
      );
    }

    const { rows } = await db.query(
      `
      SELECT
        rm.product_id,
        rm.basis,
        rm.qty_per_unit,
        p.name AS product_name,
        p.unit,
        p.active
      FROM public.production_rate_materials rm
      JOIN public.products p
        ON p.id = rm.product_id
      WHERE rm.rate_id = $1
      ORDER BY rm.product_id
      `,
      [id]
    );

    if (rows.some(row => !row.active || !row.unit)) {
      fail(
        'Revisa los materiales: deben estar activos ' +
        'y tener una unidad de inventario.',
        409
      );
    }

    // Una lista vacía solo es válida después de
    // configurarla expresamente.
    return calculateMaterials(rows, details);
  });
}

async function recordedMaterials(db, jobId) {
  const result = await db.query(
    `
    SELECT
      id,
      product_id,
      qty,
      unit_cost,
      total_cost,
      kardex_movement_id
    FROM public.print_job_materials
    WHERE print_job_id = $1
    ORDER BY product_id
    `,
    [jobId]
  );

  return result.rows;
}

// Registrar al iniciar la producción, dentro de la misma
// transacción que cambia la orden a "En proceso".
// El cobro se registra por separado.
async function recordJobMaterials(db, jobId, userId) {
  const id = positiveInteger(jobId, 'Orden');
  const actor = positiveInteger(userId, 'Usuario');

  return inSavepoint(db, async () => {
    const jobResult = await db.query(
      `
      SELECT
        id,
        status,
        materials_snapshot,
        materials_recorded_at
      FROM public.print_jobs
      WHERE id = $1
      FOR UPDATE
      `,
      [id]
    );

    const job = jobResult.rows[0];

    if (!job) {
      fail('Orden no encontrada.', 404);
    }

    // Un reintento devuelve el consumo existente.
    // No vuelve a descontar inventario.
    if (job.materials_recorded_at) {
      return {
        alreadyRecorded: true,
        materials: await recordedMaterials(db, id)
      };
    }

    if (!['Pendiente', 'En proceso'].includes(job.status)) {
      fail(
        'El estado de esta orden no permite registrar consumo.',
        409
      );
    }

    if (
      !Array.isArray(job.materials_snapshot) ||
      job.materials_snapshot.length > 50
    ) {
      fail(
        'La orden no tiene una configuración de materiales ' +
        'válida. Requiere revisión.',
        409
      );
    }

    const previous = await recordedMaterials(db, id);

    if (previous.length) {
      fail(
        'La orden ya tiene movimientos sin marca de cierre ' +
        'de consumo. Revisa su historial.',
        409
      );
    }

    const seen = new Set();

    const materials = job.materials_snapshot
      .map(item => {
        if (!item || typeof item !== 'object') {
          fail('Material guardado inválido.', 409);
        }

        const product_id = positiveInteger(
          item.product_id,
          'Producto'
        );

        if (seen.has(product_id)) {
          fail('Producto repetido en la orden.', 409);
        }

        seen.add(product_id);

        if (
          typeof item.unit !== 'string' ||
          !item.unit.trim()
        ) {
          fail(
            'Falta la unidad del material guardado.',
            409
          );
        }

        return {
          ...item,
          product_id,
          qty: decimal(micros(item.qty))
        };
      })
      .sort((a, b) => a.product_id - b.product_id);

    if (materials.length) {
      // Orden estable de bloqueos entre órdenes
      // que utilizan varios materiales.
      const { rows } = await db.query(
        `
        SELECT id, name, unit, active
        FROM public.products
        WHERE id = ANY($1::integer[])
        ORDER BY id
        FOR UPDATE
        `,
        [materials.map(item => item.product_id)]
      );

      const products = new Map(
        rows.map(product => [
          product.id,
          product
        ])
      );

      for (const item of materials) {
        const product = products.get(item.product_id);

        if (!product || !product.active) {
          fail(
            'Uno de los materiales ya no está disponible.',
            409
          );
        }

        if (product.unit !== item.unit) {
          fail(
            'Cambió la unidad de un material; ' +
            'revisa la orden antes de consumir.',
            409
          );
        }
      }
    }

    for (const item of materials) {
      const movement = await recordSalida(db, {
        productId: item.product_id,
        qty: kardexQuantity(item.qty),
        reference: 'Producción #' + id,
        userId: actor,
        allowNegative: false
      });

      // total_cost lo calcula PostgreSQL.
      // No se recibe desde el navegador.
      await db.query(
        `
        INSERT INTO public.print_job_materials (
          print_job_id,
          product_id,
          qty,
          unit_cost,
          kardex_movement_id,
          user_id
        )
        VALUES ($1, $2, $3, $4, $5, $6)
        `,
        [
          id,
          item.product_id,
          item.qty,
          movement.unitCost,
          movement.movementId,
          actor
        ]
      );
    }

    await db.query(
      `
      UPDATE public.print_jobs
      SET
        materials_recorded_at = CURRENT_TIMESTAMP,
        materials_recorded_by = $2,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      `,
      [id, actor]
    );

    await db.query(
      `
      INSERT INTO public.audit_log (
        user_id,
        action,
        entity,
        details
      )
      VALUES (
        $1,
        'consumir_materiales',
        'produccion',
        $2
      )
      `,
      [
        actor,
        JSON.stringify({
          print_job_id: id,
          materials
        })
      ]
    );

    return {
      alreadyRecorded: false,
      materials: await recordedMaterials(db, id)
    };
  });
}

module.exports = {
  normalizeRules,
  calculateMaterials,
  loadMaterialSnapshot,
  recordJobMaterials
};