'use strict';

const pool = require('../db/connection');

function fail(message, status = 400) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function text(
  value,
  label,
  max = 150,
  required = true,
  multiline = false
) {
  if (value == null && !required) {
    return null;
  }

  const forbiddenCharacters = multiline
    ? /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/
    : /[\u0000-\u001f\u007f]/;

  if (
    typeof value !== 'string' ||
    value.trim().length > max ||
    (required && !value.trim()) ||
    forbiddenCharacters.test(value)
  ) {
    fail(
      `${label}: revisa el contenido ` +
      `(máximo ${max} caracteres).`
    );
  }

  return value.trim() || null;
}

function handle(action) {
  return async (req, res) => {
    try {
      await action(req, res);
    } catch (error) {
      const conflictCodes = [
        '23505',
        '23503',
        '23514',
        '22P02'
      ];

      const status =
        error.status ||
        (
          conflictCodes.includes(error.code)
            ? 409
            : 500
        );

      if (status >= 500) {
        console.error(
          '[Operación integrada]',
          error.code || error.message
        );
      }

      const message = status < 500
        ? (
            error.status
              ? error.message
              : 'Registro duplicado, relacionado ' +
                'o con datos incompatibles.'
          )
        : 'No se completó la operación. ' +
          'Revisa las migraciones y la terminal.';

      res.status(status).json({
        error: message,
        code: error.code || 'OPERACION_ERROR'
      });
    }
  };
}

async function audit(
  db,
  userId,
  action,
  entity,
  details
) {
  await db.query(
    `
    INSERT INTO public.audit_log (
      user_id,
      action,
      entity,
      details
    )
    VALUES ($1, $2, $3, $4)
    `,
    [
      userId,
      action,
      entity,
      JSON.stringify(details)
    ]
  );
}

async function transaction(userId, action) {
  const db = await pool.connect();

  try {
    await db.query('BEGIN');

    const result = await db.query(
      `
      SELECT
        role,
        active
      FROM public.users
      WHERE id = $1
      FOR SHARE
      `,
      [userId]
    );

    const user = result.rows[0];

    if (
      !user?.active ||
      !['admin', 'superadmin'].includes(user.role)
    ) {
      fail(
        'Sin permiso para modificar el catálogo.',
        403
      );
    }

    await db.query(
      `
      SELECT set_config(
        'kc.actor_id',
        $1,
        true
      )
      `,
      [String(userId)]
    );

    const response = await action(db);

    await db.query('COMMIT');

    return response;
  } catch (error) {
    await db
      .query('ROLLBACK')
      .catch(() => {});

    throw error;
  } finally {
    db.release();
  }
}

module.exports = {
  fail,
  text,
  handle,
  audit,
  transaction
};