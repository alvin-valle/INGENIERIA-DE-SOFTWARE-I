'use strict';

const { recordSalida } = require('./kardex');
const { fail, integer, text, quote } = require('./production');

// Usar un cliente de pool.connect(), después de BEGIN.
// La ruta controla permisos, auditoría, COMMIT, ROLLBACK y release().
// Ejecutar estas funciones una por una, con await.
const BASES = ['hoja', 'cara', 'ejemplar', 'orden'];
const id = value => integer(value, 'Identificador', 2147483647);

function scaled(value, places, label) {
  if (!['string', 'number'].includes(typeof value)) {
    fail(`${label}: número inválido.`);
  }
  const input = String(value).trim();
  const pattern = new RegExp(`^\\d{1,12}(?:\\.\\d{1,${places}})?$`);
  if (!pattern.test(input)) {
    fail(`${label}: usa un número positivo con hasta ${places} decimales.`);
  }
  const [whole, fraction = ''] = input.split('.');
  const result = BigInt(whole + fraction.padEnd(places, '0'));
  if (result <= 0n) fail(`${label}: debe ser mayor que cero.`);
  return result;
}

function fixed(value, places) {
  const digits = value.toString().padStart(places + 1, '0');
  return digits.slice(0, -places) + '.' + digits.slice(-places);
}

function quantity(value) {
  const units = scaled(value, 6, 'Cantidad');
  const normalized = fixed(units, 6);
  if (
    units > BigInt(Number.MAX_SAFE_INTEGER) ||
    scaled(Number(normalized), 6, 'Cantidad') !== units
  ) {
    fail('La cantidad supera la precisión admitida por el Kardex.');
  }
  return normalized;
}

function money(value) {
  const cents = scaled(value, 2, 'Importe');
  if (cents > 9999999999n) fail('El importe supera el máximo de una orden.');
  return fixed(cents, 2);
}

async function operation(db, work) {
  if (!db || typeof db.query !== 'function' || typeof db.release !== 'function') {
    fail('Producción requiere un cliente de pool.connect() con BEGIN.', 500);
  }
  try {
    await db.query('SAVEPOINT kc_production_ledger');
  } catch (error) {
    if (error.code === '25P01') fail('Ejecuta BEGIN antes de esta operación.', 500);
    throw error;
  }
  try {
    const result = await work();
    await db.query('RELEASE SAVEPOINT kc_production_ledger');
    return result;
  } catch (error) {
    try {
      await db.query('ROLLBACK TO SAVEPOINT kc_production_ledger');
      await db.query('RELEASE SAVEPOINT kc_production_ledger');
    } catch (rollbackError) {
      error.rollbackError = rollbackError;
    }
    throw error;
  }
}

function materialList(value) {
  if (!Array.isArray(value) || value.length > 50) {
    fail('Configura un arreglo con un máximo de 50 materiales.');
  }
  const seen = new Set();
  for (const item of value) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      fail('Material inválido.');
    }
    const productId = id(item.product_id);
    if (seen.has(productId)) fail('No repitas el mismo producto en los materiales.');
    seen.add(productId);
  }
  return [...value].sort((a, b) => id(a.product_id) - id(b.product_id));
}

// Un arreglo vacío confirma expresamente una tarifa sin insumos físicos.
async function saveRateMaterials(db, { rateId, materials }) {
  rateId = id(rateId);
  const lines = materialList(materials).map(item => {
    if (!BASES.includes(item.basis)) fail('Base de consumo inválida.');
    return {
      product_id: id(item.product_id),
      basis: item.basis,
      qty_per_unit: quantity(item.qty_per_unit)
    };
  });
  return operation(db, async () => {
    const rate = (await db.query(
      'SELECT * FROM public.production_rates WHERE id = $1 FOR UPDATE',
      [rateId]
    )).rows[0];
    if (!rate) fail('Tarifa no encontrada.', 404);
    if (lines.some(item => item.basis === 'hoja') &&
        !['Impresión', 'Fotocopia'].includes(rate.service)) {
      fail('La base hoja se utiliza para Impresión y Fotocopia.');
    }
    if (lines.length) {
      const products = (await db.query(
        `SELECT id, active FROM public.products
         WHERE id = ANY($1::int[]) ORDER BY id FOR SHARE`,
        [lines.map(item => item.product_id)]
      )).rows;
      if (products.length !== lines.length || products.some(p => p.active !== true)) {
        fail('Selecciona únicamente productos existentes y activos.');
      }
    }
    await db.query('DELETE FROM public.production_rate_materials WHERE rate_id = $1', [rateId]);
    for (const item of lines) {
      await db.query(
        `INSERT INTO public.production_rate_materials
           (rate_id, product_id, basis, qty_per_unit) VALUES ($1, $2, $3, $4)`,
        [rateId, item.product_id, item.basis, item.qty_per_unit]
      );
    }
    await db.query(
      'UPDATE public.production_rates SET materials_configured = TRUE WHERE id = $1',
      [rateId]
    );
    return lines;
  });
}

// La ruta guardará calculated y materials_snapshot en la nueva orden.
// Esta preparación calcula cantidades; todavía no descuenta existencias.
async function prepareProduction(db, { rateId, pages, copies }) {
  rateId = id(rateId);
  return operation(db, async () => {
    const rate = (await db.query(
      'SELECT * FROM public.production_rates WHERE id = $1 FOR SHARE',
      [rateId]
    )).rows[0];
    if (!rate || rate.active !== true) fail('Selecciona una tarifa activa.', 409);
    if (rate.materials_configured !== true) {
      fail('Configura los materiales de esta tarifa antes de crear órdenes.', 409);
    }
    const calculated = quote(rate, pages, copies);
    const rows = (await db.query(
      `SELECT m.product_id, m.basis, m.qty_per_unit, p.name, p.unit, p.active
       FROM public.production_rate_materials m
       JOIN public.products p ON p.id = m.product_id
       WHERE m.rate_id = $1 ORDER BY m.product_id FOR SHARE OF p`,
      [rateId]
    )).rows;
    const factors = {
      hoja: calculated.sheets, cara: calculated.faces,
      ejemplar: calculated.copies, orden: 1
    };
    const materials_snapshot = materialList(rows).map(item => {
      if (item.active !== true) fail(`El insumo ${item.name} está inactivo.`, 409);
      const units = factors[item.basis];
      if (!BASES.includes(item.basis) || !Number.isSafeInteger(units) || units < 1) {
        fail('La base de un material no corresponde a este servicio.', 409);
      }
      const perUnit = quantity(item.qty_per_unit);
      const total = scaled(perUnit, 6, 'Cantidad') * BigInt(units);
      return {
        product_id: id(item.product_id), product_name: item.name,
        unit: item.unit || 'unidad', basis: item.basis,
        qty_per_unit: perUnit, units, qty: quantity(fixed(total, 6))
      };
    });
    return { calculated, materials_snapshot };
  });
}

async function lockedJob(db, jobId) {
  const job = (await db.query(
    'SELECT * FROM public.print_jobs WHERE id = $1 FOR UPDATE', [jobId]
  )).rows[0];
  if (!job) fail('Orden no encontrada.', 404);
  return job;
}

async function jobMaterials(db, jobId) {
  return (await db.query(
    'SELECT * FROM public.print_job_materials WHERE print_job_id = $1 ORDER BY product_id',
    [jobId]
  )).rows;
}

// Descuenta una sola vez y cambia la orden de Pendiente a En proceso.
// Si un insumo falla, se revierte todo el consumo de esta operación.
async function startProduction(db, { jobId, userId }) {
  jobId = id(jobId);
  userId = id(userId);
  return operation(db, async () => {
    const job = await lockedJob(db, jobId);
    if (job.materials_recorded_at != null) {
      return { job, materials: await jobMaterials(db, jobId), replayed: true };
    }
    if (job.status !== 'Pendiente') fail('Solo puedes iniciar una orden pendiente.', 409);
    if (job.materials_snapshot == null) {
      fail('Esta orden no tiene un plan de materiales. Revisa su historial antes de descontar.', 409);
    }
    const lines = materialList(job.materials_snapshot).map(item => ({
      product_id: id(item.product_id), qty: quantity(item.qty)
    }));
    for (const item of lines) {
      const movement = await recordSalida(db, {
        productId: item.product_id, qty: Number(item.qty), userId,
        reference: `Producción: orden #${jobId}`
      });
      await db.query(
        `INSERT INTO public.print_job_materials
           (print_job_id, product_id, qty, unit_cost, kardex_movement_id, user_id)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [jobId, item.product_id, item.qty, movement.unitCost, movement.movementId, userId]
      );
    }
    const updated = (await db.query(
      `UPDATE public.print_jobs SET status = 'En proceso',
         materials_recorded_at = CURRENT_TIMESTAMP, materials_recorded_by = $1,
         updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *`,
      [userId, jobId]
    )).rows[0];
    return { job: updated, materials: await jobMaterials(db, jobId), replayed: false };
  });
}

// Primer alcance: un cobro total en C$ cuando el trabajo está Listo.
// No crea una venta adicional en sales ni admite anticipos o abonos.
// Finanzas deberá bloquear el mismo turno ANTES de calcular su cierre.
async function recordProductionPayment(db, data) {
  const jobId = id(data.jobId);
  const shiftId = id(data.shiftId);
  const userId = id(data.userId);
  const amount = money(data.amount);
  const method = data.paymentMethod;
  const reference = text(data.reference, 'Referencia', 100) || null;
  const key = text(data.requestKey, 'Solicitud', 36, true).toLowerCase();
  if (!['efectivo', 'tarjeta', 'transferencia'].includes(method)) {
    fail('Método de pago inválido.');
  }
  if (method === 'transferencia' && !reference) fail('Escribe la referencia de la transferencia.');
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(key)) {
    fail('Identificador de solicitud inválido.');
  }
  return operation(db, async () => {
    await db.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))',
      ['production_payment:' + key]);
    const job = await lockedJob(db, jobId);
    const existing = (await db.query(
      `SELECT * FROM public.print_job_payments
       WHERE request_key = $1 OR print_job_id = $2`, [key, jobId]
    )).rows;
    if (existing.length) {
      const paid = existing[0];
      const same = existing.length === 1 && paid.request_key === key &&
        paid.print_job_id === jobId && paid.shift_id === shiftId && paid.user_id === userId &&
        money(paid.amount) === amount && paid.currency === 'NIO' &&
        paid.payment_method === method && (paid.payment_reference || null) === reference;
      if (!same) fail('La orden ya tiene un cobro o la solicitud fue utilizada con otros datos.', 409);
      return { payment: paid, replayed: true };
    }
    if (job.materials_snapshot == null || job.materials_recorded_at == null) {
      fail('Revisa esta orden antes de cobrar: no tiene producción registrada con este flujo.', 409);
    }
    if (job.status !== 'Listo') fail('La orden debe estar Lista para cobrarla.', 409);
    if (money(job.quoted_total) !== amount) fail('El cobro debe coincidir con el total de la orden.', 409);
    const shift = (await db.query(
      'SELECT id, cashier_id, status FROM public.cash_shifts WHERE id = $1 FOR UPDATE',
      [shiftId]
    )).rows[0];
    if (!shift) fail('Turno de caja no encontrado.', 404);
    if (shift.cashier_id !== userId) fail('Debes cobrar en tu propio turno de caja.', 403);
    if (shift.status !== 'abierto') fail('El turno de caja está cerrado.', 409);
    const payment = (await db.query(
      `INSERT INTO public.print_job_payments
         (print_job_id, shift_id, user_id, amount, currency,
          payment_method, payment_reference, request_key)
       VALUES ($1, $2, $3, $4, 'NIO', $5, $6, $7) RETURNING *`,
      [jobId, shiftId, userId, amount, method, reference, key]
    )).rows[0];
    return { payment, replayed: false };
  });
}

module.exports = {
  saveRateMaterials,
  prepareProduction,
  startProduction,
  recordProductionPayment
};