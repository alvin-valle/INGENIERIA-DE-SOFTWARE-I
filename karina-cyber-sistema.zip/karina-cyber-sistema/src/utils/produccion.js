'use strict';

const crypto = require('crypto');

// Servicios disponibles en Producción.
const SERVICES = [
  'Impresión',
  'Fotocopia',
  'Cédula',
  'Encolochado',
  'Laminado',
  'Escaneo'
];

// Flujo permitido de las órdenes.
const TRANSITIONS = {
  Pendiente: ['En proceso', 'Cancelado'],
  'En proceso': ['Listo', 'Cancelado'],
  Listo: ['Entregado'],
  Entregado: [],
  Cancelado: []
};

// Crea errores que las rutas pueden devolver al frontend.
function fail(message, status = 400) {
  const error = new Error(message);
  error.status = status;

  throw error;
}

// Valida cantidades e identificadores enteros positivos.
function integer(value, label, max = 100000) {
  if (!/^\d+$/.test(String(value))) {
    fail(label + ': escribe un entero positivo.');
  }

  const number = Number(value);

  if (
    !Number.isSafeInteger(number) ||
    number < 1 ||
    number > max
  ) {
    fail(
      label +
      ': valor fuera del límite (1–' +
      max +
      ').'
    );
  }

  return number;
}

// Valida textos recibidos desde los formularios.
function text(value, label, max, required = false) {
  if (
    value !== undefined &&
    value !== null &&
    typeof value !== 'string'
  ) {
    fail(label + ': texto inválido.');
  }

  const result = (value || '').trim();

  if (
    result.length > max ||
    (required && !result)
  ) {
    fail(
      label +
      ': revisa el contenido y su longitud.'
    );
  }

  return result;
}

// Convierte un precio a centavos enteros.
// Así evitamos errores de precisión al multiplicar dinero.
function cents(value) {
  const input = String(value);

  if (!/^(0|[1-9]\d{0,5})(\.\d{1,2})?$/.test(input)) {
    fail(
      'Precio inválido: usa hasta dos decimales.'
    );
  }

  const [whole, decimals = ''] = input.split('.');

  const amount =
    Number(whole) * 100 +
    Number(decimals.padEnd(2, '0'));

  if (amount <= 0) {
    fail('El precio debe ser mayor que cero.');
  }

  return amount;
}

// Convierte centavos a un importe con dos decimales.
function decimal(value) {
  return (value / 100).toFixed(2);
}

// Valida y normaliza una tarifa.
function tariff(input) {
  const name = text(
    input.name,
    'Nombre',
    120,
    true
  );

  const service = text(
    input.service,
    'Servicio',
    30,
    true
  );

  if (!SERVICES.includes(service)) {
    fail('Servicio inválido.');
  }

  const billing = input.billing;

  if (!['cara', 'documento'].includes(billing)) {
    fail('Unidad de cobro inválida.');
  }

  const fixedDocumentServices = [
    'Cédula',
    'Encolochado',
    'Laminado'
  ];

  if (
    fixedDocumentServices.includes(service) &&
    billing !== 'documento'
  ) {
    fail('Este servicio se cobra por documento.');
  }

  const sides = Number(input.sides);

  if (![1, 2].includes(sides)) {
    fail('Selecciona una o dos caras.');
  }

  const paper = text(
    input.paper,
    'Papel / tamaño',
    120
  );

  const color = text(
    input.color,
    'Modo de tinta',
    30
  );

  if (!['B/N', 'Color', 'No aplica'].includes(color)) {
    fail('Modo de tinta inválido.');
  }

  const raw = input.tiers;

  if (
    !Array.isArray(raw) ||
    raw.length < 1 ||
    raw.length > 20
  ) {
    fail(
      'Configura entre 1 y 20 tramos de precio.'
    );
  }

  let previous = 0;

  const tiers = raw.map((item, index) => {
    if (!item || typeof item !== 'object') {
      fail('Tramo de precio inválido.');
    }

    const last = index === raw.length - 1;

    const up_to = item.up_to === null
      ? null
      : integer(
          item.up_to,
          'Páginas máximas'
        );

    // Los límites deben aumentar.
    // El último tramo debe cubrir las páginas restantes.
    if (
      (last && up_to !== null) ||
      (
        !last &&
        (
          up_to === null ||
          up_to <= previous
        )
      )
    ) {
      fail(
        'Los tramos deben aumentar; ' +
        'el último debe tener límite null (sin límite).'
      );
    }

    previous = up_to;

    return {
      up_to,
      price: decimal(cents(item.price))
    };
  });

  return {
    name,
    service,
    billing,
    sides,
    paper,
    color,
    tiers
  };
}

// Calcula una cotización usando la tarifa seleccionada.
function quote(rate, pagesValue, copiesValue) {
  const pages = integer(
    pagesValue,
    'Páginas por documento'
  );

  const copies = integer(
    copiesValue,
    'Ejemplares'
  );

  const rule = tariff(rate);

  // El tramo depende de las páginas de cada documento.
  // Esto permite aplicar tarifas según el grosor del encolochado.
  const tier = rule.tiers.find(item => {
    return (
      item.up_to === null ||
      pages <= item.up_to
    );
  });

  const faces = pages * copies;

  // Por cara: páginas × ejemplares.
  // Por documento: cantidad de ejemplares.
  const units = rule.billing === 'cara'
    ? faces
    : copies;

  const total = cents(tier.price) * units;

  if (
    !Number.isSafeInteger(total) ||
    total > 9999999999
  ) {
    fail(
      'La cotización supera el importe máximo.'
    );
  }

  // En dúplex, cada ejemplar impar necesita su última hoja.
  // Ejemplo: 3 páginas × 2 ejemplares = 6 caras y 4 hojas.
  const usesPrintedPaper = [
    'Impresión',
    'Fotocopia'
  ].includes(rule.service);

  const sheets = usesPrintedPaper
    ? Math.ceil(pages / rule.sides) * copies
    : null;

  const result = {
    ...rule,
    tariff_id: rate.id,
    pages,
    copies,
    faces,
    sheets,
    units,
    unit_price: tier.price,
    total: decimal(total)
  };

  // Permite detectar si la tarifa cambió entre la cotización
  // mostrada en pantalla y el momento de guardar la orden.
  const quote_key = crypto
    .createHash('sha256')
    .update(JSON.stringify(result))
    .digest('hex');

  return {
    ...result,
    quote_key
  };
}

module.exports = {
  SERVICES,
  TRANSITIONS,
  fail,
  integer,
  text,
  tariff,
  quote
};