'use strict';

const {
  readPayments
} = require('../utils/print-payment-history');
const express = require('express');
const pool = require('../db/connection');
const { requireAuth, requireRole } = require('../middleware/auth');
const cash = require('../services/cash.service');

const router = express.Router();

router.use(requireAuth);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

function fail(message, code = 'IMPRESION_PAGO_VALIDACION', status = 400) {
  const error = new Error(message);
  error.code = code;
  error.status = status;
  throw error;
}

function route(work) {
  return async (req, res) => {
    try {
      await work(req, res);
    } catch (error) {
      if (res.headersSent) return;

      let status = Number.isInteger(error.status) ? error.status : 500;

      if (error.code === '23505') status = 409;
      if (status < 400 || status > 599) status = 500;

      if (status >= 500) {
        console.error('[Cobro de impresión]', error);
      }

      res.status(status).json({
        error: status >= 500 && !error.status
          ? 'No se pudo confirmar el cobro de impresión.'
          : error.message,
        code: error.code || 'IMPRESION_PAGO_ERROR'
      });
    }
  };
}

async function readPayment(db, jobId, user) {
  const canReadAll = [
    'superadmin',
    'admin',
    'auditor',
    'invitado'
  ].includes(user.role);

  const result = await db.query(`
    SELECT
      p.id,
      p.print_job_id,
      p.shift_id,
      p.cashier_id,
      p.amount,
      p.payment_method,
      p.payment_reference,
      p.paid_at,
      u.full_name AS cashier_name,
      c.id AS movement_id,
      c.shift_id AS movement_shift_id,
      c.user_id AS movement_user_id,
      c.mon AS movement_amount,
      c.metodo_pago AS movement_method,
      c.request_key AS movement_request_key
    FROM public.print_job_payments p
    LEFT JOIN public.users u
      ON u.id = p.cashier_id
    LEFT JOIN public.caja c
      ON c.print_payment_id = p.id
    WHERE p.print_job_id = $1
      AND ($2::boolean OR p.cashier_id = $3)
  `, [jobId, canReadAll, user.id]);

  if (!result.rows.length) return null;

  const row = result.rows[0];

  const reconciled =
    row.movement_id != null &&
    Number(row.movement_shift_id) === Number(row.shift_id) &&
    Number(row.movement_user_id) === Number(row.cashier_id) &&
    cash.money(row.movement_amount) === cash.money(row.amount) &&
    cash.paymentMethod(row.movement_method) ===
      cash.paymentMethod(row.payment_method) &&
    row.movement_request_key != null;

  return {
    id: row.id,
    print_job_id: row.print_job_id,
    shift_id: row.shift_id,
    cashier_id: row.cashier_id,
    cashier_name: row.cashier_name,
    amount: cash.money(row.amount),
    payment_method: row.payment_method,
    payment_reference: row.payment_reference,
    paid_at: row.paid_at,
    reconciled
  };
}

router.get(
  '/orders/:id/payment',
  requireRole('admin', 'cajero', 'auditor', 'invitado'),
  route(async (req, res) => {
    const jobId = cash.positiveId(req.params.id, 'Orden');
    const payment = await readPayment(pool, jobId, req.user);

    res.json({ payment });
  })
);

router.post(
  '/orders/:id/payment',
  requireRole('admin', 'cajero'),
  route(async (req, res) => {
    const jobId = cash.positiveId(req.params.id, 'Orden');
    const body = req.body;

    if (
      !body ||
      typeof body !== 'object' ||
      Array.isArray(body) ||
      Object.keys(body).some(key => ![
        'payment_method',
        'payment_reference',
        'request_key'
      ].includes(key))
    ) {
      fail('La solicitud de cobro contiene campos no admitidos.');
    }

    const method = cash.paymentMethod(body.payment_method);
    const reference = cash.paymentReference(
      body.payment_reference,
      method
    );
    const key = cash.requestKey(body.request_key);

    const result = await cash.withCashTransaction(
      req.user.id,
      async context => {
        const request = await cash.prepareRequest(context, {
          scope: 'printing',
          key,
          payload: {
            job_id: jobId,
            payment_method: method,
            payment_reference: reference
          }
        });

        if (request.replayed) {
          if (Number(request.record.print_job_id) !== jobId) {
            fail(
              'La clave pertenece a otra orden.',
              'IMPRESION_CLAVE_INCONSISTENTE',
              409
            );
          }

          const payment = await readPayment(
            context.db,
            jobId,
            context.user
          );

          if (!payment || !payment.reconciled) {
            fail(
              'El cobro existe, pero su movimiento de caja requiere revisión.',
              'IMPRESION_CONCILIACION_PENDIENTE',
              409
            );
          }

          return { payment, replayed: true };
        }

        const shift = await cash.lockOpenShift(context);

        const jobResult = await context.db.query(`
          SELECT id, status, quoted_total
          FROM public.print_jobs
          WHERE id = $1
          FOR UPDATE
        `, [jobId]);

        const job = jobResult.rows[0];

        if (!job) {
          fail(
            'Orden no encontrada.',
            'IMPRESION_NO_ENCONTRADA',
            404
          );
        }

        if (job.status === 'Cancelado') {
          fail(
            'Una orden cancelada no puede cobrarse.',
            'IMPRESION_CANCELADA',
            409
          );
        }

        const amount = cash.money(job.quoted_total);

        const inserted = await context.db.query(`
          INSERT INTO public.print_job_payments (
            print_job_id,
            shift_id,
            cashier_id,
            amount,
            payment_method,
            payment_reference,
            request_key,
            request_hash
          )
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
          ON CONFLICT (print_job_id) DO NOTHING
          RETURNING id
        `, [
          jobId,
          shift.id,
          context.user.id,
          amount,
          method,
          reference,
          request.key,
          request.hash
        ]);

        if (!inserted.rows.length) {
          fail(
            'Esta orden ya tiene un pago. Actualiza su historial.',
            'IMPRESION_YA_COBRADA',
            409
          );
        }

        await cash.recordMovement(context, {
          sourceId: inserted.rows[0].id
        });

        const payment = await readPayment(
          context.db,
          jobId,
          context.user
        );

        if (!payment || !payment.reconciled) {
          fail(
            'No se pudo verificar el movimiento de caja.',
            'IMPRESION_CAJA_INCONSISTENTE',
            409
          );
        }

        return { payment, replayed: false };
      }
    );

    res.status(result.replayed ? 200 : 201).json({
      ok: true,
      ...result
    });
  })
);

module.exports = router;