'use strict';

const express = require('express');

const pool = require('../db/connection');

const cash = require('../services/cash.service');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const {
  handle,
  text,
  fail,
  transaction,
  audit
} = require('../utils/enterprise');

const router = express.Router();

router.use(
  requireAuth,
  requireRole('admin', 'auditor')
);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// ============================================================
// CONSULTAR CAMPAÑAS
// ============================================================

router.get(
  '/campaigns',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        c.*,
        u.full_name AS author,

        (
          SELECT COUNT(*)
          FROM public.kc_campaign_shares s
          WHERE s.campaign_id = c.id
        ) AS share_attempts

      FROM public.kc_campaigns c

      INNER JOIN public.users u
        ON u.id = c.created_by

      ORDER BY c.id DESC

      LIMIT 200
      `
    );

    res.json(result.rows);
  })
);

// ============================================================
// CREAR CAMPAÑA
// ============================================================

router.post(
  '/campaigns',
  requireRole('admin'),
  handle(async (req, res) => {
    const title = text(
      req.body.title,
      'Título',
      150
    );

    const content = text(
      req.body.content,
      'Anuncio',
      5000,
      true,
      true
    );

    const url = text(
      req.body.url,
      'Enlace',
      1000,
      false
    );

    if (url) {
      try {
        const parsed = new URL(url);

        if (
          !['https:', 'http:'].includes(
            parsed.protocol
          ) ||
          parsed.username ||
          parsed.password
        ) {
          fail('Enlace inválido.');
        }
      } catch {
        fail(
          'Indica un enlace HTTP o HTTPS válido.'
        );
      }
    }

    const row = await transaction(
      req.user.id,
      async db => {
        const result = await db.query(
          `
          INSERT INTO public.kc_campaigns (
            title,
            content,
            url,
            created_by
          )
          VALUES ($1, $2, $3, $4)
          RETURNING *
          `,
          [
            title,
            content,
            url,
            req.user.id
          ]
        );

        const campaign = result.rows[0];

        await audit(
          db,
          req.user.id,
          'CREATE',
          'kc_campaigns',
          {
            id: campaign.id
          }
        );

        return campaign;
      }
    );

    res.status(201).json(row);
  })
);

// ============================================================
// REGISTRAR RESULTADO DE COMPARTIR
//
// No confirma que una red social haya publicado el anuncio.
// ============================================================

router.post(
  '/campaigns/:id/shares',
  requireRole('admin'),
  handle(async (req, res) => {
    const id = cash.positiveId(req.params.id);

    const {
      channel,
      outcome
    } = req.body;

    const validChannels = [
      'device',
      'whatsapp',
      'facebook',
      'copy'
    ];

    const validOutcomes = [
      'opened',
      'handed_off',
      'copied',
      'cancelled',
      'failed'
    ];

    if (
      !validChannels.includes(channel) ||
      !validOutcomes.includes(outcome)
    ) {
      fail(
        'Resultado de compartir inválido.'
      );
    }

    await transaction(
      req.user.id,
      async db => {
        await db.query(
          `
          INSERT INTO public.kc_campaign_shares (
            campaign_id,
            user_id,
            channel,
            outcome
          )
          VALUES ($1, $2, $3, $4)
          `,
          [
            id,
            req.user.id,
            channel,
            outcome
          ]
        );
      }
    );

    res.status(201).json({
      ok: true,
      publication_confirmed: false
    });
  })
);

module.exports = router;