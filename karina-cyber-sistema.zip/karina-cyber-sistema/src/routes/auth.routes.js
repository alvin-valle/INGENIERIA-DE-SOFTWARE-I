'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('node:crypto');

const pool = require('../db/connection');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// ============================================================
// CONFIGURACIÓN
// ============================================================

const HASH_ROUNDS = 12;

const BCRYPT_PATTERN =
  /^\$2[ab]\$\d{2}\$[./A-Za-z0-9]{53}$/;

const ROLE_LABELS = Object.freeze({
  superadmin: 'Superadministrador',
  admin: 'Administrador',
  cajero: 'Cajero',
  auditor: 'Auditor',
  invitado: 'Invitado'
});

// Se utiliza para comprobar una contraseña incluso cuando
// no existe el usuario, reduciendo diferencias de tiempo
// entre respuestas de autenticación.
const dummyHash = bcrypt.hashSync(
  crypto.randomBytes(32).toString('hex'),
  HASH_ROUNDS
);

// ============================================================
// LÍMITE DE INTENTOS DE ACCESO
//
// Máximo: 30 solicitudes por IP en cinco minutos.
//
// Este límite funciona en esta instancia de Node.js.
// Si se despliegan varias instancias, debe trasladarse
// a un almacén compartido.
// ============================================================

const attempts = new Map();

const WINDOW_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 30;
const MAX_BUCKETS = 5000;

let lastCleanup = 0;

function limitLogin(req, res, next) {
  const now = Date.now();

  // Elimina registros vencidos sin mantener temporizadores
  // independientes para cada dirección.
  if (now - lastCleanup >= 60000) {
    for (const [key, value] of attempts) {
      if (value.expiresAt <= now) {
        attempts.delete(key);
      }
    }

    lastCleanup = now;
  }

  // No se lee X-Forwarded-For directamente.
  // Si existe un proxy, su confianza debe configurarse
  // correctamente en Express.
  const key =
    req.ip ||
    req.socket?.remoteAddress ||
    'unknown';

  let bucket = attempts.get(key);

  if (bucket && bucket.expiresAt <= now) {
    attempts.delete(key);
    bucket = null;
  }

  if (!bucket) {
    if (attempts.size >= MAX_BUCKETS) {
      res.set('Retry-After', '60');

      return res.status(429).json({
        error:
          'Hay demasiados intentos de acceso. Intenta más tarde.'
      });
    }

    bucket = {
      count: 0,
      expiresAt: now + WINDOW_MS
    };

    attempts.set(key, bucket);
  }

  if (bucket.count >= MAX_ATTEMPTS) {
    const retryAfter = Math.max(
      1,
      Math.ceil((bucket.expiresAt - now) / 1000)
    );

    res.set('Retry-After', String(retryAfter));

    return res.status(429).json({
      error:
        'Has realizado demasiados intentos. Espera unos minutos.'
    });
  }

  bucket.count += 1;

  return next();
}

// ============================================================
// UTILIDADES
// ============================================================

function publicUser(user) {
  // Nunca devolver password_hash al navegador.
  return {
    id: user.id,
    username: user.username,
    full_name: user.full_name,
    role: user.role,
    role_label: ROLE_LABELS[user.role],
    active: true
  };
}

function invalidCredentials(res) {
  // La respuesta no revela si existe la cuenta
  // ni si está desactivada.
  return res.status(401).json({
    error: 'Usuario o contraseña incorrectos.'
  });
}

function equalLegacyPassword(password, stored) {
  // Compatibilidad temporal con las contraseñas antiguas
  // del proyecto, almacenadas en texto plano.
  //
  // SHA-256 solo se utiliza aquí para comparar dos valores
  // de longitud fija. El hash que se guarda será bcrypt.
  const suppliedDigest = crypto
    .createHash('sha256')
    .update(password, 'utf8')
    .digest();

  const storedDigest = crypto
    .createHash('sha256')
    .update(stored, 'utf8')
    .digest();

  return crypto.timingSafeEqual(
    suppliedDigest,
    storedDigest
  );
}

// Las respuestas de autenticación no deben almacenarse
// en cachés del navegador o intermediarios.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// ============================================================
// POST /api/auth/login
// ============================================================

router.post('/login', limitLogin, async (req, res) => {
  const { username, password } = req.body || {};

  if (
    typeof username !== 'string' ||
    !username.trim() ||
    username.trim().length > 50 ||
    typeof password !== 'string' ||
    password.length === 0 ||
    Buffer.byteLength(password, 'utf8') > 72
  ) {
    return res.status(400).json({
      error:
        'Ingresa un usuario válido y una contraseña de hasta 72 bytes.'
    });
  }

  // La contraseña no se recorta: sus espacios pueden formar
  // parte del valor que eligió el usuario.
  const secret = process.env.JWT_SECRET;

  if (
    typeof secret !== 'string' ||
    !secret.trim()
  ) {
    console.error(
      '[Login] JWT_SECRET no está configurado.'
    );

    return res.status(503).json({
      error:
        'El inicio de sesión no está disponible temporalmente.'
    });
  }

  try {
    const result = await pool.query(
      `
      SELECT
        id,
        username,
        full_name,
        password_hash,
        role,
        active
      FROM public.users
      WHERE username = $1
      `,
      [username.trim()]
    );

    const user = result.rows[0];

    const validRole =
      user &&
      Object.hasOwn(ROLE_LABELS, user.role);

    if (
      !user ||
      user.active !== true ||
      !validRole
    ) {
      await bcrypt.compare(password, dummyHash);
      return invalidCredentials(res);
    }

    const stored = user.password_hash;

    if (
      typeof stored !== 'string' ||
      !stored
    ) {
      await bcrypt.compare(password, dummyHash);
      return invalidCredentials(res);
    }

    const isBcrypt = BCRYPT_PATTERN.test(stored);

    let matches = false;

    if (isBcrypt) {
      matches = await bcrypt.compare(
        password,
        stored
      );
    } else {
      await bcrypt.compare(password, dummyHash);

      // Un hash con formato desconocido no se acepta
      // como si fuera una contraseña en texto plano.
      matches =
        !stored.startsWith('$') &&
        equalLegacyPassword(password, stored);
    }

    if (!matches) {
      return invalidCredentials(res);
    }

    let current;

    const needsUpgrade =
      !isBcrypt ||
      bcrypt.getRounds(stored) < HASH_ROUNDS;

    if (needsUpgrade) {
      const upgradedHash = await bcrypt.hash(
        password,
        HASH_ROUNDS
      );

      // La condición password_hash = $3 evita sobrescribir
      // una contraseña modificada por otra solicitud
      // mientras se comprobaba este inicio de sesión.
      current = await pool.query(
        `
        UPDATE public.users
        SET password_hash = $1
        WHERE id = $2
          AND password_hash = $3
          AND active = TRUE
        RETURNING
          id,
          username,
          full_name,
          role,
          active
        `,
        [
          upgradedHash,
          user.id,
          stored
        ]
      );
    } else {
      // Confirma que la cuenta sigue activa y que la
      // contraseña no cambió durante la verificación.
      current = await pool.query(
        `
        SELECT
          id,
          username,
          full_name,
          role,
          active
        FROM public.users
        WHERE id = $1
          AND password_hash = $2
          AND active = TRUE
        `,
        [
          user.id,
          stored
        ]
      );
    }

    const verified = current.rows[0];

    if (
      !verified ||
      verified.active !== true ||
      !Object.hasOwn(ROLE_LABELS, verified.role)
    ) {
      return invalidCredentials(res);
    }

    const token = jwt.sign(
      {
        id: verified.id,
        username: verified.username,
        role: verified.role
      },
      secret,
      {
        algorithm: 'HS256',
        expiresIn: '8h'
      }
    );

    return res.json({
      ok: true,
      token,
      user: publicUser(verified)
    });
  } catch (error) {
    // No registrar contraseñas, tokens ni el cuerpo
    // completo de la solicitud.
    console.error(
      '[Login]',
      error.code || error.name
    );

    return res.status(500).json({
      error:
        'No se pudo iniciar sesión. Intenta nuevamente.'
    });
  }
});

// ============================================================
// GET /api/auth/me
//
// requireAuth consulta el estado actual del usuario
// en PostgreSQL utilizando el middleware anterior.
// ============================================================

router.get('/me', requireAuth, (req, res) => {
  return res.json(publicUser(req.user));
});

module.exports = router;