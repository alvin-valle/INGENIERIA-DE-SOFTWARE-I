'use strict';

const router = require('express').Router();
const crypto = require('node:crypto');

const pool = require('../db/connection');
const cash = require('../services/cash.service');

const {
    requireAuth,
    requireRole
} = require('../middleware/auth');

const {
    handle,
    fail,
    text,
    audit,
    transaction
} = require('../utils/enterprise');

const {
    recordEntrada
} = require('../utils/kardex');

const {
    summarizeShift
} = require('./finance.routes');

router.use(requireAuth, requireRole('admin', 'auditor'));

router.use((req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
});

const admin = requireRole('admin');

const employeeFields = {
    payroll: 'nom-empleado',
    contract: 'con-emp',
    leave: 'per-emp',
    incident: 'inc-emp',
    equipment: 'epp-emp'
};

const fields = {
    payroll: [
        'nom-empleado',
        'nom-period',
        'nom-base',
        'nom-he',
        'nom-com',
        'nom-bono',
        'nom-inc',
        'nom-die',
        'nom-oing',
        'nom-epa',
        'nom-eju',
        'nom-ade',
        'nom-tar',
        'nom-ina',
        'nom-des',
        'nom-oded',
        'nom-he-money',
        'nom-tar-money',
        'nom-ina-money',
        'nom-des-money',
        'nom-inss',
        'nom-ir',
        'payment_method',
        'payment_reference'
    ],

    purchase: [
        'comp-prov',
        'comp-con',
        'comp-mon',
        'comp-est',
        'comp-invoice',
        'comp-items',
        'payment_method',
        'payment_reference'
    ],

    contract: [
        'con-emp',
        'con-ced',
        'con-tipo',
        'con-jor',
        'con-start',
        'con-end',
        'con-notes'
    ],

    leave: [
        'per-emp',
        'per-tipo',
        'per-fec',
        'per-start',
        'per-end',
        'per-status'
    ],

    incident: [
        'inc-emp',
        'inc-desc',
        'inc-date',
        'inc-level',
        'inc-status'
    ],

    equipment: [
        'epp-emp',
        'epp-equipo',
        'epp-date',
        'epp-qty'
    ]
};

function kindOf(value) {
    if (!Object.hasOwn(fields, value)) {
        fail('Tipo de expediente inválido.', 404);
    }

    return value;
}

function validDate(value, optional = false) {
    if (!value && optional) return null;

    if (
        typeof value !== 'string' ||
        !/^\d{4}-\d{2}-\d{2}$/.test(value)
    ) {
        fail('Fecha inválida.');
    }

    const parsed = new Date(value + 'T00:00:00Z');

    if (
        !Number.isFinite(parsed.getTime()) ||
        parsed.toISOString().slice(0, 10) !== value
    ) {
        fail('Fecha inválida.');
    }

    return value;
}

function cents(value) {
    return cash.toCents(
        cash.money(value || '0', { allowZero: true }),
        { allowZero: true }
    );
}

async function normalize(db, kind, raw) {
    if (
        !raw ||
        typeof raw !== 'object' ||
        Array.isArray(raw)
    ) {
        fail('Datos inválidos.');
    }

    const data = {};

    for (const key of Object.keys(raw)) {
        if (!fields[kind].includes(key)) {
            fail('Campo no admitido: ' + key);
        }

        data[key] = text(
            raw[key],
            key,
            key === 'comp-items' ? 12000 : 4000,
            false,
            true
        ) || '';
    }

    let employee = null;
    let supplier = null;
    let amount = '0.00';

    if (employeeFields[kind]) {
        employee = cash.positiveId(
            data[employeeFields[kind]],
            'Empleado'
        );

        const row = (
            await db.query(
                `SELECT full_name
                 FROM public.kc_employees
                 WHERE id = $1
                 FOR SHARE`,
                [employee]
            )
        ).rows[0];

        if (!row) fail('Empleado inexistente.');

        data.employee_name = row.full_name;
    }

    if (kind === 'payroll') {
        if (
            !/^\d{4}-(0[1-9]|1[0-2])$/.test(
                data['nom-period'] || ''
            )
        ) {
            fail('Indica el período mensual.');
        }

        const income = [
            'nom-base',
            'nom-com',
            'nom-bono',
            'nom-inc',
            'nom-die',
            'nom-oing',
            'nom-he-money'
        ];

        const deductions = [
            'nom-epa',
            'nom-eju',
            'nom-ade',
            'nom-oded',
            'nom-tar-money',
            'nom-ina-money',
            'nom-des-money',
            'nom-inss',
            'nom-ir'
        ];

        const gross = income.reduce(
            (sum, key) => sum + cents(data[key]),
            0n
        );

        const discount = deductions.reduce(
            (sum, key) => sum + cents(data[key]),
            0n
        );

        if (discount > gross) {
            fail('Las deducciones superan los ingresos.');
        }

        for (const key of [
            'nom-he',
            'nom-tar',
            'nom-ina',
            'nom-des'
        ]) {
            if (
                !/^\d{1,6}(?:\.\d{1,2})?$/.test(
                    data[key] || '0'
                )
            ) {
                fail('Cantidad inválida: ' + key);
            }
        }

        data.gross = cash.money(
            cash.fromCents(gross),
            { allowZero: true }
        );

        data.deductions = cash.money(
            cash.fromCents(discount),
            { allowZero: true }
        );

        amount = cash.money(
            cash.fromCents(gross - discount),
            { allowZero: true }
        );
    }

    if (kind === 'purchase') {
        supplier = cash.positiveId(
            data['comp-prov'],
            'Proveedor'
        );

        const row = (
            await db.query(
                `SELECT nombre
                 FROM public.proveedores
                 WHERE id = $1
                 FOR SHARE`,
                [supplier]
            )
        ).rows[0];

        if (!row) fail('Proveedor inexistente.');

        data.supplier_name = row.nombre;

        data['comp-con'] = text(
            data['comp-con'],
            'Concepto',
            255
        );

        data['comp-invoice'] = text(
            data['comp-invoice'],
            'Factura',
            80,
            false
        ) || '';

        let items;

        try {
            items = JSON.parse(data['comp-items'] || '[]');
        } catch {
            fail('Detalle de compra inválido.');
        }

        if (!Array.isArray(items) || items.length > 50) {
            fail('La compra admite hasta 50 productos.');
        }

        items = items.map(item => ({
            product_id: cash.positiveId(item.product_id),
            qty: cash.positiveId(item.qty),
            unit_cost: cash.money(item.unit_cost)
        })).sort(
            (a, b) => a.product_id - b.product_id
        );

        if (
            new Set(items.map(item => item.product_id)).size !==
                items.length ||
            items.some(item => item.qty > 1000000)
        ) {
            fail('Revisa productos y cantidades.');
        }

        amount = items.length
            ? cash.money(
                cash.fromCents(
                    items.reduce(
                        (sum, item) =>
                            sum +
                            BigInt(item.qty) *
                            cents(item.unit_cost),
                        0n
                    )
                )
            )
            : cash.money(data['comp-mon']);

        data['comp-items'] = JSON.stringify(items);
    }

    if (['purchase', 'payroll'].includes(kind)) {
        data.payment_method = cash.paymentMethod(
            data.payment_method
        );

        data.payment_reference = cash.paymentReference(
            data.payment_reference,
            data.payment_method
        ) || '';
    }

    if (kind === 'contract') {
        for (const key of [
            'con-ced',
            'con-tipo',
            'con-jor'
        ]) {
            text(data[key], key, 150);
        }

        validDate(data['con-start']);
        validDate(data['con-end'], true);

        if (
            data['con-end'] &&
            data['con-end'] < data['con-start']
        ) {
            fail('El fin del contrato precede al inicio.');
        }
    }

    if (kind === 'leave') {
        text(data['per-tipo'], 'Tipo', 150);

        validDate(data['per-start']);
        validDate(data['per-end']);

        if (data['per-start'] > data['per-end']) {
            fail('Rango de ausencia inválido.');
        }

        if (
            ![
                'Solicitada',
                'Aprobada',
                'Denegada'
            ].includes(data['per-status'])
        ) {
            fail('Estado inválido.');
        }
    }

    if (kind === 'incident') {
        text(
            data['inc-desc'],
            'Descripción',
            4000,
            true,
            true
        );

        validDate(data['inc-date']);

        if (
            !['Baja', 'Media', 'Alta'].includes(
                data['inc-level']
            ) ||
            ![
                'Abierto',
                'En seguimiento',
                'Cerrado'
            ].includes(data['inc-status'])
        ) {
            fail('Clasificación inválida.');
        }
    }

    if (kind === 'equipment') {
        text(data['epp-equipo'], 'Equipo', 150);
        validDate(data['epp-date']);

        cash.positiveId(
            data['epp-qty'],
            'Cantidad'
        );
    }

    return {
        data,
        employee,
        supplier,
        amount
    };
}

router.get('/employees', handle(async (req, res) => {
    const result = await pool.query(
        `SELECT *
         FROM public.kc_employees
         ORDER BY full_name`
    );

    res.json(result.rows);
}));

router.post('/employees', admin, handle(async (req, res) => {
    const body = req.body;

    const values = [
        text(body.full_name, 'Nombre'),
        text(body.position, 'Cargo', 100),
        cash.money(body.salary, { allowZero: true }),
        validDate(body.hired_on, true)
    ];

    const row = await transaction(
        req.user.id,
        async db => {
            const row = (
                await db.query(
                    `INSERT INTO public.kc_employees(
                        full_name,
                        position,
                        salary,
                        hired_on
                    )
                    VALUES($1,$2,$3,$4)
                    RETURNING *`,
                    values
                )
            ).rows[0];

            await audit(
                db,
                req.user.id,
                'CREATE',
                'kc_employees',
                { id: row.id }
            );

            return row;
        }
    );

    res.status(201).json(row);
}));

router.patch('/employees/:id', admin, handle(async (req, res) => {
    const body = req.body;

    if (typeof body.active !== 'boolean') {
        fail('Estado inválido.');
    }

    const row = await transaction(
        req.user.id,
        async db => {
            const row = (
                await db.query(
                    `UPDATE public.kc_employees
                     SET full_name = $1,
                         position = $2,
                         salary = $3,
                         hired_on = $4,
                         active = $5
                     WHERE id = $6
                     RETURNING *`,
                    [
                        text(body.full_name, 'Nombre'),
                        text(body.position, 'Cargo', 100),
                        cash.money(
                            body.salary,
                            { allowZero: true }
                        ),
                        validDate(body.hired_on, true),
                        body.active,
                        cash.positiveId(req.params.id)
                    ]
                )
            ).rows[0];

            if (!row) {
                fail('Empleado no encontrado.', 404);
            }

            await audit(
                db,
                req.user.id,
                'UPDATE',
                'kc_employees',
                { id: row.id }
            );

            return row;
        }
    );

    res.json(row);
}));

router.get('/records/:kind', handle(async (req, res) => {
    const kind = kindOf(req.params.kind);

    const result = await pool.query(
        `SELECT *
         FROM public.kc_business_records
         WHERE kind = $1
           AND status <> 'archived'
         ORDER BY id DESC
         LIMIT 500`,
        [kind]
    );

    res.json(result.rows);
}));

router.post('/records/:kind', admin, handle(async (req, res) => {
    const kind = kindOf(req.params.kind);

    const row = await transaction(
        req.user.id,
        async db => {
            const input = await normalize(
                db,
                kind,
                req.body.data
            );

            const row = (
                await db.query(
                    `INSERT INTO public.kc_business_records(
                        kind,
                        data,
                        employee_id,
                        supplier_id,
                        amount,
                        request_key,
                        created_by
                    )
                    VALUES($1,$2,$3,$4,$5,$6,$7)
                    RETURNING *`,
                    [
                        kind,
                        input.data,
                        input.employee,
                        input.supplier,
                        input.amount,
                        crypto.randomUUID(),
                        req.user.id
                    ]
                )
            ).rows[0];

            await audit(
                db,
                req.user.id,
                'CREATE',
                'kc_business_records',
                { id: row.id, kind }
            );

            return row;
        }
    );

    res.status(201).json(row);
}));

async function locked(db, req) {
    const kind = kindOf(req.params.kind);
    const id = cash.positiveId(req.params.id);

    const row = (
        await db.query(
            `SELECT *
             FROM public.kc_business_records
             WHERE id = $1 AND kind = $2
             FOR UPDATE`,
            [id, kind]
        )
    ).rows[0];

    if (!row) {
        fail('Expediente no encontrado.', 404);
    }

    if (row.status !== 'draft') {
        fail(
            'El expediente está pagado o archivado; ' +
            'se conserva su historial.',
            409
        );
    }

    if (row.version !== Number(req.body.version)) {
        fail(
            'Otro usuario modificó el expediente. ' +
            'Actualiza la pantalla.',
            409
        );
    }

    return row;
}

router.patch('/records/:kind/:id', admin, handle(async (req, res) => {
    const row = await transaction(
        req.user.id,
        async db => {
            const old = await locked(db, req);

            const input = await normalize(
                db,
                old.kind,
                req.body.data
            );

            const row = (
                await db.query(
                    `UPDATE public.kc_business_records
                     SET data = $1,
                         employee_id = $2,
                         supplier_id = $3,
                         amount = $4,
                         version = version + 1,
                         updated_at = now()
                     WHERE id = $5
                     RETURNING *`,
                    [
                        input.data,
                        input.employee,
                        input.supplier,
                        input.amount,
                        old.id
                    ]
                )
            ).rows[0];

            await audit(
                db,
                req.user.id,
                'UPDATE',
                'kc_business_records',
                {
                    id: row.id,
                    before: old.data,
                    after: row.data
                }
            );

            return row;
        }
    );

    res.json(row);
}));

router.delete('/records/:kind/:id', admin, handle(async (req, res) => {
    await transaction(req.user.id, async db => {
        const old = await locked(db, req);

        await db.query(
            `UPDATE public.kc_business_records
             SET status = 'archived',
                 version = version + 1,
                 updated_at = now()
             WHERE id = $1`,
            [old.id]
        );

        await audit(
            db,
            req.user.id,
            'ARCHIVE',
            'kc_business_records',
            { id: old.id }
        );
    });

    res.json({ ok: true });
}));

router.post('/records/:kind/:id/pay', admin, handle(async (req, res) => {
    const kind = kindOf(req.params.kind);

    if (!['payroll', 'purchase'].includes(kind)) {
        fail('Este expediente no es un pago.');
    }

    const result = await cash.withCashTransaction(
        req.user.id,
        async context => {
            if (
                !['admin', 'superadmin'].includes(
                    context.user.role
                )
            ) {
                fail('Sin permiso.', 403);
            }

            const db = context.db;
            const id = cash.positiveId(req.params.id);

            const row = (
                await db.query(
                    `SELECT *
                     FROM public.kc_business_records
                     WHERE id = $1 AND kind = $2
                     FOR UPDATE`,
                    [id, kind]
                )
            ).rows[0];

            if (!row) {
                fail('Expediente no encontrado.', 404);
            }

            if (row.status === 'paid') {
                if (
                    Number(req.body.version) !==
                    row.version - 1
                ) {
                    fail(
                        'Actualiza el expediente pagado.',
                        409
                    );
                }

                return {
                    record: row,
                    replayed: true
                };
            }

            if (
                row.status !== 'draft' ||
                row.version !== Number(req.body.version)
            ) {
                fail(
                    'El expediente cambió. Actualiza la pantalla.',
                    409
                );
            }

            const data = row.data;
            const amount = cash.money(row.amount);

            const method = cash.paymentMethod(
                data.payment_method
            );

            const reference = cash.paymentReference(
                data.payment_reference,
                method
            );

            const shiftId = cash.positiveId(
                req.body.shift_id,
                'Turno'
            );

            const prepared = await cash.prepareRequest(
                context,
                {
                    scope: 'expense',
                    key: row.request_key,
                    payload: {
                        document_id: row.id,
                        version: row.version,
                        shift_id: shiftId,
                        amount,
                        payment_method: method,
                        payment_reference: reference
                    }
                }
            );

            if (prepared.replayed) {
                fail(
                    'El documento requiere revisión de conciliación.',
                    409
                );
            }

            const shift = await cash.lockOpenShift(
                context,
                shiftId
            );

            const summary = await summarizeShift(
                db,
                shift
            );

            if (!summary.reconciled) {
                fail(
                    'Concilia el turno antes de pagar.',
                    409
                );
            }

            if (
                method === 'efectivo' &&
                (
                    summary.expectedCash.startsWith('-') ||
                    cents(amount) > cents(summary.expectedCash)
                )
            ) {
                fail('Efectivo insuficiente.', 409);
            }

            const description = kind === 'payroll'
                ? (
                    'Nómina ' +
                    data['nom-period'] +
                    ' · ' +
                    data.employee_name
                )
                : data['comp-con'];

            let items = [];

            if (kind === 'purchase') {
                const supplier = (
                    await db.query(
                        `SELECT estado
                         FROM public.proveedores
                         WHERE id = $1
                         FOR SHARE`,
                        [row.supplier_id]
                    )
                ).rows[0];

                if (supplier?.estado !== 'Activo') {
                    fail('El proveedor está inactivo.');
                }

                items = JSON.parse(
                    data['comp-items'] || '[]'
                );

                for (const item of items) {
                    const product = (
                        await db.query(
                            `SELECT active
                             FROM public.products
                             WHERE id = $1
                             FOR UPDATE`,
                            [item.product_id]
                        )
                    ).rows[0];

                    if (!product?.active) {
                        fail(
                            'Producto inexistente o inactivo.'
                        );
                    }
                }
            } else {
                const employee = (
                    await db.query(
                        `SELECT active
                         FROM public.kc_employees
                         WHERE id = $1
                         FOR UPDATE`,
                        [row.employee_id]
                    )
                ).rows[0];

                if (!employee?.active) {
                    fail('Empleado inactivo.');
                }
            }

            const expense = (
                await db.query(
                    `INSERT INTO public.cash_expenses(
                        shift_id,
                        user_id,
                        description,
                        category,
                        amount,
                        payment_method,
                        payment_reference,
                        request_key,
                        request_hash
                    )
                    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)
                    RETURNING id`,
                    [
                        shift.id,
                        context.user.id,
                        description,
                        kind === 'purchase' ? 'compras' : 'nomina',
                        amount,
                        method,
                        reference,
                        prepared.key,
                        prepared.hash
                    ]
                )
            ).rows[0];

            if (kind === 'payroll') {
                await db.query(
                    `INSERT INTO public.kc_payroll_payments(
                        employee_id,
                        period,
                        description,
                        amount,
                        payment_method,
                        expense_id,
                        created_by
                    )
                    VALUES($1,$2,$3,$4,$5,$6,$7)`,
                    [
                        row.employee_id,
                        data['nom-period'],
                        description,
                        amount,
                        method,
                        expense.id,
                        context.user.id
                    ]
                );
            } else {
                const purchase = (
                    await db.query(
                        `INSERT INTO public.kc_purchases(
                            supplier_id,
                            description,
                            invoice_number,
                            amount,
                            payment_method,
                            expense_id,
                            created_by
                        )
                        VALUES($1,$2,$3,$4,$5,$6,$7)
                        RETURNING id`,
                        [
                            row.supplier_id,
                            description,
                            data['comp-invoice'],
                            amount,
                            method,
                            expense.id,
                            context.user.id
                        ]
                    )
                ).rows[0];

                for (const item of items) {
                    await db.query(
                        `INSERT INTO public.kc_purchase_items(
                            purchase_id,
                            product_id,
                            qty,
                            unit_cost
                        )
                        VALUES($1,$2,$3,$4)`,
                        [
                            purchase.id,
                            item.product_id,
                            item.qty,
                            item.unit_cost
                        ]
                    );

                    await recordEntrada(db, {
                        productId: item.product_id,
                        qty: item.qty,
                        unitCost: item.unit_cost,
                        userId: context.user.id,
                        reference: 'Compra #' + purchase.id
                    });
                }
            }

            await cash.recordMovement(context, {
                sourceId: expense.id
            });

            const updated = (
                await db.query(
                    `UPDATE public.kc_business_records
                     SET status = 'paid',
                         expense_id = $1,
                         version = version + 1,
                         updated_at = now()
                     WHERE id = $2
                     RETURNING *`,
                    [expense.id, row.id]
                )
            ).rows[0];

            await audit(
                db,
                req.user.id,
                'PAYMENT',
                'kc_business_records',
                {
                    id: row.id,
                    expense_id: expense.id
                }
            );

            return {
                record: updated,
                replayed: false
            };
        }
    );

    res.json(result);
}));

router.get('/cash', handle(async (req, res) => {
    const from = validDate(req.query.from);
    const to = validDate(req.query.to);

    if (from > to) {
        fail('Rango de fechas inválido.');
    }

    const offset = Number(req.query.offset || 0);

    if (
        !Number.isSafeInteger(offset) ||
        offset < 0 ||
        offset > 1000000
    ) {
        fail('Página inválida.');
    }

    const method = String(req.query.method || '');

    if (
        ![
            '',
            'efectivo',
            'tarjeta',
            'transferencia'
        ].includes(method)
    ) {
        fail('Método inválido.');
    }

    const result = await pool.query(
        `
        WITH base AS (
            SELECT c.*, u.full_name AS cashier
            FROM public.caja c
            LEFT JOIN public.users u
                ON u.id = c.user_id
            WHERE c.fec >= $1::date
              AND c.fec < ($2::date + 1)
              AND ($4 = '' OR c.metodo_pago = $4)
        ),
        totals AS (
            SELECT
                COUNT(*) AS count,
                COALESCE(
                    SUM(mon) FILTER(WHERE tip = 'Entrada'),
                    0
                ) AS income,
                COALESCE(
                    SUM(mon) FILTER(WHERE tip = 'Salida'),
                    0
                ) AS expense
            FROM base
        ),
        daily AS (
            SELECT
                fec::date AS day,
                COALESCE(
                    SUM(mon) FILTER(WHERE tip = 'Entrada'),
                    0
                ) AS income,
                COALESCE(
                    SUM(mon) FILTER(WHERE tip = 'Salida'),
                    0
                ) AS expense
            FROM base
            GROUP BY fec::date
            ORDER BY fec::date
        ),
        methods AS (
            SELECT
                COALESCE(
                    metodo_pago,
                    'Sin especificar'
                ) AS method,
                COALESCE(
                    SUM(mon) FILTER(WHERE tip = 'Entrada'),
                    0
                ) AS income,
                COALESCE(
                    SUM(mon) FILTER(WHERE tip = 'Salida'),
                    0
                ) AS expense
            FROM base
            GROUP BY metodo_pago
        )
        SELECT
            row_to_json(totals) AS totals,

            (
                SELECT COALESCE(json_agg(daily), '[]')
                FROM daily
            ) AS daily,

            (
                SELECT COALESCE(json_agg(methods), '[]')
                FROM methods
            ) AS methods,

            (
                SELECT COALESCE(json_agg(p), '[]')
                FROM (
                    SELECT *
                    FROM base
                    ORDER BY fec DESC, id DESC
                    LIMIT 100 OFFSET $3
                ) p
            ) AS items

        FROM totals
        `,
        [from, to, offset, method]
    );

    res.json(result.rows[0]);
}));

router.get('/history/:kind', handle(async (req, res) => {
    const tables = {
        payroll: 'nomina',
        purchase: 'compras',
        employee: 'empleados',
        contract: 'contratos',
        leave: 'permisos',
        incident: 'incidentes',
        equipment: 'epp'
    };

    if (!Object.hasOwn(tables, req.params.kind)) {
        fail('Historial inválido.', 404);
    }

    const table = tables[req.params.kind];

    const exists = (
        await pool.query(
            'SELECT to_regclass($1) AS name',
            ['public.' + table]
        )
    ).rows[0].name;

    if (!exists) {
        return res.json({
            available: false,
            items: []
        });
    }

    // El nombre procede exclusivamente de la lista fija anterior.
    const result = await pool.query(
        'SELECT * FROM public.' + table + ' LIMIT 200'
    );

    res.json({
        available: true,
        items: result.rows
    });
}));

router.get('/compliance', handle(async (req, res) => {
    const result = await pool.query(`
        SELECT
            (
                SELECT COUNT(*)
                FROM public.kc_employees
                WHERE active
            ) AS employees,

            (
                SELECT COUNT(*)
                FROM public.kc_employees e
                WHERE e.active
                  AND EXISTS (
                    SELECT 1
                    FROM public.kc_business_records r
                    WHERE r.employee_id = e.id
                      AND r.kind = 'contract'
                      AND r.status = 'draft'

                      AND (r.data->>'con-start')::date <=
                          (
                            CURRENT_TIMESTAMP
                            AT TIME ZONE 'America/Managua'
                          )::date

                      AND (
                        NULLIF(r.data->>'con-end', '') IS NULL

                        OR (r.data->>'con-end')::date >=
                            (
                                CURRENT_TIMESTAMP
                                AT TIME ZONE 'America/Managua'
                            )::date
                      )
                  )
            ) AS with_contract,

            (
                SELECT COUNT(*)
                FROM public.kc_business_records
                WHERE kind = 'incident'
                  AND status = 'draft'
                  AND data->>'inc-status' <> 'Cerrado'
            ) AS open_incidents,

            (
                SELECT COUNT(*)
                FROM public.kc_business_records
                WHERE kind = 'leave'
                  AND status = 'draft'
                  AND data->>'per-status' = 'Solicitada'
            ) AS pending_leaves
    `);

    res.json(result.rows[0]);
}));

module.exports = router;