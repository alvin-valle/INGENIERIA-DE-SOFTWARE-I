const express = require('express');
const router = express.Router();

router.post('/*', async (req, res) => {
    try {
        const operator = req.body.operator || req.body.operadora || 'Desconocida';
        const amount = Number(req.body.amount || req.body.monto) || 0;
        
        res.status(201).json({
            ok: true,
            message: 'Recarga registrada exitosamente',
            data: { operator, amount }
        });
    } catch (err) {
        res.status(500).json({ error: 'Error al registrar recarga' });
    }
});

router.get('/*', async (req, res) => {
    try {
        res.json([]); 
    } catch (err) {
        res.status(500).json({ error: 'Error al obtener historial' });
    }
});

module.exports = router;