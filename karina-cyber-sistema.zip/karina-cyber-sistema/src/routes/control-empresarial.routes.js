'use strict';

const router = require('express').Router();
const crypto = require('node:crypto');
const pool = require('../db/connection');

const {
    requireAuth,
    requireRole
} = require('../middleware/auth');

const {
    handle,
    fail,
    text,
    transaction
} = require('../utils/enterprise');

router.use(
    requireAuth,
    requireRole('admin', 'auditor')
);

router.use((peticion, respuesta, siguiente) => {
    respuesta.set('Cache-Control', 'no-store');
    siguiente();
});

const administrador = requireRole('admin');

function identificador(valor) {
    if (
        !['number', 'string'].includes(typeof valor) ||
        !/^[1-9]\d*$/.test(String(valor)) ||
        Number(valor) > 2147483647
    ) {
        fail('Identificador inválido.');
    }

    return Number(valor);
}

function fechaValida(valor) {
    if (
        typeof valor !== 'string' ||
        !/^\d{4}-\d{2}-\d{2}$/.test(valor) ||
        Number(valor.slice(0, 4)) < 1
    ) {
        return false;
    }

    const fecha = new Date(valor + 'T00:00:00Z');

    return (
        Number.isFinite(fecha.getTime()) &&
        fecha.toISOString().slice(0, 10) === valor
    );
}

function hoy() {
    const partes = Object.fromEntries(
        new Intl.DateTimeFormat('en-CA', {
            timeZone: 'America/Managua',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        })
            .formatToParts(new Date())
            .map(parte => [parte.type, parte.value])
    );

    return (
        partes.year + '-' +
        partes.month + '-' +
        partes.day
    );
}

function periodo(consulta) {
    const hasta = consulta.hasta ?? hoy();

    const desde =
        consulta.desde ?? hasta.slice(0, 7) + '-01';

    if (
        !fechaValida(desde) ||
        !fechaValida(hasta) ||
        desde > hasta
    ) {
        fail(
            'Selecciona fechas válidas en orden cronológico.'
        );
    }

    const dias = (
        Date.parse(hasta + 'T00:00:00Z') -
        Date.parse(desde + 'T00:00:00Z')
    ) / 86400000 + 1;

    if (dias > 366) {
        fail('Selecciona un período de hasta 366 días.');
    }

    return { desde, hasta };
}

async function lectura(accion) {
    const cliente = await pool.connect();

    try {
        await cliente.query(
            'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY'
        );

        const resultado = await accion(cliente);

        await cliente.query('COMMIT');

        return resultado;
    } catch (error) {
        await cliente.query('ROLLBACK').catch(() => {});
        throw error;
    } finally {
        cliente.release();
    }
}

async function auditar(
    cliente,
    usuario,
    accion,
    id,
    detalle
) {
    await cliente.query(
        `
        INSERT INTO public.audit_log (
            user_id,
            action,
            entity,
            details,
            created_at
        )
        VALUES (
            $1,
            $2,
            $3,
            $4,
            CURRENT_TIMESTAMP
        )
        `,
        [
            usuario,
            accion,
            'capacitacion:' + id,
            JSON.stringify(detalle)
        ]
    );
}

function entrada(cuerpo) {
    if (
        !cuerpo ||
        typeof cuerpo !== 'object' ||
        Array.isArray(cuerpo)
    ) {
        fail('Datos de capacitación inválidos.');
    }

    if (!fechaValida(cuerpo.fecha)) {
        fail('Fecha de capacitación inválida.');
    }

    if (
        ![
            'seguridad',
            'operacion',
            'administrativa'
        ].includes(cuerpo.tipo)
    ) {
        fail('Tipo de capacitación inválido.');
    }

    if (
        ![
            'programada',
            'realizada',
            'cancelada'
        ].includes(cuerpo.estado)
    ) {
        fail('Estado de capacitación inválido.');
    }

    if (
        !Array.isArray(cuerpo.participantes) ||
        cuerpo.participantes.length > 500
    ) {
        fail('Selecciona hasta 500 participantes.');
    }

    const participantes = cuerpo.participantes
        .map(participante => {
            if (
                !participante ||
                ![
                    'convocado',
                    'asistio',
                    'no_asistio'
                ].includes(participante.asistencia)
            ) {
                fail('Asistencia inválida.');
            }

            return {
                empleado_id:
                    identificador(participante.empleado_id),

                asistencia:
                    participante.asistencia
            };
        })
        .sort((a, b) => a.empleado_id - b.empleado_id);

    if (
        new Set(
            participantes.map(p => p.empleado_id)
        ).size !== participantes.length
    ) {
        fail('No repitas participantes.');
    }

    if (
        cuerpo.estado === 'realizada' &&
        (
            cuerpo.fecha > hoy() ||
            !participantes.length ||
            participantes.some(
                p => p.asistencia === 'convocado'
            )
        )
    ) {
        fail(
            'Para marcarla realizada, registra una fecha ' +
            'no futura y la asistencia de cada participante.'
        );
    }

    return {
        titulo:
            text(cuerpo.titulo, 'Título', 180),

        fecha:
            cuerpo.fecha,

        tipo:
            cuerpo.tipo,

        estado:
            cuerpo.estado,

        descripcion:
            text(
                cuerpo.descripcion ?? '',
                'Descripción',
                2000,
                false,
                true
            ) ?? '',

        participantes
    };
}

async function guardarParticipantes(
    cliente,
    id,
    datos
) {
    const anteriores = (
        await cliente.query(
            `
            SELECT empleado_id
            FROM public.kc_rrhh_capacitacion_participantes
            WHERE capacitacion_id = $1
            `,
            [id]
        )
    ).rows;

    const existentes = new Set(
        anteriores.map(fila => fila.empleado_id)
    );

    const empleados = (
        await cliente.query(
            `
            SELECT id, active
            FROM public.kc_employees
            WHERE id = ANY($1::int[])
            ORDER BY id
            FOR SHARE
            `,
            [datos.map(fila => fila.empleado_id)]
        )
    ).rows;

    if (
        empleados.length !== datos.length ||
        empleados.some(
            empleado =>
                !empleado.active &&
                !existentes.has(empleado.id)
        )
    ) {
        fail(
            'Un participante no existe o está inactivo. ' +
            'Actualiza la selección.'
        );
    }

    await cliente.query(
        `
        DELETE FROM public.kc_rrhh_capacitacion_participantes
        WHERE capacitacion_id = $1
        `,
        [id]
    );

    for (const participante of datos) {
        await cliente.query(
            `
            INSERT INTO public.kc_rrhh_capacitacion_participantes (
                capacitacion_id,
                empleado_id,
                asistencia
            )
            VALUES ($1, $2, $3)
            `,
            [
                id,
                participante.empleado_id,
                participante.asistencia
            ]
        );
    }
}

// Consulta empleados de la fuente compartida con Contabilidad.
router.get('/empleados', handle(async (
    peticion,
    respuesta
) => {
    const buscar = text(
        peticion.query.buscar ?? '',
        'Búsqueda',
        100,
        false
    ) ?? '';

    const resultado = await pool.query(
        `
        SELECT
            id,
            full_name AS nombre,
            position AS cargo
        FROM public.kc_employees
        WHERE active
          AND (
              STRPOS(lower(full_name), lower($1)) > 0
              OR STRPOS(lower(position), lower($1)) > 0
          )
        ORDER BY full_name, id
        LIMIT 50
        `,
        [buscar]
    );

    respuesta.json(resultado.rows);
}));

router.get('/capacitaciones', handle(async (
    peticion,
    respuesta
) => {
    const { desde, hasta } = periodo(peticion.query);

    const pagina = Number(
        peticion.query.pagina ?? 1
    );

    if (
        !Number.isSafeInteger(pagina) ||
        pagina < 1 ||
        pagina > 100000
    ) {
        fail('Página inválida.');
    }

    respuesta.json(
        await lectura(async cliente => {
            const total = (
                await cliente.query(
                    `
                    SELECT COUNT(*)::text AS total
                    FROM public.kc_rrhh_capacitaciones
                    WHERE activo
                      AND fecha BETWEEN $1::date AND $2::date
                    `,
                    [desde, hasta]
                )
            ).rows[0].total;

            const filas = (
                await cliente.query(
                    `
                    SELECT
                        c.id,
                        c.titulo,
                        TO_CHAR(c.fecha, 'YYYY-MM-DD') AS fecha,
                        c.tipo,
                        c.estado,
                        c.version,
                        (
                            SELECT COUNT(*)::text
                            FROM public.kc_rrhh_capacitacion_participantes p
                            WHERE p.capacitacion_id = c.id
                        ) AS participantes
                    FROM public.kc_rrhh_capacitaciones c
                    WHERE c.activo
                      AND c.fecha BETWEEN $1::date AND $2::date
                    ORDER BY c.fecha DESC, c.id DESC
                    LIMIT 50 OFFSET $3
                    `,
                    [desde, hasta, (pagina - 1) * 50]
                )
            ).rows;

            return { filas, total, pagina };
        })
    );
}));

router.get('/capacitaciones/:id', handle(async (
    peticion,
    respuesta
) => {
    const id = identificador(peticion.params.id);

    respuesta.json(
        await lectura(async cliente => {
            const capacitacion = (
                await cliente.query(
                    `
                    SELECT
                        id,
                        titulo,
                        TO_CHAR(fecha, 'YYYY-MM-DD') AS fecha,
                        tipo,
                        estado,
                        descripcion,
                        version
                    FROM public.kc_rrhh_capacitaciones
                    WHERE id = $1
                      AND activo
                    `,
                    [id]
                )
            ).rows[0];

            if (!capacitacion) {
                fail('Capacitación no encontrada.', 404);
            }

            capacitacion.participantes = (
                await cliente.query(
                    `
                    SELECT
                        p.empleado_id,
                        p.asistencia,
                        e.full_name AS nombre
                    FROM public.kc_rrhh_capacitacion_participantes p
                    JOIN public.kc_employees e
                        ON e.id = p.empleado_id
                    WHERE p.capacitacion_id = $1
                    ORDER BY e.full_name, e.id
                    `,
                    [id]
                )
            ).rows;

            return capacitacion;
        })
    );
}));

router.post(
    '/capacitaciones',
    administrador,
    handle(async (peticion, respuesta) => {
        const datos = entrada(peticion.body);
        const clave = peticion.body.request_key;

        if (
            typeof clave !== 'string' ||
            !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(clave)
        ) {
            fail('Clave de solicitud inválida.');
        }

        const huella = crypto
            .createHash('sha256')
            .update(JSON.stringify(datos))
            .digest('hex');

        const resultado = await transaction(
            peticion.user.id,
            async cliente => {
                const creada = (
                    await cliente.query(
                        `
                        INSERT INTO public.kc_rrhh_capacitaciones (
                            titulo,
                            fecha,
                            tipo,
                            estado,
                            descripcion,
                            request_key,
                            request_hash,
                            creado_por
                        )
                        VALUES (
                            $1, $2, $3, $4,
                            $5, $6, $7, $8
                        )
                        ON CONFLICT(request_key)
                            DO NOTHING
                        RETURNING id, version
                        `,
                        [
                            datos.titulo,
                            datos.fecha,
                            datos.tipo,
                            datos.estado,
                            datos.descripcion,
                            clave,
                            huella,
                            peticion.user.id
                        ]
                    )
                ).rows[0];

                if (!creada) {
                    const anterior = (
                        await cliente.query(
                            `
                            SELECT
                                id,
                                version,
                                request_hash,
                                creado_por
                            FROM public.kc_rrhh_capacitaciones
                            WHERE request_key = $1
                            `,
                            [clave]
                        )
                    ).rows[0];

                    if (
                        !anterior ||
                        anterior.request_hash !== huella ||
                        anterior.creado_por !== peticion.user.id
                    ) {
                        fail(
                            'Esta clave corresponde a otra solicitud.',
                            409
                        );
                    }

                    return {
                        id: anterior.id,
                        version: anterior.version,
                        repetida: true
                    };
                }

                await guardarParticipantes(
                    cliente,
                    creada.id,
                    datos.participantes
                );

                await auditar(
                    cliente,
                    peticion.user.id,
                    'CAPACITACION_CREAR',
                    creada.id,
                    datos
                );

                return creada;
            }
        );

        respuesta
            .status(resultado.repetida ? 200 : 201)
            .json(resultado);
    })
);

for (const metodo of ['put', 'delete']) {
    router[metodo](
        '/capacitaciones/:id',
        administrador,
        handle(async (peticion, respuesta) => {
            const id = identificador(peticion.params.id);
            const version = peticion.body?.version;

            if (
                !Number.isSafeInteger(version) ||
                version < 1
            ) {
                fail('Versión inválida.');
            }

            const datos =
                metodo === 'put'
                    ? entrada(peticion.body)
                    : null;

            const resultado = await transaction(
                peticion.user.id,
                async cliente => {
                    const anterior = (
                        await cliente.query(
                            `
                            SELECT *
                            FROM public.kc_rrhh_capacitaciones
                            WHERE id = $1
                              AND activo
                            FOR UPDATE
                            `,
                            [id]
                        )
                    ).rows[0];

                    if (!anterior) {
                        fail(
                            'Capacitación no encontrada.',
                            404
                        );
                    }

                    if (anterior.version !== version) {
                        fail(
                            'Otro usuario modificó esta capacitación. ' +
                            'Actualiza antes de guardar.',
                            409
                        );
                    }

                    const asistenciaAnterior = (
                        await cliente.query(
                            `
                            SELECT empleado_id, asistencia
                            FROM public.kc_rrhh_capacitacion_participantes
                            WHERE capacitacion_id = $1
                            `,
                            [id]
                        )
                    ).rows;

                    if (metodo === 'delete') {
                        await cliente.query(
                            `
                            UPDATE public.kc_rrhh_capacitaciones
                            SET activo = FALSE,
                                version = version + 1,
                                actualizado_en = now()
                            WHERE id = $1
                            `,
                            [id]
                        );
                    } else {
                        await guardarParticipantes(
                            cliente,
                            id,
                            datos.participantes
                        );

                        await cliente.query(
                            `
                            UPDATE public.kc_rrhh_capacitaciones
                            SET titulo = $1,
                                fecha = $2,
                                tipo = $3,
                                estado = $4,
                                descripcion = $5,
                                version = version + 1,
                                actualizado_en = now()
                            WHERE id = $6
                            `,
                            [
                                datos.titulo,
                                datos.fecha,
                                datos.tipo,
                                datos.estado,
                                datos.descripcion,
                                id
                            ]
                        );
                    }

                    await auditar(
                        cliente,
                        peticion.user.id,

                        metodo === 'delete'
                            ? 'CAPACITACION_RETIRAR'
                            : 'CAPACITACION_EDITAR',

                        id,
                        {
                            anterior: {
                                titulo: anterior.titulo,
                                fecha: anterior.fecha,
                                estado: anterior.estado,
                                participantes: asistenciaAnterior
                            },

                            nuevo: datos
                        }
                    );

                    return {
                        id,
                        version: version + 1
                    };
                }
            );

            respuesta.json(resultado);
        })
    );
}

router.get('/cumplimiento', handle(async (
    peticion,
    respuesta
) => {
    const { desde, hasta } = periodo(peticion.query);

    respuesta.json(
        await lectura(async cliente => {
            const parametros = [desde, hasta];

            const capacitaciones = (
                await cliente.query(
                    `
                    SELECT
                        COUNT(*) FILTER (
                            WHERE estado <> 'cancelada'
                        )::text AS previstas,

                        COUNT(*) FILTER (
                            WHERE estado = 'realizada'
                        )::text AS realizadas,

                        COUNT(*) FILTER (
                            WHERE estado = 'cancelada'
                        )::text AS canceladas

                    FROM public.kc_rrhh_capacitaciones

                    WHERE activo
                      AND fecha BETWEEN $1::date AND $2::date
                    `,
                    parametros
                )
            ).rows[0];

            // Cuenta una sola vez cada día por empleado,
            // incluso si existen incapacidades solapadas.
            const incapacidad = (
                await cliente.query(
                    `
                    SELECT
                        COUNT(
                            DISTINCT (
                                i.empleado_id,
                                d.dia::date
                            )
                        )::text AS dias

                    FROM public.kc_rrhh_incidencias i

                    CROSS JOIN LATERAL generate_series(
                        GREATEST(
                            i.desde,
                            $1::date
                        )::timestamp,

                        LEAST(
                            i.hasta,
                            $2::date
                        )::timestamp,

                        INTERVAL '1 day'
                    ) d(dia)

                    WHERE i.activo
                      AND i.tipo = 'incapacidad'
                      AND i.estado = 'aprobada'
                      AND i.desde <= $2::date
                      AND i.hasta >= $1::date
                    `,
                    parametros
                )
            ).rows[0];

            const incidentes = (
                await cliente.query(
                    `
                    SELECT
                        TO_CHAR(
                            created_at AT TIME ZONE 'America/Managua',
                            'YYYY-MM'
                        ) AS mes,

                        COUNT(*)::text AS cantidad

                    FROM public.kc_business_records

                    WHERE kind = 'incident'
                      AND status <> 'archived'
                      AND (
                          created_at AT TIME ZONE 'America/Managua'
                      )::date BETWEEN $1::date AND $2::date

                    GROUP BY 1
                    ORDER BY 1
                    `,
                    parametros
                )
            ).rows;

            const empleados = (
                await cliente.query(
                    `
                    SELECT id, full_name AS nombre
                    FROM public.kc_employees
                    WHERE active
                    ORDER BY full_name, id
                    `
                )
            ).rows;

            const contratos = (
                await cliente.query(
                    `
                    SELECT DISTINCT ON(employee_id)
                        employee_id,
                        data
                    FROM public.kc_business_records
                    WHERE kind = 'contract'
                      AND status <> 'archived'
                      AND employee_id IS NOT NULL
                    ORDER BY
                        employee_id,
                        created_at DESC,
                        id DESC
                    `
                )
            ).rows;

            const anteriores = (
                await cliente.query(
                    `
                    SELECT DISTINCT ON(v.empleado_id)
                        v.empleado_id AS employee_id,
                        TO_CHAR(
                            c.fecha_fin,
                            'YYYY-MM-DD'
                        ) AS fecha_fin

                    FROM public.kc_rrhh_vinculos v

                    JOIN public.contratos c
                        ON c.empleado_id = v.empleado_anterior_id

                    WHERE lower(
                        btrim(COALESCE(c.estado, ''))
                    ) NOT IN (
                        'cancelado',
                        'anulado',
                        'inactivo'
                    )

                    ORDER BY
                        v.empleado_id,
                        c.fecha_inicio DESC,
                        c.id DESC
                    `
                )
            ).rows;

            const mapa = new Map(
                anteriores.map(contrato => [
                    contrato.employee_id,
                    {
                        fecha_fin: contrato.fecha_fin,
                        origen: 'anterior vinculado'
                    }
                ])
            );

            for (const contrato of contratos) {
                mapa.set(contrato.employee_id, {
                    fecha_fin:
                        contrato.data?.fecha_fin ??
                        contrato.data?.end_date ??
                        null,

                    origen:
                        'registro integrado'
                });
            }

            const alertas = empleados.map(empleado => {
                const contrato = mapa.get(empleado.id);

                if (!contrato) {
                    return {
                        ...empleado,
                        estado: 'Sin registro contractual',
                        origen: 'sin vínculo',
                        fecha_fin: null
                    };
                }

                const fin = fechaValida(contrato.fecha_fin)
                    ? contrato.fecha_fin
                    : null;

                let estado =
                    'Revisar vigencia: fecha final no registrada';

                if (fin) {
                    const distancia = (
                        Date.parse(fin + 'T00:00:00Z') -
                        Date.parse(hasta + 'T00:00:00Z')
                    ) / 86400000;

                    estado = distancia < 0
                        ? 'Fecha final vencida'
                        : distancia <= 30
                            ? 'Fecha final en próximos 30 días'
                            : 'Fecha final posterior a 30 días';
                }

                return {
                    ...empleado,
                    estado,
                    fecha_fin: fin,
                    origen: contrato.origen
                };
            });

            const sinVincular = (
                await cliente.query(
                    `
                    SELECT COUNT(*)::text AS total
                    FROM public.empleados e
                    WHERE NOT EXISTS (
                        SELECT 1
                        FROM public.kc_rrhh_vinculos v
                        WHERE v.empleado_anterior_id = e.id
                    )
                    `
                )
            ).rows[0].total;

            return {
                desde,
                hasta,
                capacitaciones,

                dias_incapacidad:
                    incapacidad.dias,

                incidentes,

                plantilla_actual:
                    empleados.length,

                contratos:
                    alertas,

                sin_vincular:
                    sinVincular,

                alcance:
                    'Seguimiento interno. Incapacidades: días ' +
                    'calendario aprobados, sin duplicar ' +
                    'solapamientos por empleado. Incidentes: ' +
                    'fecha de registro. Plantilla: estado actual. ' +
                    'La falta de fecha final no determina ' +
                    'incumplimiento ni se interpreta como ' +
                    'vencimiento. Los registros anteriores solo ' +
                    'se relacionan mediante vínculos explícitos.'
            };
        })
    );
}));

const esquema = {
    users: [
        'id',
        'role',
        'active'
    ],

    audit_log: [
        'created_at'
    ],

    caja: [
        'id',
        'mon',
        'tip',
        'shift_id',
        'sale_id',
        'recarga_id',
        'expense_id',
        'print_payment_id'
    ],

    sales: [
        'id',
        'request_hash'
    ],

    recargas: [
        'id',
        'request_hash'
    ],

    cash_expenses: [
        'id',
        'date',
        'request_hash'
    ],

    print_job_payments: [
        'id',
        'request_hash'
    ],

    products: [
        'id',
        'stock',
        'avg_cost'
    ],

    kardex_movements: [
        'id',
        'product_id',
        'balance_qty',
        'balance_avg_cost',
        'date'
    ],

    kc_journals: [
        'id',
        'movement_id'
    ],

    kc_journal_lines: [
        'journal_id',
        'debit',
        'credit'
    ],

    kc_business_records: [
        'kind',
        'data',
        'version'
    ],

    kc_rrhh_expedientes: [
        'empleado_id',
        'reservados'
    ],

    kc_rrhh_vinculos: [
        'empleado_id'
    ],

    kc_rrhh_incidencias: [
        'empleado_id'
    ],

    kc_rrhh_capacitaciones: [
        'fecha',
        'request_hash'
    ],

    kc_archivos_privados: [
        'id',
        'huella'
    ]
};

const comprobaciones = [
    {
        nombre:
            'Asientos descuadrados o sin líneas',

        tablas:
            ['kc_journals', 'kc_journal_lines'],

        sql: `
            SELECT COUNT(*)::text AS cantidad
            FROM (
                SELECT j.id
                FROM public.kc_journals j
                LEFT JOIN public.kc_journal_lines l
                    ON l.journal_id = j.id
                GROUP BY j.id
                HAVING COUNT(l.journal_id) = 0
                    OR COALESCE(
                        SUM(l.debit - l.credit),
                        0
                    ) <> 0
            ) q
        `
    },
    {
        nombre:
            'Productos con existencias negativas',

        tablas:
            ['products'],

        sql: `
            SELECT COUNT(*)::text AS cantidad
            FROM public.products
            WHERE stock < 0
        `
    },
    {
        nombre:
            'Productos con diferencias frente al último Kardex',

        tablas:
            ['products', 'kardex_movements'],

        sql: `
            SELECT COUNT(*)::text AS cantidad
            FROM public.products p

            JOIN LATERAL (
                SELECT balance_qty, balance_avg_cost
                FROM public.kardex_movements
                WHERE product_id = p.id
                ORDER BY date DESC NULLS LAST, id DESC
                LIMIT 1
            ) k ON TRUE

            WHERE p.stock IS DISTINCT FROM k.balance_qty
               OR p.avg_cost IS DISTINCT FROM k.balance_avg_cost
        `
    },
    {
        nombre:
            'Movimientos de caja sin asiento asociado',

        tablas:
            ['caja', 'kc_journals'],

        sql: `
            SELECT COUNT(*)::text AS cantidad
            FROM public.caja c
            WHERE NOT EXISTS (
                SELECT 1
                FROM public.kc_journals j
                WHERE j.movement_id = c.id
            )
        `
    },

    ...[
        ['sales', 'sale_id', 'Ventas'],
        ['recargas', 'recarga_id', 'Recargas'],
        ['cash_expenses', 'expense_id', 'Gastos'],
        [
            'print_job_payments',
            'print_payment_id',
            'Cobros de impresión'
        ]
    ].flatMap(([tabla, enlace, titulo]) => [
        {
            nombre:
                titulo + ' sin movimiento de caja',

            tablas:
                [tabla, 'caja'],

            sql: `
                SELECT COUNT(*)::text AS cantidad
                FROM public.${tabla} d
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM public.caja c
                    WHERE c.${enlace} = d.id
                )
            `
        },
        {
            nombre:
                titulo + ' con huella pendiente de revisión',

            tablas:
                [tabla],

            sql: `
                SELECT COUNT(*)::text AS cantidad
                FROM public.${tabla}
                WHERE request_hash IS NULL
                   OR request_hash !~ '^[0-9a-f]{64}$'
            `
        }
    ])
];

router.get('/diagnostico', handle(async (
    peticion,
    respuesta
) => {
    respuesta.json(
        await lectura(async cliente => {
            await cliente.query(
                "SET LOCAL statement_timeout = '15s'"
            );

            const columnas = (
                await cliente.query(
                    `
                    SELECT table_name, column_name
                    FROM information_schema.columns
                    WHERE table_schema = 'public'
                      AND table_name = ANY($1::text[])
                    `,
                    [Object.keys(esquema)]
                )
            ).rows;

            const faltantes = Object.entries(esquema)
                .flatMap(([tabla, campos]) =>
                    campos
                        .filter(campo =>
                            !columnas.some(columna =>
                                columna.table_name === tabla &&
                                columna.column_name === campo
                            )
                        )
                        .map(campo => tabla + '.' + campo)
                );

            const controles = [];

            for (const control of comprobaciones) {
                const estructuraIncompleta =
                    control.tablas.some(tabla =>
                        faltantes.some(campo =>
                            campo.startsWith(tabla + '.')
                        )
                    );

                if (estructuraIncompleta) {
                    controles.push({
                        nombre: control.nombre,
                        estado: 'no_evaluado',
                        cantidad: null
                    });

                    continue;
                }

                await cliente.query('SAVEPOINT control');

                try {
                    const fila = (
                        await cliente.query(control.sql)
                    ).rows[0];

                    controles.push({
                        nombre: control.nombre,

                        estado:
                            fila.cantidad === '0'
                                ? 'correcto'
                                : 'revisar',

                        cantidad:
                            fila.cantidad
                    });

                    await cliente.query(
                        'RELEASE SAVEPOINT control'
                    );
                } catch (error) {
                    await cliente.query(
                        'ROLLBACK TO SAVEPOINT control'
                    );

                    await cliente.query(
                        'RELEASE SAVEPOINT control'
                    );

                    controles.push({
                        nombre: control.nombre,
                        estado: 'error',
                        cantidad: null,

                        codigo:
                            error.code ?? 'CONSULTA_ERROR'
                    });
                }
            }

            return {
                generado_en:
                    new Date().toISOString(),

                faltantes,
                controles,

                alcance:
                    'Comprobaciones de lectura. Las alertas pueden ' +
                    'corresponder a registros anteriores a las ' +
                    'migraciones. No se crean asientos, pagos, ' +
                    'claves ni huellas para corregirlas ' +
                    'automáticamente.'
            };
        })
    );
}));

module.exports = router;