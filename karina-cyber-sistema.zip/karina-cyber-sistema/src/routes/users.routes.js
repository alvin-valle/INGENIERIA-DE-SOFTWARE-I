'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');

const pool = require('../db/connection');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const router = express.Router();

// requireRole permite también al superadministrador.
router.use(requireAuth, requireRole('admin'));

const ROLES = new Set([
  'superadmin',
  'admin',
  'cajero',
  'auditor',
  'invitado'
]);

const OPERATIONAL_ROLES = new Set([
  'cajero',
  'auditor',
  'invitado'
]);

const PUBLIC_COLUMNS =
  'id, username, full_name, role, active';

// ============================================================
// VALIDACIÓN
// ============================================================

function fail(status, message) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function idValue(value) {
  const text = String(value);
  const id = Number(text);

  if (
    !/^[1-9]\d*$/.test(text) ||
    !Number.isInteger(id) ||
    id > 2147483647
  ) {
    fail(400, 'Identificador de usuario inválido.');
  }

  return id;
}

function bodyValue(body) {
  if (
    !body ||
    typeof body !== 'object' ||
    Array.isArray(body)
  ) {
    fail(
      400,
      'Envía los datos del usuario como un objeto JSON.'
    );
  }

  const allowed = new Set([
    'username',
    'full_name',
    'role',
    'active',
    'password',
    'current_password'
  ]);

  if (
    Object.keys(body).some(key => !allowed.has(key))
  ) {
    fail(
      400,
      'La solicitud contiene campos no admitidos.'
    );
  }

  return body;
}

function usernameValue(value) {
  if (
    typeof value !== 'string' ||
    !/^[A-Za-z0-9._-]{3,50}$/.test(value.trim())
  ) {
    fail(
      400,
      'El usuario debe tener entre 3 y 50 caracteres: ' +
      'letras, números, punto, guion o guion bajo.'
    );
  }

  return value.trim();
}

function nameValue(value) {
  if (
    typeof value !== 'string' ||
    !value.trim() ||
    value.trim().length > 100 ||
    /[\u0000-\u001f]/.test(value)
  ) {
    fail(
      400,
      'El nombre completo debe tener entre 1 y 100 caracteres.'
    );
  }

  return value.trim();
}

function roleValue(value) {
  if (!ROLES.has(value)) {
    fail(400, 'Selecciona un rol válido.');
  }

  return value;
}

function activeValue(value) {
  // Compatible con la pantalla actual, que envía 0 o 1.
  if (value === true || value === 1) {
    return true;
  }

  if (value === false || value === 0) {
    return false;
  }

  fail(
    400,
    'El estado debe ser true, false, 1 o 0.'
  );
}

function passwordValue(value) {
  if (
    typeof value !== 'string' ||
    [...value].length < 12 ||
    !value.trim() ||
    Buffer.byteLength(value, 'utf8') > 72
  ) {
    fail(
      400,
      'La contraseña nueva debe tener al menos ' +
      '12 caracteres y no superar 72 bytes.'
    );
  }

  return value;
}

function publicUser(row) {
  // No devolver contraseñas ni hashes al navegador.
  return {
    id: row.id,
    username: row.username,
    full_name: row.full_name,
    role: row.role,
    active: row.active,
    created_at: row.created_at ?? null
  };
}

// ============================================================
// MANEJO DE ERRORES
// Compatible con Express 4.
// ============================================================

function handle(action) {
  return async (req, res) => {
    try {
      await action(req, res);
    } catch (error) {
      if (
        error.status &&
        error.status >= 400 &&
        error.status < 500
      ) {
        return res.status(error.status).json({
          error: error.message
        });
      }

      if (error.code === '23505') {
        return res.status(409).json({
          error:
            'Ya existe un usuario con ese nombre.'
        });
      }

      console.error(
        '[Usuarios]',
        error.code || error.name
      );

      return res.status(500).json({
        error:
          'No se pudo completar la operación de usuarios.'
      });
    }
  };
}

// ============================================================
// TRANSACCIONES
//
// Todas las modificaciones de este módulo comparten un bloqueo.
// Evita que dos solicitudes retiren simultáneamente
// a los últimos superadministradores.
//
// No crea ni modifica tablas.
// ============================================================

async function transaction(action) {
  const client = await pool.connect();
  let begun = false;

  try {
    await client.query('BEGIN');
    begun = true;

    await client.query(
      'SELECT pg_advisory_xact_lock($1, $2)',
      [748231, 1]
    );

    const result = await action(client);

    await client.query('COMMIT');
    begun = false;

    return result;
  } catch (error) {
    if (begun) {
      try {
        await client.query('ROLLBACK');
      } catch (rollbackError) {
        console.error(
          '[Usuarios: rollback]',
          rollbackError.code || rollbackError.name
        );
      }
    }

    throw error;
  } finally {
    client.release();
  }
}

// ============================================================
// AUTORIZACIÓN DE MODIFICACIONES
// ============================================================

async function currentActor(client, id) {
  const result = await client.query(
    `
    SELECT ${PUBLIC_COLUMNS}
    FROM public.users
    WHERE id = $1
    FOR UPDATE
    `,
    [id]
  );

  const actor = result.rows[0];

  if (!actor || actor.active !== true) {
    fail(
      401,
      'Tu cuenta no está disponible. Inicia sesión nuevamente.'
    );
  }

  if (
    !['admin', 'superadmin'].includes(actor.role)
  ) {
    fail(
      403,
      'Ya no tienes permisos para administrar usuarios.'
    );
  }

  return actor;
}

function checkManagement(actor, target, newRole) {
  if (actor.role === 'superadmin') {
    return;
  }

  const isSelf =
    target &&
    Number(target.id) === Number(actor.id);

  if (isSelf) {
    if (newRole !== actor.role) {
      fail(
        403,
        'No puedes cambiar tu propio rol.'
      );
    }

    return;
  }

  if (
    target &&
    !OPERATIONAL_ROLES.has(target.role)
  ) {
    fail(
      403,
      'Solo un superadministrador puede modificar ' +
      'otras cuentas administrativas.'
    );
  }

  if (!OPERATIONAL_ROLES.has(newRole)) {
    fail(
      403,
      'Solo un superadministrador puede asignar ' +
      'roles administrativos.'
    );
  }
}

async function checkUsername(
  client,
  username,
  excludedId = 0
) {
  const result = await client.query(
    `
    SELECT id
    FROM public.users
    WHERE lower(username) = lower($1)
      AND id <> $2
    LIMIT 1
    `,
    [username, excludedId]
  );

  if (result.rows.length) {
    fail(
      409,
      'Ya existe un usuario con ese nombre.'
    );
  }
}

// ============================================================
// GET /api/users
// CONSULTAR USUARIOS
// ============================================================

router.get('/', handle(async (req, res) => {
  const result = await pool.query(
    `
    SELECT
      u.id,
      u.username,
      u.full_name,
      u.role,
      u.active,
      to_jsonb(u)->>'created_at' AS created_at
    FROM public.users u
    ORDER BY u.full_name, u.id
    `
  );

  // Si created_at todavía no existe, devuelve null.
  // No se inventa una fecha de creación.
  res.json(result.rows.map(publicUser));
}));

// ============================================================
// GET /api/users/:id
// CONSULTAR UN USUARIO
// ============================================================

router.get('/:id', handle(async (req, res) => {
  const result = await pool.query(
    `
    SELECT
      u.id,
      u.username,
      u.full_name,
      u.role,
      u.active,
      to_jsonb(u)->>'created_at' AS created_at
    FROM public.users u
    WHERE u.id = $1
    `,
    [idValue(req.params.id)]
  );

  if (!result.rows[0]) {
    fail(404, 'Usuario no encontrado.');
  }

  res.json(publicUser(result.rows[0]));
}));

// ============================================================
// POST /api/users
// CREAR USUARIO
// ============================================================

router.post('/', handle(async (req, res) => {
  const body = bodyValue(req.body);

  const username = usernameValue(body.username);
  const fullName = nameValue(body.full_name);
  const role = roleValue(body.role);

  const active = Object.hasOwn(body, 'active')
    ? activeValue(body.active)
    : true;

  const hash = await bcrypt.hash(
    passwordValue(body.password),
    12
  );

  const user = await transaction(async client => {
    const actor = await currentActor(
      client,
      req.user.id
    );

    checkManagement(actor, null, role);

    await checkUsername(client, username);

    const result = await client.query(
      `
      INSERT INTO public.users (
        username,
        full_name,
        password_hash,
        role,
        active
      )
      VALUES ($1, $2, $3, $4, $5)
      RETURNING ${PUBLIC_COLUMNS}
      `,
      [
        username,
        fullName,
        hash,
        role,
        active
      ]
    );

    return publicUser(result.rows[0]);
  });

  res.status(201).json({
    ok: true,
    id: user.id,
    user
  });
}));

// ============================================================
// EDICIÓN Y BAJA LÓGICA
// ============================================================

async function modifyUser(req, deactivateOnly) {
  const id = idValue(req.params.id);

  const body = deactivateOnly
    ? { active: false }
    : bodyValue(req.body);

  const has = key => Object.hasOwn(body, key);

  const editableFields = [
    'username',
    'full_name',
    'role',
    'active',
    'password'
  ];

  if (!editableFields.some(has)) {
    fail(400, 'No hay cambios para guardar.');
  }

  const changes = {};

  if (has('username')) {
    changes.username = usernameValue(body.username);
  }

  if (has('full_name')) {
    changes.full_name = nameValue(body.full_name);
  }

  if (has('role')) {
    changes.role = roleValue(body.role);
  }

  if (has('active')) {
    changes.active = activeValue(body.active);
  }

  const passwordHash = has('password')
    ? await bcrypt.hash(
        passwordValue(body.password),
        12
      )
    : null;

  return transaction(async client => {
    const actor = await currentActor(
      client,
      req.user.id
    );

    const result = await client.query(
      `
      SELECT
        ${PUBLIC_COLUMNS},
        password_hash
      FROM public.users
      WHERE id = $1
      FOR UPDATE
      `,
      [id]
    );

    const target = result.rows[0];

    if (!target) {
      fail(404, 'Usuario no encontrado.');
    }

    const updated = {
      ...target,
      ...changes
    };

    checkManagement(
      actor,
      target,
      updated.role
    );

    const isSelf = Number(actor.id) === id;

    if (
      isSelf &&
      (
        updated.active !== true ||
        updated.role !== target.role
      )
    ) {
      fail(
        409,
        'No puedes desactivar tu cuenta ni cambiar tu propio rol.'
      );
    }

    // Para cambiar la contraseña propia se solicita
    // también la contraseña actual.
    if (isSelf && passwordHash) {
      const current = body.current_password;

      if (
        typeof current !== 'string' ||
        !current ||
        Buffer.byteLength(current, 'utf8') > 72 ||
        !await bcrypt.compare(
          current,
          target.password_hash
        )
      ) {
        fail(
          400,
          'Para cambiar tu contraseña debes indicar ' +
          'la contraseña actual correcta.'
        );
      }
    }

    const removesActiveSuperadmin =
      target.role === 'superadmin' &&
      target.active === true &&
      (
        updated.role !== 'superadmin' ||
        updated.active !== true
      );

    if (removesActiveSuperadmin) {
      const remaining = await client.query(
        `
        SELECT COUNT(*)::integer AS total
        FROM public.users
        WHERE role = 'superadmin'
          AND active = TRUE
          AND id <> $1
        `,
        [id]
      );

      if (remaining.rows[0].total < 1) {
        fail(
          409,
          'Debe permanecer al menos un superadministrador activo.'
        );
      }
    }

    if (has('username')) {
      await checkUsername(
        client,
        updated.username,
        id
      );
    }

    const saved = await client.query(
      `
      UPDATE public.users
      SET
        username = $1,
        full_name = $2,
        role = $3,
        active = $4,
        password_hash = $5
      WHERE id = $6
      RETURNING ${PUBLIC_COLUMNS}
      `,
      [
        updated.username,
        updated.full_name,
        updated.role,
        updated.active,
        passwordHash || target.password_hash,
        id
      ]
    );

    return publicUser(saved.rows[0]);
  });
}

// ============================================================
// PATCH /api/users/:id
// EDITAR DATOS, ROL, ESTADO O CONTRASEÑA
// ============================================================

router.patch('/:id', handle(async (req, res) => {
  const user = await modifyUser(req, false);

  res.json({
    ok: true,
    id: user.id,
    user
  });
}));

// ============================================================
// DELETE /api/users/:id
// DESACTIVAR SIN BORRAR HISTORIAL
// ============================================================

router.delete('/:id', handle(async (req, res) => {
  const user = await modifyUser(req, true);

  res.json({
    ok: true,
    id: user.id,
    user
  });
}));

module.exports = router;