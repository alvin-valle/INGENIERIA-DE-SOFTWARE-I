'use strict';

const express = require('express');
const pool = require('../db/connection');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const cash = require('../services/cash.service');

// Evita que el driver interprete los TIMESTAMP sin zona
// usando la zona horaria de Windows.
// Solo identificamos como UTC los registros del nuevo flujo.
const SHIFT_TIMES = `
  to_char(
    cs.created_at,
    'YYYY-MM-DD"T"HH24:MI:SS.US'
  ) ||
    CASE
      WHEN cs.request_key IS NOT NULL THEN 'Z'
      ELSE ''
    END AS created_at,

  to_char(
    cs.closed_at,
    'YYYY-MM-DD"T"HH24:MI:SS.US'
  ) ||
    CASE
      WHEN cs.close_request_key IS NOT NULL THEN 'Z'
      ELSE ''
    END AS closed_at
`;

const EXPENSE_TIME = `
  to_char(
    e.date,
    'YYYY-MM-DD"T"HH24:MI:SS.US'
  ) ||
    CASE
      WHEN e.request_key IS NOT NULL THEN 'Z'
      ELSE ''
    END AS date
`;

const router = express.Router();

router.use(requireAuth);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

const canWrite = requireRole('admin', 'cajero');

const canReadAll = user => {
  return [
    'superadmin',
    'admin',
    'auditor',
    'invitado'
  ].includes(user.role);
};

// ============================================================
// VALIDACIÓN Y ERRORES
// ============================================================

function fail(
  message,
  code = 'FINANZAS_VALIDACION',
  status = 400,
  details
) {
  const error = new Error(message);

  Object.assign(error, {
    code,
    status,
    details
  });

  throw error;
}

function route(work) {
  return async (req, res) => {
    try {
      await work(req, res);
    } catch (error) {
      if (res.headersSent) return;

      let status =
        Number.isInteger(error.status) &&
        error.status >= 400 &&
        error.status <= 599
          ? error.status
          : 500;

      let code = error.code || 'FINANZAS_ERROR';
      let message = error.message;

      if (error.code === '23505') {
        status = 409;
        code = 'FINANZAS_CONFLICTO';

        message =
          error.constraint === 'kc_cash_shifts_one_open'
            ? 'Ya existe un turno abierto para este cajero.'
            : 'La operación entra en conflicto con un registro existente.';
      }

      if (status >= 500) {
        console.error(
          '[Finanzas]',
          error.code,
          error.cause?.code || ''
        );

        if (!error.status) {
          message = 'No se pudo completar la operación financiera.';
        }
      }

      res.status(status).json({
        error: message,
        code,

        ...(
          error.details && status < 500
            ? { details: error.details }
            : {}
        )
      });
    }
  };
}

function bodyOf(req, allowed) {
  const body = req.body ?? {};

  if (
    !body ||
    typeof body !== 'object' ||
    Array.isArray(body)
  ) {
    fail('Envía un objeto JSON válido.');
  }

  if (
    Object.keys(body).some(
      key => !allowed.includes(key)
    )
  ) {
    fail('La solicitud contiene campos no admitidos.');
  }

  return body;
}

function text(
  value,
  label,
  max,
  optional = false
) {
  if (optional && value == null) return null;

  if (typeof value !== 'string') {
    fail(`${label}: indica un texto válido.`);
  }

  const result = value.trim();

  if (
    (!result && !optional) ||
    result.length > max ||
    /[\u0000-\u001f\u007f]/.test(result)
  ) {
    fail(
      `${label}: usa hasta ${max} caracteres, sin saltos de línea.`
    );
  }

  return result || null;
}

function operationKey(req, body) {
  const header = req.get('Idempotency-Key');

  const key = cash.requestKey(
    header ?? body.request_key
  );

  if (
    header != null &&
    body.request_key != null &&
    key !== cash.requestKey(body.request_key)
  ) {
    fail(
      'Las claves de operación del encabezado y del cuerpo no coinciden.'
    );
  }

  return key;
}

function limitOf(value, fallback = 60) {
  if (value == null) return fallback;

  if (
    typeof value !== 'string' ||
    !/^\d{1,3}$/.test(value)
  ) {
    fail('El límite debe estar entre 1 y 200.');
  }

  const limit = Number(value);

  if (limit < 1 || limit > 200) {
    fail('El límite debe estar entre 1 y 200.');
  }

  return limit;
}

// ============================================================
// RESPUESTAS PÚBLICAS
// No exponemos los hashes de las solicitudes.
// ============================================================

function publicShift(row) {
  if (!row) return null;

  const numberOrNull = value => {
    return value == null ? null : Number(value);
  };

  return {
    id: row.id,
    cashier_id: row.cashier_id,
    cashier_name: row.cashier_name || null,
    status: row.status,

    created_at: row.created_at,
    opened_at: row.created_at,
    closed_at: row.closed_at,

    opening_amount: numberOrNull(row.opening_amount),

    closing_amount_system: numberOrNull(
      row.closing_amount_system
    ),

    closing_amount_counted: numberOrNull(
      row.closing_amount_counted
    ),

    difference: numberOrNull(row.difference),
    closed_by: row.closed_by ?? null,
    closing_note: row.closing_note ?? null,

    legacy_opening_time: row.request_key == null
  };
}

function publicExpense(row) {
  return {
    id: row.id,
    shift_id: row.shift_id,
    user_id: row.user_id,
    description: row.description,
    category: row.category,
    amount: Number(row.amount),
    date: row.date,
    payment_method: row.payment_method,
    payment_reference: row.payment_reference,
    user_name: row.user_name || null,

    legacy_date: row.request_key == null
  };
}

// ============================================================
// CONSULTAS Y AUDITORÍA
// ============================================================

// Mantiene una lectura coherente aunque se registre un cobro
// mientras se consulta la información.
async function readSnapshot(work) {
  const db = await pool.connect();
  let discard;

  try {
    await db.query(
      'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY'
    );

    await db.query(
      "SET LOCAL statement_timeout = '15s'"
    );

    const result = await work(db);

    await db.query('COMMIT');

    return result;
  } catch (error) {
    try {
      await db.query('ROLLBACK');
    } catch (rollbackError) {
      discard = rollbackError;
    }

    throw error;
  } finally {
    db.release(discard);
  }
}

async function loadShift(db, id) {
  const result = await db.query(
    `
    SELECT
      cs.*,
      ${SHIFT_TIMES},
      u.full_name AS cashier_name
    FROM public.cash_shifts cs
    LEFT JOIN public.users u
      ON u.id = cs.cashier_id
    WHERE cs.id = $1
    `,
    [id]
  );

  return result.rows[0];
}

async function audit(
  context,
  action,
  shiftId,
  details = {}
) {
  await context.db.query(
    `
    INSERT INTO public.audit_log (
      user_id,
      action,
      entity,
      details
    )
    VALUES (
      $1,
      $2,
      'cash_shifts',
      $3
    )
    `,
    [
      context.user.id,
      action,

      JSON.stringify({
        shift_id: shiftId,
        ...details
      })
    ]
  );
}

// La suma del turno puede superar el importe máximo
// admitido para una operación individual.
function sumCents(value) {
  if (
    typeof value !== 'string' ||
    !/^\d{1,24}(?:\.\d{1,2})?$/.test(value)
  ) {
    fail(
      'Se encontraron importes inválidos en caja.',
      'CAJA_IMPORTES_INVALIDOS',
      409
    );
  }

  const [whole, fraction = ''] = value.split('.');

  return (
    BigInt(whole) * 100n +
    BigInt(fraction.padEnd(2, '0'))
  );
}

// ============================================================
// CONCILIACIÓN DEL TURNO
//
// Comprueba:
// - Documentos sin movimiento.
// - Movimientos sin documento.
// - Diferencias de usuario, turno, importe o método de pago.
// - Solicitudes y referencias inconsistentes.
//
// Los registros históricos sin enlace no se asignan
// automáticamente ni se suman nuevamente.
// ============================================================

const SUMMARY_SQL = `

WITH local_movements AS (
  SELECT *
  FROM public.caja
  WHERE shift_id = $1
),

documents AS (
  SELECT
    'sale'::text AS kind,
    id,
    shift_id,
    cashier_id AS actor_id,
    total AS amount,
    payment_method AS method,
    payment_reference AS reference,
    request_key,
    request_hash
  FROM public.sales
  WHERE shift_id = $1
     OR id IN (
       SELECT sale_id FROM local_movements
     )

  UNION ALL

  SELECT
    'recarga',
    id,
    shift_id,
    cashier_id,
    monto,
    metodo_pago,
    payment_reference,
    request_key,
    request_hash
  FROM public.recargas
  WHERE shift_id = $1
     OR id IN (
       SELECT recarga_id FROM local_movements
     )

  UNION ALL

  SELECT
    'printing',
    id,
    shift_id,
    cashier_id,
    amount,
    payment_method,
    payment_reference,
    request_key,
    request_hash
  FROM public.print_job_payments
  WHERE shift_id = $1
     OR id IN (
       SELECT print_payment_id FROM local_movements
     )

  UNION ALL

  SELECT
    'expense',
    id,
    shift_id,
    user_id,
    amount,
    payment_method,
    payment_reference,
    request_key,
    request_hash
  FROM public.cash_expenses
  WHERE shift_id = $1
     OR id IN (
       SELECT expense_id FROM local_movements
     )
),

movements AS (
  SELECT
    c.*,

    CASE
      WHEN sale_id IS NOT NULL THEN 'sale'
      WHEN recarga_id IS NOT NULL THEN 'recarga'
      WHEN print_payment_id IS NOT NULL THEN 'printing'
      WHEN expense_id IS NOT NULL THEN 'expense'
      ELSE 'unknown'
    END AS kind,

    COALESCE(
      sale_id,
      recarga_id,
      print_payment_id,
      expense_id
    ) AS document_id

  FROM public.caja c

  WHERE shift_id = $1

     OR sale_id IN (
       SELECT id
       FROM documents
       WHERE kind = 'sale'
     )

     OR recarga_id IN (
       SELECT id
       FROM documents
       WHERE kind = 'recarga'
     )

     OR print_payment_id IN (
       SELECT id
       FROM documents
       WHERE kind = 'printing'
     )

     OR expense_id IN (
       SELECT id
       FROM documents
       WHERE kind = 'expense'
     )
),

checks AS (
  SELECT
    COUNT(*) FILTER (
      WHERE d.id IS NOT NULL
        AND c.id IS NULL
    ) AS missing,

    COUNT(*) FILTER (
      WHERE d.id IS NULL
        AND c.id IS NOT NULL
    ) AS unlinked,

    COUNT(*) FILTER (
      WHERE d.id IS NOT NULL
        AND c.id IS NOT NULL
        AND (
          d.shift_id IS DISTINCT FROM $1::int

          OR c.shift_id IS DISTINCT FROM $1::int

          OR d.actor_id IS DISTINCT FROM $2::int

          OR c.user_id IS DISTINCT FROM d.actor_id

          OR d.amount IS NULL
          OR d.amount <= 0
          OR d.amount = 'NaN'::numeric

          OR c.mon IS DISTINCT FROM d.amount

          OR d.method IS NULL

          OR LOWER(BTRIM(d.method)) NOT IN (
            'efectivo',
            'tarjeta',
            'transferencia'
          )

          OR LOWER(BTRIM(c.metodo_pago))
             IS DISTINCT FROM LOWER(BTRIM(d.method))

          OR NULLIF(BTRIM(c.referencia_pago), '')
             IS DISTINCT FROM NULLIF(BTRIM(d.reference), '')

          OR (
            LOWER(BTRIM(d.method)) IN (
              'tarjeta',
              'transferencia'
            )
            AND NULLIF(BTRIM(d.reference), '') IS NULL
          )

          OR c.tip IS DISTINCT FROM
            CASE
              WHEN d.kind = 'expense' THEN 'Salida'
              ELSE 'Entrada'
            END

          OR d.request_key IS NULL

          OR c.request_key IS DISTINCT FROM d.request_key

          OR d.request_hash IS NULL

          OR d.request_hash !~ '^[0-9a-f]{64}$'

          OR c.registrado_en IS NULL

          OR NUM_NONNULLS(
            c.sale_id,
            c.recarga_id,
            c.print_payment_id,
            c.expense_id
          ) <> 1
        )
    ) AS mismatched

  FROM documents d

  FULL JOIN movements c
    ON c.kind = d.kind
   AND c.document_id = d.id
),

totals AS (
  SELECT
    LOWER(BTRIM(metodo_pago)) AS method,
    tip AS direction,
    SUM(mon)::text AS amount

  FROM local_movements

  WHERE mon > 0
    AND mon <> 'NaN'::numeric

  GROUP BY
    LOWER(BTRIM(metodo_pago)),
    tip
)

SELECT
  checks.*,

  COALESCE(
    (
      SELECT jsonb_agg(totals)
      FROM totals
    ),
    '[]'::jsonb
  ) AS totals

FROM checks
`;

async function shiftSummary(db, shift) {
  const result = await db.query(
    SUMMARY_SQL,
    [
      shift.id,
      shift.cashier_id
    ]
  );

  const data = result.rows[0];

  const issues = {
    missingMovements: Number(data.missing),
    unlinkedMovements: Number(data.unlinked),
    mismatchedMovements: Number(data.mismatched)
  };

  const balances = {
    efectivo: {
      income: 0n,
      expense: 0n
    },

    tarjeta: {
      income: 0n,
      expense: 0n
    },

    transferencia: {
      income: 0n,
      expense: 0n
    }
  };

  for (const row of data.totals) {
    if (
      !Object.hasOwn(balances, row.method) ||
      !['Entrada', 'Salida'].includes(row.direction)
    ) {
      continue;
    }

    const field = row.direction === 'Entrada'
      ? 'income'
      : 'expense';

    balances[row.method][field] += sumCents(row.amount);
  }

  const opening = cash.toCents(
    shift.opening_amount,
    { allowZero: true }
  );

  // Tarjetas y transferencias no aumentan
  // el efectivo físico del cajón.
  const expected =
    opening +
    balances.efectivo.income -
    balances.efectivo.expense;

  const reconciled = Object.values(issues).every(
    value => value === 0
  );

  const methods = {};

  for (const [name, value] of Object.entries(balances)) {
    methods[name] = {
      income: cash.fromCents(value.income),
      expense: cash.fromCents(value.expense),

      net: cash.fromCents(
        value.income - value.expense
      )
    };
  }

  return {
    shift: publicShift(shift),

    // Alcance de esta etapa de integración.
    scope: [
  'sales',
  'recargas',
  'print_job_payments',
  'cash_expenses'
],

    reconciled,
    issues,
    methods,

    expectedCash: reconciled
      ? cash.fromCents(expected)
      : null
  };
}

function requireReconciled(summary) {
  if (!summary.reconciled) {
    fail(
      'Revisa las ventas, recargas, impresiones y gastos antes de continuar.',
      summary.issues
    );
  }
}

// ============================================================
// TURNO ACTUAL
// ============================================================

router.get(
  '/cash-shifts/current',
  route(async (req, res) => {
    const result = await readSnapshot(async db => {
      const query = await db.query(
        `
        SELECT
          cs.*,
          ${SHIFT_TIMES},
          u.full_name AS cashier_name

        FROM public.cash_shifts cs

        JOIN public.users u
          ON u.id = cs.cashier_id

        WHERE cs.cashier_id = $1
          AND LOWER(BTRIM(cs.status)) = 'abierto'

        ORDER BY cs.id DESC
        LIMIT 2
        `,
        [req.user.id]
      );

      const rows = query.rows;

      if (!rows.length) {
        return { shift: null };
      }

      if (
        rows.length !== 1 ||
        rows[0].closed_at != null
      ) {
        fail(
          'El turno actual tiene información inconsistente.',
          'CAJA_TURNO_INCONSISTENTE',
          409
        );
      }

      return shiftSummary(db, rows[0]);
    });

    res.json(result);
  })
);

// ============================================================
// HISTORIAL DE TURNOS
// ============================================================

router.get(
  [
    '/cash-shifts',
    '/cash-shifts/history'
  ],

  route(async (req, res) => {
    const limit = limitOf(req.query.limit);

    const result = await pool.query(
      `
      SELECT
        cs.*,
        ${SHIFT_TIMES},
        u.full_name AS cashier_name

      FROM public.cash_shifts cs

      LEFT JOIN public.users u
        ON u.id = cs.cashier_id

      WHERE (
        $1::boolean
        OR cs.cashier_id = $2
      )

      ORDER BY
        cs.created_at DESC NULLS LAST,
        cs.id DESC

      LIMIT $3
      `,
      [
        canReadAll(req.user),
        req.user.id,
        limit
      ]
    );

    res.json(
      result.rows.map(publicShift)
    );
  })
);

// ============================================================
// APERTURA DEL TURNO
// ============================================================

router.post(
  '/cash-shifts/open',
  canWrite,

  route(async (req, res) => {
    const body = bodyOf(req, [
      'opening_amount',
      'request_key'
    ]);

    const opening = cash.money(
      body.opening_amount,
      { allowZero: true }
    );

    const key = operationKey(req, body);

    const result = await cash.withCashTransaction(
      req.user.id,

      async context => {
        const request = await cash.prepareRequest(
          context,
          {
            scope: 'open',
            key,

            payload: {
              opening_amount: opening
            }
          }
        );

        if (request.replayed) {
          return {
            id: request.record.id,

            shift: publicShift(
              await loadShift(
                context.db,
                request.record.id
              )
            ),

            replayed: true
          };
        }

        const existing = await context.db.query(
          `
          SELECT id
          FROM public.cash_shifts

          WHERE cashier_id = $1
            AND LOWER(BTRIM(status)) = 'abierto'

          FOR UPDATE
          `,
          [context.user.id]
        );

        if (existing.rows.length) {
          fail(
            'Ya tienes un turno abierto.',
            'CAJA_TURNO_YA_ABIERTO',
            409
          );
        }

        const inserted = await context.db.query(
          `
          INSERT INTO public.cash_shifts AS cs (
            cashier_id,
            status,
            opening_amount,
            request_key,
            request_hash
          )
          VALUES (
            $1,
            'abierto',
            $2,
            $3,
            $4
          )

          RETURNING
            cs.*,
            ${SHIFT_TIMES}
          `,
          [
            context.user.id,
            opening,
            request.key,
            request.hash
          ]
        );

        const shift = inserted.rows[0];

        // El fondo inicial se cuenta desde opening_amount.
        // No se duplica como una entrada adicional en caja.
        await audit(
          context,
          'CAJA_APERTURA',
          shift.id,
          {
            opening_amount: opening,
            request_key: request.key
          }
        );

        return {
          id: shift.id,

          shift: publicShift({
            ...shift,
            cashier_name: context.user.full_name
          }),

          replayed: false
        };
      }
    );

    res
      .status(result.replayed ? 200 : 201)
      .json({
        ok: true,
        ...result
      });
  })
);

// ============================================================
// CIERRE Y ARQUEO
// ============================================================

router.post(
  [
    '/cash-shifts/current/close',
    '/cash-shifts/close',
    '/cash-shifts/:id/close'
  ],

  canWrite,

  route(async (req, res) => {
    const body = bodyOf(req, [
      'shift_id',
      'counted_amount',
      'closing_note',
      'request_key'
    ]);

    const shiftId = cash.positiveId(
      req.params.id ?? body.shift_id,
      'Turno'
    );

    if (
      req.params.id != null &&
      body.shift_id != null &&
      shiftId !== cash.positiveId(body.shift_id, 'Turno')
    ) {
      fail(
        'El turno de la ruta no coincide con el turno enviado.'
      );
    }

    const counted = cash.money(
      body.counted_amount,
      { allowZero: true }
    );

    const note = text(
      body.closing_note,
      'Observación',
      1000,
      true
    );

    const key = operationKey(req, body);

    const result = await cash.withCashTransaction(
      req.user.id,

      async context => {
        const request = await cash.prepareRequest(
          context,
          {
            scope: 'close',
            key,

            payload: {
              shift_id: shiftId,
              counted_amount: counted,
              closing_note: note
            }
          }
        );

        if (request.replayed) {
          return {
            shift: publicShift(
              await loadShift(
                context.db,
                request.record.id
              )
            ),

            replayed: true
          };
        }

        const shift = await cash.lockOpenShift(
          context,
          shiftId
        );

        const summary = await shiftSummary(
          context.db,
          shift
        );

        requireReconciled(summary);

        if (summary.expectedCash.startsWith('-')) {
          fail(
            'El saldo esperado es negativo. Revisa los egresos del turno.',
            'CAJA_SALDO_NEGATIVO',
            409
          );
        }

        const expected = cash.money(
          summary.expectedCash,
          { allowZero: true }
        );

        const difference = cash.fromCents(
          cash.toCents(
            counted,
            { allowZero: true }
          ) -
          cash.toCents(
            expected,
            { allowZero: true }
          )
        );

        if (
          difference !== '0.00' &&
          !note
        ) {
          fail(
            'Describe el motivo de la diferencia de caja.'
          );
        }

        const updatedResult = await context.db.query(
          `
          UPDATE public.cash_shifts AS cs

          SET
            closed_at = CURRENT_TIMESTAMP,
            closing_amount_system = $1,
            closing_amount_counted = $2,
            difference = $3,
            status = 'cerrado',
            closed_by = $4,
            closing_note = $5,
            close_request_key = $6,
            close_request_hash = $7

          WHERE id = $8
            AND cashier_id = $4
            AND LOWER(BTRIM(status)) = 'abierto'
            AND closed_at IS NULL

          RETURNING
            cs.*,
            ${SHIFT_TIMES}
          `,
          [
            expected,
            counted,
            difference,
            context.user.id,
            note,
            request.key,
            request.hash,
            shiftId
          ]
        );

        const updated = updatedResult.rows[0];

        if (!updated) {
          fail(
            'El turno ya no está disponible para cierre.',
            'CAJA_CIERRE_CONFLICTO',
            409
          );
        }

        await audit(
          context,
          'CAJA_CIERRE',
          shiftId,
          {
            expected_cash: expected,
            counted_amount: counted,
            difference,
            request_key: request.key
          }
        );

        return {
          shift: publicShift(updated),
          replayed: false
        };
      }
    );

    res.json({
      ok: true,
      ...result,

      expectedCash:
        result.shift.closing_amount_system,

      counted:
        result.shift.closing_amount_counted,

      difference:
        result.shift.difference
    });
  })
);

// ============================================================
// CONSULTAR GASTOS
// ============================================================

router.get(
  '/cash-expenses',

  route(async (req, res) => {
    const limit = limitOf(
      req.query.limit,
      100
    );

    const requested = req.query.shift_id == null
      ? null
      : cash.positiveId(
          req.query.shift_id,
          'Turno'
        );

    const rows = await readSnapshot(async db => {
      const shiftResult = await db.query(
        requested == null
          ? `
            SELECT *
            FROM public.cash_shifts

            WHERE cashier_id = $1
              AND LOWER(BTRIM(status)) = 'abierto'

            ORDER BY id DESC
            LIMIT 1
          `
          : `
            SELECT *
            FROM public.cash_shifts
            WHERE id = $1
          `,

        [
          requested == null
            ? req.user.id
            : requested
        ]
      );

      const shift = shiftResult.rows[0];

      if (!shift) {
        if (requested != null) {
          fail(
            'Turno no encontrado.',
            'CAJA_NO_ENCONTRADA',
            404
          );
        }

        return [];
      }

      if (
        !canReadAll(req.user) &&
        shift.cashier_id !== req.user.id
      ) {
        fail(
          'No puedes consultar gastos de otro cajero.',
          'CAJA_SIN_PERMISO',
          403
        );
      }

      const result = await db.query(
        `
        SELECT
          e.*,
          ${EXPENSE_TIME},
          u.full_name AS user_name

        FROM public.cash_expenses e

        LEFT JOIN public.users u
          ON u.id = e.user_id

        WHERE e.shift_id = $1

        ORDER BY
          e.date DESC NULLS LAST,
          e.id DESC

        LIMIT $2
        `,
        [
          shift.id,
          limit
        ]
      );

      return result.rows;
    });

    res.json(
      rows.map(publicExpense)
    );
  })
);

// ============================================================
// REGISTRAR GASTO Y SU MOVIMIENTO DE CAJA
// ============================================================

router.post(
  '/cash-expenses',
  canWrite,

  route(async (req, res) => {
    const body = bodyOf(req, [
      'shift_id',
      'description',
      'category',
      'amount',
      'payment_method',
      'payment_reference',
      'request_key'
    ]);

    const payload = {
      shift_id: cash.positiveId(
        body.shift_id,
        'Turno'
      ),

      description: text(
        body.description,
        'Descripción',
        255
      ),

      category: text(
        body.category ?? 'operativo',
        'Categoría',
        100
      ),

      amount: cash.money(body.amount),

      payment_method: cash.paymentMethod(
        body.payment_method
      )
    };

    payload.payment_reference = cash.paymentReference(
      body.payment_reference,
      payload.payment_method
    );

    const key = operationKey(req, body);

    const result = await cash.withCashTransaction(
      req.user.id,

      async context => {
        const request = await cash.prepareRequest(
          context,
          {
            scope: 'expense',
            key,
            payload
          }
        );

        if (request.replayed) {
          const previous = await context.db.query(
            `
            SELECT
              e.*,
              ${EXPENSE_TIME}

            FROM public.cash_expenses e

            WHERE id = $1
            `,
            [request.record.id]
          );

          return {
            id: request.record.id,
            expense: publicExpense(previous.rows[0]),
            replayed: true
          };
        }

        const shift = await cash.lockOpenShift(
          context,
          payload.shift_id
        );

        const summary = await shiftSummary(
          context.db,
          shift
        );

        requireReconciled(summary);

        if (
          payload.payment_method === 'efectivo' &&
          (
            summary.expectedCash.startsWith('-') ||
            cash.toCents(payload.amount) >
              sumCents(summary.expectedCash)
          )
        ) {
          fail(
            'El efectivo disponible no alcanza para este gasto.',
            'CAJA_EFECTIVO_INSUFICIENTE',
            409
          );
        }

        const inserted = await context.db.query(
          `
          INSERT INTO public.cash_expenses AS e (
            shift_id,
            user_id,
            description,
            category,
            amount,
            payment_method,
            payment_reference,
            request_key,
            request_hash
          )
          VALUES (
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            $7,
            $8,
            $9
          )

          RETURNING
            e.*,
            ${EXPENSE_TIME}
          `,
          [
            shift.id,
            context.user.id,
            payload.description,
            payload.category,
            payload.amount,
            payload.payment_method,
            payload.payment_reference,
            request.key,
            request.hash
          ]
        );

        const expense = inserted.rows[0];

        await cash.recordMovement(
          context,
          {
            sourceId: expense.id
          }
        );

        return {
          id: expense.id,
          expense: publicExpense(expense),
          replayed: false
        };
      }
    );

    res
      .status(result.replayed ? 200 : 201)
      .json({
        ok: true,
        ...result
      });
  })
);

// ============================================================
// FINANZAS AVANZADAS
//
// Conservamos las URL utilizadas por la pantalla.
//
// Estos cálculos necesitan la integración contable completa.
// NULL significa "no disponible"; no representa un importe cero.
// Se retiran las respuestas con cifras simuladas.
// ============================================================

router.get(
  '/ratios',

  requireRole(
    'admin',
    'auditor',
    'invitado'
  ),

  (req, res) => {
    res.json({
      available: false,

      reason:
        'Falta integrar activos, pasivos, patrimonio y costos del período.',

      alertaLiquidez: null,

      razonesFinancieras: {
        pruebaAcida: null
      },

      puntoDeEquilibrio: {
        ingresoNecesario: null,
        copiasMensualesEstimadas: null
      },

      sistemaDuPont: {
        ROE_Total: null
      }
    });
  }
);

router.get(
  '/statements',

  requireRole(
    'admin',
    'auditor',
    'invitado'
  ),

  (req, res) => {
    res.json({
      available: false,

      reason:
        'Pendiente de integrar y conciliar los ingresos, costos y gastos de todos los módulos.',

      estadoResultados: {
        ingresosTotales: null,
        costoDeVentas: null,
        gastosOperativos: null,
        utilidadNeta: null
      }
    });
  }
);

module.exports = router;

module.exports.summarizeShift = shiftSummary;