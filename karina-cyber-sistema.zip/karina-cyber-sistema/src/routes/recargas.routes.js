'use strict';

const express = require('express');
const pool = require('../db/connection');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const cash = require('../services/cash.service');

const router = express.Router();

router.use(requireAuth);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

function fail(
  message,
  code = 'RECARGA_VALIDACION',
  status = 400
) {
  const error = new Error(message);

  error.code = code;
  error.status = status;

  throw error;
}

function route(work) {
  return async (req, res) => {
    try {
      await work(req, res);
    } catch (error) {
      if (res.headersSent) return;

      let status =
        Number.isInteger(error.status) &&
        error.status >= 400 &&
        error.status <= 599
          ? error.status
          : 500;

      let code =
        error.code ||
        'RECARGA_ERROR';

      let message =
        error.message;

      if (error.code === '23505') {
        status = 409;
        code = 'RECARGA_CONFLICTO';

        message =
          'La operación ya existe o entra en conflicto ' +
          'con un registro anterior.';
      }

      if (status >= 500) {
        console.error(
          '[Recargas]',
          error.code,
          error.cause?.code || ''
        );

        if (!error.status) {
          message =
            'No se pudo registrar la recarga.';
        }
      }

      res.status(status).json({
        error: message,
        code
      });
    }
  };
}

function limitOf(value) {
  if (value == null) return 50;

  if (
    typeof value !== 'string' ||
    !/^\d{1,3}$/.test(value)
  ) {
    fail(
      'El límite debe estar entre 1 y 200.'
    );
  }

  const result = Number(value);

  if (
    result < 1 ||
    result > 200
  ) {
    fail(
      'El límite debe estar entre 1 y 200.'
    );
  }

  return result;
}

function operatorOf(value) {
  if (
    typeof value !== 'string'
  ) {
    fail(
      'Selecciona una operadora.'
    );
  }

  const operator =
    value.trim();

  if (
    operator.length < 2 ||
    operator.length > 50 ||
    /[\u0000-\u001f\u007f]/.test(operator)
  ) {
    fail(
      'La operadora debe tener entre 2 y 50 caracteres.'
    );
  }

  return operator;
}

function phoneOf(value) {
  if (
    typeof value !== 'string'
  ) {
    fail(
      'Indica el número de destino.'
    );
  }

  const phone =
    value.trim();

  // Formato numérico internacional sencillo.
  // No presupone que todos los destinos tengan
  // la misma longitud local.
  if (
    !/^\+?[0-9]{8,15}$/.test(phone) ||
    phone.length > 20
  ) {
    fail(
      'Indica entre 8 y 15 dígitos; ' +
      'puedes anteponer el signo +.'
    );
  }

  return phone;
}

function requestBody(req) {
  const body =
    req.body;

  if (
    !body ||
    typeof body !== 'object' ||
    Array.isArray(body)
  ) {
    fail(
      'Envía los datos de la recarga en JSON.'
    );
  }

  const allowed = [
    'operator',
    'phone',
    'amount',
    'commission',
    'payment_method',
    'payment_reference',
    'delivery_confirmed',
    'request_key'
  ];

  if (
    Object.keys(body).some(
      key => !allowed.includes(key)
    )
  ) {
    fail(
      'La solicitud contiene campos no admitidos.'
    );
  }

  if (
    body.delivery_confirmed !== true
  ) {
    fail(
      'Confirma la entrega de la recarga ' +
      'antes de registrarla.'
    );
  }

  const amountCents =
    cash.toCents(body.amount);

  const commissionCents =
    cash.toCents(
      body.commission,
      { allowZero: true }
    );

  if (
    commissionCents >
    amountCents
  ) {
    fail(
      'La comisión no puede superar el monto cobrado.'
    );
  }

  const method =
    cash.paymentMethod(
      body.payment_method
    );

  const reference =
    cash.paymentReference(
      body.payment_reference,
      method
    );

  const headerKey =
    req.get('Idempotency-Key');

  const key =
    cash.requestKey(
      headerKey ??
      body.request_key
    );

  if (
    headerKey != null &&
    body.request_key != null &&
    key !== cash.requestKey(
      body.request_key
    )
  ) {
    fail(
      'Las claves de operación enviadas no coinciden.'
    );
  }

  return {
    operator:
      operatorOf(
        body.operator
      ),

    phone:
      phoneOf(
        body.phone
      ),

    amount:
      cash.fromCents(
        amountCents
      ),

    commission:
      cash.fromCents(
        commissionCents
      ),

    payment_method:
      method,

    payment_reference:
      reference,

    delivery_confirmed:
      true,

    request_key:
      key
  };
}

function publicTopup(row) {
  const commission =
    row.commission_amount == null
      ? null
      : Number(
          row.commission_amount
        );

  const gross =
    Number(row.monto);

  return {
    id: row.id,

    operator:
      row.operadora,

    telco:
      row.operadora,

    phone:
      row.numero,

    date:
      row.fecha,

    cashier_id:
      row.cashier_id,

    cashier_name:
      row.cashier_name || null,

    shift_id:
      row.shift_id,

    amount_gross:
      gross,

    commission_amount:
      commission,

    amount_net:
      commission == null
        ? null
        : gross - commission,

    payment_method:
      row.metodo_pago,

    payment_reference:
      row.payment_reference,

    // Indica confirmación manual del cajero;
    // no una respuesta técnica de la operadora.
    delivery_status:
      row.request_key == null
        ? 'historico_sin_verificar'
        : 'confirmado_por_cajero'
  };
}

async function readTopup(
  db,
  id,
  user
) {
  const result =
    await db.query(
      `
      SELECT
        r.*,

        to_char(
          r.fecha,
          'YYYY-MM-DD"T"HH24:MI:SS.US'
        ) ||
          CASE
            WHEN r.request_key IS NOT NULL
              THEN 'Z'
            ELSE ''
          END AS fecha,

        u.full_name AS cashier_name

      FROM public.recargas r

      LEFT JOIN public.users u
        ON u.id = r.cashier_id

      WHERE r.id = $1

        AND (
          $2::boolean
          OR r.cashier_id = $3
        )
      `,
      [
        id,

        [
          'superadmin',
          'admin',
          'auditor',
          'invitado'
        ].includes(
          user.role
        ),

        user.id
      ]
    );

  if (
    !result.rows[0]
  ) {
    fail(
      'Recarga no encontrada.',
      'RECARGA_NO_ENCONTRADA',
      404
    );
  }

  return publicTopup(
    result.rows[0]
  );
}

// ============================================================
// CONSULTAS
// ============================================================

router.get(
  [
    '/',
    '/recent',
    '/history'
  ],

  route(async (req, res) => {
    const limit =
      limitOf(
        req.query.limit
      );

    const canReadAll = [
      'superadmin',
      'admin',
      'auditor',
      'invitado'
    ].includes(
      req.user.role
    );

    const result =
      await pool.query(
        `
        SELECT
          r.*,

          to_char(
            r.fecha,
            'YYYY-MM-DD"T"HH24:MI:SS.US'
          ) ||
            CASE
              WHEN r.request_key IS NOT NULL
                THEN 'Z'
              ELSE ''
            END AS fecha,

          u.full_name AS cashier_name

        FROM public.recargas r

        LEFT JOIN public.users u
          ON u.id = r.cashier_id

        WHERE (
          $1::boolean
          OR r.cashier_id = $2
        )

        ORDER BY
          r.fecha DESC NULLS LAST,
          r.id DESC

        LIMIT $3
        `,
        [
          canReadAll,
          req.user.id,
          limit
        ]
      );

    res.json(
      result.rows.map(
        publicTopup
      )
    );
  })
);

router.get(
  '/:id',

  route(async (req, res) => {
    const id =
      cash.positiveId(
        req.params.id,
        'Recarga'
      );

    const topup =
      await readTopup(
        pool,
        id,
        req.user
      );

    res.json(
      topup
    );
  })
);

// ============================================================
// REGISTRO
// ============================================================

router.post(
  '/',

  requireRole(
    'admin',
    'cajero'
  ),

  route(async (req, res) => {
    const input =
      requestBody(req);

    const result =
      await cash.withCashTransaction(
        req.user.id,

        async context => {
          const request =
            await cash.prepareRequest(
              context,

              {
                scope:
                  'recarga',

                key:
                  input.request_key,

                payload: {
                  operator:
                    input.operator,

                  phone:
                    input.phone,

                  amount:
                    input.amount,

                  commission:
                    input.commission,

                  payment_method:
                    input.payment_method,

                  payment_reference:
                    input.payment_reference,

                  delivery_confirmed:
                    true
                }
              }
            );

          if (
            request.replayed
          ) {
            const topup =
              await readTopup(
                context.db,
                request.record.id,
                context.user
              );

            const ledger =
              await context.db.query(
                `
                SELECT
                  id,
                  shift_id,
                  user_id,
                  mon,
                  metodo_pago

                FROM public.caja

                WHERE recarga_id = $1
                `,
                [
                  topup.id
                ]
              );

            const movement =
              ledger.rows[0];

            if (
              ledger.rows.length !== 1 ||
              Number(
                movement.shift_id
              ) !==
                Number(
                  topup.shift_id
                ) ||
              Number(
                movement.user_id
              ) !==
                Number(
                  topup.cashier_id
                ) ||
              cash.money(
                movement.mon
              ) !==
                cash.money(
                  topup.amount_gross
                ) ||
              cash.paymentMethod(
                movement.metodo_pago
              ) !==
                cash.paymentMethod(
                  topup.payment_method
                )
            ) {
              fail(
                'La recarga existe, pero su movimiento ' +
                'de caja requiere revisión.',
                'RECARGA_CONCILIACION_PENDIENTE',
                409
              );
            }

            return {
              topup,
              replayed:
                true
            };
          }

          const shift =
            await cash.lockOpenShift(
              context
            );

          const inserted =
            await context.db.query(
              `
              INSERT INTO public.recargas (
                operadora,
                numero,
                monto,
                metodo_pago,
                shift_id,
                cashier_id,
                commission_amount,
                payment_reference,
                request_key,
                request_hash
              )

              VALUES (
                $1,
                $2,
                $3,
                $4,
                $5,
                $6,
                $7,
                $8,
                $9,
                $10
              )

              RETURNING id
              `,
              [
                input.operator,
                input.phone,
                input.amount,
                input.payment_method,
                shift.id,
                context.user.id,
                input.commission,
                input.payment_reference,
                request.key,
                request.hash
              ]
            );

          const id =
            inserted.rows[0].id;

          // Si el movimiento o la auditoría falla,
          // también se revierte la recarga.
          await cash.recordMovement(
            context,
            {
              sourceId:
                id
            }
          );

          await context.db.query(
            `
            INSERT INTO public.audit_log (
              user_id,
              action,
              entity,
              details
            )

            VALUES (
              $1,
              'RECARGA_ENTREGA_CONFIRMADA',
              'recargas',
              $2
            )
            `,
            [
              context.user.id,

              JSON.stringify({
                recarga_id:
                  id,

                shift_id:
                  shift.id,

                confirmation:
                  'manual',

                request_key:
                  request.key
              })
            ]
          );

          const topup =
            await readTopup(
              context.db,
              id,
              context.user
            );

          return {
            topup,
            replayed:
              false
          };
        }
      );

    res
      .status(
        result.replayed
          ? 200
          : 201
      )
      .json({
        ok: true,

        ...result.topup,

        replayed:
          result.replayed
      });
  })
);

module.exports = router;