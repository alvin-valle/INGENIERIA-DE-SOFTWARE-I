'use strict';

const express = require('express');
const pool = require('../db/connection');
const cash = require('../services/cash.service');

const {
    requireAuth,
    requireRole
} = require('../middleware/auth');

const {
    handle,
    text,
    transaction,
    audit,
    fail
} = require('../utils/enterprise');

const router = express.Router();

router.use(requireAuth);

router.use((req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
});

// Consulta compatible con los módulos existentes.
// Con "pagina" devuelve resultados paginados.
router.get(['/', '/products'], handle(async (req, res) => {
    const paginado = req.query.pagina !== undefined;
    const pagina = Number(req.query.pagina ?? 1);
    const limite = paginado
        ? Number(req.query.limite ?? 100)
        : 2000;

    const buscar = String(req.query.buscar ?? '').trim();
    const estado = String(req.query.estado ?? 'all');

    if (
        !Number.isSafeInteger(pagina) ||
        pagina < 1 ||
        pagina > 1000000 ||
        !Number.isSafeInteger(limite) ||
        limite < 1 ||
        limite > (paginado ? 200 : 2000) ||
        buscar.length > 100 ||
        !['all', 'active', 'inactive', 'low'].includes(estado)
    ) {
        fail('Revisa los filtros y la página solicitada.');
    }

    const resultado = await pool.query(`
        WITH filtrados AS (
            SELECT
                p.*,
                c.name AS category_name,
                pr.nombre AS supplier_name,
                ROUND(
                    p.stock * p.avg_cost,
                    2
                )::text AS inventory_value
            FROM public.products p
            LEFT JOIN public.categories c
                ON c.id = p.category_id
            LEFT JOIN public.proveedores pr
                ON pr.id = p.supplier_id
            WHERE (
                $1 = ''
                OR position(
                    lower($1)
                    IN lower(
                        p.name || ' ' ||
                        COALESCE(p.sku, '') || ' ' ||
                        COALESCE(c.name, '')
                    )
                ) > 0
            )
            AND (
                $2 = 'all'
                OR ($2 = 'active' AND p.active)
                OR ($2 = 'inactive' AND NOT p.active)
                OR (
                    $2 = 'low'
                    AND p.active
                    AND p.stock <= p.min_stock
                )
            )
        ),
        pagina AS (
            SELECT *
            FROM filtrados
            ORDER BY name, id
            LIMIT $3 OFFSET $4
        )
        SELECT
            (
                SELECT COUNT(*)::text
                FROM filtrados
            ) AS total,
            COALESCE(
                (
                    SELECT jsonb_agg(
                        to_jsonb(pagina) ||
                        jsonb_build_object(
                            'price', price::text,
                            'avg_cost', avg_cost::text,
                            'stock', stock::text,
                            'min_stock', min_stock::text
                        )
                        ORDER BY name, id
                    )
                    FROM pagina
                ),
                '[]'::jsonb
            ) AS filas
    `, [
        buscar,
        estado,
        limite,
        (pagina - 1) * limite
    ]);

    const datos = resultado.rows[0];

    res.json(
        paginado
            ? {
                filas: datos.filas,
                total: datos.total,
                pagina,
                limite,
                paginas: Math.ceil(
                    Number(datos.total) / limite
                )
            }
            : datos.filas
    );
}));

// Los indicadores abarcan todos los productos activos.
router.get('/summary', handle(async (req, res) => {
    const resultado = await pool.query(`
        SELECT
            COUNT(*) FILTER (
                WHERE active
            ) AS products,

            COALESCE(
                SUM(stock) FILTER (
                    WHERE active
                ),
                0
            )::text AS units,

            COALESCE(
                SUM(stock * avg_cost) FILTER (
                    WHERE active
                ),
                0
            )::text AS invested,

            COALESCE(
                SUM(stock * price) FILTER (
                    WHERE active
                ),
                0
            )::text AS retail_value,

            COUNT(*) FILTER (
                WHERE active
                  AND stock <= min_stock
            ) AS low_stock

        FROM public.products
    `);

    res.json(resultado.rows[0]);
}));

router.get('/categories', handle(async (req, res) => {
    const resultado = await pool.query(`
        SELECT *
        FROM public.categories
        ORDER BY name
    `);

    res.json(resultado.rows);
}));

router.post(
    '/categories',
    requireRole('admin'),
    handle(async (req, res) => {
        const nombre = text(
            req.body.name,
            'Categoría',
            100
        );

        const categoria = await transaction(
            req.user.id,
            async db => {
                const resultado = await db.query(`
                    INSERT INTO public.categories(name)
                    VALUES ($1)
                    RETURNING *
                `, [nombre]);

                const fila = resultado.rows[0];

                await audit(
                    db,
                    req.user.id,
                    'CREATE',
                    'categories',
                    { id: fila.id }
                );

                return fila;
            }
        );

        res.status(201).json(categoria);
    })
);

router.get(
    '/products/:id/kardex',
    handle(async (req, res) => {
        const id = cash.positiveId(req.params.id);

        const resultado = await pool.query(`
            SELECT
                k.*,
                u.full_name AS user_name
            FROM public.kardex_movements k
            LEFT JOIN public.users u
                ON u.id = k.user_id
            WHERE k.product_id = $1
            ORDER BY k.id DESC
            LIMIT 500
        `, [id]);

        res.json(resultado.rows);
    })
);

// Las existencias y el costo promedio se actualizan
// mediante compras, ventas y consumos.
function productInput(body) {
    const minimo = String(body.min_stock ?? '0');

    if (!/^\d{1,6}(?:\.\d{1,6})?$/.test(minimo)) {
        fail('Stock mínimo inválido.');
    }

    if (typeof body.active !== 'boolean') {
        fail('Selecciona el estado del producto.');
    }

    return [
        text(body.sku, 'SKU', 60),

        text(body.name, 'Producto', 150),

        text(
            body.unit || 'unidad',
            'Unidad',
            30
        ),

        body.category_id
            ? cash.positiveId(body.category_id)
            : null,

        body.supplier_id
            ? cash.positiveId(body.supplier_id)
            : null,

        minimo,

        cash.money(
            body.price,
            { allowZero: true }
        ),

        body.active
    ];
}

router.post(
    '/products',
    requireRole('admin'),
    handle(async (req, res) => {
        const valores = productInput(req.body);

        const producto = await transaction(
            req.user.id,
            async db => {
                const resultado = await db.query(`
                    INSERT INTO public.products (
                        sku,
                        name,
                        unit,
                        category_id,
                        supplier_id,
                        min_stock,
                        price,
                        active,
                        stock,
                        avg_cost
                    )
                    VALUES (
                        $1, $2, $3, $4,
                        $5, $6, $7, $8,
                        0, 0
                    )
                    RETURNING *
                `, valores);

                const fila = resultado.rows[0];

                await audit(
                    db,
                    req.user.id,
                    'CREATE',
                    'products',
                    { id: fila.id }
                );

                return fila;
            }
        );

        res.status(201).json(producto);
    })
);

router.patch(
    '/products/:id',
    requireRole('admin'),
    handle(async (req, res) => {
        const id = cash.positiveId(req.params.id);
        const valores = productInput(req.body);

        const producto = await transaction(
            req.user.id,
            async db => {
                const resultado = await db.query(`
                    UPDATE public.products
                    SET
                        sku = $1,
                        name = $2,
                        unit = $3,
                        category_id = $4,
                        supplier_id = $5,
                        min_stock = $6,
                        price = $7,
                        active = $8
                    WHERE id = $9
                    RETURNING *
                `, [
                    ...valores,
                    id
                ]);

                if (!resultado.rows.length) {
                    fail(
                        'Producto no encontrado.',
                        404
                    );
                }

                await audit(
                    db,
                    req.user.id,
                    'UPDATE',
                    'products',
                    { id }
                );

                return resultado.rows[0];
            }
        );

        res.json(producto);
    })
);

// Baja lógica: conserva los movimientos históricos.
router.delete(
    '/products/:id',
    requireRole('admin'),
    handle(async (req, res) => {
        const id = cash.positiveId(req.params.id);

        await transaction(
            req.user.id,
            async db => {
                const resultado = await db.query(`
                    UPDATE public.products
                    SET active = FALSE
                    WHERE id = $1
                    RETURNING id
                `, [id]);

                if (!resultado.rows.length) {
                    fail(
                        'Producto no encontrado.',
                        404
                    );
                }

                await audit(
                    db,
                    req.user.id,
                    'DEACTIVATE',
                    'products',
                    { id }
                );
            }
        );

        res.json({ ok: true });
    })
);

router.get(
    ['/suppliers', '/providers'],
    requireRole('admin', 'auditor'),
    handle(async (req, res) => {
        const resultado = await pool.query(`
            SELECT
                *,
                nombre AS name,
                tel AS phone
            FROM public.proveedores
            ORDER BY nombre
        `);

        res.json(resultado.rows);
    })
);

module.exports = router;