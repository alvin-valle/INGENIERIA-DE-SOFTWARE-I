const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/karina_cyber',
  ssl: process.env.DATABASE_URL && process.env.DATABASE_URL.includes('sslmode=require')
    ? { rejectUnauthorized: false }
    : false
});

router.get('/resumen', async (req, res) => {
  try {
    // 1. Saldo neto e ingresos en Caja
    const cajaRes = await pool.query(`
      SELECT 
        COALESCE(SUM(CASE WHEN tipo = 'INGRESO' THEN monto ELSE 0 END), 0) AS ingresos,
        COALESCE(SUM(CASE WHEN tipo = 'EGRESO' THEN monto ELSE 0 END), 0) AS egresos
      FROM caja_movimientos
    `);
    const ingresos = Number(cajaRes.rows[0].ingresos);
    const egresos = Number(cajaRes.rows[0].egresos);
    const saldoCaja = ingresos - egresos;

    // 2. Total de productos y unidades en stock
    const invRes = await pool.query(`
      SELECT COUNT(*) AS total_productos, COALESCE(SUM(stock), 0) AS total_unidades
      FROM productos
    `);

    // 3. Empleados activos
    const empRes = await pool.query(`
      SELECT COUNT(*) AS total_empleados FROM empleados WHERE estado = 'ACTIVO'
    `);

    // 4. Movimientos recientes unificados (Caja + Kardex)
    const movsRes = await pool.query(`
      SELECT id, categoria AS modulo, concepto AS descripcion, monto, tipo AS estado, fecha
      FROM caja_movimientos
      ORDER BY id DESC LIMIT 10
    `);

    res.json({
      ok: true,
      kpis: {
        saldo_caja: saldoCaja,
        ingresos_totales: ingresos,
        egresos_totales: egresos,
        total_productos: Number(invRes.rows[0].total_productos),
        total_unidades: Number(invRes.rows[0].total_unidades),
        total_empleados: Number(empRes.rows[0].total_empleados)
      },
      movimientos: movsRes.rows
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;