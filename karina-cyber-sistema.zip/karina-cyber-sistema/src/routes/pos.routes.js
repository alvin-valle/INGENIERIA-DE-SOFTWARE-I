'use strict';

const express = require('express');
const pool = require('../db/connection');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const { recordSalida } = require('../utils/kardex');
const cash = require('../services/cash.service');

const router = express.Router();

router.use(requireAuth);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

function fail(message, code = 'POS_VALIDACION', status = 400) {
  const error = new Error(message);

  error.code = code;
  error.status = status;

  throw error;
}

function route(work) {
  return async (req, res) => {
    try {
      await work(req, res);
    } catch (error) {
      if (res.headersSent) return;

      let status =
        Number.isInteger(error.status) &&
        error.status >= 400 &&
        error.status <= 599
          ? error.status
          : 500;

      let message = error.message;
      let code = error.code || 'POS_ERROR';

      if (error.code === '23505') {
        status = 409;
        code = 'POS_CONFLICTO';

        message =
          'Ya existe una operación con esos datos. ' +
          'Consulta la venta antes de volver a cobrar.';
      }

      if (status >= 500) {
        console.error(
          '[POS]',
          error.code,
          error.cause?.code || ''
        );

        if (!error.status) {
          message = 'No se pudo procesar la venta.';
        }
      }

      res.status(status).json({
        error: message,
        code
      });
    }
  };
}

function dateParam(value, label) {
  if (
    typeof value !== 'string' ||
    !/^\d{4}-\d{2}-\d{2}$/.test(value)
  ) {
    fail(`${label}: usa el formato AAAA-MM-DD.`);
  }

  const [year, month, day] =
    value.split('-').map(Number);

  const parsed = new Date(
    Date.UTC(year, month - 1, day)
  );

  if (
    parsed.getUTCFullYear() !== year ||
    parsed.getUTCMonth() !== month - 1 ||
    parsed.getUTCDate() !== day
  ) {
    fail(`${label}: fecha inválida.`);
  }

  return value;
}

function limitParam(value) {
  if (value == null) return 100;

  if (
    typeof value !== 'string' ||
    !/^\d{1,3}$/.test(value)
  ) {
    fail('El límite debe estar entre 1 y 200.');
  }

  const result = Number(value);

  if (result < 1 || result > 200) {
    fail('El límite debe estar entre 1 y 200.');
  }

  return result;
}

function parseItems(items) {
  if (
    !Array.isArray(items) ||
    items.length < 1 ||
    items.length > 100
  ) {
    fail(
      'Agrega entre 1 y 100 productos a la venta.'
    );
  }

  const seen = new Set();

  const parsed = items.map(item => {
    if (
      !item ||
      typeof item !== 'object' ||
      Array.isArray(item) ||
      Object.keys(item).some(
        key => !['product_id', 'qty'].includes(key)
      )
    ) {
      fail('El detalle de la venta contiene datos inválidos.');
    }

    const productId = cash.positiveId(
      item.product_id,
      'Producto'
    );

    const qty = Number(item.qty);

    if (
      !Number.isInteger(qty) ||
      qty < 1 ||
      qty > 1000000
    ) {
      fail(
        'La cantidad debe ser un entero positivo de hasta 1,000,000.'
      );
    }

    if (seen.has(productId)) {
      fail(
        'Un producto no puede aparecer dos veces en la misma venta.'
      );
    }

    seen.add(productId);

    return {
      product_id: productId,
      qty
    };
  });

  // Mantiene siempre el mismo orden de bloqueo de productos.
  parsed.sort(
    (a, b) => a.product_id - b.product_id
  );

  return parsed;
}

function saleBody(req) {
  const body = req.body;

  if (
    !body ||
    typeof body !== 'object' ||
    Array.isArray(body)
  ) {
    fail('Envía los datos de la venta en JSON.');
  }

  const allowed = [
    'items',
    'payment_method',
    'payment_reference',
    'request_key'
  ];

  if (
    Object.keys(body).some(
      key => !allowed.includes(key)
    )
  ) {
    fail('La venta contiene campos no admitidos.');
  }

  const items = parseItems(body.items);

  const paymentMethod = cash.paymentMethod(
    body.payment_method
  );

  const paymentReference = cash.paymentReference(
    body.payment_reference,
    paymentMethod
  );

  const headerKey = req.get('Idempotency-Key');

  const requestKey = cash.requestKey(
    headerKey ?? body.request_key
  );

  if (
    headerKey != null &&
    body.request_key != null &&
    requestKey !== cash.requestKey(body.request_key)
  ) {
    fail(
      'Las claves de operación enviadas no coinciden.'
    );
  }

  return {
    items,
    payment_method: paymentMethod,
    payment_reference: paymentReference,
    request_key: requestKey
  };
}

function publicItem(item) {
  return {
    id: item.id,
    product_id: item.product_id,
    product_name: item.product_name,
    sku: item.sku,
    qty: Number(item.qty),
    unit_price: Number(item.unit_price),
    unit_cost: Number(item.unit_cost),
    subtotal: Number(item.subtotal)
  };
}

async function readSale(db, saleId, user) {
  const saleResult = await db.query(
    `
    SELECT
      sa.*,

      to_char(
        sa.date,
        'YYYY-MM-DD"T"HH24:MI:SS.US'
      ) ||
        CASE
          WHEN sa.request_key IS NOT NULL THEN 'Z'
          ELSE ''
        END AS date,

      u.full_name AS cashier_name

    FROM public.sales sa

    JOIN public.users u
      ON u.id = sa.cashier_id

    WHERE sa.id = $1
      AND (
        $2::boolean
        OR sa.cashier_id = $3
      )
    `,
    [
      saleId,

      [
        'superadmin',
        'admin',
        'auditor',
        'invitado'
      ].includes(user.role),

      user.id
    ]
  );

  const sale = saleResult.rows[0];

  if (!sale) {
    fail(
      'Venta no encontrada.',
      'POS_VENTA_NO_ENCONTRADA',
      404
    );
  }

  const detailResult = await db.query(
    `
    SELECT
      si.*,
      p.name AS product_name,
      p.sku

    FROM public.sale_items si

    JOIN public.products p
      ON p.id = si.product_id

    WHERE si.sale_id = $1

    ORDER BY si.id
    `,
    [saleId]
  );

  return {
    id: sale.id,
    shift_id: sale.shift_id,
    cashier_id: sale.cashier_id,
    cashier_name: sale.cashier_name,
    date: sale.date,

    total: Number(sale.total),

    payment_method: sale.payment_method,
    payment_reference: sale.payment_reference,

    items: detailResult.rows.map(publicItem)
  };
}

function receiptFromSale(sale) {
  return {
    type: 'comprobante_interno',

    number: sale.id,
    date: sale.date,

    cashier_name: sale.cashier_name,

    items: sale.items.map(item => ({
      product_name: item.product_name,
      sku: item.sku,
      qty: item.qty,
      unit_price: item.unit_price,
      subtotal: item.subtotal
    })),

    total: sale.total,

    payment_method: sale.payment_method,
    payment_reference: sale.payment_reference
  };
}

// ============================================================
// CONSULTAR VENTAS
// ============================================================

router.get(
  '/sales',

  route(async (req, res) => {
    const from = req.query.date_from == null
      ? null
      : dateParam(
          req.query.date_from,
          'Fecha desde'
        );

    const to = req.query.date_to == null
      ? null
      : dateParam(
          req.query.date_to,
          'Fecha hasta'
        );

    if (from && to && from > to) {
      fail(
        'La fecha desde no puede superar la fecha hasta.'
      );
    }

    const limit = limitParam(req.query.limit);

    const canReadAll = [
      'superadmin',
      'admin',
      'auditor',
      'invitado'
    ].includes(req.user.role);

    const result = await pool.query(
      `
      SELECT
        sa.*,

        to_char(
          sa.date,
          'YYYY-MM-DD"T"HH24:MI:SS.US'
        ) ||
          CASE
            WHEN sa.request_key IS NOT NULL THEN 'Z'
            ELSE ''
          END AS date,

        u.full_name AS cashier_name

      FROM public.sales sa

      JOIN public.users u
        ON u.id = sa.cashier_id

      WHERE (
        $1::date IS NULL
        OR sa.date >= $1::date
      )

      AND (
        $2::date IS NULL
        OR sa.date < ($2::date + INTERVAL '1 day')
      )

      AND (
        $3::boolean
        OR sa.cashier_id = $4
      )

      ORDER BY
        sa.date DESC,
        sa.id DESC

      LIMIT $5
      `,
      [
        from,
        to,
        canReadAll,
        req.user.id,
        limit
      ]
    );

    res.json(
      result.rows.map(sale => ({
        id: sale.id,
        shift_id: sale.shift_id,
        cashier_id: sale.cashier_id,
        cashier_name: sale.cashier_name,
        date: sale.date,
        total: Number(sale.total),
        payment_method: sale.payment_method,
        payment_reference: sale.payment_reference
      }))
    );
  })
);

router.get(
  '/products',

  route(async (req, res) => {
    const search = String(req.query.q || '').trim();

    if (search.length > 100) {
      fail('La búsqueda no puede superar 100 caracteres.');
    }

    const result = await pool.query(
      `
      SELECT
        id,
        sku,
        name,
        unit,
        stock,
        min_stock,
        price

      FROM public.products

      WHERE active = TRUE

        AND (
          $1 = ''
          OR name ILIKE '%' || $1 || '%'
          OR sku ILIKE '%' || $1 || '%'
        )

      ORDER BY
        name,
        id

      LIMIT 80
      `,
      [search]
    );

    res.json(
      result.rows.map(product => ({
        id: product.id,
        sku: product.sku,
        name: product.name,
        unit: product.unit,
        stock: Number(product.stock),
        min_stock: Number(product.min_stock),
        price: Number(product.price)
      }))
    );
  })
);

router.get(
  '/sales/:id',

  route(async (req, res) => {
    const id = cash.positiveId(
      req.params.id,
      'Venta'
    );

    const sale = await readSale(
      pool,
      id,
      req.user
    );

    res.json({
      ...sale,
      receipt: receiptFromSale(sale)
    });
  })
);

// ============================================================
// CREAR VENTA
// ============================================================

router.post(
  '/sales',

  requireRole('admin', 'cajero'),

  route(async (req, res) => {
    const input = saleBody(req);

    const result = await cash.withCashTransaction(
      req.user.id,

      async context => {
        const request = await cash.prepareRequest(
          context,

          {
            scope: 'sale',
            key: input.request_key,

            payload: {
              items: input.items,
              payment_method:
                input.payment_method,

              payment_reference:
                input.payment_reference
            }
          }
        );

        if (request.replayed) {
          const sale = await readSale(
            context.db,
            request.record.id,
            context.user
          );

          const movementResult =
            await context.db.query(
              `
              SELECT
                id,
                shift_id,
                user_id,
                mon,
                metodo_pago

              FROM public.caja

              WHERE sale_id = $1
              `,
              [sale.id]
            );

          const movement =
            movementResult.rows[0];

          if (
            movementResult.rows.length !== 1 ||
            Number(movement.shift_id) !==
              Number(sale.shift_id) ||
            Number(movement.user_id) !==
              Number(sale.cashier_id) ||
            cash.money(movement.mon) !==
              cash.money(sale.total) ||
            cash.paymentMethod(
              movement.metodo_pago
            ) !==
              cash.paymentMethod(
                sale.payment_method
              )
          ) {
            fail(
              'La venta existe, pero requiere revisar su movimiento de caja.',
              'POS_CONCILIACION_PENDIENTE',
              409
            );
          }

          return {
            sale,
            replayed: true
          };
        }

        // El turno permanece bloqueado hasta COMMIT.
        // El cierre de caja usa el mismo bloqueo.
        const shift = await cash.lockOpenShift(
          context
        );

        const lines = [];
        let totalCents = 0n;

        // SELECT FOR UPDATE bloquea cada producto.
        // El orden evita conflictos entre ventas concurrentes.
        for (const requested of input.items) {
          const productResult =
            await context.db.query(
              `
              SELECT
                id,
                name,
                sku,
                price,
                stock,
                active

              FROM public.products

              WHERE id = $1

              FOR UPDATE
              `,
              [requested.product_id]
            );

          const product =
            productResult.rows[0];

          if (
            !product ||
            product.active !== true
          ) {
            fail(
              'Uno de los productos ya no está disponible.',
              'POS_PRODUCTO_NO_DISPONIBLE',
              409
            );
          }

          if (
            !Number.isInteger(
              Number(product.stock)
            ) ||
            Number(product.stock) <
              requested.qty
          ) {
            fail(
              `Stock insuficiente para "${product.name}".`,
              'STOCK_INSUFICIENTE',
              409
            );
          }

          const unitCents = cash.toCents(
            product.price
          );

          const subtotalCents =
            unitCents *
            BigInt(requested.qty);

          totalCents += subtotalCents;

          lines.push({
            product,
            qty: requested.qty,
            unit_price:
              cash.fromCents(unitCents),

            subtotal:
              cash.fromCents(
                subtotalCents
              )
          });
        }

        // sales.total es NUMERIC(10,2).
        // Comprueba que el total cabe antes de insertar.
        const total = cash.money(
          cash.fromCents(totalCents)
        );

        const inserted =
          await context.db.query(
            `
            INSERT INTO public.sales (
              shift_id,
              cashier_id,
              total,
              payment_method,
              payment_reference,
              request_key,
              request_hash
            )
            VALUES (
              $1,
              $2,
              $3,
              $4,
              $5,
              $6,
              $7
            )

            RETURNING id
            `,
            [
              shift.id,
              context.user.id,
              total,
              input.payment_method,
              input.payment_reference,
              request.key,
              request.hash
            ]
          );

        const saleId =
          inserted.rows[0].id;

        for (const line of lines) {
          const kardex =
            await recordSalida(
              context.db,

              {
                productId:
                  line.product.id,

                qty:
                  line.qty,

                reference:
                  `Venta #${saleId}`,

                userId:
                  context.user.id
              }
            );

          const unitCost = cash.money(
            kardex.unitCost,
            { allowZero: true }
          );

          await context.db.query(
            `
            INSERT INTO public.sale_items (
              sale_id,
              product_id,
              qty,
              unit_price,
              unit_cost,
              subtotal
            )
            VALUES (
              $1,
              $2,
              $3,
              $4,
              $5,
              $6
            )
            `,
            [
              saleId,
              line.product.id,
              line.qty,
              line.unit_price,
              unitCost,
              line.subtotal
            ]
          );
        }

        await cash.recordMovement(
          context,
          {
            sourceId: saleId
          }
        );

        // Se consulta antes de COMMIT usando el mismo
        // cliente. No queda una venta confirmada aunque
        // falle una lectura posterior al cobro.
        const sale = await readSale(
          context.db,
          saleId,
          context.user
        );

        return {
          sale,
          replayed: false
        };
      }
    );

    res
      .status(
        result.replayed ? 200 : 201
      )
      .json({
        ok: true,

        ...result.sale,

        replayed:
          result.replayed,

        receipt:
          receiptFromSale(
            result.sale
          )
      });
  })
);

module.exports = router;