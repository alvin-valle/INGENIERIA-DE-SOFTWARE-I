'use strict';

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const pool = require('../db/connection');
const {
  readPayments
} = require('../utils/print-payment-history');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const {
  TRANSITIONS,
  fail,
  integer,
  text,
  tariff,
  quote
} = require('../utils/produccion');

const router = express.Router();

// ============================================================
// 1. CONFIGURACIÓN DE ARCHIVOS
// ============================================================

const directory = path.join(
  __dirname,
  '../../uploads'
);

fs.mkdirSync(directory, {
  recursive: true
});

const extensions = new Set([
  '.pdf',
  '.doc',
  '.docx',
  '.xls',
  '.xlsx',
  '.png',
  '.jpg',
  '.jpeg'
]);

const upload = multer({
  storage: multer.diskStorage({
    destination: directory,

    filename: (req, file, cb) => {
      const extension = path
        .extname(file.originalname)
        .toLowerCase();

      cb(
        null,
        crypto.randomUUID() + extension
      );
    }
  }),

  limits: {
    fileSize: 20 * 1024 * 1024,
    files: 1,
    fields: 12,
    fieldSize: 4096
  },

  fileFilter: (req, file, cb) => {
    const extension = path
      .extname(file.originalname)
      .toLowerCase();

    if (extensions.has(extension)) {
      return cb(null, true);
    }

    const error = new Error(
      'Formato no admitido. Usa PDF, Word, Excel, PNG o JPG.'
    );

    error.status = 400;

    cb(error);
  }
});

// ============================================================
// 2. AUTENTICACIÓN Y PERMISOS
// requireRole permite también superadmin según tu middleware.
// ============================================================

const write = requireRole('admin', 'cajero');
const admin = requireRole('admin');

const wrap = fn => {
  return (req, res, next) => {
    return Promise.resolve(
      fn(req, res)
    ).catch(next);
  };
};

router.use(
  requireAuth,
  requireRole('admin', 'cajero', 'auditor')
);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');

  req.body ||= {};

  next();
});

// ============================================================
// 3. UTILIDADES
// ============================================================

async function transaction(fn) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const result = await fn(client);

    await client.query('COMMIT');

    return result;
  } catch (error) {
    await client
      .query('ROLLBACK')
      .catch(() => {});

    throw error;
  } finally {
    client.release();
  }
}

async function audit(
  client,
  req,
  action,
  details
) {
  await client.query(
    `
    INSERT INTO public.audit_log (
      user_id,
      action,
      entity,
      details
    )
    VALUES ($1, $2, $3, $4)
    `,
    [
      req.user.id,
      action,
      'produccion',
      JSON.stringify(details)
    ]
  );
}

async function removeUpload(req) {
  if (!req.file || req.keepUpload) {
    return;
  }

  await fs.promises
    .unlink(req.file.path)
    .catch(error => {
      if (error.code !== 'ENOENT') {
        console.error(
          '[Producción: archivo temporal]',
          error
        );
      }
    });
}

const id = value => {
  return integer(
    value,
    'Identificador',
    2147483647
  );
};

// Campos públicos del historial.
// No se expone el nombre físico del archivo almacenado.
const fields = `
  j.id,
  j.file_name,
  j.print_type,
  j.paper_size,
  j.orientation,
  j.copies,
  j.status,

  TO_CHAR(
    j.created_at,
    'YYYY-MM-DD"T"HH24:MI:SS'
  ) AS created_at,

  j.production_details,
  j.quoted_total,
  j.customer_name,
  j.customer_contact,
  j.notes,

  (
    j.file_storage_key IS NOT NULL
  ) AS has_file
`;

// ============================================================
// 4. CONSULTAR TARIFAS
// ============================================================

router.get(
  '/rates',
  wrap(async (req, res) => {
    const result = await pool.query(`
      SELECT *
      FROM public.production_rates
      ORDER BY active DESC, name, id
    `);

    res.json(result.rows);
  })
);

// ============================================================
// 5. CREAR TARIFA
// ============================================================

router.post(
  '/rates',
  admin,
  wrap(async (req, res) => {
    const r = tariff(req.body || {});

    const row = await transaction(async client => {
      const result = await client.query(
        `
        INSERT INTO public.production_rates (
          name,
          service,
          billing,
          sides,
          paper,
          color,
          tiers
        )
        VALUES (
          $1, $2, $3, $4, $5, $6, $7
        )
        RETURNING *
        `,
        [
          r.name,
          r.service,
          r.billing,
          r.sides,
          r.paper,
          r.color,
          JSON.stringify(r.tiers)
        ]
      );

      await audit(
        client,
        req,
        'crear_tarifa',
        {
          id: result.rows[0].id,
          ...r
        }
      );

      return result.rows[0];
    });

    res.status(201).json(row);
  })
);

// ============================================================
// 6. EDITAR O DESACTIVAR TARIFA
// Los precios de las órdenes anteriores se conservan.
// ============================================================

router.put(
  '/rates/:id',
  admin,
  wrap(async (req, res) => {
    const r = tariff(req.body || {});

    if (typeof req.body.active !== 'boolean') {
      fail('Estado de tarifa inválido.');
    }

    const row = await transaction(async client => {
      const result = await client.query(
        `
        UPDATE public.production_rates
        SET
          name = $1,
          service = $2,
          billing = $3,
          sides = $4,
          paper = $5,
          color = $6,
          tiers = $7,
          active = $8
        WHERE id = $9
        RETURNING *
        `,
        [
          r.name,
          r.service,
          r.billing,
          r.sides,
          r.paper,
          r.color,
          JSON.stringify(r.tiers),
          req.body.active,
          id(req.params.id)
        ]
      );

      if (!result.rows.length) {
        fail('Tarifa no encontrada.', 404);
      }

      await audit(
        client,
        req,
        'editar_tarifa',
        {
          id: result.rows[0].id,
          ...r,
          active: req.body.active
        }
      );

      return result.rows[0];
    });

    res.json(row);
  })
);

// ============================================================
// 7. CALCULAR COTIZACIÓN
// No registra ventas ni cobros.
// ============================================================

router.post(
  '/quote',
  wrap(async (req, res) => {
    const { rows } = await pool.query(
      `
      SELECT *
      FROM public.production_rates
      WHERE id = $1
        AND active
      `,
      [
        id(req.body.tariff_id)
      ]
    );

    if (!rows.length) {
      fail(
        'Selecciona una tarifa activa.',
        400
      );
    }

    const calculated = quote(
      rows[0],
      req.body.pages,
      req.body.copies
    );

    res.json(calculated);
  })
);

// ============================================================
// 8. REGISTRAR ORDEN CON ADJUNTO OPCIONAL
// ============================================================

router.post(
  '/upload',
  write,
  upload.single('file'),
  wrap(async (req, res) => {
    const data = {
      tariff_id: id(req.body.tariff_id),

      pages: integer(
        req.body.pages,
        'Páginas'
      ),

      copies: integer(
        req.body.copies,
        'Ejemplares'
      ),

      customer_name: text(
        req.body.customer_name,
        'Cliente',
        120
      ),

      customer_contact: text(
        req.body.customer_contact,
        'Teléfono o cédula',
        80
      ),

      notes: text(
        req.body.notes,
        'Notas',
        1000
      ),

      orientation: text(
        req.body.orientation,
        'Orientación',
        30
      ),

      quote_key: text(
        req.body.quote_key,
        'Cotización',
        64,
        true
      )
    };

    if (
      !['Vertical', 'Horizontal'].includes(
        data.orientation
      )
    ) {
      fail('Orientación inválida.');
    }

    const key = text(
      req.body.request_key,
      'Identificador de solicitud',
      36,
      true
    ).toLowerCase();

    const uuidPattern =
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    if (!uuidPattern.test(key)) {
      fail(
        'Identificador de solicitud inválido.'
      );
    }

    // Identifica el contenido del adjunto.
    const fileHash = crypto.createHash('sha256');

    if (req.file) {
      for await (
        const chunk of fs.createReadStream(req.file.path)
      ) {
        fileHash.update(chunk);
      }
    }

    // Identifica el contenido completo de la solicitud.
    const hash = crypto
      .createHash('sha256')
      .update(
        JSON.stringify({
          ...data,
          user: req.user.id,
          file: req.file?.originalname || null,
          bytes: fileHash.digest('hex')
        })
      )
      .digest('hex');

    let created = false;

    const job = await transaction(async client => {
      // Serializa los reintentos de una misma solicitud.
      await client.query(
        `
        SELECT pg_advisory_xact_lock(
          hashtextextended($1, 0)
        )
        `,
        [key]
      );

      const existing = await client.query(
        `
        SELECT *
        FROM public.print_jobs
        WHERE request_key = $1
        `,
        [key]
      );

      if (existing.rows.length) {
        if (
          existing.rows[0].request_hash !== hash
        ) {
          fail(
            'La solicitud ya existe con otros datos. ' +
            'Actualiza el historial antes de volver a registrar.',
            409
          );
        }

        return existing.rows[0];
      }

      // Evita que la tarifa cambie mientras se guarda la orden.
      const rate = await client.query(
        `
        SELECT *
        FROM public.production_rates
        WHERE id = $1
          AND active
        FOR SHARE
        `,
        [data.tariff_id]
      );

      if (!rate.rows.length) {
        fail(
          'La tarifa ya no está activa. Selecciona otra.'
        );
      }

      const calculated = quote(
        rate.rows[0],
        data.pages,
        data.copies
      );

      if (
        calculated.quote_key !== data.quote_key
      ) {
        fail(
          'La tarifa cambió. ' +
          'Actualiza la cotización antes de guardar.',
          409
        );
      }

      const result = await client.query(
        `
        INSERT INTO public.print_jobs (
          file_name,
          print_type,
          paper_size,
          orientation,
          copies,
          status,
          created_at,
          production_details,
          quoted_total,
          customer_name,
          customer_contact,
          notes,
          created_by,
          file_storage_key,
          request_key,
          request_hash,
          updated_at
        )
        VALUES (
          $1,
          $2,
          $3,
          $4,
          $5,
          'Pendiente',
          CURRENT_TIMESTAMP AT TIME ZONE 'America/Managua',
          $6,
          $7,
          $8,
          $9,
          $10,
          $11,
          $12,
          $13,
          $14,
          CURRENT_TIMESTAMP
        )
        RETURNING *
        `,
        [
          req.file?.originalname ||
            'Trabajo sin archivo adjunto',

          calculated.color,
          calculated.paper,
          data.orientation,
          data.copies,
          JSON.stringify(calculated),
          calculated.total,
          data.customer_name,
          data.customer_contact,
          data.notes,
          req.user.id,
          req.file?.filename || null,
          key,
          hash
        ]
      );

      await audit(
        client,
        req,
        'crear_orden',
        {
          id: result.rows[0].id,
          total_cotizado: calculated.total
        }
      );

      // Conserva el archivo si se pierde la conexión durante
      // el COMMIT y no puede confirmarse su resultado.
      req.keepUpload = true;

      created = true;

      return result.rows[0];
    });

    // En un reintento, elimina el nuevo adjunto duplicado.
    await removeUpload(req);

    res.status(created ? 201 : 200).json({
      ok: true,

      job: {
        id: job.id,
        status: job.status,
        quoted_total: job.quoted_total
      }
    });
  })
);

// ============================================================
// 9. FILTROS DEL HISTORIAL
// ============================================================

function filters(req) {
  const q = text(
    req.query.q,
    'Búsqueda',
    120
  );

  const status = text(
    req.query.status,
    'Estado',
    30
  );

  if (
    status &&
    !Object.hasOwn(TRANSITIONS, status)
  ) {
    fail('Estado inválido.');
  }

  return {
    sql: `
      WHERE (
        $1 = ''
        OR strpos(
          lower(
            concat_ws(
              ' ',
              j.id::text,
              j.file_name,
              j.customer_name,
              j.customer_contact,
              j.production_details->>'name'
            )
          ),
          lower($1)
        ) > 0
      )
      AND (
        $2 = ''
        OR j.status = $2
      )
    `,

    params: [q, status]
  };
}

// ============================================================
// 10. CONSULTAR ÓRDENES CON PAGINACIÓN
// ============================================================

router.get(
  '/orders',
  wrap(async (req, res) => {
    const page = integer(
      req.query.page || 1,
      'Página',
      100000
    );

    const f = filters(req);

    const { rows } = await pool.query(
      `
      SELECT ${fields}

      FROM public.print_jobs j

      ${f.sql}

      ORDER BY
        j.created_at DESC,
        j.id DESC

      LIMIT 25
      OFFSET $3
      `,
      [
        ...f.params,
        (page - 1) * 25
      ]
    );

    const count = await pool.query(
      `
      SELECT COUNT(*)::int AS total

      FROM public.print_jobs j

      ${f.sql}
      `,
      f.params
    );

    const payments = await readPayments(
      pool,
      rows.map(row => row.id),
      req.user
    );

    const items = rows.map(row => ({
      ...row,

      payment:
        payments.get(String(row.id)) || null
    }));

    res.set('Cache-Control', 'no-store');

    res.json({
      items,
      total: count.rows[0].total,
      page,
      page_size: 25
    });
  })
);

// ============================================================
// 11. HISTORIAL COMPATIBLE CON LAS RUTAS ANTERIORES
// Devuelve un arreglo.
// ============================================================

router.get(
  ['/history', '/recent'],
  wrap(async (req, res) => {
    const result = await pool.query(`
      SELECT ${fields}
      FROM public.print_jobs j
      ORDER BY j.created_at DESC, j.id DESC
      LIMIT 20
    `);

    res.json(result.rows);
  })
);

// ============================================================
// 12. RESUMEN OPERATIVO DE PRODUCCIÓN
// ============================================================

router.get(
  '/overview',
  wrap(async (req, res) => {
    const state = await pool.query(`
      SELECT
        status,
        COUNT(*)::int AS count
      FROM public.print_jobs
      GROUP BY status
    `);

    const daily = await pool.query(`
      WITH days AS (
        SELECT generate_series(
          (
            CURRENT_TIMESTAMP
            AT TIME ZONE 'America/Managua'
          )::date - 6,

          (
            CURRENT_TIMESTAMP
            AT TIME ZONE 'America/Managua'
          )::date,

          INTERVAL '1 day'
        ) AS day
      )

      SELECT
        TO_CHAR(
          d.day,
          'YYYY-MM-DD'
        ) AS date,

        COUNT(j.id)::int AS count

      FROM days d

      LEFT JOIN public.print_jobs j
        ON j.created_at >= d.day
        AND j.created_at < d.day + INTERVAL '1 day'

      GROUP BY d.day
      ORDER BY d.day
    `);

    res.json({
      states: state.rows,
      daily: daily.rows
    });
  })
);

// ============================================================
// 13. CAMBIAR ESTADO DE UNA ORDEN
// ============================================================

router.patch(
  '/orders/:id/status',
  write,
  wrap(async (req, res) => {
    const jobId = id(req.params.id);

    const target = text(
      req.body.status,
      'Estado',
      30,
      true
    );

    const expected = text(
      req.body.expected_status,
      'Estado anterior',
      30,
      true
    );

    const row = await transaction(async client => {
      const result = await client.query(
        `
        SELECT id, status
        FROM public.print_jobs
        WHERE id = $1
        FOR UPDATE
        `,
        [jobId]
      );

      if (!result.rows.length) {
        fail(
          'Orden no encontrada.',
          404
        );
      }

      const current = result.rows[0].status;

      if (current !== expected) {
        fail(
          'Otro usuario modificó esta orden. ' +
          'Actualiza el historial.',
          409
        );
      }

      if (
        !Object.hasOwn(TRANSITIONS, current) ||
        !TRANSITIONS[current].includes(target)
      ) {
        fail(
          'Cambio de estado no permitido.',
          409
        );
      }

      await client.query(
        `
        UPDATE public.print_jobs
        SET
          status = $1,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
        `,
        [
          target,
          jobId
        ]
      );

      await audit(
        client,
        req,
        'estado_orden',
        {
          id: jobId,
          anterior: current,
          nuevo: target
        }
      );

      return {
        id: jobId,
        status: target
      };
    });

    res.json(row);
  })
);

// ============================================================
// 14. DESCARGAR EL ARCHIVO VINCULADO A UNA ORDEN
// ============================================================

router.get(
  '/orders/:id/file',
  wrap(async (req, res) => {
    const { rows } = await pool.query(
      `
      SELECT
        file_name,
        file_storage_key
      FROM public.print_jobs
      WHERE id = $1
      `,
      [
        id(req.params.id)
      ]
    );

    const row = rows[0];

    if (!row?.file_storage_key) {
      fail(
        'Esta orden no tiene un archivo recuperable vinculado.',
        404
      );
    }

    const storedNamePattern =
      /^[0-9a-f-]{36}\.[a-z0-9]+$/;

    if (
      !storedNamePattern.test(row.file_storage_key)
    ) {
      fail(
        'Referencia de archivo inválida.',
        500
      );
    }

    const file = path.join(
      directory,
      row.file_storage_key
    );

    try {
      await fs.promises.access(file);
    } catch {
      fail(
        'El archivo ya no está disponible.',
        404
      );
    }

    res.set(
      'X-Content-Type-Options',
      'nosniff'
    );

    await new Promise((resolve, reject) => {
      res.download(
        file,
        row.file_name,
        error => {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
        }
      );
    });
  })
);

// ============================================================
// 15. MANEJO DE ERRORES
// ============================================================

router.use((error, req, res, next) => {
  removeUpload(req)
    .then(() => {
      if (res.headersSent) {
        return next(error);
      }

      console.error(
        '[Producción]',
        error
      );

      let status = error.status || 500;
      let message;

      if (error instanceof multer.MulterError) {
        status = error.code === 'LIMIT_FILE_SIZE'
          ? 413
          : 400;

        message =
          'Revisa el adjunto: máximo 20 MB y un solo archivo.';
      } else if (error.code === '23505') {
        status = 409;

        message =
          'Ya existe una tarifa activa con ese nombre.';
      } else if (status < 500) {
        message = error.message;
      } else {
        message =
          'No se pudo completar la operación de Producción. ' +
          'Revisa la terminal del servidor.';
      }

      res.status(status).json({
        error: message
      });
    })
    .catch(next);
});

module.exports = router;