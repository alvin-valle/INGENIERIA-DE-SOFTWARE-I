'use strict';

const router = require('express').Router();
const pool = require('../db/connection');

const {
    requireAuth,
    requireRole
} = require('../middleware/auth');

router.use(
    requireAuth,
    requireRole('admin', 'auditor')
);

router.use((peticion, respuesta, siguiente) => {
    respuesta.set('Cache-Control', 'no-store');
    siguiente();
});

const consultas = {
    empleados: {
        tabla: 'empleados',
        titulo: 'Empleados anteriores',
        destino: 'rh-empleados',

        sql: `
            SELECT
                id,
                nom,
                car,
                sal,
                TO_CHAR(fec, 'YYYY-MM-DD') AS fec,
                est
            FROM public.empleados
            ORDER BY id DESC
        `,

        columnas: [
            ['nom', 'Nombre'],
            ['car', 'Cargo'],
            ['sal', 'Salario'],
            ['fec', 'Ingreso'],
            ['est', 'Estado']
        ]
    },

    nomina: {
        tabla: 'nomina',
        titulo: 'Nómina anterior',
        destino: 'conta-nomina',

        sql: `
            SELECT
                n.*,
                TO_CHAR(
                    n.fecha,
                    'YYYY-MM-DD"T"HH24:MI:SS'
                ) AS fecha,
                COALESCE(
                    e.nom,
                    'Empleado sin vínculo'
                ) AS empleado,
                e.nom AS nombre_empleado,
                e.car AS cargo_empleado,
                TO_CHAR(
                    e.fec,
                    'YYYY-MM-DD'
                ) AS ingreso_empleado
            FROM public.nomina n
            LEFT JOIN public.empleados e
                ON e.id = n.empleado_id
            ORDER BY n.id DESC
        `,

        columnas: [
            ['empleado', 'Empleado'],
            ['bruto', 'Bruto'],
            ['tot_ded', 'Deducciones'],
            ['neto', 'Neto'],
            ['fecha', 'Fecha'],
            ['metodo_pago', 'Método']
        ]
    },

    compras: {
        tabla: 'compras',
        titulo: 'Compras anteriores',
        destino: 'conta-compras',

        sql: `
            SELECT
                c.*,
                TO_CHAR(c.fec, 'YYYY-MM-DD') AS fec,
                p.nombre AS prov
            FROM public.compras c
            LEFT JOIN public.proveedores p
                ON p.id = c.proveedor_id
            ORDER BY c.id DESC
        `,

        columnas: [
            ['prov', 'Proveedor'],
            ['con', 'Concepto'],
            ['mon', 'Importe'],
            ['fec', 'Fecha'],
            ['est', 'Estado'],
            ['metodo_pago', 'Método']
        ]
    },

    contratos: {
        tabla: 'contratos',
        titulo: 'Contratos anteriores',
        destino: 'rh-contratos',

        sql: `
            SELECT
                c.*,
                TO_CHAR(
                    c.fecha_inicio,
                    'YYYY-MM-DD'
                ) AS fecha_inicio,
                TO_CHAR(
                    c.fecha_fin,
                    'YYYY-MM-DD'
                ) AS fecha_fin,
                e.nom AS emp,
                c.jornada AS jor
            FROM public.contratos c
            LEFT JOIN public.empleados e
                ON e.id = c.empleado_id
            ORDER BY c.id DESC
        `,

        columnas: [
            ['emp', 'Empleado'],
            ['tipo', 'Tipo'],
            ['jornada', 'Jornada'],
            ['fecha_inicio', 'Inicio'],
            ['fecha_fin', 'Fin'],
            ['salario', 'Salario'],
            ['estado', 'Estado']
        ]
    },

    permisos: {
        tabla: 'permisos',
        titulo: 'Ausencias anteriores',
        destino: 'rh-permisos',

        sql: `
            SELECT p.*, e.nom AS emp
            FROM public.permisos p
            LEFT JOIN public.empleados e
                ON e.id = p.empleado_id
            ORDER BY p.id DESC
        `,

        columnas: [
            ['emp', 'Empleado'],
            ['tip', 'Tipo'],
            ['fec', 'Fechas'],
            ['estado', 'Estado']
        ]
    },

    proveedores: {
        tabla: 'proveedores',
        titulo: 'Proveedores',
        destino: 'dash-proveedores',

        sql: `
            SELECT *
            FROM public.proveedores
            ORDER BY id DESC
        `,

        columnas: [
            ['nombre', 'Proveedor'],
            ['service_type', 'Servicio'],
            ['metodo_pago_pref', 'Método'],
            ['estado', 'Estado']
        ]
    },

    caja: {
        tabla: 'caja',
        titulo: 'Movimientos de caja',
        destino: 'finanzas-caja',

        sql: `
            SELECT
                c.*,
                TO_CHAR(c.fec, 'YYYY-MM-DD') AS fec,
                u.full_name AS cajero
            FROM public.caja c
            LEFT JOIN public.users u
                ON u.id = c.user_id
            ORDER BY c.fec DESC, c.id DESC
        `,

        columnas: [
            ['fec', 'Fecha'],
            ['con', 'Concepto'],
            ['tip', 'Tipo'],
            ['mon', 'Importe'],
            ['metodo_pago', 'Método'],
            ['cajero', 'Cajero'],
            ['shift_id', 'Turno']
        ]
    },

    ordenes: {
        tabla: 'ordenes',
        sql: `
            SELECT *
            FROM public.ordenes
            ORDER BY id DESC
        `
    },

    ventas: {
        tabla: 'sales',
        sql: `
            SELECT
                s.*,
                TO_CHAR(
                    s.date,
                    'YYYY-MM-DD"T"HH24:MI:SS'
                ) AS date
            FROM public.sales s
            ORDER BY s.id DESC
        `
    },

    facturas: {
        tabla: 'facturas',
        sql: `
            SELECT *
            FROM public.facturas
            ORDER BY id DESC
        `
    },

    mercadotecnia: {
        tabla: 'mercadotecnia',
        sql: `
            SELECT *
            FROM public.mercadotecnia
            ORDER BY id DESC
        `
    },

    liquidaciones: {
        tabla: 'liquidaciones',
        sql: `
            SELECT *
            FROM public.liquidaciones
            ORDER BY id DESC
        `
    }
};

function fecha(valor, nombre) {
    if (
        typeof valor !== 'string' ||
        !/^\d{4}-\d{2}-\d{2}$/.test(valor)
    ) {
        throw Object.assign(
            new Error(nombre + ': usa AAAA-MM-DD.'),
            { status: 400 }
        );
    }

    const resultado = new Date(valor + 'T00:00:00Z');

    if (
        Number(valor.slice(0, 4)) < 1 ||
        !Number.isFinite(resultado.getTime()) ||
        resultado.toISOString().slice(0, 10) !== valor
    ) {
        throw Object.assign(
            new Error(nombre + ': fecha inválida.'),
            { status: 400 }
        );
    }

    return valor;
}

function centavos(valor) {
    const texto = String(valor);

    if (!/^-?\d+(?:\.\d{1,2})?$/.test(texto)) {
        throw new Error('Importe contable inválido.');
    }

    const negativo = texto.startsWith('-');
    const partes = texto.replace(/^-/, '').split('.');

    const resultado =
        BigInt(partes[0]) * 100n +
        BigInt((partes[1] || '').padEnd(2, '0'));

    return negativo ? -resultado : resultado;
}

function importe(valor) {
    const negativo = valor < 0n;
    const absoluto = negativo ? -valor : valor;

    return (
        (negativo ? '-' : '') +
        (absoluto / 100n) +
        '.' +
        String(absoluto % 100n).padStart(2, '0')
    );
}

function filasBalance(cuentas) {
    const filas = [];

    let activos = 0n;
    let pasivos = 0n;
    let patrimonio = 0n;
    let resultado = 0n;

    for (const cuenta of cuentas) {
        const debe = centavos(cuenta.debe);
        const haber = centavos(cuenta.haber);

        if (cuenta.clase === 'income') {
            resultado += haber - debe;
            continue;
        }

        if (cuenta.clase === 'expense') {
            resultado -= debe - haber;
            continue;
        }

        const saldo = cuenta.clase === 'asset'
            ? debe - haber
            : haber - debe;

        if (cuenta.clase === 'asset') activos += saldo;
        if (cuenta.clase === 'liability') pasivos += saldo;
        if (cuenta.clase === 'equity') patrimonio += saldo;

        filas.push({
            grupo: {
                asset: 'Activo',
                liability: 'Pasivo',
                equity: 'Patrimonio'
            }[cuenta.clase],
            cuenta: cuenta.cuenta,
            importe: importe(saldo)
        });
    }

    filas.push({
        grupo: 'Patrimonio',
        cuenta: 'Resultado acumulado registrado',
        importe: importe(resultado)
    });

    filas.push({
        grupo: 'Total',
        cuenta: 'Activos registrados',
        importe: importe(activos)
    });

    filas.push({
        grupo: 'Total',
        cuenta: 'Pasivos y patrimonio registrados',
        importe: importe(
            pasivos + patrimonio + resultado
        )
    });

    filas.push({
        grupo: 'Control',
        cuenta: 'Diferencia contable',
        importe: importe(
            activos - pasivos - patrimonio - resultado
        )
    });

    return filas;
}

function filasResultados(cuentas) {
    let ingresos = 0n;
    let gastos = 0n;

    const filas = [];

    for (const cuenta of cuentas) {
        const saldo = cuenta.clase === 'income'
            ? centavos(cuenta.haber) - centavos(cuenta.debe)
            : centavos(cuenta.debe) - centavos(cuenta.haber);

        if (cuenta.clase === 'income') {
            ingresos += saldo;
        } else {
            gastos += saldo;
        }

        filas.push({
            grupo: cuenta.clase === 'income'
                ? 'Ingreso'
                : 'Costo / gasto',
            cuenta: cuenta.cuenta,
            importe: importe(saldo)
        });
    }

    filas.push({
        grupo: 'Total',
        cuenta: 'Ingresos registrados',
        importe: importe(ingresos)
    });

    filas.push({
        grupo: 'Total',
        cuenta: 'Costos y gastos registrados',
        importe: importe(gastos)
    });

    filas.push({
        grupo: 'Resultado',
        cuenta: 'Resultado del período',
        importe: importe(ingresos - gastos)
    });

    return filas;
}

function paginasValidas(valor) {
    let paginas = {};

    if (valor) {
        if (
            typeof valor !== 'string' ||
            valor.length > 2000
        ) {
            throw Object.assign(
                new Error('Paginación inválida.'),
                { status: 400 }
            );
        }

        try {
            paginas = JSON.parse(valor);
        } catch {
            throw Object.assign(
                new Error('Paginación inválida.'),
                { status: 400 }
            );
        }
    }

    if (
        !paginas ||
        typeof paginas !== 'object' ||
        Array.isArray(paginas)
    ) {
        throw Object.assign(
            new Error('Paginación inválida.'),
            { status: 400 }
        );
    }

    for (const [nombre, pagina] of Object.entries(paginas)) {
        if (
            !Object.hasOwn(consultas, nombre) ||
            !Number.isSafeInteger(pagina) ||
            pagina < 1 ||
            pagina > 1000000
        ) {
            throw Object.assign(
                new Error('Página fuera de rango.'),
                { status: 400 }
            );
        }
    }

    return paginas;
}

async function lectura(operacion) {
    const cliente = await pool.connect();

    try {
        await cliente.query(
            'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY'
        );

        const resultado = await operacion(cliente);

        await cliente.query('COMMIT');

        return resultado;
    } catch (error) {
        await cliente.query('ROLLBACK').catch(() => {});
        throw error;
    } finally {
        cliente.release();
    }
}

function ruta(operacion) {
    return async (peticion, respuesta) => {
        try {
            respuesta.json(await operacion(peticion));
        } catch (error) {
            console.error(
                '[Sincronización]',
                error.code || error.message
            );

            respuesta.status(error.status || 500).json({
                error: error.status
                    ? error.message
                    : (
                        'No se pudo consultar la base de datos. ' +
                        'Revisa la terminal del servidor.'
                    ),
                codigo: error.code || 'SINCRONIZACION_ERROR'
            });
        }
    };
}

router.get('/integraciones', (peticion, respuesta) => {
    respuesta.json({
        banpro_billetera: {
            habilitada: false,
            estado: 'pendiente',
            operaciones_disponibles: []
        }
    });
});

router.get('/resumen', ruta(async peticion => {
    const paginas = paginasValidas(
        peticion.query.paginas
    );

    return lectura(async cliente => {
        const fuentes = {};

        for (
            const [nombre, configuracion]
            of Object.entries(consultas)
        ) {
            const existe = (
                await cliente.query(
                    'SELECT to_regclass($1) AS nombre',
                    ['public.' + configuracion.tabla]
                )
            ).rows[0].nombre;

            const base = {
                titulo: configuracion.titulo || nombre,
                destino: configuracion.destino || null,
                columnas: configuracion.columnas || [],
                pagina: paginas[nombre] || 1
            };

            if (!existe) {
                fuentes[nombre] = {
                    ...base,
                    estado: 'sin_tabla',
                    filas: [],
                    total: 0
                };

                continue;
            }

            await cliente.query('SAVEPOINT fuente');

            try {
                // El nombre procede de la lista fija de consultas.
                const cuenta = await cliente.query(
                    'SELECT COUNT(*)::text AS total FROM public.' +
                    configuracion.tabla
                );

                const resultado = await cliente.query(
                    configuracion.sql + ' LIMIT $1 OFFSET $2',
                    [
                        100,
                        (base.pagina - 1) * 100
                    ]
                );

                fuentes[nombre] = {
                    ...base,
                    estado: 'correcto',
                    filas: resultado.rows,
                    total: cuenta.rows[0].total
                };

                await cliente.query(
                    'RELEASE SAVEPOINT fuente'
                );
            } catch (error) {
                await cliente.query(
                    'ROLLBACK TO SAVEPOINT fuente'
                );

                await cliente.query(
                    'RELEASE SAVEPOINT fuente'
                );

                fuentes[nombre] = {
                    ...base,
                    estado: 'error',
                    filas: [],
                    total: null,
                    error: 'No se pudo consultar esta fuente.',
                    codigo: error.code || 'CONSULTA_ERROR'
                };
            }
        }

        const caja = (
            await cliente.query(`
                SELECT
                    COUNT(*)::text AS movimientos,

                    COALESCE(
                        SUM(mon) FILTER(
                            WHERE tip = 'Entrada'
                        ),
                        0
                    )::text AS entradas,

                    COALESCE(
                        SUM(mon) FILTER(
                            WHERE tip = 'Salida'
                        ),
                        0
                    )::text AS salidas

                FROM public.caja
            `)
        ).rows[0];

        return {
            generado_en: new Date().toISOString(),
            fuentes,
            caja,
            parcial: Object.values(fuentes).some(
                fuente => fuente.estado === 'error'
            )
        };
    });
}));

router.get('/estados', ruta(async peticion => {
    const desde = fecha(
        peticion.query.desde,
        'Fecha inicial'
    );

    const hasta = fecha(
        peticion.query.hasta,
        'Fecha final'
    );

    if (desde > hasta) {
        throw Object.assign(
            new Error(
                'La fecha inicial supera la fecha final.'
            ),
            { status: 400 }
        );
    }

    return lectura(async cliente => {
        const parametros = [desde, hasta];

        const balance = await cliente.query(`
            SELECT
                a.code AS codigo,
                a.name AS cuenta,
                a.kind AS clase,

                COALESCE(
                    SUM(l.debit) FILTER(
                        WHERE (
                            j.posted_at
                            AT TIME ZONE 'America/Managua'
                        )::date <= $2::date
                    ),
                    0
                )::text AS debe,

                COALESCE(
                    SUM(l.credit) FILTER(
                        WHERE (
                            j.posted_at
                            AT TIME ZONE 'America/Managua'
                        )::date <= $2::date
                    ),
                    0
                )::text AS haber

            FROM public.kc_accounts a

            LEFT JOIN public.kc_journal_lines l
                ON l.account_code = a.code

            LEFT JOIN public.kc_journals j
                ON j.id = l.journal_id

            WHERE $1::date IS NOT NULL

            GROUP BY a.code, a.name, a.kind
            ORDER BY a.code
        `, parametros);

        const resultados = await cliente.query(`
            SELECT
                a.code AS codigo,
                a.name AS cuenta,
                a.kind AS clase,
                SUM(l.debit)::text AS debe,
                SUM(l.credit)::text AS haber

            FROM public.kc_journal_lines l

            JOIN public.kc_accounts a
                ON a.code = l.account_code

            JOIN public.kc_journals j
                ON j.id = l.journal_id

            WHERE a.kind IN ('income', 'expense')

              AND (
                j.posted_at
                AT TIME ZONE 'America/Managua'
              )::date BETWEEN $1::date AND $2::date

            GROUP BY a.code, a.name, a.kind
            ORDER BY a.code
        `, parametros);

        const flujo = await cliente.query(`
            SELECT
                tip AS tipo,
                COALESCE(
                    metodo_pago,
                    'Sin especificar'
                ) AS metodo,
                COUNT(*)::text AS registros,
                SUM(mon)::text AS importe

            FROM public.caja

            WHERE fec BETWEEN $1::date AND $2::date

            GROUP BY tip, metodo_pago
            ORDER BY tip, metodo_pago
        `, parametros);

        return {
            desde,
            hasta,
            balance: filasBalance(balance.rows),
            resultados: filasResultados(resultados.rows),
            flujo: flujo.rows,

            alcance:
                'Balance: movimientos contabilizados acumulados ' +
                'hasta el corte. Resultados: asientos del período. ' +
                'Flujo: cobros y pagos registrados en caja. ' +
                'No se reconstruyen saldos iniciales ni registros ' +
                'anteriores sin asiento.'
        };
    });
}));

module.exports = router;