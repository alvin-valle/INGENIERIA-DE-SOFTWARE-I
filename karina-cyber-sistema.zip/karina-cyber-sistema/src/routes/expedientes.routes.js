'use strict';

const router = require('express').Router();
const crypto = require('node:crypto');
const multer = require('multer');

const pool = require('../db/connection');

const {
    requireAuth,
    requireRole
} = require('../middleware/auth');

const {
    handle,
    text,
    fail,
    transaction
} = require('../utils/enterprise');

const caja = require('../services/cash.service');
const privados = require('../services/archivos-privados');

router.use(
    requireAuth,
    requireRole('admin', 'auditor')
);

router.use((peticion, respuesta, siguiente) => {
    respuesta.set('Cache-Control', 'no-store');
    siguiente();
});

const administrador = requireRole('admin');

const identificador = valor => caja.positiveId(valor);

const textoOpcional = (
    valor,
    nombre,
    maximo = 150
) => text(
    valor ?? '',
    nombre,
    maximo,
    false,
    true
);

const camposDatos = [
    'fecha_nacimiento',
    'telefono',
    'correo',
    'direccion',
    'departamento',
    'tipo_contrato',
    'horario',
    'bono_fijo',
    'deduccion_fija',
    'observaciones'
];

const consultaBase = `
    SELECT
        e.*,
        TO_CHAR(
            e.hired_on,
            'YYYY-MM-DD'
        ) AS hired_on,
        p.datos,
        p.reservados,
        p.mascaras,
        COALESCE(
            p.version,
            0
        ) AS version_expediente
    FROM public.kc_employees e
    LEFT JOIN public.kc_rrhh_expedientes p
        ON p.empleado_id = e.id
`;

function fecha(valor, obligatoria = false) {
    if (!valor && !obligatoria) return null;

    if (
        typeof valor !== 'string' ||
        !/^\d{4}-\d{2}-\d{2}$/.test(valor) ||
        Number(valor.slice(0, 4)) < 1
    ) {
        fail('Fecha inválida.');
    }

    const resultado = new Date(
        valor + 'T00:00:00Z'
    );

    if (
        !Number.isFinite(resultado.getTime()) ||
        resultado.toISOString().slice(0, 10) !== valor
    ) {
        fail('Fecha inválida.');
    }

    return valor;
}

function revision(fila) {
    return crypto
        .createHash('sha256')
        .update(
            JSON.stringify([
                fila.id,
                fila.full_name,
                fila.position,
                String(fila.salary),
                fila.hired_on,
                fila.active,
                fila.version_expediente
            ])
        )
        .digest('hex');
}

function basicos(fila) {
    return {
        id: fila.id,
        nombre: fila.full_name,
        cargo: fila.position,
        salario: fila.salary,
        fecha_ingreso: fila.hired_on,
        activo: fila.active,
        origen: fila.origen || 'actual',
        revision: fila.origen === 'anterior'
            ? null
            : revision(fila)
    };
}

async function obtenerBase(
    cliente,
    id,
    bloquear = false
) {
    const fila = (
        await cliente.query(
            consultaBase +
            ' WHERE e.id = $1' +
            (
                bloquear
                    ? ' FOR UPDATE OF e'
                    : ''
            ),
            [id]
        )
    ).rows[0];

    if (!fila) {
        fail('Empleado no encontrado.', 404);
    }

    return fila;
}

async function auditar(
    cliente,
    usuario,
    accion,
    empleado,
    detalle = {}
) {
    await cliente.query(
        `
        INSERT INTO public.audit_log(
            user_id,
            action,
            entity,
            details,
            created_at
        )
        VALUES(
            $1,
            $2,
            $3,
            $4,
            CURRENT_TIMESTAMP
        )
        `,
        [
            usuario,
            accion,
            empleado
                ? 'rrhh:' + empleado
                : 'publicidad',
            JSON.stringify(
                empleado
                    ? {
                        empleado_id: empleado,
                        ...detalle
                    }
                    : detalle
            )
        ]
    );
}

async function lectura(operacion) {
    const cliente = await pool.connect();

    try {
        await cliente.query(
            'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY'
        );

        const resultado = await operacion(cliente);

        await cliente.query('COMMIT');

        return resultado;
    } catch (error) {
        await cliente.query('ROLLBACK').catch(() => {});
        throw error;
    } finally {
        cliente.release();
    }
}

function validarDatos(datos) {
    if (
        !datos ||
        typeof datos !== 'object' ||
        Array.isArray(datos)
    ) {
        fail('Datos del expediente inválidos.');
    }

    for (const campo of Object.keys(datos)) {
        if (!camposDatos.includes(campo)) {
            fail('Campo de expediente no permitido.');
        }
    }

    const resultado = {};

    for (const campo of camposDatos) {
        if (
            ['bono_fijo', 'deduccion_fija'].includes(campo)
        ) {
            resultado[campo] =
                datos[campo] == null ||
                datos[campo] === ''
                    ? null
                    : caja.money(
                        datos[campo],
                        { allowZero: true }
                    );
        } else if (campo === 'fecha_nacimiento') {
            resultado[campo] = fecha(datos[campo]);
        } else {
            resultado[campo] = textoOpcional(
                datos[campo],
                campo,
                campo === 'observaciones' ||
                campo === 'direccion'
                    ? 2000
                    : 150
            );
        }
    }

    if (
        resultado.correo &&
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
            resultado.correo
        )
    ) {
        fail('Correo inválido.');
    }

    return resultado;
}

function validarReservados(datos) {
    if (
        !datos ||
        typeof datos !== 'object' ||
        Array.isArray(datos) ||
        Object.keys(datos).some(
            clave => ![
                'cedula',
                'pasaporte',
                'cuentas'
            ].includes(clave)
        )
    ) {
        fail('Datos reservados inválidos.');
    }

    const cuentas = datos.cuentas ?? [];

    if (
        !Array.isArray(cuentas) ||
        cuentas.length > 10
    ) {
        fail('Se admiten hasta diez cuentas bancarias.');
    }

    return {
        cedula: text(
            datos.cedula ?? '',
            'Cédula',
            60,
            false
        ),

        pasaporte: text(
            datos.pasaporte ?? '',
            'Pasaporte',
            60,
            false
        ),

        cuentas: cuentas.map(cuenta => {
            if (
                !cuenta ||
                typeof cuenta !== 'object' ||
                Array.isArray(cuenta) ||
                Object.keys(cuenta).some(
                    clave => ![
                        'banco',
                        'titular',
                        'numero'
                    ].includes(clave)
                )
            ) {
                fail('Cuenta bancaria inválida.');
            }

            return {
                banco: text(
                    cuenta.banco,
                    'Banco',
                    120
                ),

                titular: textoOpcional(
                    cuenta.titular,
                    'Titular',
                    150
                ),

                numero: text(
                    cuenta.numero,
                    'Cuenta bancaria',
                    80
                )
            };
        })
    };
}

function mascaras(datos) {
    const ocultar = valor => valor
        ? '••••' + valor.slice(-4)
        : null;

    return {
        cedula: ocultar(datos.cedula),
        pasaporte: ocultar(datos.pasaporte),

        cuentas: datos.cuentas.map(cuenta => ({
            banco: cuenta.banco,
            numero: ocultar(cuenta.numero)
        }))
    };
}

router.get('/empleados', handle(async (
    peticion,
    respuesta
) => {
    const pagina = Number(
        peticion.query.pagina || 1
    );

    if (
        !Number.isSafeInteger(pagina) ||
        pagina < 1 ||
        pagina > 100000
    ) {
        fail('Página inválida.');
    }

    const busqueda = textoOpcional(
        peticion.query.buscar,
        'Búsqueda',
        100
    ) || '';

    const resultado = await lectura(async cliente => {
        const parametros = [
            '%' + busqueda + '%'
        ];

        const union = `
            WITH empleados_consultados AS (
                SELECT
                    e.id,
                    e.full_name,
                    e.position,
                    e.salary,
                    TO_CHAR(
                        e.hired_on,
                        'YYYY-MM-DD'
                    ) AS hired_on,
                    e.active,
                    COALESCE(
                        p.version,
                        0
                    ) AS version_expediente,
                    'actual'::text AS origen
                FROM public.kc_employees e
                LEFT JOIN public.kc_rrhh_expedientes p
                    ON p.empleado_id = e.id

                UNION ALL

                SELECT
                    a.id,
                    a.nom,
                    a.car,
                    a.sal,
                    TO_CHAR(
                        a.fec,
                        'YYYY-MM-DD'
                    ),
                    CASE
                        WHEN a.est = 'Activo' THEN TRUE
                        WHEN a.est = 'Inactivo' THEN FALSE
                        ELSE NULL
                    END,
                    0,
                    'anterior'
                FROM public.empleados a
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM public.kc_rrhh_vinculos v
                    WHERE v.empleado_anterior_id = a.id
                )
            )
        `;

        const total = (
            await cliente.query(
                union + `
                    SELECT COUNT(*)::text AS total
                    FROM empleados_consultados
                    WHERE full_name ILIKE $1
                       OR position ILIKE $1
                `,
                parametros
            )
        ).rows[0].total;

        const filas = (
            await cliente.query(
                union + `
                    SELECT *
                    FROM empleados_consultados
                    WHERE full_name ILIKE $1
                       OR position ILIKE $1
                    ORDER BY full_name, origen, id
                    LIMIT 50 OFFSET $2
                `,
                [
                    parametros[0],
                    (pagina - 1) * 50
                ]
            )
        ).rows;

        const resumen = (
            await cliente.query(`
                SELECT
                    COUNT(*) FILTER(
                        WHERE active
                    )::text AS activos,
                    AVG(salary) FILTER(
                        WHERE active
                    )::text AS salario_promedio
                FROM public.kc_employees
            `)
        ).rows[0];

        return {
            filas: filas.map(basicos),
            total,
            pagina,
            resumen
        };
    });

    respuesta.json(resultado);
}));

router.get(
    '/anteriores',
    administrador,
    handle(async (peticion, respuesta) => {
        const resultado = await pool.query(`
            SELECT
                e.id,
                e.nom,
                e.car,
                e.sal,
                TO_CHAR(
                    e.fec,
                    'YYYY-MM-DD'
                ) AS fec,
                e.est,
                v.empleado_id
            FROM public.empleados e
            LEFT JOIN public.kc_rrhh_vinculos v
                ON v.empleado_anterior_id = e.id
            ORDER BY e.nom, e.id
            LIMIT 200
        `);

        respuesta.json(resultado.rows);
    })
);

router.post(
    '/importar/:id',
    administrador,
    handle(async (peticion, respuesta) => {
        const anterior = identificador(
            peticion.params.id
        );

        const resultado = await transaction(
            peticion.user.id,
            async cliente => {
                const origen = (
                    await cliente.query(
                        `
                        SELECT
                            *,
                            TO_CHAR(
                                fec,
                                'YYYY-MM-DD'
                            ) AS fec
                        FROM public.empleados
                        WHERE id = $1
                        FOR UPDATE
                        `,
                        [anterior]
                    )
                ).rows[0];

                if (!origen) {
                    fail(
                        'Registro anterior no encontrado.',
                        404
                    );
                }

                const vinculado = await cliente.query(
                    `
                    SELECT empleado_id
                    FROM public.kc_rrhh_vinculos
                    WHERE empleado_anterior_id = $1
                    `,
                    [anterior]
                );

                if (vinculado.rows.length) {
                    fail(
                        'El registro ya está vinculado.',
                        409
                    );
                }

                let empleado;

                if (peticion.body.empleado_id) {
                    empleado = identificador(
                        peticion.body.empleado_id
                    );

                    await obtenerBase(
                        cliente,
                        empleado,
                        true
                    );
                } else {
                    if (
                        typeof peticion.body.activo !==
                        'boolean'
                    ) {
                        fail(
                            'Selecciona el estado del empleado.'
                        );
                    }

                    empleado = (
                        await cliente.query(
                            `
                            INSERT INTO public.kc_employees(
                                full_name,
                                position,
                                salary,
                                hired_on,
                                active
                            )
                            VALUES($1,$2,$3,$4,$5)
                            RETURNING id
                            `,
                            [
                                text(
                                    origen.nom,
                                    'Nombre'
                                ),
                                text(
                                    origen.car,
                                    'Cargo',
                                    100
                                ),
                                caja.money(
                                    origen.sal,
                                    { allowZero: true }
                                ),
                                origen.fec,
                                peticion.body.activo
                            ]
                        )
                    ).rows[0].id;
                }

                await cliente.query(
                    `
                    INSERT INTO public.kc_rrhh_vinculos(
                        empleado_id,
                        empleado_anterior_id,
                        creado_por
                    )
                    VALUES($1,$2,$3)
                    `,
                    [
                        empleado,
                        anterior,
                        peticion.user.id
                    ]
                );

                await auditar(
                    cliente,
                    peticion.user.id,
                    'RRHH_VINCULAR',
                    empleado,
                    {
                        empleado_anterior_id: anterior
                    }
                );

                return {
                    empleado_id: empleado
                };
            }
        );

        respuesta.status(201).json(resultado);
    })
);

router.get(
    '/empleados/:id',
    administrador,
    handle(async (peticion, respuesta) => {
        const id = identificador(
            peticion.params.id
        );

        const resultado = await lectura(async cliente => {
            const base = await obtenerBase(
                cliente,
                id
            );

            const pagos = (
                await cliente.query(
                    `
                    SELECT
                        p.id,
                        p.period,
                        p.description,
                        p.amount,
                        p.payment_method,
                        p.expense_id,
                        p.created_at,
                        c.shift_id,
                        c.payment_reference
                    FROM public.kc_payroll_payments p
                    JOIN public.cash_expenses c
                        ON c.id = p.expense_id
                    WHERE p.employee_id = $1
                    ORDER BY p.created_at DESC, p.id DESC
                    LIMIT 100
                    `,
                    [id]
                )
            ).rows;

            const expedientes = (
                await cliente.query(
                    `
                    SELECT
                        id,
                        kind,
                        data,
                        status,
                        amount,
                        expense_id,
                        created_at
                    FROM public.kc_business_records
                    WHERE employee_id = $1
                      AND status <> 'archived'
                      AND (
                        kind <> 'payroll'
                        OR status = 'draft'
                      )
                    ORDER BY id DESC
                    LIMIT 100
                    `,
                    [id]
                )
            ).rows;

            const incidencias = (
                await cliente.query(
                    `
                    SELECT
                        *,
                        TO_CHAR(
                            desde,
                            'YYYY-MM-DD'
                        ) AS desde,
                        TO_CHAR(
                            hasta,
                            'YYYY-MM-DD'
                        ) AS hasta
                    FROM public.kc_rrhh_incidencias
                    WHERE empleado_id = $1
                      AND activo
                    ORDER BY desde DESC, id DESC
                    LIMIT 100
                    `,
                    [id]
                )
            ).rows;

            const documentos = (
                await cliente.query(
                    `
                    SELECT
                        id,
                        categoria,
                        nombre_original,
                        tipo,
                        tamanio,
                        creado_en
                    FROM public.kc_archivos_privados
                    WHERE empleado_id = $1
                      AND ambito = 'rrhh'
                      AND activo
                    ORDER BY creado_en DESC
                    LIMIT 100
                    `,
                    [id]
                )
            ).rows;

            const vinculo = (
                await cliente.query(
                    `
                    SELECT empleado_anterior_id
                    FROM public.kc_rrhh_vinculos
                    WHERE empleado_id = $1
                    `,
                    [id]
                )
            ).rows[0];

            const historico = {
                nomina: [],
                contratos: [],
                permisos: []
            };

            if (vinculo) {
                const consultas = {
                    nomina: `
                        SELECT
                            id,
                            bruto,
                            tot_ded,
                            neto,
                            TO_CHAR(
                                fecha,
                                'YYYY-MM-DD"T"HH24:MI:SS'
                            ) AS fecha,
                            metodo_pago
                        FROM public.nomina
                        WHERE empleado_id = $1
                        ORDER BY id DESC
                        LIMIT 100
                    `,

                    contratos: `
                        SELECT
                            *,
                            TO_CHAR(
                                fecha_inicio,
                                'YYYY-MM-DD'
                            ) AS fecha_inicio,
                            TO_CHAR(
                                fecha_fin,
                                'YYYY-MM-DD'
                            ) AS fecha_fin
                        FROM public.contratos
                        WHERE empleado_id = $1
                        ORDER BY id DESC
                        LIMIT 100
                    `,

                    permisos: `
                        SELECT *
                        FROM public.permisos
                        WHERE empleado_id = $1
                        ORDER BY id DESC
                        LIMIT 100
                    `
                };

                for (
                    const [nombre, consulta]
                    of Object.entries(consultas)
                ) {
                    historico[nombre] = (
                        await cliente.query(
                            consulta,
                            [vinculo.empleado_anterior_id]
                        )
                    ).rows;
                }
            }

            return {
                empleado: basicos(base),
                datos: base.datos || {},
                mascaras: base.mascaras || {},
                pagos,
                expedientes,
                incidencias,
                documentos,
                historico
            };
        });

        respuesta.json(resultado);
    })
);

router.get(
    '/empleados/:id/reservados',
    administrador,
    handle(async (peticion, respuesta) => {
        const id = identificador(
            peticion.params.id
        );

        const datos = await transaction(
            peticion.user.id,
            async cliente => {
                const base = await obtenerBase(
                    cliente,
                    id,
                    true
                );

                const resultado = base.reservados
                    ? JSON.parse(
                        privados.descifrar(
                            base.reservados
                        ).toString('utf8')
                    )
                    : {
                        cedula: null,
                        pasaporte: null,
                        cuentas: []
                    };

                await auditar(
                    cliente,
                    peticion.user.id,
                    'RRHH_LEER_RESERVADOS',
                    id
                );

                return resultado;
            }
        );

        respuesta.json(datos);
    })
);

async function guardarEmpleado(peticion, id) {
    const cuerpo = peticion.body;

    if (
        typeof cuerpo.activo !== 'boolean'
    ) {
        fail('Estado de empleado inválido.');
    }

    const datos = validarDatos(
        cuerpo.datos
    );

    const valores = [
        text(cuerpo.nombre, 'Nombre'),
        text(cuerpo.cargo, 'Cargo', 100),
        caja.money(
            cuerpo.salario,
            { allowZero: true }
        ),
        fecha(cuerpo.fecha_ingreso),
        cuerpo.activo
    ];

    return transaction(
        peticion.user.id,
        async cliente => {
            let anterior = null;

            if (id) {
                anterior = await obtenerBase(
                    cliente,
                    id,
                    true
                );

                if (
                    cuerpo.revision !==
                    revision(anterior)
                ) {
                    fail(
                        'El empleado cambió en otro módulo. ' +
                        'Actualiza el expediente antes de guardar.',
                        409
                    );
                }
            }

            let reservado =
                anterior?.reservados || null;

            let mascara =
                anterior?.mascaras || {};

            if (
                Object.hasOwn(
                    cuerpo,
                    'reservados'
                )
            ) {
                const datosReservados =
                    validarReservados(
                        cuerpo.reservados
                    );

                const tieneDatos =
                    datosReservados.cedula ||
                    datosReservados.pasaporte ||
                    datosReservados.cuentas.length;

                reservado = tieneDatos
                    ? privados.cifrar(
                        Buffer.from(
                            JSON.stringify(
                                datosReservados
                            ),
                            'utf8'
                        )
                    )
                    : null;

                mascara = mascaras(
                    datosReservados
                );
            }

            if (!id) {
                id = (
                    await cliente.query(
                        `
                        INSERT INTO public.kc_employees(
                            full_name,
                            position,
                            salary,
                            hired_on,
                            active
                        )
                        VALUES($1,$2,$3,$4,$5)
                        RETURNING id
                        `,
                        valores
                    )
                ).rows[0].id;
            } else {
                await cliente.query(
                    `
                    UPDATE public.kc_employees
                    SET full_name = $1,
                        position = $2,
                        salary = $3,
                        hired_on = $4,
                        active = $5
                    WHERE id = $6
                    `,
                    [...valores, id]
                );
            }

            await cliente.query(
                `
                INSERT INTO public.kc_rrhh_expedientes(
                    empleado_id,
                    datos,
                    reservados,
                    mascaras,
                    actualizado_por
                )
                VALUES($1,$2,$3,$4,$5)

                ON CONFLICT(empleado_id)
                DO UPDATE SET
                    datos = EXCLUDED.datos,
                    reservados = EXCLUDED.reservados,
                    mascaras = EXCLUDED.mascaras,
                    version =
                        kc_rrhh_expedientes.version + 1,
                    actualizado_por =
                        EXCLUDED.actualizado_por,
                    actualizado_en = now()
                `,
                [
                    id,
                    datos,
                    reservado,
                    mascara,
                    peticion.user.id
                ]
            );

            await auditar(
                cliente,
                peticion.user.id,
                anterior
                    ? 'RRHH_EDITAR'
                    : 'RRHH_CREAR',
                id,
                {
                    datos_reservados_modificados:
                        Object.hasOwn(
                            cuerpo,
                            'reservados'
                        )
                }
            );

            return basicos(
                await obtenerBase(
                    cliente,
                    id
                )
            );
        }
    );
}

router.post(
    '/empleados',
    administrador,
    handle(async (peticion, respuesta) => {
        respuesta.status(201).json(
            await guardarEmpleado(
                peticion,
                null
            )
        );
    })
);

router.put(
    '/empleados/:id',
    administrador,
    handle(async (peticion, respuesta) => {
        respuesta.json(
            await guardarEmpleado(
                peticion,
                identificador(
                    peticion.params.id
                )
            )
        );
    })
);

router.delete(
    '/empleados/:id',
    administrador,
    handle(async (peticion, respuesta) => {
        const id = identificador(
            peticion.params.id
        );

        await transaction(
            peticion.user.id,
            async cliente => {
                const base = await obtenerBase(
                    cliente,
                    id,
                    true
                );

                if (
                    peticion.body.revision !==
                    revision(base)
                ) {
                    fail(
                        'El empleado fue modificado. ' +
                        'Actualiza la lista.',
                        409
                    );
                }

                await cliente.query(
                    `
                    UPDATE public.kc_employees
                    SET active = FALSE
                    WHERE id = $1
                    `,
                    [id]
                );

                await auditar(
                    cliente,
                    peticion.user.id,
                    'RRHH_DESACTIVAR',
                    id
                );
            }
        );

        respuesta.json({ ok: true });
    })
);

router.get(
    '/empleados/:id/remuneracion',
    handle(async (peticion, respuesta) => {
        const base = await obtenerBase(
            pool,
            identificador(
                peticion.params.id
            )
        );

        const periodo = peticion.query.periodo;

        let horas = null;
        let cruzadas = 0;

        if (periodo) {
            if (
                typeof periodo !== 'string' ||
                !/^\d{4}-(0[1-9]|1[0-2])$/.test(periodo) ||
                Number(periodo.slice(0, 4)) < 1
            ) {
                fail('Período inválido.');
            }

            const fila = (
                await pool.query(
                    `
                    SELECT
                        COALESCE(
                            SUM(horas) FILTER(
                                WHERE desde >= $2::date
                                  AND hasta < (
                                    $2::date +
                                    INTERVAL '1 month'
                                  )
                            ),
                            0
                        )::text AS horas,

                        COUNT(*) FILTER(
                            WHERE NOT(
                                desde >= $2::date
                                AND hasta < (
                                    $2::date +
                                    INTERVAL '1 month'
                                )
                            )
                        )::int AS cruzadas

                    FROM public.kc_rrhh_incidencias

                    WHERE empleado_id = $1
                      AND tipo = 'hora_extra'
                      AND estado = 'aprobada'
                      AND activo

                      AND desde < (
                        $2::date +
                        INTERVAL '1 month'
                      )

                      AND hasta >= $2::date
                    `,
                    [
                        base.id,
                        periodo + '-01'
                    ]
                )
            ).rows[0];

            horas = fila.horas;
            cruzadas = fila.cruzadas;
        }

        respuesta.json({
            salario: base.salary,
            bono_fijo:
                base.datos?.bono_fijo ?? null,
            deduccion_fija:
                base.datos?.deduccion_fija ?? null,
            horas_extra_aprobadas: horas,
            incidencias_cruzadas: cruzadas
        });
    })
);

function datosIncidencia(cuerpo) {
    if (
        ![
            'asistencia',
            'falta',
            'incapacidad',
            'hora_extra'
        ].includes(cuerpo.tipo)
    ) {
        fail('Tipo de incidencia inválido.');
    }

    const desde = fecha(
        cuerpo.desde,
        true
    );

    const hasta = fecha(
        cuerpo.hasta,
        true
    );

    if (desde > hasta) {
        fail('El rango de fechas es inválido.');
    }

    const horas = caja.money(
        cuerpo.horas || '0',
        { allowZero: true }
    );

    const dias =
        (
            Date.parse(hasta) -
            Date.parse(desde)
        ) / 86400000 + 1;

    if (
        Number(horas) > 999999.99 ||
        Number(horas) > dias * 24 ||
        (
            cuerpo.tipo === 'hora_extra' &&
            Number(horas) <= 0
        )
    ) {
        fail('Revisa las horas registradas.');
    }

    if (
        ![
            'pendiente',
            'aprobada',
            'rechazada'
        ].includes(cuerpo.estado)
    ) {
        fail('Estado de incidencia inválido.');
    }

    return [
        cuerpo.tipo,
        desde,
        hasta,
        horas,
        text(
            cuerpo.descripcion,
            'Descripción',
            2000,
            true,
            true
        ),
        cuerpo.estado
    ];
}

router.post(
    '/empleados/:id/incidencias',
    administrador,
    handle(async (peticion, respuesta) => {
        const id = identificador(
            peticion.params.id
        );

        const valores = datosIncidencia(
            peticion.body
        );

        const fila = await transaction(
            peticion.user.id,
            async cliente => {
                await obtenerBase(
                    cliente,
                    id,
                    true
                );

                const resultado = (
                    await cliente.query(
                        `
                        INSERT INTO public.kc_rrhh_incidencias(
                            empleado_id,
                            tipo,
                            desde,
                            hasta,
                            horas,
                            descripcion,
                            estado,
                            creado_por
                        )
                        VALUES($1,$2,$3,$4,$5,$6,$7,$8)
                        RETURNING *
                        `,
                        [
                            id,
                            ...valores,
                            peticion.user.id
                        ]
                    )
                ).rows[0];

                await auditar(
                    cliente,
                    peticion.user.id,
                    'RRHH_INCIDENCIA_CREAR',
                    id,
                    {
                        incidencia_id:
                            resultado.id
                    }
                );

                return resultado;
            }
        );

        respuesta.status(201).json(fila);
    })
);

for (const metodo of ['put', 'delete']) {
    router[metodo](
        '/empleados/:id/incidencias/:incidencia',
        administrador,

        handle(async (peticion, respuesta) => {
            const id = identificador(
                peticion.params.id
            );

            const incidencia = identificador(
                peticion.params.incidencia
            );

            const valores = metodo === 'put'
                ? datosIncidencia(peticion.body)
                : null;

            await transaction(
                peticion.user.id,
                async cliente => {
                    await obtenerBase(
                        cliente,
                        id,
                        true
                    );

                    const anterior = (
                        await cliente.query(
                            `
                            SELECT version
                            FROM public.kc_rrhh_incidencias
                            WHERE id = $1
                              AND empleado_id = $2
                              AND activo
                            FOR UPDATE
                            `,
                            [incidencia, id]
                        )
                    ).rows[0];

                    if (!anterior) {
                        fail(
                            'Incidencia no encontrada.',
                            404
                        );
                    }

                    if (
                        anterior.version !==
                        Number(peticion.body.version)
                    ) {
                        fail(
                            'La incidencia fue modificada. ' +
                            'Actualiza el expediente.',
                            409
                        );
                    }

                    if (metodo === 'delete') {
                        await cliente.query(
                            `
                            UPDATE public.kc_rrhh_incidencias
                            SET activo = FALSE,
                                version = version + 1,
                                actualizado_en = now()
                            WHERE id = $1
                            `,
                            [incidencia]
                        );
                    } else {
                        await cliente.query(
                            `
                            UPDATE public.kc_rrhh_incidencias
                            SET tipo = $1,
                                desde = $2,
                                hasta = $3,
                                horas = $4,
                                descripcion = $5,
                                estado = $6,
                                version = version + 1,
                                actualizado_en = now()
                            WHERE id = $7
                            `,
                            [...valores, incidencia]
                        );
                    }

                    await auditar(
                        cliente,
                        peticion.user.id,
                        metodo === 'delete'
                            ? 'RRHH_INCIDENCIA_RETIRAR'
                            : 'RRHH_INCIDENCIA_EDITAR',
                        id,
                        {
                            incidencia_id: incidencia
                        }
                    );
                }
            );

            respuesta.json({ ok: true });
        })
    );
}

const recibir = multer({
    storage: multer.memoryStorage(),

    limits: {
        fileSize: 10485760,
        files: 1,
        fields: 4,
        fieldSize: 6000
    }
}).single('archivo');

function cargarArchivo(
    peticion,
    respuesta,
    siguiente
) {
    recibir(
        peticion,
        respuesta,
        error => {
            if (error) {
                return respuesta.status(
                    error.code === 'LIMIT_FILE_SIZE'
                        ? 413
                        : 400
                ).json({
                    error:
                        error.code === 'LIMIT_FILE_SIZE'
                            ? 'El máximo permitido es 10 MB.'
                            : 'No se recibió el archivo.'
                });
            }

            siguiente();
        }
    );
}

async function registrarArchivo(
    peticion,
    ambito,
    empleado
) {
    if (!peticion.file?.buffer?.length) {
        fail('Selecciona un archivo.');
    }

    const tipo = privados.tipoArchivo(
        peticion.file.buffer
    );

    const permitidos = ambito === 'rrhh'
        ? [
            'application/pdf',
            'image/png',
            'image/jpeg'
        ]
        : [
            'image/png',
            'image/jpeg',
            'video/mp4'
        ];

    if (!permitidos.includes(tipo)) {
        fail(
            'Ese formato no está permitido en esta sección.'
        );
    }

    const extension = {
        'application/pdf': '.pdf',
        'image/png': '.png',
        'image/jpeg': '.jpg',
        'video/mp4': '.mp4'
    }[tipo];

    const nombre = text(
        peticion.file.originalname
            .replace(
                /[\\/\u0000-\u001f]/g,
                '_'
            )
            .replace(/\.[^.]*$/, '')
            .slice(-180) || 'archivo',
        'Nombre de archivo',
        180
    ) + extension;

    let categoria;
    let datos = {};

    if (ambito === 'rrhh') {
        categoria = peticion.body.categoria;

        if (
            ![
                'contrato_firmado',
                'identificacion',
                'certificado_estudio',
                'otro'
            ].includes(categoria)
        ) {
            fail(
                'Categoría de documento inválida.'
            );
        }
    } else {
        categoria = 'publicidad';

        const plataforma =
            peticion.body.plataforma;

        if (
            ![
                'facebook',
                'instagram',
                'whatsapp',
                'tiktok',
                'otra'
            ].includes(plataforma)
        ) {
            fail('Plataforma inválida.');
        }

        datos = {
            plataforma,
            titulo: text(
                peticion.body.titulo,
                'Título',
                150
            ),
            texto: textoOpcional(
                peticion.body.texto,
                'Texto',
                5000
            )
        };
    }

    const id = crypto.randomUUID();
    let guardado = false;

    try {
        return await transaction(
            peticion.user.id,
            async cliente => {
                if (empleado) {
                    await obtenerBase(
                        cliente,
                        empleado,
                        true
                    );
                }

                const huella = await privados.guardar(
                    id,
                    peticion.file.buffer
                );

                guardado = true;

                await cliente.query(
                    `
                    INSERT INTO public.kc_archivos_privados(
                        id,
                        ambito,
                        empleado_id,
                        categoria,
                        nombre_original,
                        tipo,
                        tamanio,
                        huella,
                        datos,
                        creado_por
                    )
                    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
                    `,
                    [
                        id,
                        ambito,
                        empleado,
                        categoria,
                        nombre,
                        tipo,
                        peticion.file.size,
                        huella,
                        datos,
                        peticion.user.id
                    ]
                );

                await auditar(
                    cliente,
                    peticion.user.id,
                    ambito === 'rrhh'
                        ? 'RRHH_DOCUMENTO_CARGAR'
                        : 'PUBLICIDAD_CARGAR',
                    empleado || null,
                    { archivo_id: id }
                );

                return {
                    id,
                    nombre_original: nombre,
                    tipo,
                    tamanio: peticion.file.size,
                    datos
                };
            }
        );
    } catch (error) {
        if (guardado) {
            await privados.eliminarHuerfano(id);
        }

        throw error;
    }
}

router.post(
    '/empleados/:id/documentos',
    administrador,
    cargarArchivo,

    handle(async (peticion, respuesta) => {
        respuesta.status(201).json(
            await registrarArchivo(
                peticion,
                'rrhh',
                identificador(
                    peticion.params.id
                )
            )
        );
    })
);

router.post(
    '/publicidad',
    administrador,
    cargarArchivo,

    handle(async (peticion, respuesta) => {
        respuesta.status(201).json(
            await registrarArchivo(
                peticion,
                'publicidad',
                null
            )
        );
    })
);

router.get(
    '/publicidad',
    handle(async (peticion, respuesta) => {
        const resultado = await pool.query(`
            SELECT
                id,
                nombre_original,
                tipo,
                tamanio,
                datos,
                creado_en
            FROM public.kc_archivos_privados
            WHERE ambito = 'publicidad'
              AND activo
            ORDER BY creado_en DESC
            LIMIT 100
        `);

        respuesta.json(resultado.rows);
    })
);

router.get(
    '/archivos/:id',
    handle(async (peticion, respuesta) => {
        const id = peticion.params.id;

        if (!/^[0-9a-f-]{36}$/i.test(id)) {
            fail('Archivo inválido.');
        }

        const fila = (
            await pool.query(
                `
                SELECT *
                FROM public.kc_archivos_privados
                WHERE id = $1
                  AND activo
                `,
                [id]
            )
        ).rows[0];

        if (!fila) {
            fail(
                'Archivo no encontrado.',
                404
            );
        }

        if (
            fila.ambito === 'rrhh' &&
            ![
                'admin',
                'superadmin'
            ].includes(peticion.user.role)
        ) {
            fail(
                'Sin acceso al documento.',
                403
            );
        }

        const contenido = await privados.leer(
            fila.id,
            fila.huella
        );

        await pool.query(
            `
            INSERT INTO public.audit_log(
                user_id,
                action,
                entity,
                details,
                created_at
            )
            VALUES(
                $1,
                'ARCHIVO_DESCARGAR',
                $2,
                $3,
                now()
            )
            `,
            [
                peticion.user.id,
                fila.empleado_id
                    ? 'rrhh:' + fila.empleado_id
                    : 'publicidad',
                JSON.stringify({
                    archivo_id: id
                })
            ]
        );

        respuesta.set(
            'Content-Type',
            fila.tipo
        );

        respuesta.set(
            'X-Content-Type-Options',
            'nosniff'
        );

        respuesta.set(
            'Content-Disposition',
            "attachment; filename*=UTF-8''" +
            encodeURIComponent(
                fila.nombre_original
            )
        );

        respuesta.send(contenido);
    })
);

router.delete(
    '/archivos/:id',
    administrador,

    handle(async (peticion, respuesta) => {
        const id = peticion.params.id;

        if (!/^[0-9a-f-]{36}$/i.test(id)) {
            fail('Archivo inválido.');
        }

        await transaction(
            peticion.user.id,
            async cliente => {
                const fila = (
                    await cliente.query(
                        `
                        UPDATE public.kc_archivos_privados
                        SET activo = FALSE
                        WHERE id = $1
                          AND activo
                        RETURNING empleado_id
                        `,
                        [id]
                    )
                ).rows[0];

                if (!fila) {
                    fail(
                        'Archivo no encontrado.',
                        404
                    );
                }

                await auditar(
                    cliente,
                    peticion.user.id,
                    'ARCHIVO_RETIRAR',
                    fila.empleado_id || null,
                    {
                        archivo_id: id
                    }
                );
            }
        );

        respuesta.json({ ok: true });
    })
);

router.post(
    '/publicidad/:id/compartidos',
    administrador,

    handle(async (peticion, respuesta) => {
        const id = peticion.params.id;
        const resultado = peticion.body.resultado;

        if (
            !/^[0-9a-f-]{36}$/i.test(id) ||
            ![
                'entregado',
                'cancelado',
                'fallido'
            ].includes(resultado)
        ) {
            fail('Resultado inválido.');
        }

        await transaction(
            peticion.user.id,
            async cliente => {
                const existe = (
                    await cliente.query(
                        `
                        SELECT id
                        FROM public.kc_archivos_privados
                        WHERE id = $1
                          AND ambito = 'publicidad'
                          AND activo
                        FOR SHARE
                        `,
                        [id]
                    )
                ).rows.length;

                if (!existe) {
                    fail(
                        'Publicidad no encontrada.',
                        404
                    );
                }

                await cliente.query(
                    `
                    INSERT INTO public.kc_publicidad_compartidos(
                        archivo_id,
                        usuario_id,
                        resultado
                    )
                    VALUES($1,$2,$3)
                    `,
                    [
                        id,
                        peticion.user.id,
                        resultado
                    ]
                );
            }
        );

        respuesta.status(201).json({
            ok: true,
            publicacion_confirmada: false
        });
    })
);

module.exports = router;