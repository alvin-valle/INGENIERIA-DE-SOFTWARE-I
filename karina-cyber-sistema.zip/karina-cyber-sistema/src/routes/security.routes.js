const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');

const pool = require('../db/connection');

const {
  requireAuth,
  requireRole,
  blockReadOnly
} = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth, requireRole('admin', 'cajero'));

router.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

// Conserva la carpeta existente para no perder archivos pendientes.
// Solo se gestionan archivos recibidos en esta carpeta.
const TEMP_DIR = path.resolve(
  __dirname,
  '../../data/temp_demo'
);

const MAX_SIZE = 5 * 1024 * 1024;

fs.mkdirSync(TEMP_DIR, { recursive: true });

const realDirectory = fs.realpathSync(TEMP_DIR);

// Evita dos borrados simultáneos del mismo archivo en este proceso.
const locks = new Set();

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, realDirectory);
    },

    filename: (req, file, cb) => {
      const name = file.originalname
        .replace(/[^a-zA-Z0-9._-]/g, '_')
        .slice(-150) || 'archivo';

      cb(
        null,
        crypto.randomUUID() + '_' + name
      );
    }
  }),

  limits: {
    fileSize: MAX_SIZE,
    files: 1
  }
});

function safePath(name) {
  if (
    typeof name !== 'string' ||
    !name ||
    name.startsWith('.') ||
    /[\\/\x00-\x1f:]/.test(name) ||
    path.basename(name) !== name
  ) {
    return null;
  }

  const target = path.resolve(realDirectory, name);

  return path.dirname(target) === realDirectory
    ? target
    : null;
}

// ------------------------------------------------------------
// Listado de archivos temporales.
// ------------------------------------------------------------

router.get('/temp-files', async (req, res) => {
  try {
    const entries = await fs.promises.readdir(
      realDirectory,
      { withFileTypes: true }
    );

    const files = [];

    for (const entry of entries) {
      if (!entry.isFile() || !safePath(entry.name)) {
        continue;
      }

      try {
        const stat = await fs.promises.lstat(
          safePath(entry.name)
        );

        if (
          stat.isFile() &&
          !stat.isSymbolicLink() &&
          stat.nlink === 1
        ) {
          files.push({
            name: entry.name,
            size: stat.size,
            modified: stat.mtime.toISOString()
          });
        }
      } catch (error) {
        // Otro proceso pudo eliminarlo durante el listado.
        if (error.code !== 'ENOENT') {
          throw error;
        }
      }
    }

    files.sort(
      (a, b) => b.modified.localeCompare(a.modified)
    );

    res.json(files);
  } catch (error) {
    console.error('[Seguridad: archivos]', error);

    res.status(500).json({
      error:
        'No se pudo consultar la carpeta de archivos temporales.'
    });
  }
});

// ------------------------------------------------------------
// Carga de un archivo temporal.
// ------------------------------------------------------------

router.post(
  '/temp-files',
  blockReadOnly,
  (req, res) => {
    upload.single('file')(req, res, error => {
      if (error) {
        console.error('[Seguridad: carga]', error);

        return res.status(400).json({
          error: error.code === 'LIMIT_FILE_SIZE'
            ? 'El archivo supera el máximo de 5 MB.'
            : 'No se pudo cargar el archivo.'
        });
      }

      if (!req.file) {
        return res.status(400).json({
          error: 'Selecciona un archivo.'
        });
      }

      return res.status(201).json({
        name: req.file.filename,
        size: req.file.size
      });
    });
  }
);

// ------------------------------------------------------------
// Historial real de PostgreSQL.
// ------------------------------------------------------------

router.get('/log', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        sd.id,
        sd.file_name,
        sd.file_size,
        sd.passes,
        sd.method,
        sd.status,
        TO_CHAR(
          sd.date,
          'YYYY-MM-DD"T"HH24:MI:SS'
        ) AS date,
        COALESCE(
          u.full_name,
          u.username,
          'Usuario sin registro'
        ) AS user_name
      FROM secure_deletions sd
      LEFT JOIN users u ON u.id = sd.user_id
      ORDER BY sd.date DESC, sd.id DESC
      LIMIT 100
    `);

    res.json(result.rows);
  } catch (error) {
    console.error('[Seguridad: bitácora]', error);

    res.status(500).json({
      error:
        'No se pudo consultar la bitácora en PostgreSQL.'
    });
  }
});

// ------------------------------------------------------------
// Sobrescritura y eliminación de un archivo.
// No garantiza eliminar copias en SSD, respaldos o instantáneas.
// ------------------------------------------------------------

router.post(
  '/secure-delete/:filename',
  blockReadOnly,
  async (req, res) => {
    const name = req.params.filename;
    const target = safePath(name);

    if (!target) {
      return res.status(400).json({
        error: 'Nombre de archivo no permitido.'
      });
    }

    if (locks.has(name)) {
      return res.status(409).json({
        error: 'Este archivo ya se está procesando.'
      });
    }

    locks.add(name);

    let handle = null;
    let logId = null;
    let deleted = false;
    let passes = 0;

    try {
      const initial = await fs.promises.lstat(target);

      if (
        !initial.isFile() ||
        initial.isSymbolicLink() ||
        initial.nlink !== 1
      ) {
        return res.status(400).json({
          error:
            'Solo se admiten archivos regulares, sin enlaces.'
        });
      }

      if (initial.size > MAX_SIZE) {
        return res.status(400).json({
          error:
            'Este módulo solo procesa archivos de hasta 5 MB.'
        });
      }

      const flags =
        fs.constants.O_RDWR |
        (fs.constants.O_NOFOLLOW || 0);

      handle = await fs.promises.open(target, flags);

      const opened = await handle.stat();

      if (
        opened.ino !== initial.ino ||
        opened.dev !== initial.dev ||
        opened.nlink !== 1 ||
        opened.size !== initial.size ||
        !opened.isFile()
      ) {
        return res.status(409).json({
          error:
            'El archivo cambió. Actualiza la lista antes de continuar.'
        });
      }

      // Primero se registra la intención de borrado.
      // Si PostgreSQL falla aquí, el archivo permanece intacto.
      const result = await pool.query(
        `
        INSERT INTO secure_deletions (
          user_id,
          file_name,
          file_size,
          passes,
          method,
          status
        )
        VALUES (
          $1,
          $2,
          $3,
          0,
          'overwrite-random-3pass',
          'en_proceso'
        )
        RETURNING id
        `,
        [
          req.user.id,
          name,
          initial.size
        ]
      );

      logId = result.rows[0].id;

      for (let pass = 0; pass < 3; pass++) {
        for (
          let position = 0;
          position < initial.size;
        ) {
          const buffer = crypto.randomBytes(
            Math.min(65536, initial.size - position)
          );

          let written = 0;

          // Atiende también escrituras parciales.
          while (written < buffer.length) {
            const out = await handle.write(
              buffer,
              written,
              buffer.length - written,
              position + written
            );

            if (out.bytesWritten <= 0) {
              throw new Error('Escritura incompleta.');
            }

            written += out.bytesWritten;
          }

          position += buffer.length;
        }

        await handle.sync();
        passes++;
      }

      await handle.close();
      handle = null;

      const current = await fs.promises.lstat(target);

      if (
        current.ino !== initial.ino ||
        current.dev !== initial.dev ||
        current.isSymbolicLink()
      ) {
        throw new Error(
          'El archivo cambió durante el procesamiento.'
        );
      }

      await fs.promises.unlink(target);
      deleted = true;

      await pool.query(
        `
        UPDATE secure_deletions
        SET status = 'completado',
            passes = $1
        WHERE id = $2
        `,
        [passes, logId]
      );

      return res.json({
        ok: true,
        deleted: true,
        passes
      });
    } catch (error) {
      console.error('[Seguridad: eliminación]', error);

      if (deleted) {
        // El archivo ya fue eliminado: no indicar que sigue existiendo.
        return res.json({
          ok: true,
          deleted: true,
          passes,
          warning:
            'El archivo fue eliminado, pero no se pudo actualizar ' +
            'la bitácora. Su registro quedó en proceso; solicita ' +
            'revisión al administrador.'
        });
      }

      if (logId !== null) {
        await pool.query(
          `
          UPDATE secure_deletions
          SET status = 'error',
              passes = $1
          WHERE id = $2
          `,
          [passes, logId]
        ).catch(logError => {
          console.error(
            '[Seguridad: actualizar incidencia]',
            logError
          );
        });
      }

      const message = error.code === 'ENOENT'
        ? 'El archivo ya no existe.'
        : logId === null
          ? 'No se pudo iniciar el borrado. El archivo no fue sobrescrito.'
          : 'El borrado no se completó; el archivo puede estar ' +
            'parcialmente sobrescrito. Revisa la terminal.';

      return res.status(
        error.code === 'ENOENT' ? 404 : 500
      ).json({
        error: message
      });
    } finally {
      if (handle) {
        await handle.close().catch(error => {
          console.error(
            '[Seguridad: cerrar archivo]',
            error
          );
        });
      }

      locks.delete(name);
    }
  }
);

module.exports = router;