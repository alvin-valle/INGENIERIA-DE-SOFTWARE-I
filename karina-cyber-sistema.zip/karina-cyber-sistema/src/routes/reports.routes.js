const express = require('express');
const pool = require('../db/connection');
const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth);
router.use(requireRole('admin', 'auditor'));

router.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

// ------------------------------------------------------------
// Fechas
// ------------------------------------------------------------

function todayInNicaragua() {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Managua',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(new Date());

  const values = {};

  for (const part of parts) {
    if (part.type !== 'literal') {
      values[part.type] = part.value;
    }
  }

  return `${values.year}-${values.month}-${values.day}`;
}

function isValidDate(value) {
  if (
    typeof value !== 'string' ||
    !/^\d{4}-\d{2}-\d{2}$/.test(value)
  ) {
    return false;
  }

  const year = Number(value.slice(0, 4));

  if (year < 1 || year > 9999) {
    return false;
  }

  const parsed = new Date(`${value}T00:00:00.000Z`);

  return (
    Number.isFinite(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === value
  );
}

function validateDateRange(req, res, next) {
  const today = todayInNicaragua();

  const defaultFrom = new Date(`${today}T00:00:00.000Z`);
  defaultFrom.setUTCDate(defaultFrom.getUTCDate() - 29);

  const from = req.query.from === undefined
    ? defaultFrom.toISOString().slice(0, 10)
    : req.query.from;

  const to = req.query.to === undefined
    ? today
    : req.query.to;

  if (!isValidDate(from) || !isValidDate(to)) {
    return res.status(400).json({
      error: 'Las fechas deben ser válidas y tener formato AAAA-MM-DD.'
    });
  }

  if (from > to) {
    return res.status(400).json({
      error: 'La fecha inicial no puede ser posterior a la fecha final.'
    });
  }

  req.reportRange = { from, to };
  next();
}

router.use(validateDateRange);

// ------------------------------------------------------------
// GET /api/reports/margins
// Ingresos, costo histórico y utilidad por producto.
// ------------------------------------------------------------

router.get('/margins', async (req, res) => {
  const { from, to } = req.reportRange;

  try {
    const result = await pool.query(
      `
      WITH product_totals AS (
        SELECT
          si.product_id AS id,
          p.sku,
          COALESCE(p.name, 'Producto sin catálogo') AS name,
          COALESCE(c.name, 'Sin categoría') AS category,
          SUM(si.qty) AS qty_sold,
          SUM(si.subtotal) AS revenue,
          SUM(si.qty * si.unit_cost) AS cost
        FROM sale_items si
        INNER JOIN sales sa
          ON sa.id = si.sale_id
        LEFT JOIN products p
          ON p.id = si.product_id
        LEFT JOIN categories c
          ON c.id = p.category_id
        WHERE sa.date >= $1::date
          AND sa.date < ($2::date + INTERVAL '1 day')
        GROUP BY
          si.product_id,
          p.sku,
          p.name,
          c.name
      ),
      product_margins AS (
        SELECT
          id,
          sku,
          name,
          category,
          qty_sold,
          ROUND(revenue, 2) AS revenue,
          ROUND(cost, 2) AS cost,
          ROUND(revenue - cost, 2) AS margin,
          CASE
            WHEN revenue > 0 THEN
              ROUND(((revenue - cost) / revenue) * 100, 2)
            ELSE 0
          END AS "marginPct"
        FROM product_totals
      )
      SELECT
        COALESCE(
          JSON_AGG(
            product_margins
            ORDER BY revenue DESC, name ASC
          ),
          '[]'::json
        ) AS products,
        JSON_BUILD_OBJECT(
          'revenue', COALESCE(SUM(revenue), 0),
          'cost', COALESCE(SUM(cost), 0),
          'margin', COALESCE(SUM(margin), 0)
        ) AS totals
      FROM product_margins
      `,
      [from, to]
    );

    const report = result.rows[0];

    res.json({
      source: 'postgresql',
      from,
      to,
      products: report.products,
      totals: report.totals
    });
  } catch (error) {
    console.error('[Reportes: márgenes]', error);

    res.status(500).json({
      error:
        'No se pudo consultar el reporte de ventas en PostgreSQL. ' +
        'Revisa el detalle en la terminal del servidor.'
    });
  }
});

// ------------------------------------------------------------
// CSV
// Escapa comillas, separadores y saltos de línea.
// Protege los campos de texto frente a fórmulas de hojas de cálculo.
// ------------------------------------------------------------

function csvCell(value) {
  let text = value === null || value === undefined
    ? ''
    : String(value);

  if (/^[\s]*[=+\-@]/.test(text) || /^[\t\r\n]/.test(text)) {
    text = "'" + text;
  }

  return '"' + text.replace(/"/g, '""') + '"';
}

// ------------------------------------------------------------
// GET /api/reports/export/sales.csv
// Exporta las ventas registradas dentro del período solicitado.
// ------------------------------------------------------------

router.get('/export/sales.csv', async (req, res) => {
  const { from, to } = req.reportRange;

  try {
    const result = await pool.query(
      `
      SELECT
        sa.id,
        TO_CHAR(
          sa.date,
          'YYYY-MM-DD HH24:MI:SS'
        ) AS date,
        COALESCE(
          u.full_name,
          'Usuario sin registro'
        ) AS cashier_name,
        COALESCE(
          sa.payment_method,
          'Sin especificar'
        ) AS payment_method,
        sa.total
      FROM sales sa
      LEFT JOIN users u
        ON u.id = sa.cashier_id
      WHERE sa.date >= $1::date
        AND sa.date < ($2::date + INTERVAL '1 day')
      ORDER BY sa.date ASC, sa.id ASC
      `,
      [from, to]
    );

    const headers = [
      'ID',
      'Fecha',
      'Cajero',
      'Método de pago',
      'Total (C$)'
    ];

    const lines = [
      headers.map(csvCell).join(',')
    ];

    for (const sale of result.rows) {
      lines.push(
        [
          sale.id,
          sale.date,
          sale.cashier_name,
          sale.payment_method,
          sale.total
        ].map(csvCell).join(',')
      );
    }

    // BOM UTF-8 para facilitar la lectura de tildes en Excel.
    const csv = '\uFEFF' + lines.join('\r\n') + '\r\n';

    res.setHeader(
      'Content-Type',
      'text/csv; charset=utf-8'
    );

    res.setHeader(
      'Content-Disposition',
      `attachment; filename="ventas_${from}_a_${to}.csv"`
    );

    res.status(200).send(csv);
  } catch (error) {
    console.error('[Reportes: exportación CSV]', error);

    res.status(500).json({
      error:
        'No se pudo exportar el archivo de ventas. ' +
        'Revisa el detalle en la terminal del servidor.'
    });
  }
});

// Evita que una ruta de reportes inexistente llegue
// al bloque genérico de respuestas de demostración.
router.use((req, res) => {
  res.status(404).json({
    error: 'La ruta de reportes solicitada no existe.'
  });
});

module.exports = router;