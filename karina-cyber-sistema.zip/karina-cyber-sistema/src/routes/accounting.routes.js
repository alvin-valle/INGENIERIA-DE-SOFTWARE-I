'use strict';

const express = require('express');

const pool = require('../db/connection');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const {
  handle
} = require('../utils/enterprise');

const router = express.Router();

router.use(
  requireAuth,
  requireRole('admin', 'auditor')
);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// ============================================================
// CONSULTAR LIBRO CONTABLE
// ============================================================

router.get(
  '/ledger',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        j.id,
        j.movement_id,
        j.description,
        j.posted_at,

        jsonb_agg(
          jsonb_build_object(
            'account',
            a.name,

            'code',
            l.account_code,

            'debit',
            l.debit::text,

            'credit',
            l.credit::text
          )

          ORDER BY l.id
        ) AS lines,

        SUM(l.debit)::text AS debit,

        SUM(l.credit)::text AS credit

      FROM public.kc_journals j

      INNER JOIN public.kc_journal_lines l
        ON l.journal_id = j.id

      INNER JOIN public.kc_accounts a
        ON a.code = l.account_code

      GROUP BY j.id

      ORDER BY j.id DESC

      LIMIT 200
      `
    );

    res.json({
      scope:
        'Nuevos movimientos desde la instalación ' +
        'del libro contable; sin saldos iniciales ' +
        'ni reconstrucción histórica.',

      items: result.rows
    });
  })
);

// ============================================================
// CONSULTAR MOVIMIENTOS POR CUENTA
// ============================================================

router.get(
  '/trial-balance',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        a.code,
        a.name,
        a.kind,

        COALESCE(
          SUM(l.debit),
          0
        )::text AS debit,

        COALESCE(
          SUM(l.credit),
          0
        )::text AS credit

      FROM public.kc_accounts a

      LEFT JOIN public.kc_journal_lines l
        ON l.account_code = a.code

      GROUP BY a.code

      ORDER BY a.code
      `
    );

    res.json({
      items: result.rows
    });
  })
);

module.exports = router;