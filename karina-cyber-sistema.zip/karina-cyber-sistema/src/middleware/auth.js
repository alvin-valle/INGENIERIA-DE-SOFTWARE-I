'use strict';

const jwt = require('jsonwebtoken');
const pool = require('../db/connection');

// Roles reconocidos por el sistema.
// "invitado" se conserva por compatibilidad con las rutas actuales.
const VALID_ROLES = new Set([
  'superadmin',
  'admin',
  'cajero',
  'auditor',
  'invitado'
]);

// Tener un rol de escritura no concede acceso a todos los módulos.
// Cada ruta debe aplicar también requireRole().
const WRITE_ROLES = new Set([
  'superadmin',
  'admin',
  'cajero'
]);

function unauthorized(res) {
  return res.status(401).json({
    error:
      'Sesión inválida o expirada. Inicia sesión nuevamente.'
  });
}

// ============================================================
// AUTENTICACIÓN
// Verifica el token y consulta el usuario actual en PostgreSQL.
// ============================================================

async function requireAuth(req, res, next) {
  const header = req.headers.authorization;

  const match = typeof header === 'string'
    ? /^Bearer\s+(\S+)$/i.exec(header.trim())
    : null;

  if (!match || match[1].length > 8192) {
    return unauthorized(res);
  }

  const secret = process.env.JWT_SECRET;

  if (
    typeof secret !== 'string' ||
    !secret.trim()
  ) {
    console.error(
      '[Autenticación] JWT_SECRET no está configurado.'
    );

    return res.status(500).json({
      error:
        'La autenticación no está configurada en el servidor.'
    });
  }

  let payload;

  try {
    // jwt.verify también comprueba la expiración del token.
    payload = jwt.verify(match[1], secret, {
      algorithms: ['HS256']
    });
  } catch {
    return unauthorized(res);
  }

  const id = Number(payload && payload.id);

  if (
    !payload ||
    typeof payload !== 'object' ||
    !Number.isInteger(payload.exp) ||
    !Number.isInteger(id) ||
    id < 1 ||
    id > 2147483647
  ) {
    return unauthorized(res);
  }

  let user;

  try {
    const result = await pool.query(
      `
      SELECT
        id,
        username,
        full_name,
        role,
        active
      FROM public.users
      WHERE id = $1
      `,
      [id]
    );

    user = result.rows[0];
  } catch (error) {
    console.error(
      '[Autenticación: consultar usuario]',
      error.code || error.name
    );

    // Si PostgreSQL no responde, no permitimos el acceso
    // basándonos únicamente en datos antiguos del token.
    return res.status(503).json({
      error:
        'No se pudo verificar la sesión. Intenta nuevamente.'
    });
  }

  if (
    !user ||
    user.active !== true ||
    !VALID_ROLES.has(user.role)
  ) {
    return unauthorized(res);
  }

  // La autorización utiliza el rol actual de PostgreSQL.
  // Cambiar el rol o desactivar al usuario tendrá efecto
  // en sus siguientes solicitudes protegidas.
  req.user = {
    id: user.id,
    username: user.username,
    full_name: user.full_name,
    role: user.role
  };

  return next();
}

// ============================================================
// AUTORIZACIÓN POR ROL
//
// Acepta las dos formas utilizadas en tu proyecto:
//
// requireRole('admin', 'cajero')
// requireRole(['admin', 'cajero'])
// ============================================================

function requireRole(...roles) {
  const flattened = roles.flat(Infinity);

  if (
    flattened.length === 0 ||
    flattened.some(role => !VALID_ROLES.has(role))
  ) {
    throw new TypeError(
      'requireRole necesita al menos un rol válido.'
    );
  }

  const allowed = new Set(flattened);

  return (req, res, next) => {
    if (!req.user) {
      return unauthorized(res);
    }

    if (
      req.user.role === 'superadmin' ||
      allowed.has(req.user.role)
    ) {
      return next();
    }

    return res.status(403).json({
      error:
        'No tienes permisos para realizar esta acción.'
    });
  };
}

// ============================================================
// BLOQUEO DE ESCRITURA PARA AUDITORES E INVITADOS
// Se utiliza después de requireAuth.
// ============================================================

function blockReadOnly(req, res, next) {
  if (!req.user) {
    return unauthorized(res);
  }

  if (!WRITE_ROLES.has(req.user.role)) {
    return res.status(403).json({
      error:
        'Tu perfil tiene acceso de solo lectura.'
    });
  }

  return next();
}

module.exports = {
  requireAuth,
  requireRole,
  blockReadOnly
};