'use strict';

const { Pool } = require('pg');

require('dotenv').config();

const pool = new Pool({
  user: process.env.DB_USER,

  host: process.env.DB_HOST,

  database: process.env.DB_NAME,

  password: process.env.DB_PASSWORD,

  port: Number(process.env.DB_PORT) || 5432,

  // Máximo de conexiones simultáneas de este proceso.
  max: 20,

  // Evita solicitudes esperando indefinidamente
  // cuando PostgreSQL no está disponible.
  connectionTimeoutMillis: 5000,

  // Libera conexiones que permanecen inactivas.
  idleTimeoutMillis: 30000,

  // Activar únicamente cuando tu servidor utilice SSL.
  ...(process.env.DB_SSL === 'true'
    ? {
        ssl: {
          rejectUnauthorized: true
        }
      }
    : {})
});

pool.on('error', error => {
  console.error(
    '[PostgreSQL: conexión inactiva]',
    error.code || error.name
  );
});

module.exports = pool;