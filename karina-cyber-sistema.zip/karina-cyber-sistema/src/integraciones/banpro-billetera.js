'use strict';

function obtenerEstado() {
    return {
        proveedor: 'banpro_billetera',
        habilitada: false,
        estado: 'pendiente_de_integracion',
        operaciones_disponibles: []
    };
}

async function procesarOperacion() {
    throw Object.assign(
        new Error(
            'La billetera móvil BanPro todavía no está integrada.'
        ),
        {
            status: 501,
            code: 'BANPRO_NO_IMPLEMENTADO'
        }
    );
}

module.exports = Object.freeze({
    obtenerEstado,
    procesarOperacion
});