'use strict';

(() => {
    const $ = id => document.getElementById(id);

    const E = value => String(value ?? '').replace(
        /[&<>"']/g,
        character => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[character])
    );

    const money = value => value == null
        ? '—'
        : 'C$ ' + Number(value).toLocaleString('es-NI', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

    function today() {
        const parts = Object.fromEntries(
            new Intl.DateTimeFormat('en-CA', {
                timeZone: 'America/Managua',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).formatToParts(new Date()).map(
                part => [part.type, part.value]
            )
        );

        return parts.year + '-' + parts.month + '-' + parts.day;
    }

    const write = () => [
        'admin',
        'superadmin'
    ].includes(Auth.getUser()?.role);

    const state = {
        suppliers: [],
        employees: [],
        records: {},
        products: [],
        charts: {},
        cash: null,
        offset: 0,
        from: today().slice(0, 7) + '-01',
        to: today(),
        method: ''
    };

    const edits = new Map();
    const running = new Map();

    const configs = {
        payroll: [
            'form-nomina',
            'modal-nomina',
            'tbody-nomina',
            'abrirModalNominaDirecto',
            'Nómina'
        ],
        purchase: [
            'form-compra',
            'modal-compra',
            'tbody-compras',
            'abrirModalCompra',
            'Compra'
        ],
        contract: [
            'form-contrato',
            'modal-contrato',
            'tbody-contratos',
            'abrirModalContrato',
            'Contrato'
        ],
        leave: [
            'form-permiso',
            'modal-permiso',
            'tbody-permisos',
            'abrirModalPermiso',
            'Ausencia'
        ],
        incident: [
            'form-incidente',
            'modal-incidente',
            'tbody-incidentes',
            'abrirModalIncidente',
            'Incidente'
        ],
        equipment: [
            'form-epp',
            'modal-epp',
            'tbody-epp',
            'abrirModalEPP',
            'Asignación de EPP'
        ]
    };

    const methodOptions = [
        ['efectivo', 'Efectivo'],
        ['transferencia', 'Transferencia'],
        ['tarjeta', 'Tarjeta']
    ];

    function error(value) {
        if (typeof apiErrorToast === 'function') {
            apiErrorToast(value);
        } else {
            alert(value.message || String(value));
        }
    }

    function task(key, operation) {
        if (running.has(key)) {
            return running.get(key);
        }

        const promise = Promise.resolve()
            .then(operation)
            .catch(err => {
                status(key, err.message, true);
                error(err);
            })
            .finally(() => running.delete(key));

        running.set(key, promise);

        return promise;
    }

    function status(key, message, bad = false) {
        let node = $('biz-status-' + key);

        if (!node) {
            node = document.createElement('p');
            node.id = 'biz-status-' + key;
            node.setAttribute('role', 'status');
            $('biz-notices').append(node);
        }

        node.className = 'biz-notice' + (
            bad ? ' biz-error' : ''
        );

        node.textContent = message;

        if (bad) $('biz-notices').open = true;
    }

    function badge(value) {
        return '<span class="biz-badge">' + E(value) + '</span>';
    }

    function action(label, kind, id, verb = 'edit') {
        return (
            '<button type="button" class="biz-btn" ' +
            'data-biz-action="' + verb + '" ' +
            'data-kind="' + kind + '" ' +
            'data-id="' + E(id) + '">' +
                E(label) +
            '</button>'
        );
    }

    function grid(bodyId, headers, rows) {
        const body = $(bodyId);

        if (!body) return;

        const table = body.closest('table');
        const head = table.tHead || table.createTHead();

        head.innerHTML = '<tr>' + headers.map(
            heading => '<th>' + E(heading) + '</th>'
        ).join('') + '</tr>';

        body.innerHTML = rows.length
            ? rows.map(row => {
                return '<tr>' + row.map(
                    value => '<td>' + value + '</td>'
                ).join('') + '</tr>';
            }).join('')
            : (
                '<tr><td colspan="' + headers.length + '" ' +
                'class="biz-empty">' +
                'Todavía no hay registros.' +
                '</td></tr>'
            );

        if (
            !table.parentElement.classList.contains(
                'biz-table-wrap'
            )
        ) {
            const wrapper = document.createElement('div');
            wrapper.className = 'biz-table-wrap';

            table.before(wrapper);
            wrapper.append(table);
        }
    }

    function field(
        form,
        id,
        label,
        type = 'text',
        choices = null,
        value = ''
    ) {
        if ($(id)) return;

        const wrapper = document.createElement('label');
        wrapper.className = 'biz-field';
        wrapper.textContent = label;

        const input = document.createElement(
            choices
                ? 'select'
                : type === 'textarea'
                    ? 'textarea'
                    : 'input'
        );

        input.id = id;

        if (choices) {
            choices.forEach(([value, label]) => {
                input.add(new Option(label, value));
            });
        } else if (type !== 'textarea') {
            input.type = type;
        }

        if (type === 'number') {
            input.min = '0';
            input.step = '0.01';
        }

        input.value = value;
        wrapper.append(input);
        form.append(wrapper);

        return input;
    }

    function options(id, rows, label) {
        const element = $(id);

        if (!element) return;

        const selected = element.value;

        element.replaceChildren(
            new Option('Selecciona…', '')
        );

        rows.forEach(row => {
            element.add(
                new Option(label(row), row.id)
            );
        });

        element.value = selected;
    }

    function employeeOptions() {
        for (const id of [
            'nom-empleado',
            'con-emp',
            'per-emp',
            'inc-emp',
            'epp-emp'
        ]) {
            options(id, state.employees, employee => {
                return employee.full_name + (
                    employee.active ? '' : ' · Inactivo'
                );
            });
        }

        options(
            'comp-prov',
            state.suppliers,
            supplier => supplier.nombre
        );
    }

    function modal(id, open) {
        $(id)?.classList.toggle('hidden', !open);
    }

    function collect(form) {
        const data = {};

        form.querySelectorAll(
            'input[id],select[id],textarea[id]'
        ).forEach(element => {
            if (element.type !== 'file') {
                data[element.id] = element.value;
            }
        });

        return data;
    }

    function fill(form, data) {
        form.reset();

        form.querySelectorAll(
            'input[id],select[id],textarea[id]'
        ).forEach(element => {
            if (Object.hasOwn(data, element.id)) {
                element.value = data[element.id] ?? '';
            }
        });
    }

    function extraForms() {
        const supplier = $('form-proveedor');

        field(
            supplier,
            'biz-supplier-service',
            'Servicio / producto que ofrece'
        );

        field(
            supplier,
            'biz-supplier-method',
            'Forma de pago preferida',
            'text',
            methodOptions
        );

        field(
            supplier,
            'biz-supplier-state',
            'Estado',
            'text',
            [
                ['Activo', 'Activo'],
                ['Inactivo', 'Inactivo']
            ]
        );

        $('inp-prov-saldo').readOnly = true;
        $('inp-prov-saldo').required = false;

        $('inp-prov-saldo').title =
            'Saldo histórico. Los movimientos contables se ' +
            'registran mediante operaciones de pago.';

        field(
            $('form-emp'),
            'biz-employee-state',
            'Estado',
            'text',
            [
                ['true', 'Activo'],
                ['false', 'Inactivo']
            ]
        );

        const payroll = $('form-nomina');

        field(
            payroll,
            'nom-period',
            'Período mensual',
            'month',
            null,
            today().slice(0, 7)
        );

        const payrollAmounts = [
            ['nom-he-money', 'Horas extras: importe aprobado'],
            ['nom-tar-money', 'Tardanzas: deducción aprobada'],
            ['nom-ina-money', 'Inasistencias: deducción aprobada'],
            ['nom-des-money', 'Descansos: deducción aprobada'],
            ['nom-inss', 'Retención INSS aprobada'],
            ['nom-ir', 'Retención IR aprobada']
        ];

        payrollAmounts.forEach(([id, label]) => {
            field(
                payroll,
                id,
                label,
                'number',
                null,
                '0'
            );
        });

        for (const kind of ['payroll', 'purchase']) {
            const form = $(configs[kind][0]);

            field(
                form,
                'biz-' + kind + '-method',
                'Forma de pago',
                'text',
                methodOptions
            );

            field(
                form,
                'biz-' + kind + '-reference',
                'Referencia bancaria / tarjeta'
            );

            const note = document.createElement('p');
            note.className = 'biz-help';

            note.textContent = kind === 'payroll'
                ? (
                    'Las cantidades de horas y días se conservan. ' +
                    'Ingresa los importes y retenciones aprobados ' +
                    'por contabilidad; no se aplican tasas ' +
                    'legales automáticas.'
                )
                : (
                    'Guarda el borrador. Confirmar pago registra ' +
                    'el gasto y, si hay productos, su entrada ' +
                    'al inventario.'
                );

            form.append(note);
        }

        const purchase = $('form-compra');

        field(
            purchase,
            'comp-invoice',
            'Factura del proveedor'
        );

        const items = document.createElement('section');

        items.id = 'biz-purchase-items';
        items.className = 'biz-span';

        items.innerHTML = `
            <h4>Productos recibidos</h4>
            <p class="biz-help">
                Para un servicio, deja esta lista vacía
                y utiliza el costo total del formulario.
            </p>
            <div id="biz-purchase-lines"></div>
            <button
                type="button"
                class="biz-btn"
                id="biz-add-line"
            >
                Agregar producto
            </button>
        `;

        purchase.append(items);

        $('biz-add-line').onclick = () => purchaseLine();

        const contract = $('form-contrato');

        field(contract, 'con-start', 'Inicio del contrato', 'date');
        field(contract, 'con-end', 'Fin del contrato, si corresponde', 'date');
        field(
            contract,
            'con-notes',
            'Texto y observaciones aprobados del contrato',
            'textarea'
        );

        const leave = $('form-permiso');

        field(leave, 'per-start', 'Desde', 'date');
        field(leave, 'per-end', 'Hasta', 'date');

        field(
            leave,
            'per-status',
            'Estado de solicitud',
            'text',
            [
                ['Solicitada', 'Solicitada'],
                ['Aprobada', 'Aprobada'],
                ['Denegada', 'Denegada']
            ]
        );

        const incident = $('form-incidente');

        field(incident, 'inc-date', 'Fecha del incidente', 'date');

        field(
            incident,
            'inc-level',
            'Nivel',
            'text',
            [
                ['Baja', 'Baja'],
                ['Media', 'Media'],
                ['Alta', 'Alta']
            ]
        );

        field(
            incident,
            'inc-status',
            'Seguimiento',
            'text',
            [
                ['Abierto', 'Abierto'],
                ['En seguimiento', 'En seguimiento'],
                ['Cerrado', 'Cerrado']
            ]
        );

        const equipment = $('form-epp');

        field(equipment, 'epp-date', 'Fecha de entrega', 'date');
        field(equipment, 'epp-qty', 'Cantidad entregada', 'number', null, '1');

        const equipmentButton = equipment.querySelector(
            'button[onclick*="Asignación registrada"]'
        );

        if (equipmentButton) {
            equipmentButton.removeAttribute('onclick');
            equipmentButton.type = 'submit';
            equipmentButton.textContent = 'Guardar asignación';
        }

        for (const kind of Object.keys(configs)) {
            const form = $(configs[kind][0]);
            const submit = form.querySelector('[type="submit"]');

            if (submit) {
                submit.textContent = [
                    'purchase',
                    'payroll'
                ].includes(kind)
                    ? 'Guardar borrador'
                    : 'Guardar expediente';
            }
        }
    }

    function purchaseTotal() {
        const rows = [...$('biz-purchase-lines').children];

        $('comp-mon').readOnly = rows.length > 0;

        if (rows.length) {
            $('comp-mon').value = rows.reduce((total, row) => {
                const qty = Number(
                    row.querySelector('[data-qty]').value
                ) || 0;

                const cost = Number(
                    row.querySelector('[data-cost]').value
                ) || 0;

                return total + qty * cost;
            }, 0).toFixed(2);
        }
    }

    function purchaseLine(item = {}) {
        const row = document.createElement('div');
        row.className = 'biz-purchase-line';

        const products = state.products.filter(product => {
            return product.active ||
                String(product.id) === String(item.product_id);
        });

        row.innerHTML = (
            '<select aria-label="Producto" data-product>' +
                '<option value="">Producto…</option>' +
                products.map(product => {
                    return '<option value="' + E(product.id) + '">' +
                        E(product.name) +
                    '</option>';
                }).join('') +
            '</select>' +
            '<input data-qty type="number" min="1" step="1" ' +
                'placeholder="Cantidad" aria-label="Cantidad">' +
            '<input data-cost type="number" min="0.01" step="0.01" ' +
                'placeholder="Costo unitario" aria-label="Costo unitario">' +
            '<button class="biz-btn" type="button">Quitar línea</button>'
        );

        row.querySelector('[data-product]').value =
            item.product_id || '';

        row.querySelector('[data-qty]').value =
            item.qty || 1;

        row.querySelector('[data-cost]').value =
            item.unit_cost || '';

        row.querySelector('button').onclick = () => {
            row.remove();
            purchaseTotal();
        };

        row.addEventListener('input', purchaseTotal);
        row.addEventListener('change', purchaseTotal);

        $('biz-purchase-lines').append(row);

        purchaseTotal();
    }

    function documentData(kind) {
        const data = collect($(configs[kind][0]));

        if (['purchase', 'payroll'].includes(kind)) {
            data.payment_method =
                data['biz-' + kind + '-method'];

            data.payment_reference =
                data['biz-' + kind + '-reference'];

            delete data['biz-' + kind + '-method'];
            delete data['biz-' + kind + '-reference'];
        }

        if (kind === 'purchase') {
            data['comp-items'] = JSON.stringify(
                [...$('biz-purchase-lines').children].map(row => ({
                    product_id: row.querySelector('[data-product]').value,
                    qty: row.querySelector('[data-qty]').value,
                    unit_cost: row.querySelector('[data-cost]').value
                }))
            );
        }

        return data;
    }

    function openDoc(kind, id = null) {
        if (!write()) {
            return error(
                new Error('Esta cuenta tiene acceso de consulta.')
            );
        }

        const record = id
            ? state.records[kind]?.find(
                row => String(row.id) === String(id)
            )
            : null;

        if (id && !record) return;

        if (record?.status === 'paid') {
            return previewDoc(kind, record);
        }

        employeeOptions();

        const form = $(configs[kind][0]);

        fill(form, record?.data || {});
        edits.set(kind, record);

        if (['purchase', 'payroll'].includes(kind)) {
            $('biz-' + kind + '-method').value =
                record?.data.payment_method || 'efectivo';

            $('biz-' + kind + '-reference').value =
                record?.data.payment_reference || '';
        }

        if (kind === 'payroll' && !record) {
            $('nom-period').value = today().slice(0, 7);

            form.querySelectorAll(
                'input[type="number"]'
            ).forEach(input => {
                input.value = '0';
            });
        }

        if (kind === 'purchase') {
            $('biz-purchase-lines').replaceChildren();

            const items = JSON.parse(
                record?.data['comp-items'] || '[]'
            );

            items.forEach(purchaseLine);
            purchaseTotal();
        }

        modal(configs[kind][1], true);
    }

    async function saveDoc(kind) {
        const old = edits.get(kind);

        await api(
            '/business/records/' + kind +
            (old ? '/' + old.id : ''),
            {
                method: old ? 'PATCH' : 'POST',
                body: {
                    data: documentData(kind),
                    ...(old ? { version: old.version } : {})
                }
            }
        );

        modal(configs[kind][1], false);

        await loadRecords(kind);
        await compliance();
    }

    function bindSubmit(id, operation) {
        const form = $(id);
        let busy = false;

        form.addEventListener('submit', async event => {
            event.preventDefault();
            event.stopImmediatePropagation();

            if (busy) return;

            if (!write()) {
                return error(
                    new Error('Sin permiso para modificar.')
                );
            }

            busy = true;

            const button = form.querySelector('[type="submit"]');

            if (button) button.disabled = true;

            try {
                await operation();
            } catch (err) {
                error(err);
            } finally {
                busy = false;

                if (button) button.disabled = false;
            }
        }, true);
    }

    async function loadSuppliers() {
        state.suppliers = await api('/operations/suppliers');

        employeeOptions();

        grid(
            'tbody-proveedores',
            [
                'RUC / Empresa',
                'Contacto',
                'Categoría / servicio',
                'Saldo histórico',
                'Forma de pago',
                'Estado',
                'Acciones'
            ],
            state.suppliers.map(supplier => [
                '<strong>' + E(supplier.nombre) + '</strong>' +
                '<small>' + E(supplier.ruc) + '</small>',

                E(supplier.tel) +
                '<small>' + E(supplier.email) + '</small>',

                E(supplier.categoria) +
                '<small>' + E(supplier.service_type) + '</small>',

                supplier.saldo == null
                    ? '—'
                    : money(supplier.saldo),

                E(supplier.metodo_pago_pref || 'Por completar'),
                badge(supplier.estado),

                write()
                    ? action('Editar', 'supplier', supplier.id) +
                      action('Desactivar', 'supplier', supplier.id, 'archive')
                    : ''
            ])
        );

        $('kpi-prov-total').textContent = state.suppliers.length;

        $('kpi-prov-activos').textContent =
            state.suppliers.filter(
                supplier => supplier.estado === 'Activo'
            ).length;

        $('kpi-prov-deuda').textContent = 'Por conciliar';

        status(
            'suppliers',
            'Proveedores actualizados. Los saldos históricos ' +
            'no equivalen a una conciliación de cuentas por pagar.'
        );
    }

    function openSupplier(id) {
        if (!write()) return;

        const supplier = id
            ? state.suppliers.find(
                row => String(row.id) === String(id)
            )
            : null;

        edits.set('supplier', supplier);
        $('form-proveedor').reset();

        const mapping = {
            'inp-prov-ruc': 'ruc',
            'inp-prov-nombre': 'nombre',
            'inp-prov-tel': 'tel',
            'inp-prov-email': 'email',
            'inp-prov-cat': 'categoria',
            'inp-prov-saldo': 'saldo',
            'biz-supplier-service': 'service_type',
            'biz-supplier-method': 'metodo_pago_pref',
            'biz-supplier-state': 'estado'
        };

        for (const [id, key] of Object.entries(mapping)) {
            const element = $(id);

            const value = supplier?.[key] ?? (
                key === 'estado'
                    ? 'Activo'
                    : key === 'metodo_pago_pref'
                        ? 'efectivo'
                        : ''
            );

            if (
                element.tagName === 'SELECT' &&
                value &&
                ![...element.options].some(
                    option => option.value === String(value)
                )
            ) {
                element.add(new Option(value, value));
            }

            element.value = value;
        }

        $('inp-prov-saldo').disabled = true;

        modal('modal-proveedor', true);
    }

    async function saveSupplier() {
        const old = edits.get('supplier');

        const body = {
            nombre: $('inp-prov-nombre').value,
            ruc: $('inp-prov-ruc').value,
            tel: $('inp-prov-tel').value,
            email: $('inp-prov-email').value,
            categoria: $('inp-prov-cat').value,
            service_type: $('biz-supplier-service').value,
            metodo_pago_pref: $('biz-supplier-method').value,
            estado: $('biz-supplier-state').value
        };

        await api(
            '/operations/suppliers' + (old ? '/' + old.id : ''),
            {
                method: old ? 'PATCH' : 'POST',
                body
            }
        );

        modal('modal-proveedor', false);
        await loadSuppliers();
    }

    async function loadEmployees() {
        state.employees = await api('/business/employees');

        employeeOptions();

        grid(
            'tbody-emp-activos',
            [
                'Empleado',
                'Cargo',
                'Ingreso',
                'Salario base',
                'Estado / acciones'
            ],
            state.employees.map(employee => [
                '<strong>' + E(employee.full_name) + '</strong>' +
                '<small>EMP-' + E(employee.id) + '</small>',

                E(employee.position),

                E(
                    String(employee.hired_on || '').slice(0, 10) ||
                    'No registrado'
                ),

                money(employee.salary),

                badge(employee.active ? 'Activo' : 'Inactivo') +
                (
                    write()
                        ? action('Editar', 'employee', employee.id) +
                          action(
                              'Desactivar',
                              'employee',
                              employee.id,
                              'archive'
                          ) +
                          action(
                              'Preparar nómina',
                              'employee',
                              employee.id,
                              'payroll'
                          )
                        : ''
                )
            ])
        );

        const active = state.employees.filter(
            employee => employee.active
        );

        $('rrhh-total').textContent = active.length;

        $('rrhh-prom').textContent = active.length
            ? money(
                active.reduce(
                    (sum, employee) => sum + Number(employee.salary),
                    0
                ) / active.length
            )
            : money(0);

        $('kpi-pasivo-laboral').textContent = 'Por evaluar';

        status('employees', 'Directorio de empleados actualizado.');
    }

    function openEmployee(id) {
        if (!write()) return;

        const employee = id
            ? state.employees.find(
                row => String(row.id) === String(id)
            )
            : null;

        edits.set('employee', employee);

        fill($('form-emp'), {
            'emp-nom': employee?.full_name || '',
            'emp-car': employee?.position || '',
            'emp-sal': employee?.salary || '0',
            'emp-fec': String(employee?.hired_on || '').slice(0, 10),
            'biz-employee-state': String(employee?.active ?? true)
        });

        modal('modal-emp', true);
    }

    async function saveEmployee() {
        const old = edits.get('employee');

        await api(
            '/business/employees' + (old ? '/' + old.id : ''),
            {
                method: old ? 'PATCH' : 'POST',
                body: {
                    full_name: $('emp-nom').value,
                    position: $('emp-car').value,
                    salary: $('emp-sal').value,
                    hired_on: $('emp-fec').value,
                    active: $('biz-employee-state').value === 'true'
                }
            }
        );

        modal('modal-emp', false);

        await loadEmployees();
        await compliance();
    }

    function recordActions(kind, record) {
        let html = action('Ver / PDF', kind, record.id, 'view');

        if (write() && record.status === 'draft') {
            html += action('Editar', kind, record.id);
            html += action('Archivar', kind, record.id, 'archive');

            if (['payroll', 'purchase'].includes(kind)) {
                html += action(
                    'Confirmar pago',
                    kind,
                    record.id,
                    'pay'
                );
            }
        }

        return html;
    }

    async function loadRecords(kind) {
        const rows = await api('/business/records/' + kind);
        state.records[kind] = rows;

        const statusLabel = record => badge(
            record.status === 'paid'
                ? 'Pagado'
                : 'Borrador / expediente'
        );

        const actions = record => recordActions(kind, record);

        let headers;
        let values;

        if (kind === 'payroll') {
            headers = [
                'Empleado / período',
                'Bruto',
                'Deducciones',
                'Neto',
                'Pago / estado',
                'Acciones'
            ];

            values = rows.map(record => [
                E(record.data.employee_name) +
                '<small>' + E(record.data['nom-period']) + '</small>',
                money(record.data.gross),
                money(record.data.deductions),
                money(record.amount),
                E(record.data.payment_method) + ' ' + statusLabel(record),
                actions(record)
            ]);
        }

        if (kind === 'purchase') {
            headers = [
                'Orden / proveedor',
                'Concepto',
                'Importe',
                'Pago / estado',
                'Acciones'
            ];

            values = rows.map(record => [
                '#' + record.id + ' · ' + E(record.data.supplier_name),
                E(record.data['comp-con']),
                money(record.amount),
                E(record.data.payment_method) + ' ' + statusLabel(record),
                actions(record)
            ]);
        }

        if (kind === 'contract') {
            headers = [
                'Empleado',
                'Identificación',
                'Contrato',
                'Jornada / vigencia',
                'Acciones'
            ];

            values = rows.map(record => [
                E(record.data.employee_name),
                E(record.data['con-ced']),
                E(record.data['con-tipo']),
                E(record.data['con-jor']) +
                '<small>' +
                    E(record.data['con-start']) + ' → ' +
                    E(record.data['con-end'] || 'Sin fecha final') +
                '</small>',
                actions(record)
            ]);
        }

        if (kind === 'leave') {
            headers = [
                'Empleado',
                'Tipo',
                'Fechas / estado',
                'Acciones'
            ];

            values = rows.map(record => [
                E(record.data.employee_name),
                E(record.data['per-tipo']),
                E(record.data['per-start']) + ' → ' +
                E(record.data['per-end']) + ' ' +
                badge(record.data['per-status']),
                actions(record)
            ]);
        }

        if (kind === 'incident') {
            headers = [
                'Empleado / fecha',
                'Descripción / seguimiento',
                'Acciones'
            ];

            values = rows.map(record => [
                E(record.data.employee_name) +
                '<small>' + E(record.data['inc-date']) + '</small>',
                E(record.data['inc-desc']) +
                '<small>' +
                    E(record.data['inc-level']) + ' · ' +
                    E(record.data['inc-status']) +
                '</small>',
                actions(record)
            ]);
        }

        if (kind === 'equipment') {
            headers = [
                'Empleado',
                'Equipo / cantidad',
                'Fecha',
                'Acciones'
            ];

            values = rows.map(record => [
                E(record.data.employee_name),
                E(record.data['epp-equipo']) +
                ' × ' +
                E(record.data['epp-qty']),
                E(record.data['epp-date']),
                actions(record)
            ]);
        }

        grid(configs[kind][2], headers, values);

        status(
            kind,
            configs[kind][4] + ': ' +
            rows.length +
            ' registros consultados; máximo 500.'
        );
    }

    function labelFor(id) {
        const labels = {
            payment_method: 'Forma de pago',
            payment_reference: 'Referencia de pago'
        };

        if (labels[id]) return labels[id];

        const element = $(id);

        if (!element) return id;

        const label = element.closest('label');

        if (label) {
            return label.firstChild?.textContent.trim() || id;
        }

        const previous = element.previousElementSibling;

        return previous?.tagName === 'LABEL'
            ? previous.textContent.trim()
            : element.placeholder || id;
    }

    function preview(title, html) {
        $('preview-title').textContent = title;

        $('preview-content').innerHTML =
            '<article class="biz-document">' + html + '</article>';

        $('ticket-contenido').innerHTML = html;

        $('btn-descargar-excel').classList.add('hidden');
        $('btn-descargar-txt').classList.add('hidden');

        let button = $('biz-pdf');

        if (!button) {
            button = document.createElement('button');
            button.id = 'biz-pdf';
            button.className = 'biz-btn biz-primary';
            button.textContent = 'Descargar PDF';

            $('btn-descargar-txt').parentElement.prepend(button);
        }

        button.onclick = async () => {
            if (typeof html2pdf !== 'function') {
                return error(new Error(
                    'No se cargó el generador PDF. ' +
                    'Usa Imprimir y Guardar como PDF.'
                ));
            }

            button.disabled = true;

            try {
                await html2pdf()
                    .set({
                        filename: title.replace(
                            /[^a-z0-9_-]/gi,
                            '_'
                        ) + '.pdf',
                        margin: 10,
                        html2canvas: { scale: 2 },
                        jsPDF: {
                            unit: 'mm',
                            format: 'a4',
                            orientation: 'portrait'
                        }
                    })
                    .from($('preview-content'))
                    .save();
            } catch (err) {
                error(err);
            } finally {
                button.disabled = false;
            }
        };

        modal('modal-preview', true);
    }

    function previewDoc(kind, record) {
        const skip = [
            'comp-items',
            'employee_name',
            'supplier_name',
            'gross',
            'deductions'
        ];

        let details = Object.entries(record.data)
            .filter(([key]) => !skip.includes(key))
            .map(([key, value]) => {
                return '<tr><th>' + E(labelFor(key)) +
                    '</th><td>' + E(value) + '</td></tr>';
            }).join('');

        if (kind === 'purchase') {
            const items = JSON.parse(
                record.data['comp-items'] || '[]'
            );

            details += items.map(item => {
                return (
                    '<tr><th>Producto #' +
                    E(item.product_id) +
                    '</th><td>' +
                    E(item.qty) + ' × ' + money(item.unit_cost) +
                    '</td></tr>'
                );
            }).join('');
        }

        const total = ['purchase', 'payroll'].includes(kind)
            ? (
                '<h2>Total: ' + money(record.amount) + '</h2>' +
                '<p>Gasto asociado: ' +
                    E(record.expense_id || 'Sin pago') +
                '</p>'
            )
            : '';

        preview(
            configs[kind][4] + '_' + record.id,
            '<header>' +
                '<strong>K@rin@ Cyber</strong>' +
                '<h1>' + E(configs[kind][4]) +
                    ' #' + record.id + '</h1>' +
                '<p>' +
                    E(
                        record.data.employee_name ||
                        record.data.supplier_name ||
                        ''
                    ) +
                '</p>' +
            '</header>' +
            '<p>Estado: ' +
                E(
                    record.status === 'paid'
                        ? 'Pagado'
                        : 'Expediente / borrador'
                ) +
            '</p>' +
            '<table>' + details + '</table>' +
            total +
            '<footer>' +
                'Registro interno. El contenido de contratos y ' +
                'cálculos laborales requiere aprobación del responsable.' +
            '</footer>'
        );
    }

    async function pay(kind, record) {
        if (!confirm(
            '¿Confirmar pago de ' +
            money(record.amount) +
            ' mediante ' +
            record.data.payment_method +
            '?'
        )) {
            return;
        }

        const snapshot = await api('/finance/cash-shifts/current');

        if (!snapshot.shift || !snapshot.reconciled) {
            throw new Error(
                'Abre y concilia tu turno en Control de caja.'
            );
        }

        await api(
            '/business/records/' +
            kind + '/' + record.id + '/pay',
            {
                method: 'POST',
                body: {
                    version: record.version,
                    shift_id: snapshot.shift.id
                }
            }
        );

        await loadRecords(kind);
        await cashView();

        if (typeof refreshShiftBadge === 'function') {
            await refreshShiftBadge();
        }

        if (typeof actualizarInventarioDashboard === 'function') {
            await actualizarInventarioDashboard();
        }
    }

    function chart(id, type, labels, datasets) {
        if (typeof Chart === 'undefined') return;

        state.charts[id]?.destroy();

        const canvas = $(id);

        if (!canvas) return;

        state.charts[id] = new Chart(canvas, {
            type,
            data: {
                labels,
                datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                },
                ...(
                    type === 'line' || type === 'bar'
                        ? {
                            scales: {
                                y: { beginAtZero: true }
                            }
                        }
                        : {}
                )
            }
        });
    }

    function charts() {
        const data = state.cash;

        if (!data) return;

        chart(
            'chartCajaBar',
            'line',
            data.daily.map(row => String(row.day).slice(0, 10)),
            [
                {
                    label: 'Entradas',
                    data: data.daily.map(row => row.income),
                    borderColor: '#0d9488',
                    backgroundColor: '#ccfbf1',
                    tension: 0.25
                },
                {
                    label: 'Salidas',
                    data: data.daily.map(row => row.expense),
                    borderColor: '#e11d48',
                    backgroundColor: '#ffe4e6',
                    tension: 0.25
                }
            ]
        );

        chart(
            'chartGastosPie',
            'doughnut',
            data.methods.map(row => row.method),
            [{
                label: 'Egresos por método',
                data: data.methods.map(row => row.expense),
                backgroundColor: [
                    '#0d9488',
                    '#4f46e5',
                    '#f59e0b',
                    '#64748b'
                ]
            }]
        );
    }

    function filters() {
        const panel = $('finanzas-caja');
        const bar = document.createElement('div');

        bar.className = 'biz-toolbar';
        bar.id = 'biz-cash-filters';

        bar.innerHTML = `
            <label>
                Desde
                <input id="biz-from" type="date">
            </label>
            <label>
                Hasta
                <input id="biz-to" type="date">
            </label>
            <button
                class="biz-btn biz-primary"
                type="button"
                id="biz-filter"
            >
                Consultar período
            </button>
            <a class="biz-btn" href="/caja-chica.html">
                Administrar mi turno
            </a>
        `;

        panel.prepend(bar);

        $('biz-from').value = state.from;
        $('biz-to').value = state.to;

        $('biz-filter').onclick = () => {
            state.from = $('biz-from').value;
            state.to = $('biz-to').value;
            state.offset = 0;

            task('cash', cashView);
        };

        const pager = document.createElement('div');

        pager.className = 'biz-toolbar';

        pager.innerHTML = `
            <button class="biz-btn" id="biz-prev">Anterior</button>
            <span id="biz-page"></span>
            <button class="biz-btn" id="biz-next">Siguiente</button>
        `;

        panel.append(pager);

        $('biz-prev').onclick = () => {
            state.offset = Math.max(0, state.offset - 100);
            task('cash', cashView);
        };

        $('biz-next').onclick = () => {
            state.offset += 100;
            task('cash', cashView);
        };

        const statistics = $('finanzas-estadistica');
        const dateInput = statistics.querySelector('input[type="date"]');

        dateInput.value = state.from;

        const select = statistics.querySelector('select');

        select.replaceChildren(
            new Option('Todos los métodos', ''),
            ...methodOptions.map(
                ([value, label]) => new Option(label, value)
            )
        );

        select.previousElementSibling.textContent = 'Forma de pago';

        const end = document.createElement('label');

        end.className = 'biz-field';
        end.textContent = 'Hasta';

        const endInput = document.createElement('input');

        endInput.type = 'date';
        endInput.value = state.to;

        end.append(endInput);
        dateInput.closest('.flex-1').after(end);

        statistics.querySelector('button').onclick = () => {
            state.from = dateInput.value;
            state.to = endInput.value;
            state.method = select.value;
            state.offset = 0;

            $('biz-from').value = state.from;
            $('biz-to').value = state.to;

            task('cash', cashView);
        };

        const titles = statistics.querySelectorAll(
            '.power-bi-card h3'
        );

        const labels = [
            'Promedio diario del período',
            'Mayor egreso diario',
            'Entradas del período',
            'Flujo neto del período'
        ];

        titles.forEach((element, index) => {
            if (index < 4) {
                element.id = 'biz-stat-' + index;
                element.textContent = '—';
                element.previousElementSibling.textContent =
                    labels[index];
            }
        });
    }

    async function cashView() {
        const query = new URLSearchParams({
            from: state.from,
            to: state.to,
            offset: String(state.offset),
            method: state.method
        });

        const data = await api('/business/cash?' + query);

        state.cash = data;

        grid(
            'tbody-caja',
            [
                'Fecha',
                'Concepto / referencia',
                'Tipo',
                'Importe',
                'Método',
                'Cajero / turno',
                'Documento'
            ],
            data.items.map(row => [
                E(String(row.fec).slice(0, 10)),

                E(row.con) +
                '<small>' + E(row.referencia_pago || '') + '</small>',

                badge(row.tip),
                money(row.mon),
                E(row.metodo_pago || 'Sin especificar'),

                E(row.cashier || 'No registrado') +
                ' / ' +
                E(row.shift_id ?? '—'),

                E(
                    row.sale_id
                        ? 'Venta #' + row.sale_id
                        : row.print_payment_id
                            ? 'Impresión / pago #' + row.print_payment_id
                            : row.recarga_id
                                ? 'Recarga #' + row.recarga_id
                                : row.expense_id
                                    ? 'Gasto #' + row.expense_id
                                    : 'Histórico'
                )
            ])
        );

        const income = Number(data.totals.income);
        const expense = Number(data.totals.expense);
        const net = income - expense;

        const indicators = [
            ['caja-entradas', income, 'Entradas del período'],
            ['caja-salidas', expense, 'Salidas del período'],
            ['caja-saldo', net, 'Flujo neto del período']
        ];

        indicators.forEach(([id, value, label]) => {
            $(id).textContent = money(value);
            $(id).previousElementSibling.textContent = label;
        });

        const days = Math.round(
            (
                Date.parse(state.to) -
                Date.parse(state.from)
            ) / 86400000
        ) + 1;

        [
            income / days,
            Math.max(
                0,
                ...data.daily.map(row => Number(row.expense))
            ),
            income,
            net
        ].forEach((value, index) => {
            $('biz-stat-' + index).textContent = money(value);
        });

        [
            ['flu-ent', income],
            ['flu-sal', expense],
            ['flu-neto', net]
        ].forEach(([id, value]) => {
            if ($(id)) $(id).textContent = money(value);
        });

        $('biz-page').textContent =
            (data.items.length ? state.offset + 1 : 0) +
            '–' +
            (state.offset + data.items.length) +
            ' de ' +
            data.totals.count;

        $('biz-prev').disabled = state.offset === 0;

        $('biz-next').disabled =
            state.offset + data.items.length >=
            Number(data.totals.count);

        charts();

        status(
            'cash',
            'Caja: ' + state.from + ' a ' + state.to +
            (
                state.method
                    ? ' · ' + state.method
                    : ' · Todos los métodos'
            ) +
            '. El flujo neto no es el saldo físico del turno.'
        );
    }

    async function invoices() {
        const rows = await api('/pos/sales?limit=100');

        grid(
            'tbody-facturas',
            [
                'Comprobante',
                'Fecha / cajero',
                'Forma de pago',
                'Importe',
                'Vista / descarga'
            ],
            rows.map(sale => [
                '#' + sale.id,

                E(String(sale.date).slice(0, 10)) +
                '<small>' + E(sale.cashier_name) + '</small>',

                E(sale.payment_method),
                money(sale.total),

                action(
                    'Ver factura',
                    'invoice',
                    sale.id,
                    'view'
                )
            ])
        );

        status(
            'invoices',
            'Últimas ' + rows.length +
            ' ventas consultadas, máximo 100.'
        );
    }

    async function invoice(id) {
        const sale = await api(
            '/pos/sales/' + encodeURIComponent(id)
        );

        const items = sale.items.map(item => {
            return (
                '<tr>' +
                    '<td>' + E(item.product_name) + '</td>' +
                    '<td>' + E(item.qty) + '</td>' +
                    '<td>' + money(item.unit_price) + '</td>' +
                    '<td>' + money(item.subtotal) + '</td>' +
                '</tr>'
            );
        }).join('');

        preview(
            'Comprobante_' + sale.id,
            '<header>' +
                '<strong>K@rin@ Cyber</strong>' +
                '<h1>Comprobante de venta #' + E(sale.id) + '</h1>' +
                '<p>' + E(sale.date) + '</p>' +
            '</header>' +

            '<p>Cajero: ' + E(sale.cashier_name) + '</p>' +
            '<p>Cliente: no registrado en esta venta.</p>' +

            '<table>' +
                '<thead><tr>' +
                    '<th>Descripción</th>' +
                    '<th>Cantidad</th>' +
                    '<th>Precio</th>' +
                    '<th>Importe</th>' +
                '</tr></thead>' +
                '<tbody>' + items + '</tbody>' +
            '</table>' +

            '<h2>Total: ' + money(sale.total) + '</h2>' +

            '<p>Pago: ' + E(sale.payment_method) +
                ' · ' + E(sale.payment_reference || 'Sin referencia') +
            '</p>' +

            '<p>Turno: ' + E(sale.shift_id ?? '—') +
                ' · Movimiento: ' +
                E(sale.movement_id ?? 'No enlazado') +
            '</p>' +

            '<footer>' +
                'Comprobante interno. No acredita autorización ' +
                'de facturación fiscal.' +
            '</footer>'
        );
    }

    async function compliance() {
        const data = await api('/business/compliance');

        const cards = $('rh-cumplimiento').querySelectorAll(
            '.grid.grid-cols-4 .power-bi-card'
        );

        [
            ['Empleados activos', data.employees],
            ['Con contrato registrado vigente', data.with_contract],
            ['Incidentes abiertos', data.open_incidents],
            ['Ausencias por resolver', data.pending_leaves]
        ].forEach(([label, value], index) => {
            if (!cards[index]) return;

            cards[index].querySelector('p').textContent = label;
            cards[index].querySelector('h3').textContent = value;
        });

        const incidents = state.records.incident || [];

        const counts = [
            'Abierto',
            'En seguimiento',
            'Cerrado'
        ].map(status => {
            return incidents.filter(record => {
                return record.data['inc-status'] === status;
            }).length;
        });

        chart(
            'chartAccidentesCumplimiento',
            'bar',
            ['Abierto', 'En seguimiento', 'Cerrado'],
            [{
                label: 'Incidentes consultados (hasta 500)',
                data: counts,
                backgroundColor: [
                    '#e11d48',
                    '#f59e0b',
                    '#0d9488'
                ]
            }]
        );

        chart(
            'chartContratosCumplimiento',
            'doughnut',
            ['Con registro vigente', 'Sin registro vigente'],
            [{
                data: [
                    Number(data.with_contract),
                    Math.max(
                        0,
                        Number(data.employees) -
                        Number(data.with_contract)
                    )
                ],
                backgroundColor: ['#0d9488', '#e2e8f0']
            }]
        );

        const input = $('rh-cumplimiento').querySelector(
            'input[type="date"]'
        );

        input.value = today();
        input.readOnly = true;
        input.previousElementSibling.textContent =
            'Consulta al día de hoy';

        $('rh-cumplimiento').querySelector('button').onclick = () => {
            task('compliance', compliance);
        };

        status(
            'compliance',
            'Indicadores de registros internos. No constituyen ' +
            'una certificación de cumplimiento legal.'
        );
    }

    async function accounting() {
        const results = await Promise.allSettled([
            api('/accounting/trial-balance'),
            api('/finance/statements')
        ]);

        for (const result of results) {
            if (result.status === 'rejected') {
                throw result.reason;
            }
        }

        const accounts = results[0].value;
        const report = results[1].value;

        let panel = $('biz-trial');

        if (!panel) {
            panel = document.createElement('div');
            panel.id = 'biz-trial';
            panel.className = 'power-bi-card p-6';

            panel.innerHTML = `
                <h3>
                    Movimientos por cuenta desde la integración contable
                </h3>
                <table>
                    <tbody id="biz-trial-body"></tbody>
                </table>
            `;

            $('conta-balance').append(panel);
        }

        grid(
            'biz-trial-body',
            ['Cuenta', 'Debe', 'Haber'],
            accounts.items.map(account => [
                E(account.code) + ' · ' + E(account.name),
                money(account.debit),
                money(account.credit)
            ])
        );

        [
            'bal-caja',
            'bal-act-tot',
            'bal-pasivo'
        ].forEach(id => {
            if ($(id)) $(id).textContent = 'Por conciliar';
        });

        $('conta-balance').querySelectorAll('td').forEach(cell => {
            if (cell.textContent.includes('114,500')) {
                cell.textContent = 'Por registrar';
            }
        });

        if (report.available) {
            const values = report.estadoResultados;

            $('res-ventas').textContent =
                money(values.ingresosTotales);

            $('res-costos').textContent = money(
                Number(values.costoDeVentas) +
                Number(values.gastosOperativos)
            );

            $('res-neta').textContent =
                money(values.utilidadNeta);

            $('res-neta').previousElementSibling.textContent =
                'RESULTADO OPERATIVO REGISTRADO';
        }

        status(
            'accounting',
            'Las cuentas muestran asientos nuevos. Los estados ' +
            'completos necesitan saldos iniciales y ajustes de cierre.'
        );
    }

    async function overview() {
        const data = await api('/operations/overview');

        let box = $('biz-overview');

        if (!box) {
            box = document.createElement('div');
            box.id = 'biz-overview';
            box.className = 'biz-overview';

            $('dash-inicio').append(box);
        }

        box.innerHTML = [
            ['Órdenes pendientes', data.production_pending],
            ['Proveedores activos', data.active_suppliers],
            ['Empleados activos', data.active_employees],
            ['Inversión en inventario', money(data.inventory_value)]
        ].map(([label, value]) => {
            return (
                '<div class="power-bi-card">' +
                    '<p>' + E(label) + '</p>' +
                    '<strong>' + E(value) + '</strong>' +
                '</div>'
            );
        }).join('');
    }

    async function editor(title, fields, values, onSave) {
        const dialog = document.createElement('dialog');
        dialog.className = 'biz-editor';

        const controls = fields.map(field => {
            const input = field.options
                ? (
                    '<select name="' + field.name + '">' +
                    field.options.map(([value, label]) => {
                        return '<option value="' + E(value) + '">' +
                            E(label) +
                        '</option>';
                    }).join('') +
                    '</select>'
                )
                : (
                    '<input name="' + field.name + '" ' +
                    'type="' + (field.type || 'text') + '" ' +
                    (
                        field.type === 'number'
                            ? 'min="0" step="0.000001"'
                            : ''
                    ) +
                    '>'
                );

            return (
                '<label class="biz-field">' +
                    E(field.label) +
                    input +
                '</label>'
            );
        }).join('');

        dialog.innerHTML = (
            '<form>' +
                '<h2>' + E(title) + '</h2>' +
                controls +
                '<p class="biz-form-error" role="alert"></p>' +
                '<div class="biz-toolbar">' +
                    '<button type="button" data-close>Cancelar</button>' +
                    '<button type="submit" class="biz-btn biz-primary">' +
                        'Guardar' +
                    '</button>' +
                '</div>' +
            '</form>'
        );

        document.body.append(dialog);

        const form = dialog.querySelector('form');

        fields.forEach(field => {
            form.elements[field.name].value =
                values[field.name] ?? field.value ?? '';

            form.elements[field.name].required =
                field.required !== false;
        });

        let busy = false;

        dialog.querySelector('[data-close]').onclick = () => {
            if (!busy) dialog.close();
        };

        dialog.addEventListener('cancel', event => {
            if (busy) event.preventDefault();
        });

        dialog.addEventListener(
            'close',
            () => dialog.remove(),
            { once: true }
        );

        form.onsubmit = async event => {
            event.preventDefault();

            if (busy) return;

            busy = true;
            form.querySelector('[type="submit"]').disabled = true;

            try {
                await onSave(
                    Object.fromEntries(new FormData(form))
                );

                dialog.close();
            } catch (err) {
                form.querySelector('[role="alert"]').textContent =
                    err.message;
            } finally {
                busy = false;
                form.querySelector('[type="submit"]').disabled = false;
            }
        };

        dialog.showModal();
    }

    async function productEditor(id) {
        const results = await Promise.allSettled([
            api('/inventory/products'),
            api('/inventory/categories')
        ]);

        for (const result of results) {
            if (result.status === 'rejected') {
                throw result.reason;
            }
        }

        state.products = results[0].value;

        const categories = results[1].value;

        const item = id
            ? state.products.find(
                product => String(product.id) === String(id)
            )
            : {};

        if (!item) {
            throw new Error('Producto no encontrado.');
        }

        editor(
            id ? 'Editar producto' : 'Nuevo producto',
            [
                { name: 'sku', label: 'SKU' },
                { name: 'name', label: 'Nombre' },
                {
                    name: 'unit',
                    label: 'Unidad',
                    value: 'unidad'
                },
                {
                    name: 'category_id',
                    label: 'Categoría',
                    required: false,
                    options: [
                        ['', 'Sin categoría'],
                        ...categories.map(
                            category => [category.id, category.name]
                        )
                    ]
                },
                {
                    name: 'supplier_id',
                    label: 'Proveedor',
                    required: false,
                    options: [
                        ['', 'Sin proveedor'],
                        ...state.suppliers.map(
                            supplier => [supplier.id, supplier.nombre]
                        )
                    ]
                },
                {
                    name: 'min_stock',
                    label: 'Existencia mínima',
                    type: 'number',
                    value: 0
                },
                {
                    name: 'price',
                    label: 'Precio de venta',
                    type: 'number',
                    value: 0
                },
                {
                    name: 'active',
                    label: 'Estado',
                    value: 'true',
                    options: [
                        ['true', 'Activo'],
                        ['false', 'Inactivo']
                    ]
                }
            ],
            item,
            async body => {
                body.active = body.active === 'true';

                await api(
                    '/inventory/products' + (id ? '/' + id : ''),
                    {
                        method: id ? 'PATCH' : 'POST',
                        body
                    }
                );

                await actualizarInventarioDashboard();
            }
        );
    }

    function inventoryCRUD() {
        const host = $('kc-inventory');

        if (!host || !write()) return;

        const button = document.createElement('button');

        button.className = 'biz-btn biz-primary';
        button.type = 'button';
        button.textContent = 'Nuevo producto';

        button.onclick = () => {
            task('inventory-edit', () => productEditor());
        };

        host.querySelector('.kc-toolbar').append(button);

        new MutationObserver(() => {
            host.querySelectorAll(
                'button[data-kardex-id]'
            ).forEach(button => {
                if (
                    button.parentElement.querySelector(
                        '[data-biz-action]'
                    )
                ) {
                    return;
                }

                button.insertAdjacentHTML(
                    'afterend',
                    action(
                        'Editar',
                        'product',
                        button.dataset.kardexId
                    ) +
                    action(
                        'Desactivar',
                        'product',
                        button.dataset.kardexId,
                        'archive'
                    )
                );
            });
        }).observe($('kc-stock-table'), {
            childList: true,
            subtree: true
        });
    }

    async function history(kind) {
        const result = await api('/business/history/' + kind);

        if (!result.available) {
            return error(new Error(
                'No existe una tabla histórica para esta sección. ' +
                'Los expedientes nuevos se conservan en el registro integrado.'
            ));
        }

        const keys = [
            ...new Set(
                result.items.flatMap(row => Object.keys(row))
            )
        ];

        const head = keys.map(
            key => '<th>' + E(key) + '</th>'
        ).join('');

        const rows = result.items.map(row => {
            return '<tr>' + keys.map(key => {
                const value = typeof row[key] === 'object'
                    ? JSON.stringify(row[key])
                    : row[key];

                return '<td>' + E(value) + '</td>';
            }).join('') + '</tr>';
        }).join('');

        preview(
            'Historial_' + kind,
            '<h1>Registros anteriores</h1>' +
            '<p>Consulta de hasta 200 registros. ' +
                'No se han reconstruido pagos ni vínculos.</p>' +
            '<div class="biz-table-wrap"><table>' +
                '<thead><tr>' + head + '</tr></thead>' +
                '<tbody>' + rows + '</tbody>' +
            '</table></div>'
        );
    }

    async function handleAction(button) {
        const kind = button.dataset.kind;
        const id = button.dataset.id;
        const verb = button.dataset.bizAction;

        if (verb === 'history') return history(kind);
        if (kind === 'invoice') return invoice(id);

        if (kind === 'product') {
            if (verb === 'archive') {
                if (confirm(
                    '¿Desactivar este producto conservando su historial?'
                )) {
                    await api('/inventory/products/' + id, {
                        method: 'DELETE'
                    });

                    await actualizarInventarioDashboard();
                }

                return;
            }

            return productEditor(id);
        }

        if (kind === 'supplier') {
            if (verb === 'archive') {
                if (confirm('¿Desactivar proveedor?')) {
                    await api('/operations/suppliers/' + id, {
                        method: 'DELETE'
                    });

                    await loadSuppliers();
                }

                return;
            }

            return openSupplier(id);
        }

        if (kind === 'employee') {
            if (verb === 'archive') {
                if (confirm(
                    '¿Desactivar empleado conservando su historial?'
                )) {
                    await api('/operations/employees/' + id, {
                        method: 'DELETE'
                    });

                    await loadEmployees();
                }

                return;
            }

            if (verb === 'payroll') {
                openDoc('payroll');

                $('nom-empleado').value = id;
                window.cargarDatosEmpNomina();

                return;
            }

            return openEmployee(id);
        }

        const record = state.records[kind]?.find(
            row => String(row.id) === String(id)
        );

        if (!record) return;

        if (verb === 'view') return previewDoc(kind, record);
        if (verb === 'pay') return pay(kind, record);

        if (verb === 'archive') {
            if (confirm(
                '¿Archivar este expediente conservando la auditoría?'
            )) {
                await api(
                    '/business/records/' + kind + '/' + id,
                    {
                        method: 'DELETE',
                        body: {
                            version: record.version
                        }
                    }
                );

                await loadRecords(kind);
                await compliance();
            }

            return;
        }

        openDoc(kind, id);
    }

    /* ERP_RECARGA_refresh */
    window.addEventListener('erp:solicitar-recarga', evento => {
        evento.detail.promesas.push(Promise.resolve().then(() => refresh()));
    });
    async function refresh() {
        const jobs = [
            ['suppliers', loadSuppliers],
            ['employees', loadEmployees],
            ['cash', cashView],
            ['invoices', invoices],
            ['accounting', accounting],
            ['overview', overview],
            ...Object.keys(configs).map(kind => [
                kind,
                () => loadRecords(kind)
            ])
        ];

        await Promise.allSettled(
            jobs.map(([key, operation]) => {
                return task(key, operation);
            })
        );

        await task('compliance', compliance);
    }

    function start() {
        if (!$('dash-inicio')) return;

        document.body.classList.add('biz-dashboard');

        const notices = document.createElement('details');

        notices.id = 'biz-notices';
        notices.setAttribute('aria-live', 'polite');
        notices.innerHTML = '<summary>Estado de actualización</summary>';

        $('dash-inicio').append(notices);

        for (const id of [
            'bal-caja',
            'bal-act-tot',
            'bal-pasivo',
            'res-ventas',
            'res-costos',
            'res-neta',
            'caja-entradas',
            'caja-salidas',
            'caja-saldo',
            'rrhh-total',
            'rrhh-prom',
            'kpi-pasivo-laboral',
            'kpi-prov-total',
            'kpi-prov-activos',
            'kpi-prov-deuda'
        ]) {
            if ($(id)) $(id).textContent = '—';
        }

        $('rh-cumplimiento').querySelectorAll(
            '.grid.grid-cols-4 h3'
        ).forEach(element => {
            element.textContent = '—';
        });

        $('conta-balance').querySelectorAll('td').forEach(cell => {
            if (cell.textContent.includes('114,500')) {
                cell.textContent = 'Por registrar';
            }
        });

        extraForms();
        filters();
        inventoryCRUD();

        const histories = {
            payroll: 'conta-nomina',
            purchase: 'conta-compras',
            employee: 'rh-empleados',
            contract: 'rh-contratos',
            leave: 'rh-permisos',
            incident: 'rh-seguridad',
            equipment: 'rh-seguridad'
        };

        for (const [kind, id] of Object.entries(histories)) {
            const box = document.createElement('div');

            box.innerHTML = action(
                'Registros anteriores · ' +
                (configs[kind]?.[4] || 'Empleados'),
                kind,
                '',
                'history'
            );

            $(id).append(box);
        }

        for (const [kind, config] of Object.entries(configs)) {
            window[config[3]] = () => openDoc(kind);

            bindSubmit(
                config[0],
                () => saveDoc(kind)
            );
        }

        window.abrirModalProveedor = () => openSupplier();
        window.editProv = openSupplier;

        window.abrirModalEmp = () => openEmployee();
        window.editEmp = openEmployee;

        bindSubmit('form-proveedor', saveSupplier);
        bindSubmit('form-emp', saveEmployee);

        window.cargarDatosEmpNomina = () => {
            const employee = state.employees.find(row => {
                return String(row.id) === $('nom-empleado').value;
            });

            if (employee) {
                $('nom-base').value = employee.salary;
            }
        };

        window.abrirModalCaja = () => {
            location.assign('/caja-chica.html');
        };

        window.abrirModalFactura = () => {
            location.assign('/pos.html');
        };

        $('chartGastosPie')
            .parentElement
            .parentElement
            .querySelector('h3')
            .textContent = 'Egresos por forma de pago';

        $('chartAccidentesCumplimiento')
            .parentElement
            .parentElement
            .querySelector('h3')
            .textContent = 'Incidentes registrados por estado';

        $('chartContratosCumplimiento')
            .parentElement
            .parentElement
            .querySelector('h3')
            .textContent = 'Cobertura de contratos registrados';

        window.renderChartsFinanzas = charts;

        window.renderChartsCumplimiento = () => {
            task('compliance', compliance);
        };

        window.exportarPDFStats = async () => {
            if (typeof html2pdf !== 'function') {
                return error(
                    new Error('No se cargó el generador PDF.')
                );
            }

            try {
                await html2pdf()
                    .set({
                        filename: 'Informe_registros_RRHH.pdf',
                        margin: 10
                    })
                    .from($('rh-cumplimiento'))
                    .save();
            } catch (err) {
                error(err);
            }
        };

        $('rh-cumplimiento').querySelector(
            '[onclick="exportarPDFStats()"]'
        ).textContent = 'Descargar informe de registros';

        window.sincronizarBaseDatos = refresh;

        document.addEventListener('click', async event => {
            const button = event.target.closest(
                '[data-biz-action]'
            );

            if (!button || button.disabled) return;

            event.preventDefault();
            button.disabled = true;

            try {
                await handleAction(button);
            } catch (err) {
                error(err);
            } finally {
                button.disabled = false;
            }
        });

        api('/inventory/products')
            .then(products => {
                state.products = products;
            })
            .catch(error);

        if (typeof window.cargarPanelesOriginales === 'function') {
            task(
                'original',
                window.cargarPanelesOriginales
            );
        }

        refresh();
    }

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            start,
            { once: true }
        );
    } else {
        start();
    }
})();