/* K@rin@ cyber — núcleo compartido del frontend */

const API_BASE = '/api';

// ============================================================
// 1. SESIÓN Y AUTENTICACIÓN
// ============================================================

const Auth = {
  getToken() {
    return localStorage.getItem('kc_token');
  },

  getUser() {
    try {
      return JSON.parse(
        localStorage.getItem('kc_user') || 'null'
      );
    } catch {
      return null;
    }
  },

  setSession(token, user) {
    localStorage.setItem('kc_token', token);

    localStorage.setItem(
      'kc_user',
      JSON.stringify(user)
    );
  },

  clear() {
    localStorage.removeItem('kc_token');
    localStorage.removeItem('kc_user');
  },

  logout() {
    Auth.clear();

    window.location.href = '/index.html';
  }
};

// ============================================================
// 2. COMUNICACIÓN CON EL SERVIDOR
// ============================================================

async function api(
  path,
  {
    method = 'GET',
    body,
    isForm = false
  } = {}
) {
  const headers = {};
  const token = Auth.getToken();

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  // Para FormData, el navegador agrega Content-Type
  // y el separador multipart correspondiente.
  if (!isForm) {
    headers['Content-Type'] = 'application/json';
  }

  const res = await fetch(API_BASE + path, {
    method,
    headers,

    body: body
      ? (
          isForm
            ? body
            : JSON.stringify(body)
        )
      : undefined
  });

  if (res.status === 401) {
    Auth.clear();

    window.location.href = '/index.html';

    throw new Error('Sesión expirada.');
  }

  const contentType =
    res.headers.get('content-type') || '';

  const isJson = contentType.includes(
    'application/json'
  );

  const data = isJson
    ? await res.json().catch(() => ({}))
    : await res.blob();

  if (!res.ok) {
    const message =
      (
        isJson &&
        data &&
        data.error
      ) ||
      'Ocurrió un error inesperado.';

    const err = new Error(message);

    // Permite distinguir errores de validación, permisos,
    // conflictos y errores internos.
    err.status = res.status;

    throw err;
  }

  return data;
}

// ============================================================
// 3. UTILIDADES DE FORMATO
// ============================================================

function money(n) {
  return 'C$ ' + Number(n || 0).toLocaleString(
    'es-NI',
    {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }
  );
}

// Conserva el tratamiento de fechas de los módulos existentes.
function toDate(raw) {
  if (!raw) return null;

  let s = String(raw).replace(' ', 'T');

  if (!/[zZ]|[+-]\d{2}:?\d{2}$/.test(s)) {
    s += 'Z';
  }

  const d = new Date(s);

  return isNaN(d.getTime())
    ? null
    : d;
}

function fmtDateTime(value) {
  const d = toDate(value);

  if (!d) return '—';

  return d.toLocaleString('es-NI', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function fmtDate(value) {
  const d = toDate(value);

  if (!d) return '—';

  return d.toLocaleDateString('es-NI', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

function initials(name) {
  if (!name) return '?';

  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(word => word[0])
    .join('')
    .toUpperCase();
}

function escapeHtml(str) {
  const entities = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  };

  return String(str ?? '').replace(
    /[&<>"']/g,
    character => entities[character]
  );
}

// ============================================================
// 4. NOTIFICACIONES
// ============================================================

function toast(message, type = 'info') {
  let wrap = document.querySelector('.toast-wrap');

  if (!wrap) {
    wrap = document.createElement('div');
    wrap.className = 'toast-wrap';

    document.body.appendChild(wrap);
  }

  const el = document.createElement('div');

  el.className = `toast ${type}`;

  const icon = type === 'error'
    ? 'bi-exclamation-circle'
    : type === 'success'
      ? 'bi-check-circle'
      : 'bi-info-circle';

  el.innerHTML = `
    <i class="bi ${icon}"></i>
    <span>${escapeHtml(message)}</span>
  `;

  wrap.appendChild(el);

  setTimeout(() => {
    el.remove();
  }, 4200);
}

function apiErrorToast(err) {
  toast(
    err.message || 'Ocurrió un error.',
    'error'
  );
}

// ============================================================
// 5. MENÚ DEL SISTEMA
// ============================================================

const NAV_ITEMS = [
    { section: 'GENERAL' },
    { label: 'Dashboard', icon: 'bi-grid-1x2', href: '/dashboard.html' },
    
    // Sub-módulos con iconos personalizados
    { label: 'Producción', icon: 'bi-box-seam', href: '/dashboard.html#produccion' },
    { label: 'Proveedores', icon: 'bi-truck', href: '/dashboard.html#proveedores' },
    { label: 'Cont. Financiera', icon: 'bi-journal-text', href: '/dashboard.html#contabilidad' },
    { label: 'Finanzas', icon: 'bi-cash-coin', href: '/dashboard.html#finanzas' },
    { label: 'Recursos Humanos', icon: 'bi-people', href: '/dashboard.html#rrhh' },
    
    // TUS MÓDULOS INTACTOS
    { section: 'OPERACIÓN DIARIA' },
    { label: 'Punto de venta', icon: 'bi-cart3', href: '/pos.html' },
    { label: 'Producción y servicios', icon: 'bi-printer', href: '/impresiones.html' },
    { label: 'Recargas', icon: 'bi-phone', href: '/recargas.html' },
    { label: 'Caja chica', icon: 'bi-cash-stack', href: '/caja-chica.html' },
    
    { section: 'ADMINISTRACIÓN' },
    { label: 'Inventario y Kardex', icon: 'bi-box-seam', href: '/inventario.html' },
    { label: 'Reportes', icon: 'bi-bar-chart-line', href: '/reportes.html' },
    { label: 'Seguridad digital', icon: 'bi-shield-check', href: '/seguridad.html' },
    { label: 'Usuarios', icon: 'bi-people', href: '/usuarios.html' }
];

// ============================================================
// 6. VERIFICACIÓN DE SESIÓN
// ============================================================

function requireAuthOrRedirect() {
  if (!Auth.getToken()) {
    window.location.href = '/index.html';

    return false;
  }

  return true;
}

// ============================================================
// 7. ESTRUCTURA COMPARTIDA DE LAS PÁGINAS
// ============================================================

function renderShell({
  title,
  subtitle,
  active
}) {
  const user = Auth.getUser() || {};

  const currentPath = window.location.pathname;
  const currentHash = window.location.hash;

  const navHtml = NAV_ITEMS.map(item => {
    if (item.section) {
      return `
        <div class="nav-section">
          ${item.section}
        </div>
      `;
    }

    if (item.sub) {
      if (!currentPath.endsWith(item.parent)) {
        return '';
      }

      return item.items.map(sub => {
        const isActive =
          currentHash === '#' + sub.hash
            ? 'active'
            : '';

        return `
          <a
            href="${item.parent}#${sub.hash}"
            class="sub-link ${isActive}"
          >
            <span
              class="dot"
              style="background:${sub.color}"
            ></span>

            ${sub.label}
          </a>
        `;
      }).join('');
    }

    if (
      item.roles &&
      !item.roles.includes(user.role)
    ) {
      return '';
    }

    const isActive =
      currentPath.endsWith(item.href)
        ? 'active'
        : '';

    return `
      <a
        href="${item.href}"
        class="${isActive}"
      >
        <i class="bi ${item.icon}"></i>
        ${item.label}
      </a>
    `;
  }).join('');

  document.getElementById('app-shell').innerHTML = `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <div class="mark">K@</div>

        <div class="name">
          K@rin@ cyber
          <small>Sistema administrativo</small>
        </div>
      </div>

      <nav class="sidebar-nav">
        ${navHtml}
      </nav>

      <div class="sidebar-foot">
        <div class="user">
          <div class="avatar">
            ${escapeHtml(initials(user.full_name))}
          </div>

          <div class="who">
            <div class="n">
              ${escapeHtml(user.full_name || '')}
            </div>

            <div class="r">
              ${escapeHtml(user.role_label || '')}
            </div>
          </div>
        </div>

        <button
          class="logout-btn"
          onclick="Auth.logout()"
        >
          <i class="bi bi-box-arrow-left"></i>
          Cerrar sesión
        </button>
      </div>
    </aside>

    <div class="main">
      <header class="topbar">
        <div class="flex items-center gap-3">
          <button
            class="menu-toggle"
            id="menuToggle"
            aria-label="Abrir menú"
          >
            <i class="bi bi-list"></i>
          </button>

          <div class="page-title">
            ${escapeHtml(title)}

            ${
              subtitle
                ? `<small>${escapeHtml(subtitle)}</small>`
                : ''
            }
          </div>
        </div>

        <div class="right">
          <span
            id="shiftBadge"
            class="shift-badge closed"
          >
            <span class="dot"></span>
            Verificando turno…
          </span>
        </div>
      </header>

      <main
        class="content"
        id="page-content"
      ></main>
    </div>
  `;

  document
    .getElementById('menuToggle')
    .addEventListener('click', () => {
      document
        .getElementById('sidebar')
        .classList.toggle('open');
    });

  if (
    ['cajero', 'admin', 'superadmin']
      .includes(user.role)
  ) {
    refreshShiftBadge();
  } else {
    document.getElementById(
      'shiftBadge'
    ).style.display = 'none';
  }
}

// ============================================================
// 8. INDICADOR DEL TURNO DE CAJA
// ============================================================

async function refreshShiftBadge() {
  const badge = document.getElementById(
    'shiftBadge'
  );

  if (!badge) return;

  try {
    const data = await api(
      '/finance/cash-shifts/current'
    );

    if (data.shift) {
      badge.className = 'shift-badge open';

      const expectedCashText =
        data.expectedCash == null
          ? ''
          : ' · ' + money(data.expectedCash);

      badge.innerHTML = `
        <span class="dot"></span>
        Turno abierto${expectedCashText}
      `;
    } else {
      badge.className = 'shift-badge closed';

      badge.innerHTML = `
        <span class="dot"></span>
        Sin turno de caja abierto
      `;
    }
  } catch {
    badge.style.display = 'none';
  }
}

// ============================================================
// 9. AÑO AUTOMÁTICO
// ============================================================

document.addEventListener(
  'DOMContentLoaded',
  () => {
    const yearElement = document.querySelector(
      '[data-year]'
    );

    if (yearElement) {
      yearElement.textContent =
        new Date().getFullYear();
    }
  }
);


/////==================================================================
