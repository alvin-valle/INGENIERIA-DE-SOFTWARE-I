'use strict';

require('dotenv').config();

const express = require('express');

const path = require('path');

const multer = require('multer');

const pool = require('./db/connection');

const {
  requireAuth,
  requireRole
} = require('./middleware/auth');

const app = express();

const PORT = Number(process.env.PORT) || 3000;

const publicDirectory = path.resolve(
  __dirname,
  '../public'
);

// ============================================================
// CONFIGURACIÓN
// ============================================================

if (
  !process.env.JWT_SECRET ||
  process.env.JWT_SECRET.length < 32
) {
  throw new Error(
    'Configura JWT_SECRET en .env con al menos ' +
    '32 caracteres aleatorios.'
  );
}

app.disable('x-powered-by');

app.use(
  express.json({
    limit: '256kb'
  })
);

app.use(
  express.static(publicDirectory)
);

// ============================================================
// FUNCIONES COMPARTIDAS
// ============================================================

function unavailable(moduleName) {
  return (req, res) => {
    res.status(503).json({
      error:
        `Las escrituras de ${moduleName} están pendientes ` +
        'de integración con la base de datos y sus ' +
        'movimientos relacionados.',

      code: 'MODULO_PENDIENTE_INTEGRACION'
    });
  };
}

function handleRead(work) {
  return async (req, res, next) => {
    try {
      await work(req, res, next);
    } catch (error) {
      next(error);
    }
  };
}

// ============================================================
// AUTENTICACIÓN
// ============================================================

app.use(
  '/api/auth',
  require('./routes/auth.routes')
);

// ============================================================
// USUARIOS
// ============================================================

app.use(
  [
    '/api/users',
    '/api/auth/users'
  ],
  require('./routes/users.routes')
);

// ============================================================
// PUNTO DE VENTA
// ============================================================

app.use(
  '/api/pos',
  require('./routes/pos.routes')
);

// ============================================================
// RECARGAS
// Todos los alias utilizan el mismo servicio.
// ============================================================

const recargasRoutes = require(
  './routes/recargas.routes'
);

app.use(
  '/api/recargas',
  recargasRoutes
);

app.use(
  '/api/topups',
  recargasRoutes
);

app.use(
  '/api/finance/recargas',
  recargasRoutes
);

// ============================================================
// FINANZAS Y CONTROL DE CAJA
// ============================================================

app.use(
  '/api/finance',
  require('./routes/finance.routes')
);

// ============================================================
// INVENTARIO
// ============================================================

app.use(
  '/api/inventory',
  require('./routes/inventory.routes')
);

// ============================================================
// OPERACIÓN GENERAL
// ============================================================

app.use(
  '/api/operations',
  require('./routes/operations.routes')
);

// ============================================================
// MARKETING
// ============================================================

app.use(
  '/api/marketing',
  require('./routes/marketing.routes')
);

// ============================================================
// REPORTES
// ============================================================

app.use(
  '/api/reports',
  require('./routes/reports.routes')
);

// ============================================================
// DASHBOARD
// ============================================================

app.use(
  '/api/dashboard',
  require('./routes/dashboard.routes')
);

// ============================================================
// PRODUCCIÓN E IMPRESIONES
// ============================================================

const printingRoutes = require(
  './routes/printing.routes'
);

const printingPaymentsRoutes = require(
  './routes/print-payments.routes'
);

// Las rutas de pago se registran antes de las rutas generales.
app.use(
    '/api/business',
    require('./routes/business.routes')
);

app.use(
  '/api/printing-services',
  printingPaymentsRoutes
);

app.use(
  '/api/services/printing',
  printingPaymentsRoutes
);

app.use(
  '/api/printing-services',
  printingRoutes
);

app.use(
  '/api/services/printing',
  printingRoutes
);

// ============================================================
// SEGURIDAD DIGITAL
// ============================================================

app.use(
  '/api/security',
  require('./routes/security.routes')
);

// ============================================================
// CONTABILIDAD
// ============================================================

app.use(
  '/api/accounting',
  require('./routes/accounting.routes')
);

// ============================================================
// CONSULTA DE REGISTROS ANTERIORES
//
// Se conservan las lecturas para consultar el historial.
// Las operaciones nuevas utilizan los módulos integrados.
// ============================================================

const legacyTables = Object.freeze({
  ordenes: {
    table: 'ordenes',
    key: 'id'
  },

  proveedores: {
    table: 'proveedores',
    key: 'id'
  },

  compras: {
    table: 'compras',
    key: 'id'
  },

  empleados: {
    table: 'empleados',
    key: 'id'
  },

  liquidaciones: {
    table: 'liquidaciones',
    key: 'id'
  },

  permisos: {
    table: 'permisos',
    key: 'id'
  },

  nomina: {
    table: 'nomina',
    key: 'id'
  },

  facturas: {
    table: 'facturas',
    key: 'id'
  },

  caja: {
    table: 'caja',
    key: 'id'
  },

  mercadotecnia: {
    table: 'mercadotecnia',
    key: 'id'
  },

  produccion: {
    table: 'ordenes_produccion',
    key: 'id_orden'
  }
});

app.get(
  '/api/:legacy',

  requireAuth,

  requireRole('admin', 'auditor'),

  handleRead(async (req, res, next) => {
    const config = legacyTables[req.params.legacy];

    if (!config) {
      return next();
    }

    const result = await pool.query(
      `
      SELECT *
      FROM public.${config.table}

      ORDER BY ${config.key} DESC

      LIMIT 200
      `
    );

    res.json(result.rows);
  })
);

app.all(
  '/api/:legacy',

  requireAuth,

  requireRole('admin'),

  (req, res, next) => {
    const config = legacyTables[req.params.legacy];

    if (!config) {
      return next();
    }

    return unavailable(
      req.params.legacy
    )(req, res);
  }
);

// ============================================================
// API NO ENCONTRADA
// ============================================================

app.use(
  '/api',
  (req, res) => {
    res.status(404).json({
      error: 'La ruta solicitada no existe.',

      code: 'API_NO_ENCONTRADA'
    });
  }
);

// ============================================================
// PÁGINA NO ENCONTRADA
// ============================================================

app.use((req, res) => {
  res
    .status(404)
    .type('text/plain')
    .send(
      'Página o archivo no encontrado.'
    );
});

// ============================================================
// MANEJO CENTRAL DE ERRORES
// ============================================================

app.use((error, req, res, next) => {
  if (res.headersSent) {
    return next(error);
  }

  if (error instanceof multer.MulterError) {
    return res
      .status(
        error.code === 'LIMIT_FILE_SIZE'
          ? 413
          : 400
      )
      .json({
        error:
          'No se pudo recibir el archivo adjunto.',

        code: error.code
      });
  }

  if (error.type === 'entity.parse.failed') {
    return res.status(400).json({
      error:
        'El cuerpo contiene JSON inválido.',

      code: 'JSON_INVALIDO'
    });
  }

  if (error.type === 'entity.too.large') {
    return res.status(413).json({
      error:
        'La solicitud supera el tamaño permitido.',

      code: 'SOLICITUD_DEMASIADO_GRANDE'
    });
  }

  console.error(
    '[Servidor]',
    error.code || error.name || 'ERROR'
  );

  return res.status(500).json({
    error:
      'Ocurrió un error interno. ' +
      'Revisa la terminal del servidor.',

    code: 'ERROR_INTERNO'
  });
});

// ============================================================
// INICIAR SERVIDOR
// ============================================================

async function start() {
  await pool.query(
    `
    SELECT 1
    FROM public.users
    LIMIT 1
    `
  );

  app.listen(
    PORT,
    () => {
      console.log(
        `Servidor iniciado en http://localhost:${PORT}`
      );
    }
  );
}

start().catch(error => {
  console.error(
    'No se pudo iniciar el servidor:',
    error.message || error.code || error.name
  );

  process.exitCode = 1;

  pool.end().catch(() => {});
});

module.exports = app;