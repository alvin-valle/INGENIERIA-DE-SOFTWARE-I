const express = require('express');
const pool = require('../db/connection');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const router = express.Router();

// requireRole permite también superadmin,
// según el middleware de autenticación existente.
router.use(requireAuth, requireRole('admin', 'auditor'));

router.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

const round2 = value =>
  Math.round((Number(value) + Number.EPSILON) * 100) / 100;

const sum = values =>
  values.reduce((total, value) => total + Number(value), 0);

const TABLES = [
  ['users', 'Usuarios'],
  ['products', 'Productos'],
  ['categories', 'Categorías'],
  ['suppliers', 'Proveedores'],
  ['kardex_movements', 'Movimientos de Kardex'],
  ['cash_shifts', 'Turnos de caja'],
  ['sales', 'Ventas'],
  ['sale_items', 'Detalle de ventas'],
  ['print_jobs', 'Trabajos de impresión'],
  ['production_rates', 'Tarifas de producción'],
  ['cash_expenses', 'Gastos de caja'],
  ['audit_log', 'Auditoría'],
  ['secure_deletions', 'Historial de eliminaciones']
];

// Las columnas TIMESTAMP se consultan según el calendario almacenado.
// No se convierten retroactivamente a otra zona horaria.
async function buildDashboard() {
  const client = await pool.connect();

  try {
    // Todas las consultas observan la misma instantánea de los datos.
    // Esta transacción únicamente permite lecturas.
    await client.query(
      'BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY'
    );

    const query = async (sql, params = []) => {
      const result = await client.query(sql, params);
      return result.rows;
    };

    const [{ today }] = await query(`
      SELECT TO_CHAR(
        CURRENT_TIMESTAMP AT TIME ZONE 'America/Managua',
        'YYYY-MM-DD'
      ) AS today
    `);

    const params = [today];

    // ================================================================
    // 1. VENTAS POS DEL DÍA
    // ================================================================

    const [salesStats] = await query(`
      SELECT
        COALESCE(
          SUM(total) FILTER (WHERE date >= $1::date),
          0
        )::float8 AS today_total,
        COUNT(*) FILTER (
          WHERE date >= $1::date
        )::int AS today_count
      FROM sales
      WHERE date >= $1::date - INTERVAL '29 days'
        AND date < $1::date + INTERVAL '1 day'
    `, params);

    // ================================================================
    // 2. MOVIMIENTOS DIARIOS: ÚLTIMOS SIETE DÍAS
    // Incluye también los días sin movimientos.
    // ================================================================

    const daily = await query(`
      SELECT
        TO_CHAR(d.day, 'YYYY-MM-DD') AS date,
        COALESCE(s.total, 0)::float8 AS total,
        COALESCE(e.total, 0)::float8 AS expense,
        COALESCE(p.count, 0)::int AS jobs
      FROM generate_series(
        $1::date - INTERVAL '6 days',
        $1::date,
        INTERVAL '1 day'
      ) d(day)
      LEFT JOIN (
        SELECT
          date::date AS day,
          SUM(total) AS total
        FROM sales
        WHERE date >= $1::date - INTERVAL '6 days'
          AND date < $1::date + INTERVAL '1 day'
        GROUP BY date::date
      ) s ON s.day = d.day::date
      LEFT JOIN (
        SELECT
          ce.created_at::date AS day,
          SUM(ce.amount) AS total
        FROM cash_expenses ce
        WHERE ce.created_at >= $1::date - INTERVAL '6 days'
          AND ce.created_at < $1::date + INTERVAL '1 day'
        GROUP BY ce.created_at::date
      ) e ON e.day = d.day::date
      LEFT JOIN (
        SELECT
          created_at::date AS day,
          COUNT(*) AS count
        FROM print_jobs
        WHERE created_at >= $1::date - INTERVAL '6 days'
          AND created_at < $1::date + INTERVAL '1 day'
        GROUP BY created_at::date
      ) p ON p.day = d.day::date
      ORDER BY d.day
    `, params);

    // ================================================================
    // 3. INVENTARIO Y EXISTENCIAS BAJAS
    // ================================================================

    const [inventory] = await query(`
      SELECT
        COALESCE(SUM(stock * avg_cost), 0)::float8 AS cost,
        COALESCE(SUM(stock * price), 0)::float8 AS sale,
        COUNT(*) FILTER (
          WHERE stock <= min_stock
        )::int AS low_count
      FROM products
      WHERE active IS TRUE
    `);

    const lowStock = await query(`
      SELECT
        id,
        sku,
        name,
        stock,
        min_stock,
        unit
      FROM products
      WHERE active IS TRUE
        AND stock <= min_stock
      ORDER BY stock - min_stock, id
      LIMIT 10
    `);

    // ================================================================
    // 4. TURNOS DE CAJA ABIERTOS
    // NULL significa que el fondo inicial no fue registrado.
    // ================================================================

    const openShifts = await query(`
      SELECT
        cs.id,
        cs.cashier_id,
        COALESCE(
          u.full_name,
          'Usuario sin registro'
        ) AS cashier_name,
        TO_CHAR(
          cs.created_at,
          'YYYY-MM-DD"T"HH24:MI:SS'
        ) AS opened_at,
        cs.opening_amount::float8 AS opening_amount
      FROM cash_shifts cs
      LEFT JOIN users u ON u.id = cs.cashier_id
      WHERE cs.status = 'abierto'
      ORDER BY cs.created_at DESC
    `);

    // ================================================================
    // 5. MOVIMIENTOS DE KARDEX
    // ================================================================

    const movements = await query(`
      SELECT
        type,
        COUNT(*)::int AS count,
        COALESCE(SUM(qty), 0)::float8 AS qty
      FROM kardex_movements
      WHERE date >= $1::date - INTERVAL '6 days'
        AND date < $1::date + INTERVAL '1 day'
      GROUP BY type
    `, params);

    // ================================================================
    // 6. ÓRDENES POR TIPO DE SERVICIO
    // Las cotizaciones no se suman a los ingresos cobrados.
    // ================================================================

    const serviceTypes = await query(`
      SELECT
        COALESCE(
          production_details->>'service',
          print_type,
          'Sin especificar'
        ) AS label,
        COUNT(*)::int AS count,
        COALESCE(SUM(copies), 0)::float8 AS qty
      FROM print_jobs
      WHERE created_at >= $1::date - INTERVAL '6 days'
        AND created_at < $1::date + INTERVAL '1 day'
      GROUP BY COALESCE(
        production_details->>'service',
        print_type,
        'Sin especificar'
      )
      ORDER BY count DESC
    `, params);

    // ================================================================
    // 7. VENTAS Y COSTOS POR CATEGORÍA
    // Utiliza el costo registrado al realizar cada venta.
    // ================================================================

    const categories = await query(`
      SELECT
        COALESCE(c.name, 'Sin categoría') AS category,
        COALESCE(SUM(si.subtotal), 0)::float8 AS revenue,
        COALESCE(
          SUM(si.qty * si.unit_cost),
          0
        )::float8 AS cost,
        COALESCE(
          SUM(si.subtotal) FILTER (
            WHERE sa.date >= $1::date - INTERVAL '6 days'
          ),
          0
        )::float8 AS revenue7
      FROM sale_items si
      JOIN sales sa ON sa.id = si.sale_id
      LEFT JOIN products p ON p.id = si.product_id
      LEFT JOIN categories c ON c.id = p.category_id
      WHERE sa.date >= $1::date - INTERVAL '29 days'
        AND sa.date < $1::date + INTERVAL '1 day'
      GROUP BY c.name
      ORDER BY revenue DESC
    `, params);

    // ================================================================
    // 8. CINCO PRODUCTOS MÁS VENDIDOS EN TREINTA DÍAS
    // ================================================================

    const topProducts = await query(`
      SELECT
        COALESCE(
          p.name,
          'Producto sin catálogo'
        ) AS name,
        p.sku,
        SUM(si.qty)::float8 AS qty,
        SUM(si.subtotal)::float8 AS total
      FROM sale_items si
      JOIN sales sa ON sa.id = si.sale_id
      LEFT JOIN products p ON p.id = si.product_id
      WHERE sa.date >= $1::date - INTERVAL '29 days'
        AND sa.date < $1::date + INTERVAL '1 day'
      GROUP BY si.product_id, p.name, p.sku
      ORDER BY qty DESC, total DESC
      LIMIT 5
    `, params);

    // ================================================================
    // 9. TRANSACCIONES POS POR HORA EN CATORCE DÍAS
    // Hoy y los trece días anteriores.
    // ================================================================

    const hourlyRaw = await query(`
      SELECT
        EXTRACT(HOUR FROM date)::int AS hour,
        COUNT(*)::int AS count
      FROM sales
      WHERE date >= $1::date - INTERVAL '13 days'
        AND date < $1::date + INTERVAL '1 day'
      GROUP BY EXTRACT(HOUR FROM date)
      ORDER BY hour
    `, params);

    // ================================================================
    // 10. INFORMACIÓN DE LA BASE DE DATOS
    // ================================================================

    const tableCounts = [];

    for (const [table, label] of TABLES) {
      // El nombre de tabla procede exclusivamente de la lista constante.
      const [{ count }] = await query(`
        SELECT COUNT(*)::float8 AS count
        FROM "${table}"
      `);

      tableCounts.push({ table, label, count });
    }

    const [database] = await query(`
      SELECT
        pg_database_size(
          current_database()
        )::float8 AS bytes,
        (
          SELECT TO_CHAR(
            MAX(created_at),
            'YYYY-MM-DD"T"HH24:MI:SS'
          )
          FROM audit_log
        ) AS last_activity
    `);

    await client.query('COMMIT');

    // ================================================================
    // 11. PREPARACIÓN DE DATOS PARA EL FRONTEND
    // ================================================================

    const current = daily.slice(-7);
    const last = daily[daily.length - 1];

    const revenue30 = round2(
      sum(categories.map(row => row.revenue))
    );

    const cost30 = round2(
      sum(categories.map(row => row.cost))
    );

    const margin30 = round2(revenue30 - cost30);

    const categoryBreakdown = categories
      .filter(row => row.revenue7 > 0)
      .map(row => ({
        label: row.category,
        total: round2(row.revenue7)
      }));

    const hourlyDemand = Array.from(
      { length: 24 },
      (_, hour) => ({
        hour: String(hour).padStart(2, '0') + ':00',
        count: hourlyRaw.find(
          row => row.hour === hour
        )?.count || 0
      })
    );

    const movement = type =>
      movements.find(row => row.type === type) || {
        count: 0,
        qty: 0
      };

    const dailyRevenueSeries = current.map(row => ({
      date: row.date,
      total: round2(row.total)
    }));

    // Identifica qué información está integrada actualmente.
    // Los valores no disponibles se representan con null.
    const availability = {
      printingRevenue: false,
      recargas: false,
      printerCounters: false,
      incomeScope:
        'Ventas POS registradas; excluye cobros de impresión y recargas.',
      cashScope:
        'Gastos y turnos registrados; los fondos iniciales no registrados se muestran como no disponibles.'
    };

    const summary = {
      source: 'postgresql',
      today,
      availability,

      ingresosHoy: round2(salesStats.today_total),

      ventasHoy: {
        total: round2(salesStats.today_total),
        count: salesStats.today_count
      },

      impresionesHoy: {
        total: null,
        count: last.jobs
      },

      recargasHoy: {
        total: null,
        count: null
      },

      gastosHoy: round2(last.expense),
      lowStock,
      lowStockCount: inventory.low_count,
      openShifts,
      dailyRevenueSeries,
      categoryBreakdown,
      hourlyDemand,
      topProducts,
      discrepanciesCount: null,
      inventoryValue: round2(inventory.cost)
    };

    const materias = {
      produccion: {
        serviciosHoy: last.jobs,
        valorServiciosHoy: null,

        serviceTypeBreakdown: serviceTypes.map(row => ({
          ...row,
          type: row.label,
          total: null
        })),

        kardexEntradas7d: movement('entrada'),
        kardexSalidas7d: movement('salida'),

        dailyProductionSeries: current.map(row => ({
          date: row.date,
          count: row.jobs
        })),

        discrepanciesCount7d: null
      },

      finanzas: {
        ingresosHoy: summary.ingresosHoy,
        gastosHoy: summary.gastosHoy,

        // Diferencia entre ventas POS y gastos registrados.
        // No representa el saldo físico de caja ni la utilidad neta.
        flujoNetoHoy: round2(
          summary.ingresosHoy - summary.gastosHoy
        ),

        openShifts,
        openShiftsCount: openShifts.length,

        incomeVsExpense7d: current.map(row => ({
          date: row.date,
          ingresos: round2(row.total),
          gastos: round2(row.expense)
        }))
      },

      contabilidad: {
        inventoryValueCost: round2(inventory.cost),
        inventoryValueSale: round2(inventory.sale),
        cogs30d: cost30,
        revenue30d: revenue30,
        utilidadBruta30d: margin30,

        margenPct30d: revenue30 > 0
          ? round2(margin30 / revenue30 * 100)
          : 0,

        marginByCategory: categories.map(row => ({
          category: row.category,
          revenue: round2(row.revenue),
          cost: round2(row.cost),
          margin: round2(row.revenue - row.cost)
        }))
      },

      basesDeDatos: {
        tableCounts,

        totalRecords: sum(
          tableCounts.map(row => row.count)
        ),

        biggestTable: tableCounts.reduce(
          (a, b) => a.count >= b.count ? a : b
        ),

        dbSizeBytes: database.bytes,
        dbSizeMb: round2(database.bytes / 1048576),
        lastActivity: database.last_activity
      },

      mercadotecnia: {
        categoryBreakdown,
        topProducts,
        telcoBreakdown7d: [],
        hourlyDemand
      }
    };

    return { summary, materias };
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

// ====================================================================
// ENDPOINTS
// GET /api/dashboard/overview
// GET /api/dashboard/summary
// GET /api/dashboard/materias
// ====================================================================

for (const endpoint of ['overview', 'summary', 'materias']) {
  router.get('/' + endpoint, async (req, res) => {
    try {
      const result = await buildDashboard();

      res.json(
        endpoint === 'overview'
          ? result
          : result[endpoint]
      );
    } catch (error) {
      console.error('[Dashboard]', error);

      res.status(500).json({
        error:
          'No se pudo consultar el Dashboard. ' +
          'Revisa el detalle en la terminal del servidor.'
      });
    }
  });
}

module.exports = router;