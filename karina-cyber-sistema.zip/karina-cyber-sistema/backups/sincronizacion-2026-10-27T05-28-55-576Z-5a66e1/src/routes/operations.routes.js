'use strict';

const express = require('express');

const pool = require('../db/connection');

const cash = require('../services/cash.service');

const {
  requireAuth,
  requireRole
} = require('../middleware/auth');

const {
  handle,
  text,
  fail,
  audit,
  transaction
} = require('../utils/enterprise');

const {
  recordEntrada
} = require('../utils/kardex');

const {
  summarizeShift
} = require('./finance.routes');

const router = express.Router();

router.use(
  requireAuth,
  requireRole('admin', 'auditor')
);

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

const admin = requireRole('admin');

// ============================================================
// PROVEEDORES
// ============================================================

router.get(
  '/suppliers',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        p.*,

        COALESCE(
          (
            SELECT SUM(amount)
            FROM public.kc_purchases
            WHERE supplier_id = p.id
          ),
          0
        )::text AS total_paid

      FROM public.proveedores p

      ORDER BY p.nombre
      `
    );

    res.json(result.rows);
  })
);

function supplierInput(body) {
  const email = text(
    body.email,
    'Correo',
    150,
    false
  );

  if (
    email &&
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  ) {
    fail('Correo inválido.');
  }

  if (
    !['Activo', 'Inactivo'].includes(body.estado)
  ) {
    fail('Estado inválido.');
  }

  return [
    text(body.nombre, 'Proveedor'),

    text(
      body.ruc,
      'RUC',
      40,
      false
    ),

    text(
      body.tel,
      'Teléfono',
      40,
      false
    ),

    email,

    text(
      body.categoria,
      'Categoría',
      120,
      false
    ),

    text(
      body.service_type,
      'Servicio',
      150
    ),

    cash.paymentMethod(
      body.metodo_pago_pref
    ),

    body.estado
  ];
}

router.post(
  '/suppliers',
  admin,
  handle(async (req, res) => {
    const values = supplierInput(req.body);

    const row = await transaction(
      req.user.id,
      async db => {
        const result = await db.query(
          `
          INSERT INTO public.proveedores (
            nombre,
            ruc,
            tel,
            email,
            categoria,
            service_type,
            metodo_pago_pref,
            estado
          )
          VALUES (
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            $7,
            $8
          )
          RETURNING *
          `,
          values
        );

        const supplier = result.rows[0];

        await audit(
          db,
          req.user.id,
          'CREATE',
          'proveedores',
          {
            id: supplier.id
          }
        );

        return supplier;
      }
    );

    res.status(201).json(row);
  })
);

router.patch(
  '/suppliers/:id',
  admin,
  handle(async (req, res) => {
    const id = cash.positiveId(req.params.id);

    const values = supplierInput(req.body);

    const row = await transaction(
      req.user.id,
      async db => {
        const result = await db.query(
          `
          UPDATE public.proveedores

          SET
            nombre = $1,
            ruc = $2,
            tel = $3,
            email = $4,
            categoria = $5,
            service_type = $6,
            metodo_pago_pref = $7,
            estado = $8

          WHERE id = $9

          RETURNING *
          `,
          [
            ...values,
            id
          ]
        );

        if (!result.rows.length) {
          fail(
            'Proveedor no encontrado.',
            404
          );
        }

        await audit(
          db,
          req.user.id,
          'UPDATE',
          'proveedores',
          { id }
        );

        return result.rows[0];
      }
    );

    res.json(row);
  })
);

router.delete(
  '/suppliers/:id',
  admin,
  handle(async (req, res) => {
    const id = cash.positiveId(req.params.id);

    await transaction(
      req.user.id,
      async db => {
        const result = await db.query(
          `
          UPDATE public.proveedores
          SET estado = 'Inactivo'
          WHERE id = $1
          RETURNING id
          `,
          [id]
        );

        if (!result.rows.length) {
          fail(
            'Proveedor no encontrado.',
            404
          );
        }

        await audit(
          db,
          req.user.id,
          'DEACTIVATE',
          'proveedores',
          { id }
        );
      }
    );

    res.json({
      ok: true
    });
  })
);

// ============================================================
// EMPLEADOS
// ============================================================

router.get(
  '/employees',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT *
      FROM public.kc_employees
      ORDER BY full_name
      `
    );

    res.json(result.rows);
  })
);

function employeeInput(body) {
  if (typeof body.active !== 'boolean') {
    fail('Estado inválido.');
  }

  return [
    text(
      body.full_name,
      'Nombre'
    ),

    text(
      body.position,
      'Cargo',
      100
    ),

    cash.money(
      body.salary,
      {
        allowZero: true
      }
    ),

    body.active
  ];
}

router.post(
  '/employees',
  admin,
  handle(async (req, res) => {
    const values = employeeInput(req.body);

    const row = await transaction(
      req.user.id,
      async db => {
        const result = await db.query(
          `
          INSERT INTO public.kc_employees (
            full_name,
            position,
            salary,
            active
          )
          VALUES ($1, $2, $3, $4)
          RETURNING *
          `,
          values
        );

        const employee = result.rows[0];

        await audit(
          db,
          req.user.id,
          'CREATE',
          'kc_employees',
          {
            id: employee.id
          }
        );

        return employee;
      }
    );

    res.status(201).json(row);
  })
);

router.patch(
  '/employees/:id',
  admin,
  handle(async (req, res) => {
    const id = cash.positiveId(req.params.id);

    const values = employeeInput(req.body);

    const row = await transaction(
      req.user.id,
      async db => {
        const result = await db.query(
          `
          UPDATE public.kc_employees

          SET
            full_name = $1,
            position = $2,
            salary = $3,
            active = $4

          WHERE id = $5

          RETURNING *
          `,
          [
            ...values,
            id
          ]
        );

        if (!result.rows.length) {
          fail(
            'Empleado no encontrado.',
            404
          );
        }

        await audit(
          db,
          req.user.id,
          'UPDATE',
          'kc_employees',
          { id }
        );

        return result.rows[0];
      }
    );

    res.json(row);
  })
);

router.delete(
  '/employees/:id',
  admin,
  handle(async (req, res) => {
    const id = cash.positiveId(req.params.id);

    await transaction(
      req.user.id,
      async db => {
        const result = await db.query(
          `
          UPDATE public.kc_employees
          SET active = FALSE
          WHERE id = $1
          RETURNING id
          `,
          [id]
        );

        if (!result.rows.length) {
          fail(
            'Empleado no encontrado.',
            404
          );
        }

        await audit(
          db,
          req.user.id,
          'DEACTIVATE',
          'kc_employees',
          { id }
        );
      }
    );

    res.json({
      ok: true
    });
  })
);

// ============================================================
// HISTORIAL DE COMPRAS Y PAGOS
// ============================================================

router.get(
  '/purchases',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        p.*,
        s.nombre AS supplier_name,
        e.payment_reference,
        e.shift_id,
        e.date AS paid_at

      FROM public.kc_purchases p

      INNER JOIN public.proveedores s
        ON s.id = p.supplier_id

      INNER JOIN public.cash_expenses e
        ON e.id = p.expense_id

      ORDER BY p.id DESC

      LIMIT 500
      `
    );

    res.json(result.rows);
  })
);

router.get(
  '/payroll',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        p.*,
        e.full_name AS employee_name,
        c.payment_reference,
        c.shift_id

      FROM public.kc_payroll_payments p

      INNER JOIN public.kc_employees e
        ON e.id = p.employee_id

      INNER JOIN public.cash_expenses c
        ON c.id = p.expense_id

      ORDER BY p.id DESC

      LIMIT 500
      `
    );

    res.json(result.rows);
  })
);

// ============================================================
// REGISTRO TRANSACCIONAL DE COMPRAS Y NÓMINA
//
// Un único gasto enlaza:
// documento + caja chica + Control de caja.
//
// Las compras de productos también actualizan Kardex.
// ============================================================

async function postPayment(req, kind) {
  const body = req.body;

  const method = cash.paymentMethod(
    body.payment_method
  );

  const reference = cash.paymentReference(
    body.payment_reference,
    method
  );

  const description = text(
    body.description,
    'Concepto',
    255
  );

  const key = cash.requestKey(
    body.request_key
  );

  const shiftId = cash.positiveId(
    body.shift_id,
    'Turno'
  );

  let payload = {
    kind,
    shift_id: shiftId,
    description,
    payment_method: method,
    payment_reference: reference
  };

  if (kind === 'purchase') {
    const items = body.items ?? [];

    if (
      !Array.isArray(items) ||
      items.length > 100
    ) {
      fail(
        'La compra admite hasta 100 productos.'
      );
    }

    const normalized = items
      .map(item => ({
        product_id: cash.positiveId(
          item.product_id
        ),

        qty: cash.positiveId(
          item.qty,
          'Cantidad'
        ),

        unit_cost: cash.money(
          item.unit_cost
        )
      }))
      .sort(
        (first, second) =>
          first.product_id - second.product_id
      );

    const uniqueProducts = new Set(
      normalized.map(item => item.product_id)
    );

    if (
      uniqueProducts.size !== normalized.length
    ) {
      fail('No repitas productos.');
    }

    if (
      normalized.some(item => item.qty > 1000000)
    ) {
      fail('Cantidad fuera del límite.');
    }

    const amount = normalized.length
      ? cash.fromCents(
          normalized.reduce(
            (sum, item) =>
              sum +
              BigInt(item.qty) *
              cash.toCents(item.unit_cost),
            0n
          )
        )
      : cash.money(body.amount);

    payload = {
      ...payload,

      supplier_id: cash.positiveId(
        body.supplier_id
      ),

      invoice_number: text(
        body.invoice_number,
        'Comprobante',
        80,
        false
      ),

      items: normalized,

      amount: cash.money(amount)
    };
  } else {
    if (
      typeof body.period !== 'string' ||
      !/^\d{4}-(0[1-9]|1[0-2])$/.test(body.period)
    ) {
      fail(
        'Período inválido: AAAA-MM.'
      );
    }

    payload = {
      ...payload,

      employee_id: cash.positiveId(
        body.employee_id
      ),

      period: body.period,

      amount: cash.money(body.amount)
    };
  }

  return cash.withCashTransaction(
    req.user.id,
    async context => {
      if (
        !['admin', 'superadmin'].includes(
          context.user.role
        )
      ) {
        fail(
          'Sin permiso para compras o nómina.',
          403
        );
      }

      const request = await cash.prepareRequest(
        context,
        {
          scope: 'expense',
          key,
          payload
        }
      );

      const table = kind === 'purchase'
        ? 'kc_purchases'
        : 'kc_payroll_payments';

      // La clave identifica la misma operación en un reintento.

      if (request.replayed) {
        const previous = await context.db.query(
          `
          SELECT *
          FROM public.${table}
          WHERE expense_id = $1
          `,
          [request.record.id]
        );

        if (!previous.rows.length) {
          fail(
            'La clave corresponde a otra operación.',
            409
          );
        }

        return {
          record: previous.rows[0],
          replayed: true
        };
      }

      const shift = await cash.lockOpenShift(
        context,
        shiftId
      );

      const summary = await summarizeShift(
        context.db,
        shift
      );

      if (!summary.reconciled) {
        fail(
          'El turno requiere conciliación ' +
          'en Control de caja.',
          409
        );
      }

      if (method === 'efectivo') {
        const negativeCash =
          summary.expectedCash.startsWith('-');

        const insufficientCash =
          !negativeCash &&
          cash.toCents(payload.amount) >
          cash.toCents(
            summary.expectedCash,
            {
              allowZero: true
            }
          );

        if (negativeCash || insufficientCash) {
          fail(
            'Efectivo insuficiente para este pago.',
            409
          );
        }
      }

      // Validar y bloquear los documentos relacionados.

      if (kind === 'purchase') {
        const supplierResult =
          await context.db.query(
            `
            SELECT estado
            FROM public.proveedores
            WHERE id = $1
            FOR SHARE
            `,
            [payload.supplier_id]
          );

        const supplier = supplierResult.rows[0];

        if (
          !supplier ||
          supplier.estado !== 'Activo'
        ) {
          fail(
            'Selecciona un proveedor activo.'
          );
        }

        for (const item of payload.items) {
          const productResult =
            await context.db.query(
              `
              SELECT active
              FROM public.products
              WHERE id = $1
              FOR UPDATE
              `,
              [item.product_id]
            );

          if (!productResult.rows[0]?.active) {
            fail(
              'La compra contiene un producto ' +
              'inexistente o inactivo.'
            );
          }
        }
      } else {
        const employeeResult =
          await context.db.query(
            `
            SELECT *
            FROM public.kc_employees
            WHERE id = $1
            FOR UPDATE
            `,
            [payload.employee_id]
          );

        if (!employeeResult.rows[0]?.active) {
          fail(
            'Selecciona un empleado activo.'
          );
        }
      }

      // Crear el gasto que utilizará caja.

      const expenseResult =
        await context.db.query(
          `
          INSERT INTO public.cash_expenses (
            shift_id,
            user_id,
            description,
            category,
            amount,
            payment_method,
            payment_reference,
            request_key,
            request_hash
          )
          VALUES (
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            $7,
            $8,
            $9
          )
          RETURNING id
          `,
          [
            shift.id,
            context.user.id,
            description,

            kind === 'purchase'
              ? 'compras'
              : 'nomina',

            payload.amount,
            method,
            reference,
            request.key,
            request.hash
          ]
        );

      const expense = expenseResult.rows[0];

      let record;

      if (kind === 'purchase') {
        const purchaseResult =
          await context.db.query(
            `
            INSERT INTO public.kc_purchases (
              supplier_id,
              description,
              invoice_number,
              amount,
              payment_method,
              expense_id,
              created_by
            )
            VALUES (
              $1,
              $2,
              $3,
              $4,
              $5,
              $6,
              $7
            )
            RETURNING *
            `,
            [
              payload.supplier_id,
              description,
              payload.invoice_number,
              payload.amount,
              method,
              expense.id,
              context.user.id
            ]
          );

        record = purchaseResult.rows[0];

        for (const item of payload.items) {
          await context.db.query(
            `
            INSERT INTO public.kc_purchase_items (
              purchase_id,
              product_id,
              qty,
              unit_cost
            )
            VALUES ($1, $2, $3, $4)
            `,
            [
              record.id,
              item.product_id,
              item.qty,
              item.unit_cost
            ]
          );

          await recordEntrada(
            context.db,
            {
              productId: item.product_id,
              qty: item.qty,
              unitCost: item.unit_cost,
              userId: context.user.id,
              reference: `Compra #${record.id}`
            }
          );
        }
      } else {
        const payrollResult =
          await context.db.query(
            `
            INSERT INTO public.kc_payroll_payments (
              employee_id,
              period,
              description,
              amount,
              payment_method,
              expense_id,
              created_by
            )
            VALUES (
              $1,
              $2,
              $3,
              $4,
              $5,
              $6,
              $7
            )
            RETURNING *
            `,
            [
              payload.employee_id,
              payload.period,
              description,
              payload.amount,
              method,
              expense.id,
              context.user.id
            ]
          );

        record = payrollResult.rows[0];
      }

      // Registrar el movimiento desde el documento guardado.

      await cash.recordMovement(
        context,
        {
          sourceId: expense.id
        }
      );

      await audit(
        context.db,
        context.user.id,
        'PAYMENT',
        table,
        {
          id: record.id,
          expense_id: expense.id,
          request_key: request.key
        }
      );

      return {
        record,
        replayed: false
      };
    }
  );
}

// ============================================================
// REGISTRAR COMPRA
// ============================================================

router.post(
  '/purchases',
  admin,
  handle(async (req, res) => {
    const result = await postPayment(
      req,
      'purchase'
    );

    res
      .status(result.replayed ? 200 : 201)
      .json({
        ok: true,
        ...result
      });
  })
);

// ============================================================
// REGISTRAR PAGO DE EMPLEADO
// ============================================================

router.post(
  '/payroll',
  admin,
  handle(async (req, res) => {
    const result = await postPayment(
      req,
      'payroll'
    );

    res
      .status(result.replayed ? 200 : 201)
      .json({
        ok: true,
        ...result
      });
  })
);

// ============================================================
// LIBRO OPERATIVO DE CAJA
// ============================================================

router.get(
  '/ledger',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        c.*,
        u.full_name AS cashier_name

      FROM public.caja c

      LEFT JOIN public.users u
        ON u.id = c.user_id

      ORDER BY c.id DESC

      LIMIT 500
      `
    );

    res.json(result.rows);
  })
);

// ============================================================
// AUDITORÍA
// ============================================================

router.get(
  '/audit',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        a.id,
        a.date,
        a.action,
        a.entity,
        a.details,
        u.full_name AS actor

      FROM public.audit_log a

      LEFT JOIN public.users u
        ON u.id = a.user_id

      ORDER BY a.id DESC

      LIMIT 200
      `
    );

    res.json(result.rows);
  })
);

// ============================================================
// RESUMEN GENERAL
// ============================================================

router.get(
  '/overview',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        (
          SELECT COUNT(*)
          FROM public.print_jobs
          WHERE status NOT IN (
            'Entregado',
            'Cancelado'
          )
        ) AS production_pending,

        (
          SELECT COUNT(*)
          FROM public.proveedores
          WHERE estado = 'Activo'
        ) AS active_suppliers,

        (
          SELECT COUNT(*)
          FROM public.kc_employees
          WHERE active
        ) AS active_employees,

        (
          SELECT
            COALESCE(
              SUM(stock * avg_cost),
              0
            )::text
          FROM public.products
          WHERE active
        ) AS inventory_value,

        (
          SELECT COUNT(*)
          FROM public.products
          WHERE active
            AND stock <= min_stock
        ) AS low_stock,

        (
          SELECT COUNT(*)
          FROM public.cash_shifts
          WHERE status = 'abierto'
        ) AS open_shifts
      `
    );

    res.json(result.rows[0]);
  })
);

// ============================================================
// CONSULTAR INSUMOS CONFIGURADOS
// ============================================================

router.get(
  '/production-materials',
  handle(async (req, res) => {
    const result = await pool.query(
      `
      SELECT
        m.*,
        r.name AS rate_name,
        p.name AS product_name

      FROM public.kc_print_materials m

      INNER JOIN public.production_rates r
        ON r.id = m.rate_id

      INNER JOIN public.products p
        ON p.id = m.product_id

      ORDER BY
        r.name,
        p.name
      `
    );

    res.json(result.rows);
  })
);

// ============================================================
// CONFIGURAR INSUMO POR TARIFA
// ============================================================

router.post(
  '/production-materials',
  admin,
  handle(async (req, res) => {
    const rateId = cash.positiveId(
      req.body.rate_id
    );

    const productId = cash.positiveId(
      req.body.product_id
    );

    const qty = String(
      req.body.qty_per_order
    );

    if (
      !/^\d{1,6}(?:\.\d{1,6})?$/.test(qty) ||
      Number(qty) <= 0
    ) {
      fail(
        'Cantidad de insumo inválida.'
      );
    }

    await transaction(
      req.user.id,
      async db => {
        await db.query(
          `
          INSERT INTO public.kc_print_materials (
            rate_id,
            product_id,
            qty_per_order
          )
          VALUES ($1, $2, $3)

          ON CONFLICT (
            rate_id,
            product_id
          )

          DO UPDATE
          SET qty_per_order =
            EXCLUDED.qty_per_order
          `,
          [
            rateId,
            productId,
            qty
          ]
        );

        await audit(
          db,
          req.user.id,
          'CONFIGURE',
          'kc_print_materials',
          {
            rateId,
            productId,
            qty
          }
        );
      }
    );

    res.json({
      ok: true
    });
  })
);

// ============================================================
// QUITAR CONFIGURACIÓN DE INSUMO
// ============================================================

router.delete(
  '/production-materials/:rate/:product',
  admin,
  handle(async (req, res) => {
    const rate = cash.positiveId(
      req.params.rate
    );

    const product = cash.positiveId(
      req.params.product
    );

    await transaction(
      req.user.id,
      async db => {
        await db.query(
          `
          DELETE FROM public.kc_print_materials

          WHERE rate_id = $1
            AND product_id = $2
          `,
          [
            rate,
            product
          ]
        );

        await audit(
          db,
          req.user.id,
          'DELETE',
          'kc_print_materials',
          {
            rate,
            product
          }
        );
      }
    );

    res.json({
      ok: true
    });
  })
);

module.exports = router;