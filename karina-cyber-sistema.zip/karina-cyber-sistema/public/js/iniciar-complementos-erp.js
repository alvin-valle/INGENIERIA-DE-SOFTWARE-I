'use strict';

(() => {
    if (window.__complementosERPInstalados) return;

    window.__complementosERPInstalados = true;

    document.body.classList.add('erp-empresarial');

    const estilo = document.createElement('link');

    estilo.rel = 'stylesheet';
    estilo.href = '/css/tema-empresarial.css';

    document.head.append(estilo);

    const documentoListo =
        document.readyState === 'loading'
            ? new Promise(resolver => {
                document.addEventListener(
                    'DOMContentLoaded',
                    resolver,
                    { once: true }
                );
            })
            : Promise.resolve();

    const moduloListo = new Promise(
        (resolver, rechazar) => {
            if (window.ComplementosERP) {
                resolver();
                return;
            }

            const script = document.createElement('script');

            script.src = '/js/complementos-erp.js';
            script.onload = resolver;

            script.onerror = () => {
                rechazar(
                    new Error(
                        'No se pudo cargar complementos-erp.js.'
                    )
                );
            };

            document.body.append(script);
        }
    );

    const preparado = Promise.all([
        documentoListo,
        moduloListo
    ]).then(() => {
        window.ComplementosERP.iniciar();
    });

    preparado.catch(error => {
        if (
            typeof apiErrorToast === 'function'
        ) {
            apiErrorToast(error);
        } else {
            console.error(error.message);
        }
    });

    window.addEventListener(
        'erp:solicitar-recarga',
        evento => {
            const anteriores = [
                ...evento.detail.promesas
            ];

            evento.detail.promesas.push(
                Promise.allSettled(anteriores)
                    .then(() => preparado)
                    .then(() => {
                        return window.ComplementosERP.recargar();
                    })
            );
        }
    );

    window.actualizarERPTrasCambio = async () => {
        if (
            typeof window.sincronizarERP !==
            'function'
        ) {
            await preparado;

            return window.ComplementosERP.recargar();
        }

        // Espera una posible consulta anterior y fuerza
        // una lectura posterior al guardado.
        await window.sincronizarERP();

        return window.sincronizarERP();
    };
})();