function navegar() {
    const raiz = $('page-content');

    if (!raiz) return;

    const esDashboard = !!$('dash-inicio');

    const claveRuta = location.pathname
        .split('/')
        .pop()
        .replace(/\.html$/, '');

    const solicitada = location.hash
        .slice(1)
        .split('/')[0] || 'inicio';

    const clave = esDashboard
        ? (
            $('dash-' + solicitada)
                ? solicitada
                : 'inicio'
        )
        : (
            modulos[claveRuta]
                ? claveRuta
                : 'inicio'
        );

    aplicarTema(document.body, clave);

    if (esDashboard) {
        // Muestra exclusivamente el panel seleccionado.
        for (
            const panel of
            raiz.querySelectorAll('.dash-panel')
        ) {
            const activa = panel.id === 'dash-' + clave;

            panel.hidden = !activa;
            panel.classList.toggle('hidden', !activa);

            panel.setAttribute(
                'aria-hidden',
                String(!activa)
            );
        }

        const inicio = $('dash-inicio');
        const menu = $('main-menu-container');

        if (inicio && menu) {
            // Las tarjetas pertenecen únicamente al inicio.
            // Recupera el menú si la versión anterior lo trasladó.
            if (!inicio.contains(menu)) {
                const referencia = [...inicio.children].find(
                    nodo => [
                        'ce-diagnostico',
                        'biz-notices'
                    ].includes(nodo.id)
                );

                inicio.insertBefore(
                    menu,
                    referencia || null
                );
            }

            const mostrarMenu = clave === 'inicio';

            menu.hidden = !mostrarMenu;

            menu.classList.toggle(
                'hidden',
                !mostrarMenu
            );

            menu.setAttribute(
                'aria-hidden',
                String(!mostrarMenu)
            );

            menu.querySelectorAll('.menu-btn').forEach(
                boton => {
                    const activo =
                        boton.dataset.target === clave;

                    boton.classList.toggle(
                        'erp-modulo-elegido',
                        activo
                    );

                    boton.setAttribute(
                        'aria-pressed',
                        String(activo)
                    );
                }
            );
        }

        // Elimina la barra que mostraba las tarjetas fuera del inicio.
        const barraAnterior = $('erp-navegacion-modulos');

        if (
            barraAnterior &&
            !barraAnterior.contains(menu)
        ) {
            barraAnterior.remove();
        }

        // Conserva la navegación lateral.
        document.querySelectorAll(
            '.sidebar-nav a'
        ).forEach(enlace => {
            const url = new URL(
                enlace.href,
                location.href
            );

            const activo =
                url.pathname === location.pathname &&
                (
                    url.hash.slice(1) || 'inicio'
                ) === clave;

            enlace.classList.toggle(
                'active',
                activo
            );

            if (activo) {
                enlace.setAttribute(
                    'aria-current',
                    'page'
                );
            } else {
                enlace.removeAttribute('aria-current');
            }
        });
    }

    let rutaActual = $('erp-ruta-modulo');

    const titulo = document.querySelector(
        '.page-title'
    );

    if (titulo && !rutaActual) {
        rutaActual = document.createElement('span');
        rutaActual.id = 'erp-ruta-modulo';

        titulo.append(rutaActual);
    }

    if (
        rutaActual &&
        rutaActual.textContent !== modulos[clave][0]
    ) {
        rutaActual.textContent = modulos[clave][0];
    }

    requestAnimationFrame(() => {
        window.redimensionarGraficosERP?.(
            esDashboard
                ? $('dash-' + clave)
                : raiz
        );
    });
}