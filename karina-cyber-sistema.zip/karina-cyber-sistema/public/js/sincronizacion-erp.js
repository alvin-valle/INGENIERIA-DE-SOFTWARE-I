'use strict';

(() => {
    if (window.sincronizarERP) return;

    const paginas = {};

    let pendiente = null;
    let erroresAPI = [];
    let panelesAnteriores = false;
    let facturasReales = [];

    const escapar = valor => String(valor ?? '—').replace(
        /[&<>"']/g,
        caracter => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[caracter])
    );

    const dinero = valor => valor == null
        ? '—'
        : 'C$ ' + Number(valor).toLocaleString('es-NI', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

    const esAdministracion = () => [
        'admin',
        'superadmin',
        'auditor'
    ].includes(Auth.getUser()?.role);

    const columnasImporte = new Set([
        'sal',
        'salario',
        'bruto',
        'tot_ded',
        'neto',
        'mon'
    ]);

    function aviso(texto, esError = false) {
        let elemento = document.getElementById(
            'erp-estado-sincronizacion'
        );

        if (!elemento) {
            elemento = document.createElement('p');

            elemento.id = 'erp-estado-sincronizacion';
            elemento.setAttribute('role', 'status');
            elemento.setAttribute('aria-live', 'polite');

            (
                document.getElementById('page-content') ||
                document.body
            ).prepend(elemento);
        }

        elemento.textContent = texto;

        elemento.className = 'erp-aviso' + (
            esError ? ' erp-aviso-error' : ''
        );
    }

    function pintarFuentes(datos) {
        const destinos = {
            empleados: 'rh-empleados',
            nomina: 'conta-nomina',
            compras: 'conta-compras',
            contratos: 'rh-contratos',
            permisos: 'rh-permisos'
        };

        for (
            const [nombre, destino]
            of Object.entries(destinos)
        ) {
            const contenedor = document.getElementById(destino);
            const fuente = datos.fuentes[nombre];

            if (!contenedor || !fuente) continue;

            let seccion = document.getElementById(
                'erp-fuente-' + nombre
            );

            if (!seccion) {
                seccion = document.createElement('section');
                seccion.id = 'erp-fuente-' + nombre;
                seccion.className = 'erp-fuente power-bi-card';

                contenedor.append(seccion);
            }

            if (fuente.estado === 'sin_tabla') {
                seccion.replaceChildren();

                const mensaje = document.createElement('p');

                mensaje.textContent =
                    'No existe una fuente anterior para esta sección.';

                seccion.append(mensaje);
                continue;
            }

            if (fuente.estado === 'error') {
                let mensaje = seccion.querySelector('[role="alert"]');

                if (!mensaje) {
                    mensaje = document.createElement('p');
                    mensaje.setAttribute('role', 'alert');
                    seccion.prepend(mensaje);
                }

                mensaje.textContent =
                    'No se pudo actualizar esta fuente. ' +
                    fuente.codigo;

                continue;
            }

            const cabecera = fuente.columnas.map(
                ([, titulo]) => '<th>' + escapar(titulo) + '</th>'
            ).join('');

            const filas = fuente.filas.map(fila => {
                return '<tr>' + fuente.columnas.map(([campo]) => {
                    let valor = fila[campo];

                    if (columnasImporte.has(campo)) {
                        valor = dinero(valor);
                    } else if (
                        [
                            'fec',
                            'fecha',
                            'fecha_inicio',
                            'fecha_fin'
                        ].includes(campo) &&
                        valor
                    ) {
                        valor = String(valor).slice(0, 10);
                    }

                    return '<td>' + escapar(valor) + '</td>';
                }).join('') + '</tr>';
            }).join('');

            const desde = fuente.filas.length
                ? (fuente.pagina - 1) * 100 + 1
                : 0;

            const hasta =
                (fuente.pagina - 1) * 100 +
                fuente.filas.length;

            seccion.innerHTML =
                '<h3>' + escapar(fuente.titulo) + '</h3>' +

                '<p>' +
                    'Registros de la fuente anterior. Se conservan ' +
                    'sus identificadores y no se asignan pagos ' +
                    'ni vínculos nuevos.' +
                '</p>' +

                '<div class="erp-tabla">' +
                    '<table>' +
                        '<thead><tr>' + cabecera + '</tr></thead>' +
                        '<tbody>' +
                            (
                                filas ||
                                '<tr><td colspan="' +
                                fuente.columnas.length +
                                '">No hay registros guardados ' +
                                'en esta fuente.</td></tr>'
                            ) +
                        '</tbody>' +
                    '</table>' +
                '</div>' +

                '<div class="erp-paginacion">' +
                    '<button type="button" ' +
                        'data-erp-pagina="anterior">Anterior</button>' +
                    '<span>' +
                        desde + '–' + hasta +
                        ' de ' + escapar(fuente.total) +
                    '</span>' +
                    '<button type="button" ' +
                        'data-erp-pagina="siguiente">Siguiente</button>' +
                '</div>';

            seccion.querySelector(
                '[data-erp-pagina="anterior"]'
            ).disabled = fuente.pagina <= 1;

            seccion.querySelector(
                '[data-erp-pagina="siguiente"]'
            ).disabled = hasta >= Number(fuente.total);

            seccion.querySelectorAll(
                '[data-erp-pagina]'
            ).forEach(boton => {
                boton.onclick = () => {
                    paginas[nombre] = Math.max(
                        1,
                        fuente.pagina + (
                            boton.dataset.erpPagina === 'anterior'
                                ? -1
                                : 1
                        )
                    );

                    sincronizar();
                };
            });
        }
    }

    function protegerDatos(valor) {
        if (typeof valor === 'string') {
            return valor.replace(
                /[&<>"']/g,
                caracter => ({
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#39;'
                }[caracter])
            );
        }

        if (Array.isArray(valor)) {
            return valor.map(protegerDatos);
        }

        if (valor && typeof valor === 'object') {
            return Object.fromEntries(
                Object.entries(valor).map(([clave, dato]) => [
                    clave,
                    protegerDatos(dato)
                ])
            );
        }

        return valor;
    }

    window.datosAnterioresERP = datos => {
        const resultado = {};

        for (
            const [nombre, fuente]
            of Object.entries(datos.fuentes)
        ) {
            if (fuente.estado !== 'correcto') continue;

            let filas = fuente.filas;

            if (nombre === 'nomina') {
                filas = filas.map(fila => ({
                    ...(fila.datos_completos || {}),
                    ...fila,

                    emp: {
                        nom:
                            fila.nombre_empleado ||
                            'Empleado sin vínculo',
                        car: fila.cargo_empleado,
                        fec: fila.ingreso_empleado
                    },

                    inssL: fila.inssl,
                    inssP: fila.inssp
                }));
            }

            if (nombre === 'contratos') {
                filas = filas.map(fila => ({
                    ...fila,
                    ced: 'No registrada en esta fuente'
                }));
            }

            resultado[nombre] = protegerDatos(filas);
        }

        const anteriores =
            datos.fuentes.facturas?.estado === 'correcto'
                ? datos.fuentes.facturas.filas.map(factura => ({
                    ...factura,
                    origen: 'anterior'
                }))
                : [];

        const ventas =
            datos.fuentes.ventas?.estado === 'correcto'
                ? datos.fuentes.ventas.filas.map(venta => ({
                    id: venta.id,
                    cli: 'Cliente no registrado',
                    con: 'Venta registrada en punto de venta',
                    mon: venta.total,
                    fec: String(venta.date || '').slice(0, 10),
                    origen: 'sales'
                }))
                : [];

        facturasReales = [...anteriores, ...ventas];

        resultado.facturas = protegerDatos(facturasReales);

        return resultado;
    };

    window.formatearImporteERP = valor => {
        if (
            valor == null ||
            valor === '' ||
            !Number.isFinite(Number(valor))
        ) {
            return '—';
        }

        return Number(valor).toLocaleString('es-NI', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    };

    window.pintarCajaRealERP = datos => {
        for (const [id, valor] of [
            ['caja-entradas', datos.caja.entradas],
            ['caja-salidas', datos.caja.salidas]
        ]) {
            const elemento = document.getElementById(id);

            if (elemento) {
                elemento.textContent = dinero(valor);
            }
        }

        for (const id of [
            'caja-saldo',
            'bal-caja',
            'bal-act-tot',
            'bal-pasivo'
        ]) {
            const elemento = document.getElementById(id);

            if (elemento) {
                elemento.textContent = 'Requiere conciliación';
            }
        }

        document.querySelectorAll(
            '#conta-balance td'
        ).forEach(celda => {
            if (celda.textContent.includes('114,500')) {
                celda.textContent = 'Sin saldo inicial registrado';
            }
        });

        const cuerpo = document.getElementById('tbody-caja');
        const fuente = datos.fuentes.caja;

        if (!cuerpo || fuente.estado !== 'correcto') return;

        cuerpo.innerHTML = fuente.filas.map(fila => {
            return (
                '<tr>' +
                    '<td>' +
                        escapar(String(fila.fec).slice(0, 10)) +
                    '</td>' +
                    '<td>' + escapar(fila.con) + '</td>' +
                    '<td>' + escapar(fila.tip) + '</td>' +
                    '<td>—</td>' +
                    '<td>' + escapar(dinero(fila.mon)) + '</td>' +
                    '<td>—</td>' +
                '</tr>'
            );
        }).join('') || (
            '<tr><td colspan="6">' +
                'No hay movimientos de caja registrados.' +
            '</td></tr>'
        );

        let pagina = document.getElementById(
            'erp-caja-pagina'
        );

        if (!pagina) {
            pagina = document.createElement('div');
            pagina.id = 'erp-caja-pagina';
            pagina.className = 'erp-paginacion';

            document.getElementById(
                'finanzas-caja'
            ).append(pagina);
        }

        const fin =
            (fuente.pagina - 1) * 100 +
            fuente.filas.length;

        pagina.innerHTML =
            '<button type="button" data-anterior>Anterior</button>' +
            '<span>Página ' + fuente.pagina +
                ' · ' + escapar(fuente.total) +
                ' movimientos registrados</span>' +
            '<button type="button" data-siguiente>Siguiente</button>';

        pagina.querySelector(
            '[data-anterior]'
        ).disabled = fuente.pagina <= 1;

        pagina.querySelector(
            '[data-siguiente]'
        ).disabled = fin >= Number(fuente.total);

        pagina.querySelector('[data-anterior]').onclick = () => {
            paginas.caja = fuente.pagina - 1;
            sincronizar();
        };

        pagina.querySelector('[data-siguiente]').onclick = () => {
            paginas.caja = fuente.pagina + 1;
            sincronizar();
        };
    };

    async function consultarFuentes() {
        if (
            !esAdministracion() ||
            !document.getElementById('dash-inicio')
        ) {
            return;
        }

        const datos = await api(
            '/sincronizacion/resumen?' +
            new URLSearchParams({
                paginas: JSON.stringify(paginas)
            })
        );

        if (panelesAnteriores) {
            pintarFuentes(datos);
        }

        datos.errores_interfaz = [];

        window.dispatchEvent(
            new CustomEvent('erp:datos', {
                detail: datos
            })
        );

        erroresAPI.push(
            ...datos.errores_interfaz.map(mensaje => ({
                mensaje
            }))
        );

        if (!panelesAnteriores) {
            for (const id of [
                'tbody-proveedores',
                'tbody-compras',
                'tbody-nomina',
                'tbody-emp-activos',
                'tbody-contratos',
                'tbody-permisos',
                'tbody-facturas'
            ]) {
                const cuerpo = document.getElementById(id);

                if (cuerpo && !cuerpo.children.length) {
                    const columnas = cuerpo.closest('table')
                        .querySelectorAll('thead th').length || 1;

                    cuerpo.innerHTML =
                        '<tr><td colspan="' + columnas + '">' +
                            'No hay registros guardados en esta fuente.' +
                        '</td></tr>';
                }
            }
        }

        for (const fuente of Object.values(datos.fuentes)) {
            if (fuente.estado === 'error') {
                erroresAPI.push({
                    mensaje:
                        fuente.titulo + ': ' +
                        fuente.codigo
                });
            }
        }
    }

    function sincronizar() {
        if (pendiente) return pendiente;

        pendiente = (async () => {
            erroresAPI = [];

            const boton =
                document.getElementById('btn-sync') ||
                document.getElementById('erp-actualizar');

            const texto = boton?.innerHTML;

            if (boton) {
                boton.disabled = true;
                boton.setAttribute('aria-busy', 'true');
                boton.textContent = 'Sincronizando…';
            }

            aviso('Consultando los registros guardados…');

            try {
                const detalle = {
                    promesas: []
                };

                if (
                    typeof window.actualizarInventarioDashboard ===
                    'function'
                ) {
                    detalle.promesas.push(
                        Promise.resolve().then(
                            window.actualizarInventarioDashboard
                        )
                    );
                }

                window.dispatchEvent(
                    new CustomEvent('erp:solicitar-recarga', {
                        detail: detalle
                    })
                );

                const resultados = await Promise.allSettled([
                    consultarFuentes(),
                    ...detalle.promesas
                ]);

                const fallos = resultados
                    .filter(resultado => {
                        return resultado.status === 'rejected';
                    })
                    .map(resultado => {
                        return resultado.reason?.message ||
                            'Error de actualización';
                    });

                fallos.push(
                    ...erroresAPI.map(error => error.mensaje)
                );

                if (fallos.length) {
                    aviso(
                        'Actualización incompleta: ' +
                        [...new Set(fallos)].join(' · '),
                        true
                    );

                    return false;
                }

                aviso(
                    'Datos actualizados desde la base de datos. ' +
                    new Date().toLocaleTimeString('es-NI', {
                        timeZone: 'America/Managua'
                    })
                );

                return true;
            } finally {
                if (boton) {
                    boton.disabled = false;
                    boton.removeAttribute('aria-busy');
                    boton.innerHTML = texto;
                }
            }
        })()
            .catch(error => {
                aviso(
                    'No se completó la actualización: ' +
                    error.message,
                    true
                );

                return false;
            })
            .finally(() => {
                pendiente = null;
            });

        return pendiente;
    }

    async function exportar(tipo) {
        if (!window.XLSX) {
            throw new Error(
                'No se cargó la biblioteca de Excel ' +
                'incluida en el dashboard.'
            );
        }

        const desde = document.getElementById(
            'erp-desde'
        ).value;

        const hasta = document.getElementById(
            'erp-hasta'
        ).value;

        const datos = await api(
            '/sincronizacion/estados?' +
            new URLSearchParams({ desde, hasta })
        );

        const titulos = {
            balance: 'Balance de movimientos contabilizados',
            resultados: 'Estado de resultados registrado',
            flujo: 'Flujo de cobros y pagos registrados'
        };

        let filas;

        if (tipo === 'flujo') {
            filas = [
                ['Tipo', 'Método', 'Registros', 'Importe'],
                ...datos.flujo.map(fila => [
                    fila.tipo,
                    fila.metodo,
                    Number(fila.registros),
                    Number(fila.importe)
                ])
            ];
        } else {
            filas = [
                ['Grupo', 'Cuenta', 'Importe'],
                ...datos[tipo].map(fila => [
                    fila.grupo,
                    fila.cuenta,
                    Number(fila.importe)
                ])
            ];
        }

        const hoja = XLSX.utils.aoa_to_sheet([
            [titulos[tipo]],
            ['Desde', desde, 'Hasta', hasta],
            [datos.alcance],
            [],
            ...filas
        ]);

        hoja['!cols'] = [
            { wch: 24 },
            { wch: 46 },
            { wch: 18 },
            { wch: 20 },
            { wch: 20 }
        ];

        const columna = tipo === 'flujo' ? 3 : 2;

        for (
            let fila = 5;
            fila < 5 + filas.length;
            fila++
        ) {
            const celda = hoja[
                XLSX.utils.encode_cell({
                    r: fila,
                    c: columna
                })
            ];

            if (celda && celda.t === 'n') {
                celda.z = '#,##0.00';
            }
        }

        const libro = XLSX.utils.book_new();

        XLSX.utils.book_append_sheet(
            libro,
            hoja,
            'Estado financiero'
        );

        XLSX.writeFile(
            libro,
            tipo + '_' + hasta + '.xlsx'
        );
    }

    function prepararExportaciones() {
        const contenedor = document.getElementById(
            'dash-contabilidad'
        );

        if (!contenedor) return;

        const partes = Object.fromEntries(
            new Intl.DateTimeFormat('en-CA', {
                timeZone: 'America/Managua',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).formatToParts(new Date()).map(parte => [
                parte.type,
                parte.value
            ])
        );

        const hoy =
            partes.year + '-' +
            partes.month + '-' +
            partes.day;

        const barra = document.createElement('div');

        barra.className = 'erp-paginacion';

        barra.innerHTML =
            '<label>Desde ' +
                '<input id="erp-desde" type="date">' +
            '</label>' +
            '<label>Hasta ' +
                '<input id="erp-hasta" type="date">' +
            '</label>';

        contenedor.prepend(barra);

        document.getElementById('erp-desde').value =
            hoy.slice(0, 7) + '-01';

        document.getElementById('erp-hasta').value = hoy;

        for (const [tipo, id] of [
            ['balance', 'conta-balance'],
            ['resultados', 'conta-resultados'],
            ['flujo', 'conta-flujo']
        ]) {
            const panel = document.getElementById(id);

            if (!panel) continue;

            const boton = document.createElement('button');

            boton.className = 'erp-boton';
            boton.type = 'button';
            boton.textContent = 'Exportar a Excel (.xlsx)';

            boton.onclick = async () => {
                boton.disabled = true;

                try {
                    await exportar(tipo);
                } catch (error) {
                    aviso(error.message, true);
                } finally {
                    boton.disabled = false;
                }
            };

            panel.prepend(boton);
        }
    }

    window.verFacturaRealERP = async indice => {
        try {
            const registro = facturasReales[indice];

            if (!registro) {
                throw new Error('Comprobante no encontrado.');
            }

            const venta = registro.origen === 'sales'
                ? await api(
                    '/pos/sales/' +
                    encodeURIComponent(registro.id)
                )
                : null;

            const filas = venta
                ? venta.items.map(item => {
                    return (
                        '<tr>' +
                            '<td>' + escapar(item.product_name) + '</td>' +
                            '<td>' + escapar(item.qty) + '</td>' +
                            '<td>' + escapar(dinero(item.unit_price)) + '</td>' +
                            '<td>' + escapar(dinero(item.subtotal)) + '</td>' +
                        '</tr>'
                    );
                }).join('')
                : (
                    '<tr>' +
                        '<td>' + escapar(registro.con) + '</td>' +
                        '<td>—</td>' +
                        '<td>—</td>' +
                        '<td>' + escapar(dinero(registro.mon)) + '</td>' +
                    '</tr>'
                );

            const html =
                '<article class="erp-comprobante">' +
                    '<header>' +
                        '<strong>K@rin@ Cyber</strong>' +
                        '<h2>Comprobante ' +
                            (venta ? 'VTA-' : 'FAC-') +
                            escapar(registro.id) +
                        '</h2>' +
                    '</header>' +

                    '<p>Cliente: ' +
                        escapar(registro.cli || 'No registrado') +
                    '</p>' +

                    '<p>Fecha: ' +
                        escapar(venta?.date || registro.fec) +
                    '</p>' +

                    '<table>' +
                        '<thead><tr>' +
                            '<th>Descripción</th>' +
                            '<th>Cantidad</th>' +
                            '<th>Precio</th>' +
                            '<th>Importe</th>' +
                        '</tr></thead>' +
                        '<tbody>' + filas + '</tbody>' +
                    '</table>' +

                    '<h3>Total: ' +
                        escapar(
                            dinero(venta?.total ?? registro.mon)
                        ) +
                    '</h3>' +

                    '<p>Forma de pago: ' +
                        escapar(
                            venta?.payment_method ||
                            registro.metodo_pago ||
                            'No registrada'
                        ) +
                    '</p>' +

                    '<footer>' +
                        'Comprobante interno. Los datos fiscales ' +
                        'requieren configuración y validación ' +
                        'del responsable.' +
                    '</footer>' +
                '</article>';

            const contenido = document.getElementById(
                'preview-content'
            );

            contenido.innerHTML = html;

            document.getElementById(
                'preview-title'
            ).textContent = 'Comprobante de venta';

            document.getElementById(
                'ticket-contenido'
            ).innerHTML = html;

            for (const id of [
                'btn-descargar-txt',
                'btn-descargar-excel'
            ]) {
                document.getElementById(id)
                    ?.classList.add('hidden');
            }

            let boton = document.getElementById(
                'erp-factura-pdf'
            );

            if (!boton) {
                boton = document.createElement('button');
                boton.id = 'erp-factura-pdf';
                boton.className = 'erp-boton';
                boton.textContent = 'Descargar PDF';

                document.getElementById(
                    'btn-descargar-txt'
                ).parentElement.prepend(boton);
            }

            boton.onclick = async () => {
                boton.disabled = true;

                try {
                    if (typeof html2pdf !== 'function') {
                        throw new Error(
                            'No se cargó el generador PDF. ' +
                            'Usa Imprimir y Guardar como PDF.'
                        );
                    }

                    await html2pdf()
                        .set({
                            filename:
                                'Comprobante_' +
                                registro.origen + '_' +
                                registro.id + '.pdf',
                            margin: 10,
                            html2canvas: {
                                scale: 2
                            },
                            jsPDF: {
                                unit: 'mm',
                                format: 'a4',
                                orientation: 'portrait'
                            }
                        })
                        .from(contenido)
                        .save();
                } catch (error) {
                    aviso(error.message, true);
                } finally {
                    boton.disabled = false;
                }
            };

            document.getElementById(
                'modal-preview'
            ).classList.remove('hidden');
        } catch (error) {
            aviso(error.message, true);
        }
    };

    window.sincronizarERP = sincronizar;

    window.addEventListener('erp:error-api', evento => {
        if (pendiente) {
            erroresAPI.push(evento.detail);
        }
    });

    window.addEventListener('error', evento => {
        if (pendiente) {
            erroresAPI.push({
                mensaje:
                    evento.message ||
                    'Error al actualizar la interfaz'
            });
        }
    });

    function iniciar() {
        if (
            typeof api !== 'function' ||
            !document.getElementById('page-content')
        ) {
            return;
        }

        panelesAnteriores = !!document.querySelector(
            'script[src*="dashboard-business.js"]'
        );

        const original = document.getElementById('btn-sync');

        if (original) {
            original.removeAttribute('onclick');

            original.addEventListener('click', evento => {
                evento.preventDefault();
                evento.stopImmediatePropagation();
                sincronizar();
            }, true);
        } else {
            const asegurarBoton = () => {
                const contenedor = document.getElementById(
                    'page-content'
                );

                if (
                    !contenedor ||
                    document.getElementById('erp-actualizar')
                ) {
                    return;
                }

                const boton = document.createElement('button');

                boton.id = 'erp-actualizar';
                boton.className = 'erp-boton';
                boton.textContent = 'Actualizar datos';
                boton.onclick = sincronizar;

                contenedor.prepend(boton);
            };

            asegurarBoton();

            new MutationObserver(asegurarBoton).observe(
                document.getElementById('page-content'),
                { childList: true }
            );
        }

        window.sincronizarBaseDatos = sincronizar;

        prepararExportaciones();

        if (document.getElementById('dash-inicio')) {
            sincronizar();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            iniciar,
            { once: true }
        );
    } else {
        iniciar();
    }
})();