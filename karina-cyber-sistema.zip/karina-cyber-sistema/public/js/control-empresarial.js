'use strict';

(() => {
    if (window.ControlEmpresarialERP) return;

    const $ = id => document.getElementById(id);

    const ruta = '/control-empresarial';

    const escapar = valor =>
        String(valor ?? '').replace(
            /[&<>"']/g,
            caracter => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            }[caracter])
        );

    const administrador = () =>
        ['admin', 'superadmin'].includes(
            Auth.getUser()?.role
        );

    let resumen = null;
    let pagina = 1;
    let generacion = 0;
    let pendiente = null;
    let clavePendiente = '';

    function fechaHoy() {
        const partes = Object.fromEntries(
            new Intl.DateTimeFormat('en-CA', {
                timeZone: 'America/Managua',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            })
                .formatToParts(new Date())
                .map(parte => [parte.type, parte.value])
        );

        return (
            partes.year + '-' +
            partes.month + '-' +
            partes.day
        );
    }

    function aviso(texto, error = false) {
        const nodo = $('ce-aviso');

        if (nodo) {
            nodo.textContent = texto;

            nodo.className =
                'ce-aviso' +
                (error ? ' ce-error' : '');
        }
    }

    function tarjetas() {
        return [
            ...(
                $('rh-cumplimiento')
                    ?.querySelectorAll('.power-bi-card') ?? []
            )
        ]
            .filter(nodo =>
                nodo.querySelector('h3') &&
                nodo.querySelector('p')
            )
            .slice(0, 4);
    }

    function pintarResumen() {
        if (!resumen) {
            tarjetas().forEach(tarjeta => {
                tarjeta.querySelector('h3').textContent = '—';
            });

            return;
        }

        const previstas =
            Number(resumen.capacitaciones.previstas);

        const realizadas =
            Number(resumen.capacitaciones.realizadas);

        const vencidos = resumen.contratos.filter(
            contrato =>
                contrato.estado === 'Fecha final vencida'
        ).length;

        const porcentaje = previstas
            ? (
                realizadas / previstas * 100
            ).toLocaleString('es-NI', {
                maximumFractionDigits: 1
            })
            : null;

        const datos = [
            [
                'Capacitaciones realizadas',
                previstas
                    ? realizadas + ' / ' + previstas +
                        ' · ' + porcentaje + ' %'
                    : 'Sin programación'
            ],
            [
                'Días calendario de incapacidad',
                resumen.dias_incapacidad
            ],
            [
                'Registros con fecha final vencida',
                vencidos
            ],
            [
                'Empleados integrados activos hoy',
                resumen.plantilla_actual
            ]
        ];

        tarjetas().forEach((tarjeta, indice) => {
            tarjeta.querySelector('p').textContent =
                datos[indice][0];

            tarjeta.querySelector('h3').textContent =
                datos[indice][1];
        });

        const detalle = $('ce-contratos');

        if (detalle) {
            const filas = resumen.contratos.map(
                contrato =>
                    '<tr><td>' +
                    escapar(contrato.nombre) +
                    '</td><td>' +
                    escapar(contrato.origen) +
                    '</td><td>' +
                    escapar(
                        contrato.fecha_fin || 'No registrada'
                    ) +
                    '</td><td>' +
                    escapar(contrato.estado) +
                    '</td></tr>'
            ).join('');

            detalle.innerHTML =
                '<h3>Seguimiento contractual</h3>' +
                '<p>' +
                escapar(resumen.alcance) +
                '</p><p>' +
                escapar(resumen.sin_vincular) +
                ' registros de empleados anteriores ' +
                'pendientes de vinculación. ' +
                escapar(resumen.capacitaciones.canceladas) +
                ' capacitaciones canceladas en el período.' +
                '</p><div class="ce-desplazamiento">' +
                '<table class="ce-tabla"><thead><tr>' +
                '<th>Empleado</th>' +
                '<th>Fuente</th>' +
                '<th>Fecha final</th>' +
                '<th>Revisión</th>' +
                '</tr></thead><tbody>' +
                (
                    filas ||
                    '<tr><td colspan="4">' +
                    'No hay empleados integrados activos.' +
                    '</td></tr>'
                ) +
                '</tbody></table></div>';
        }

        pintarGraficos();
    }

    function pintarGraficos() {
        if (typeof window.Chart !== 'function') return;

        for (const id of [
            'chartAccidentesCumplimiento',
            'chartContratosCumplimiento'
        ]) {
            const nodo = $(id);

            if (nodo) {
                Chart.getChart(nodo)?.destroy();
            }
        }

        if (!resumen) return;

        const salud = $('chartAccidentesCumplimiento');
        const contratos = $('chartContratosCumplimiento');

        const conRegistro = resumen.contratos.filter(
            contrato => contrato.origen !== 'sin vínculo'
        ).length;

        if (salud) {
            window.crearGraficoERP(salud, {
                type: 'bar',

                data: {
                    labels:
                        resumen.incidentes.map(
                            incidente => incidente.mes
                        ),

                    datasets: [{
                        label: 'Incidentes registrados',

                        data:
                            resumen.incidentes.map(
                                incidente =>
                                    Number(incidente.cantidad)
                            ),

                        backgroundColor: '#7c3aed',
                        borderRadius: 4
                    }]
                },

                options: {
                    responsive: true,
                    maintainAspectRatio: false,

                    plugins: {
                        legend: {
                            display: false
                        },

                        title: {
                            display: true,

                            text:
                                resumen.incidentes.length
                                    ? 'Registros del período'
                                    : 'No hay incidentes registrados en el período'
                        }
                    },

                    scales: {
                        y: {
                            beginAtZero: true,

                            ticks: {
                                stepSize: 1
                            }
                        }
                    }
                }
            });
        }

        if (contratos) {
            window.crearGraficoERP(contratos, {
                type: 'doughnut',

                data: {
                    labels: [
                        'Con registro contractual',
                        'Sin registro contractual'
                    ],

                    datasets: [{
                        data: [
                            conRegistro,
                            resumen.plantilla_actual -
                                conRegistro
                        ],

                        backgroundColor: [
                            '#0f766e',
                            '#c2410c'
                        ],

                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },

                options: {
                    responsive: true,
                    maintainAspectRatio: false,

                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    }

    function pintarCapacitaciones(datos) {
        const panel = $('ce-capacitaciones');
        if (!panel) return;

        const filas = datos.filas.map(capacitacion =>
            '<tr><td>' +
            escapar(capacitacion.fecha) +
            '</td><td>' +
            escapar(capacitacion.titulo) +
            '</td><td>' +
            escapar(capacitacion.tipo) +
            '</td><td>' +
            escapar(capacitacion.estado) +
            '</td><td>' +
            escapar(capacitacion.participantes) +
            '</td><td>' +
            '<button type="button" ' +
            'class="ce-boton ce-secundario" ' +
            'data-ce-editar="' + capacitacion.id + '">' +
            (administrador() ? 'Editar' : 'Ver') +
            '</button>' +
            (
                administrador()
                    ? ' <button type="button" ' +
                      'class="ce-boton ce-secundario" ' +
                      'data-ce-retirar="' + capacitacion.id +
                      '" data-version="' +
                      capacitacion.version +
                      '">Retirar</button>'
                    : ''
            ) +
            '</td></tr>'
        ).join('');

        panel.innerHTML =
            '<div class="ce-cabecera"><div>' +
            '<h3>Capacitaciones y asistencia</h3>' +
            '<p>Programación y registro de participantes ' +
            'vinculados al expediente de empleados.</p>' +
            '</div>' +
            (
                administrador()
                    ? '<button type="button" class="ce-boton" ' +
                      'data-ce-nueva>Nueva capacitación</button>'
                    : ''
            ) +
            '</div><div class="ce-desplazamiento">' +
            '<table class="ce-tabla"><thead><tr>' +
            '<th>Fecha</th><th>Capacitación</th>' +
            '<th>Tipo</th><th>Estado</th>' +
            '<th>Participantes</th><th>Acciones</th>' +
            '</tr></thead><tbody>' +
            (
                filas ||
                '<tr><td colspan="6">' +
                'No hay capacitaciones registradas ' +
                'en el período seleccionado.' +
                '</td></tr>'
            ) +
            '</tbody></table></div>' +
            '<div class="ce-acciones">' +
            '<button type="button" ' +
            'class="ce-boton ce-secundario" ' +
            'data-ce-pagina="-1" ' +
            (pagina <= 1 ? 'disabled' : '') +
            '>Anterior</button>' +
            '<span>Página ' + pagina +
            ' · ' + escapar(datos.total) +
            ' registros</span>' +
            '<button type="button" ' +
            'class="ce-boton ce-secundario" ' +
            'data-ce-pagina="1" ' +
            (
                pagina * 50 >= Number(datos.total)
                    ? 'disabled'
                    : ''
            ) +
            '>Siguiente</button></div>';
    }

    function cargarCumplimiento() {
        if (!$('ce-desde')) {
            return Promise.resolve();
        }

        const desde = $('ce-desde').value;
        const hasta = $('ce-hasta').value;

        if (!desde || !hasta || desde > hasta) {
            const error = new Error(
                'Selecciona un período válido.'
            );

            aviso(error.message, true);

            return Promise.reject(error);
        }

        const clave =
            desde + '|' + hasta + '|' + pagina;

        if (pendiente && clave === clavePendiente) {
            return pendiente;
        }

        const turno = ++generacion;
        clavePendiente = clave;

        aviso(
            'Consultando los registros de cumplimiento…'
        );

        const tarea = (async () => {
            const parametros = new URLSearchParams({
                desde,
                hasta,
                pagina
            });

            const [datos, lista] = await Promise.all([
                api(ruta + '/cumplimiento?' + parametros),
                api(ruta + '/capacitaciones?' + parametros)
            ]);

            if (turno !== generacion) return;

            resumen = datos;

            pintarResumen();
            pintarCapacitaciones(lista);

            aviso(
                'Actualizado desde PostgreSQL. Período ' +
                desde + ' a ' + hasta +
                '. Reporte interno de seguimiento.'
            );
        })()
            .catch(error => {
                if (turno === generacion) {
                    aviso(
                        error.message +
                        ' Los datos anteriores pueden ' +
                        'estar desactualizados.',
                        true
                    );
                }

                throw error;
            })
            .finally(() => {
                if (pendiente === tarea) {
                    pendiente = null;
                }
            });

        pendiente = tarea;

        return tarea;
    }

   async function cargarDiagnostico() {
    const panel = $('ce-diagnostico');

    if (!panel) return;

    const abierto =
        panel.querySelector('details')?.open || false;

    panel.setAttribute('aria-busy', 'true');

    const anterior = panel.querySelector(
        '[data-ce-diagnostico-estado]'
    );

    if (anterior) {
        anterior.textContent = 'Comprobando…';
    }

    panel.querySelector(
        '[data-ce-diagnostico-aviso]'
    )?.remove();

    try {
        const datos = await api(
            ruta + '/diagnostico'
        );

        if (
            !Array.isArray(datos.controles) ||
            !Array.isArray(datos.faltantes)
        ) {
            throw new Error(
                'Respuesta de comprobación no válida.'
            );
        }

        const etiquetas = {
            correcto: 'Sin diferencias detectadas',
            revisar: 'Por revisar',
            no_evaluado: 'Sin evaluar',
            error: 'Error de consulta'
        };

        const cantidades = {
            correcto: 0,
            revisar: 0,
            no_evaluado: 0,
            error: 0
        };

        const filas = datos.controles.map(control => {
            const estado = Object.hasOwn(
                etiquetas,
                control.estado
            )
                ? control.estado
                : 'no_evaluado';

            cantidades[estado]++;

            return (
                '<tr>' +
                    '<td>' +
                        escapar(control.nombre) +
                    '</td>' +

                    '<td>' +
                        escapar(etiquetas[estado]) +
                        (
                            control.codigo
                                ? ' · ' + escapar(control.codigo)
                                : ''
                        ) +
                    '</td>' +

                    '<td>' +
                        escapar(control.cantidad ?? '—') +
                    '</td>' +
                '</tr>'
            );
        }).join('');

        const incompleto =
            datos.faltantes.length > 0 ||
            cantidades.error > 0 ||
            cantidades.no_evaluado > 0;

        const revisar =
            incompleto ||
            cantidades.revisar > 0;

        const fecha = new Date(
            datos.generado_en
        );

        const hora = Number.isNaN(fecha.getTime())
            ? 'Hora no disponible'
            : fecha.toLocaleString('es-NI', {
                timeZone: 'America/Managua'
            });

        const estado = revisar
            ? 'Requiere revisión'
            : !datos.controles.length
                ? 'Sin comprobaciones'
                : 'Sin diferencias detectadas';

        panel.dataset.consulta = 'actualizada';

        panel.innerHTML =
            '<div class="ce-cabecera">' +
                '<div>' +
                    '<h3>Comprobación del sistema</h3>' +

                    '<p data-ce-diagnostico-estado>' +
                        escapar(hora) +
                    '</p>' +
                '</div>' +

                '<button ' +
                    'type="button" ' +
                    'class="ce-boton ce-secundario" ' +
                    'data-ce-diagnostico>' +
                    'Comprobar' +
                '</button>' +
            '</div>' +

            '<div class="dash-comprobacion-resumen">' +
                '<span class="' +
                    (cantidades.correcto ? 'correcto' : '') +
                '">' +
                    'Correctas: ' + cantidades.correcto +
                '</span>' +

                '<span class="' +
                    (cantidades.revisar ? 'revisar' : '') +
                '">' +
                    'Por revisar: ' + cantidades.revisar +
                '</span>' +

                '<span>' +
                    'Sin evaluar: ' + cantidades.no_evaluado +
                '</span>' +

                '<span class="' +
                    (cantidades.error ? 'error' : '') +
                '">' +
                    'Errores: ' + cantidades.error +
                '</span>' +

                '<strong class="dash-control-estado">' +
                    estado +
                '</strong>' +
            '</div>' +

            '<details' + (
                abierto ? ' open' : ''
            ) + '>' +
                '<summary>Ver comprobaciones</summary>' +

                '<p>' +
                    escapar(datos.alcance) +
                '</p>' +

                (
                    datos.faltantes.length
                        ? '<p class="ce-aviso ce-error">' +
                            'Estructura pendiente: ' +
                            datos.faltantes
                                .map(escapar)
                                .join(' · ') +
                          '</p>'
                        : ''
                ) +

                '<div class="ce-desplazamiento">' +
                    '<table class="ce-tabla">' +
                        '<thead>' +
                            '<tr>' +
                                '<th>Comprobación</th>' +
                                '<th>Estado</th>' +
                                '<th>Registros</th>' +
                            '</tr>' +
                        '</thead>' +

                        '<tbody>' +
                            (
                                filas ||
                                '<tr>' +
                                    '<td colspan="3">' +
                                        'No se recibieron comprobaciones.' +
                                    '</td>' +
                                '</tr>'
                            ) +
                        '</tbody>' +
                    '</table>' +
                '</div>' +

                '<p>' +
                    '<a href="/finanzas.html">' +
                        'Abrir control de caja' +
                    '</a>' +
                '</p>' +
            '</details>';

        if (incompleto) {
            throw Object.assign(
                new Error(
                    'Hay comprobaciones pendientes. ' +
                    'Revisa su detalle.'
                ),
                { mostrado: true }
            );
        }
    } catch (error) {
        if (!error.mostrado) {
            panel.dataset.consulta = 'error';

            const estado = panel.querySelector(
                '.dash-control-estado'
            );

            if (estado) {
                estado.textContent = 'Sin actualizar';
            }

            const fecha = panel.querySelector(
                '[data-ce-diagnostico-estado]'
            );

            if (fecha) {
                fecha.textContent = 'Consulta fallida';
            }

            const nota = document.createElement('p');

            nota.dataset.ceDiagnosticoAviso = '';
            nota.className = 'ce-aviso ce-error';

            nota.setAttribute('role', 'alert');

            nota.textContent =
                'No se pudo comprobar: ' +
                error.message;

            panel.prepend(nota);
        }

        throw error;
    } finally {
        panel.removeAttribute('aria-busy');
    }
}

    async function recargar() {
        const resultados = await Promise.allSettled([
            cargarCumplimiento(),
            cargarDiagnostico()
        ]);

        const errores = resultados.filter(
            resultado => resultado.status === 'rejected'
        );

        if (errores.length) {
            throw new Error(
                errores.map(
                    resultado => resultado.reason.message
                ).join(' · ')
            );
        }
    }

    async function editarCapacitacion(id = null) {
        if ($('ce-editor')) return;

        const datos = id
            ? await api(ruta + '/capacitaciones/' + id)
            : {
                titulo: '',
                fecha: fechaHoy(),
                tipo: 'seguridad',
                estado: 'programada',
                descripcion: '',
                participantes: []
            };

        if ($('ce-editor')) return;

        if (
            !id &&
            typeof crypto.randomUUID !== 'function'
        ) {
            throw new Error(
                'Abre el sistema en localhost o mediante HTTPS ' +
                'para crear solicitudes seguras.'
            );
        }

        const clave = id ? null : crypto.randomUUID();

        const seleccionados = new Map(
            datos.participantes.map(participante => [
                participante.empleado_id,
                { ...participante }
            ])
        );

        let candidatos = [];
        let busqueda = 0;
        let enviando = false;

        const dialogo = document.createElement('dialog');

        dialogo.id = 'ce-editor';
        dialogo.className = 'ce-dialogo';

        dialogo.innerHTML = `
            <form>
                <div class="ce-cabecera">
                    <h2>${
                        escapar(
                            id
                                ? 'Capacitación #' + id
                                : 'Nueva capacitación'
                        )
                    }</h2>

                    <button
                        type="button"
                        class="ce-boton ce-secundario"
                        data-ce-cerrar
                    >
                        Cerrar
                    </button>
                </div>

                <p
                    class="ce-aviso"
                    role="status"
                    data-ce-editor-aviso
                >
                    Los cambios se guardan en la base de datos.
                </p>

                <fieldset ${
                    !administrador() ? 'disabled' : ''
                }>
                    <div class="ce-cuadricula">
                        <label>
                            Título
                            <input
                                name="titulo"
                                maxlength="180"
                                required
                            >
                        </label>

                        <label>
                            Fecha
                            <input
                                name="fecha"
                                type="date"
                                required
                            >
                        </label>

                        <label>
                            Tipo
                            <select name="tipo">
                                <option value="seguridad">
                                    Seguridad e higiene
                                </option>
                                <option value="operacion">
                                    Operación
                                </option>
                                <option value="administrativa">
                                    Administrativa
                                </option>
                            </select>
                        </label>

                        <label>
                            Estado
                            <select name="estado">
                                <option value="programada">
                                    Programada
                                </option>
                                <option value="realizada">
                                    Realizada
                                </option>
                                <option value="cancelada">
                                    Cancelada
                                </option>
                            </select>
                        </label>
                    </div>

                    <label>
                        Descripción
                        <textarea
                            name="descripcion"
                            maxlength="2000"
                            rows="3"
                        ></textarea>
                    </label>

                    <h3>Participantes</h3>

                    <div class="ce-acciones">
                        <input
                            type="search"
                            name="buscar"
                            aria-label="Buscar empleados"
                            placeholder="Buscar empleados activos"
                        >

                        <button
                            type="button"
                            class="ce-boton ce-secundario"
                            data-ce-buscar
                        >
                            Buscar
                        </button>
                    </div>

                    <p>
                        Se muestran hasta 50 coincidencias.
                        Ajusta la búsqueda para agregar otros empleados.
                    </p>

                    <div data-ce-candidatos></div>

                    <div
                        class="ce-desplazamiento"
                        data-ce-seleccionados
                    ></div>

                    ${
                        administrador()
                            ? `
                                <div class="ce-acciones">
                                    <button
                                        type="submit"
                                        class="ce-boton"
                                    >
                                        Guardar capacitación
                                    </button>
                                </div>
                            `
                            : ''
                    }
                </fieldset>
            </form>
        `;

        const formulario =
            dialogo.querySelector('form');

        const campos = formulario.elements;

        for (const campo of [
            'titulo',
            'fecha',
            'tipo',
            'estado',
            'descripcion'
        ]) {
            campos.namedItem(campo).value = datos[campo];
        }

        function mensaje(texto, error = false) {
            const nodo = dialogo.querySelector(
                '[data-ce-editor-aviso]'
            );

            nodo.textContent = texto;

            nodo.className =
                'ce-aviso' +
                (error ? ' ce-error' : '');
        }

        function pintarSeleccionados() {
            const filas = [
                ...seleccionados.values()
            ].map(participante => {
                const opciones = [
                    ['convocado', 'Convocado'],
                    ['asistio', 'Asistió'],
                    ['no_asistio', 'No asistió']
                ].map(([valor, titulo]) =>
                    '<option value="' + valor + '" ' +
                    (
                        participante.asistencia === valor
                            ? 'selected'
                            : ''
                    ) +
                    '>' + titulo + '</option>'
                ).join('');

                return (
                    '<tr><td>' +
                    escapar(participante.nombre) +
                    '</td><td>' +
                    '<select data-ce-asistencia="' +
                    participante.empleado_id +
                    '">' +
                    opciones +
                    '</select></td><td>' +
                    '<button type="button" ' +
                    'class="ce-boton ce-secundario" ' +
                    'data-ce-quitar="' +
                    participante.empleado_id +
                    '">Quitar</button>' +
                    '</td></tr>'
                );
            }).join('');

            dialogo.querySelector(
                '[data-ce-seleccionados]'
            ).innerHTML =
                '<table class="ce-tabla"><thead><tr>' +
                '<th>Empleado</th>' +
                '<th>Asistencia</th>' +
                '<th>Acción</th>' +
                '</tr></thead><tbody>' +
                (
                    filas ||
                    '<tr><td colspan="3">' +
                    'Agrega los participantes de esta capacitación.' +
                    '</td></tr>'
                ) +
                '</tbody></table>';
        }

        async function buscarEmpleados() {
            const turno = ++busqueda;

            const lista = await api(
                ruta + '/empleados?' +
                new URLSearchParams({
                    buscar:
                        campos.namedItem('buscar').value
                })
            );

            if (
                turno !== busqueda ||
                !dialogo.isConnected
            ) {
                return;
            }

            candidatos = lista;

            dialogo.querySelector(
                '[data-ce-candidatos]'
            ).innerHTML =
                lista.map(empleado =>
                    '<button type="button" ' +
                    'class="ce-boton ce-secundario" ' +
                    'data-ce-agregar="' + empleado.id + '">' +
                    'Agregar ' +
                    escapar(empleado.nombre) +
                    ' · ' +
                    escapar(empleado.cargo) +
                    '</button>'
                ).join(' ') ||
                '<p>No hay coincidencias.</p>';
        }

        dialogo.addEventListener('click', evento => {
            const boton = evento.target.closest('button');

            if (!boton || enviando) return;

            if (boton.hasAttribute('data-ce-cerrar')) {
                dialogo.close();
                return;
            }

            if (!administrador()) return;

            if (boton.hasAttribute('data-ce-buscar')) {
                buscarEmpleados().catch(error =>
                    mensaje(error.message, true)
                );
            }

            if (boton.dataset.ceAgregar) {
                const empleado = candidatos.find(
                    candidato =>
                        candidato.id ===
                        Number(boton.dataset.ceAgregar)
                );

                if (
                    empleado &&
                    !seleccionados.has(empleado.id)
                ) {
                    seleccionados.set(empleado.id, {
                        empleado_id: empleado.id,
                        nombre: empleado.nombre,
                        asistencia: 'convocado'
                    });

                    pintarSeleccionados();
                }
            }

            if (boton.dataset.ceQuitar) {
                seleccionados.delete(
                    Number(boton.dataset.ceQuitar)
                );

                pintarSeleccionados();
            }
        });

        dialogo.addEventListener('change', evento => {
            const idEmpleado = Number(
                evento.target.dataset.ceAsistencia
            );

            if (
                idEmpleado &&
                seleccionados.has(idEmpleado)
            ) {
                seleccionados.get(idEmpleado).asistencia =
                    evento.target.value;
            }
        });

        dialogo.addEventListener('cancel', evento => {
            if (enviando) {
                evento.preventDefault();
            }
        });

        dialogo.addEventListener('close', () => {
            busqueda++;
            dialogo.remove();
        }, { once: true });

        formulario.addEventListener(
            'submit',
            async evento => {
                evento.preventDefault();

                if (enviando || !administrador()) return;

                const cuerpo = {
                    participantes: [
                        ...seleccionados.values()
                    ].map(({
                        empleado_id,
                        asistencia
                    }) => ({
                        empleado_id,
                        asistencia
                    }))
                };

                for (const campo of [
                    'titulo',
                    'fecha',
                    'tipo',
                    'estado',
                    'descripcion'
                ]) {
                    cuerpo[campo] =
                        campos.namedItem(campo).value;
                }

                if (id) {
                    cuerpo.version = datos.version;
                } else {
                    cuerpo.request_key = clave;
                }

                enviando = true;

                dialogo.querySelector('fieldset').disabled =
                    true;

                mensaje(
                    'Guardando capacitación y asistencia…'
                );

                try {
                    await api(
                        ruta + '/capacitaciones' +
                        (id ? '/' + id : ''),
                        {
                            method: id ? 'PUT' : 'POST',
                            body: cuerpo
                        }
                    );

                    enviando = false;
                    dialogo.close();

                    try {
                        if (
                            typeof window.actualizarERPTrasCambio
                                === 'function'
                        ) {
                            await window.actualizarERPTrasCambio();
                        } else {
                            await recargar();
                        }
                    } catch (error) {
                        aviso(
                            'El guardado se completó, pero falta ' +
                            'actualizar la vista: ' +
                            error.message,
                            true
                        );
                    }
                } catch (error) {
                    mensaje(error.message, true);
                } finally {
                    enviando = false;

                    if (dialogo.isConnected) {
                        dialogo.querySelector(
                            'fieldset'
                        ).disabled = false;
                    }
                }
            }
        );

        document.body.append(dialogo);

        pintarSeleccionados();
        dialogo.showModal();

        if (administrador()) {
            buscarEmpleados().catch(error =>
                mensaje(error.message, true)
            );
        }
    }

    function iniciar() {
        if (
            ![
                'admin',
                'superadmin',
                'auditor'
            ].includes(Auth.getUser()?.role)
        ) {
            return;
        }

        const cumplimiento = $('rh-cumplimiento');

        if (cumplimiento) {
            const desde = cumplimiento.querySelector(
                'input[type=date]'
            );

            const aplicar =
                cumplimiento.querySelector('button');

            if (desde && aplicar) {
                desde.id = 'ce-desde';

                desde.value =
                    fechaHoy().slice(0, 7) + '-01';

                desde.parentElement
                    .querySelector('label')
                    .textContent = 'Desde';

                const campo =
                    document.createElement('label');

                campo.className = 'ce-campo';
                campo.textContent = 'Hasta';

                const hasta =
                    document.createElement('input');

                hasta.id = 'ce-hasta';
                hasta.type = 'date';
                hasta.value = fechaHoy();

                campo.append(hasta);
                aplicar.before(campo);

                aplicar.onclick = async () => {
                    pagina = 1;
                    aplicar.disabled = true;

                    try {
                        await cargarCumplimiento();
                    } catch {
                        // La consulta muestra su error en pantalla.
                    } finally {
                        aplicar.disabled = false;
                    }
                };
            }

            const avisoNodo =
                document.createElement('p');

            avisoNodo.id = 'ce-aviso';
            avisoNodo.className = 'ce-aviso';
            avisoNodo.setAttribute('role', 'status');

            cumplimiento.prepend(avisoNodo);

            for (const id of [
                'ce-contratos',
                'ce-capacitaciones'
            ]) {
                const seccion =
                    document.createElement('section');

                seccion.id = id;
                seccion.className = 'ce-panel';

                cumplimiento.append(seccion);
            }

            for (const [id, titulo] of [
                [
                    'chartAccidentesCumplimiento',
                    'Incidentes registrados por mes'
                ],
                [
                    'chartContratosCumplimiento',
                    'Cobertura de registros contractuales'
                ]
            ]) {
                const cabecera = $(id)
                    ?.closest('.power-bi-card')
                    ?.querySelector('h3');

                if (cabecera) {
                    cabecera.textContent = titulo;
                }
            }

            window.renderChartsCumplimiento =
                pintarResumen;

            pintarResumen();
            pintarGraficos();

            const botonPDF = cumplimiento.querySelector(
                'button[onclick*="exportarPDFStats"]'
            );

            if (botonPDF) {
                botonPDF.textContent =
                    'Descargar seguimiento interno en PDF';
            }

            window.exportarPDFStats = async () => {
                if (botonPDF) botonPDF.disabled = true;

                try {
                    await cargarCumplimiento();

                    if (typeof html2pdf !== 'function') {
                        throw new Error(
                            'No está disponible el generador PDF.'
                        );
                    }

                    await html2pdf()
                        .set({
                            filename:
                                'Seguimiento_interno_' +
                                $('ce-hasta').value +
                                '.pdf',

                            margin: 8,

                            html2canvas: {
                                scale: 2,

                                ignoreElements:
                                    nodo =>
                                        nodo.tagName === 'BUTTON'
                            },

                            jsPDF: {
                                unit: 'mm',
                                format: 'a4',
                                orientation: 'landscape'
                            }
                        })
                        .from(cumplimiento)
                        .save();
                } catch (error) {
                    aviso(error.message, true);
                } finally {
                    if (botonPDF) {
                        botonPDF.disabled = false;
                    }
                }
            };
        }

        const destino =
            $('dash-inicio') ||
            (
                location.pathname.endsWith('/reportes.html')
                    ? $('page-content')
                    : null
            );

        if (destino && !$('ce-diagnostico')) {
            const panel =
                document.createElement('section');

            panel.id = 'ce-diagnostico';
            panel.className = 'ce-panel';

            panel.innerHTML =
                '<h3>Control de integración empresarial</h3>' +
                '<p data-ce-diagnostico-estado>' +
                'Consultando comprobaciones…</p>';

            destino.append(panel);
        }

        document.addEventListener(
            'click',
            async evento => {
                const boton = evento.target.closest(
                    '[data-ce-nueva],' +
                    '[data-ce-editar],' +
                    '[data-ce-retirar],' +
                    '[data-ce-pagina],' +
                    '[data-ce-diagnostico]'
                );

                if (!boton || boton.disabled) return;

                evento.preventDefault();
                boton.disabled = true;

                try {
                    if (boton.hasAttribute('data-ce-nueva')) {
                        await editarCapacitacion();
                    } else if (boton.dataset.ceEditar) {
                        await editarCapacitacion(
                            boton.dataset.ceEditar
                        );
                    } else if (
                        boton.dataset.ceRetirar &&
                        administrador()
                    ) {
                        const confirmar = window.confirm(
                            '¿Retirar esta capacitación de la ' +
                            'programación activa? Su historial ' +
                            'de auditoría se conserva.'
                        );

                        if (!confirmar) return;

                        await api(
                            ruta + '/capacitaciones/' +
                            boton.dataset.ceRetirar,
                            {
                                method: 'DELETE',

                                body: {
                                    version:
                                        Number(
                                            boton.dataset.version
                                        )
                                }
                            }
                        );

                        pagina = 1;

                        if (pendiente) {
                            await pendiente.catch(() => {});
                        }

                        await cargarCumplimiento();
                    } else if (boton.dataset.cePagina) {
                        pagina = Math.max(
                            1,
                            pagina +
                            Number(boton.dataset.cePagina)
                        );

                        await cargarCumplimiento();
                    } else if (
                        boton.hasAttribute('data-ce-diagnostico')
                    ) {
                        await cargarDiagnostico();
                    }
                } catch (error) {
                    aviso(error.message, true);
                } finally {
                    if (boton.isConnected) {
                        boton.disabled = false;
                    }
                }
            }
        );

        recargar().catch(() => {});
    }

    window.addEventListener(
        'erp:solicitar-recarga',
        evento => {
            const anteriores = [
                ...evento.detail.promesas
            ];

            evento.detail.promesas.push(
                Promise.allSettled(anteriores)
                    .then(recargar)
            );
        }
    );

    window.ControlEmpresarialERP = {
        recargar
    };

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            iniciar,
            { once: true }
        );
    } else {
        iniciar();
    }
})();