'use strict';

(() => {
    const modules = [
        'inicio',
        'produccion',
        'proveedores',
        'contabilidad',
        'finanzas',
        'inventario',
        'rrhh'
    ];

    const groups = [
        [
            'cambiarSubConta',
            'dash-contabilidad',
            'conta-',
            ['nomina', 'compras', 'balance', 'resultados', 'flujo']
        ],
        [
            'cambiarSubFinanzas',
            'dash-finanzas',
            'finanzas-',
            ['caja', 'facturas', 'estadistica', 'mkt']
        ],
        [
            'cambiarSubRH',
            'dash-rrhh',
            'rh-',
            ['empleados', 'contratos', 'permisos', 'seguridad', 'cumplimiento']
        ]
    ];

    const $ = id => document.getElementById(id);

    const esc = value => String(value ?? '').replace(
        /[&<>"']/g,
        char => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[char])
    );

    const number = value => {
        if (
            value === null ||
            value === undefined ||
            value === '' ||
            !Number.isFinite(Number(value))
        ) {
            return '—';
        }

        return Number(value).toLocaleString('es-NI', {
            maximumFractionDigits: 6
        });
    };

    const currency = value => {
        if (
            value === null ||
            value === undefined ||
            value === '' ||
            !Number.isFinite(Number(value))
        ) {
            return '—';
        }

        return 'C$ ' + Number(value).toLocaleString('es-NI', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    };

    const date = value => {
        if (!value) return '—';

        const parsed = new Date(value);

        if (Number.isNaN(parsed.getTime())) {
            return '—';
        }

        return parsed.toLocaleString('es-NI', {
            timeZone: 'America/Managua'
        });
    };

    function current() {
        const key = location.hash.slice(1);
        return modules.includes(key) ? key : 'inicio';
    }

    function navigation() {
        const key = current();

        modules.forEach(name => {
            const section = $('dash-' + name);

            if (!section) return;

            /*
             * Conserva visible la cabecera y el menú original.
             * También muestra el módulo seleccionado.
             */
            const hidden = name !== key;

            if (section.hidden !== hidden) {
                section.hidden = hidden;
            }
        });

        document.querySelectorAll(
            '#main-menu-container .menu-btn'
        ).forEach(button => {
            const selected = button.dataset.target === key;

            modules.forEach(name => {
                button.classList.toggle(
                    'active-' + name,
                    selected && name === key
                );
            });

            if (selected) {
                button.setAttribute('aria-current', 'page');
            } else {
                button.removeAttribute('aria-current');
            }
        });

        document.querySelectorAll(
            '.sidebar-nav a[href]'
        ).forEach(link => {
            let url;

            try {
                url = new URL(
                    link.getAttribute('href'),
                    location.href
                );
            } catch {
                return;
            }

            if (
                url.origin !== location.origin ||
                url.pathname !== location.pathname
            ) {
                return;
            }

            const selected =
                (url.hash.slice(1) || 'inicio') === key;

            link.classList.toggle('active', selected);

            if (selected) {
                link.setAttribute('aria-current', 'page');
            } else {
                link.removeAttribute('aria-current');
            }
        });
    }

    function tabs() {
        groups.forEach(([name, sectionId, prefix, names]) => {
            const section = $(sectionId);

            if (!section) return;

            const buttons = [
                ...section.querySelectorAll('.sub-tab-btn')
            ];

            function select(tab, button) {
                if (!names.includes(tab)) return;

                names.forEach(name => {
                    const panel = $(prefix + name);

                    if (panel) {
                        panel.hidden = name !== tab;
                    }
                });

                buttons.forEach(item => {
                    item.classList.toggle(
                        'kc-tab-selected',
                        item === button
                    );

                    item.setAttribute(
                        'aria-pressed',
                        String(item === button)
                    );
                });

                requestAnimationFrame(() => {
                    if (typeof Chart === 'undefined') return;

                    if (
                        prefix === 'finanzas-' &&
                        tab === 'estadistica' &&
                        typeof window.renderChartsFinanzas === 'function'
                    ) {
                        window.renderChartsFinanzas();
                    }

                    if (
                        prefix === 'rh-' &&
                        tab === 'cumplimiento' &&
                        typeof window.renderChartsCumplimiento === 'function'
                    ) {
                        window.renderChartsCumplimiento();
                    }
                });
            }

            /*
             * Los botones originales siguen utilizando
             * los mismos nombres de función.
             */
            window[name] = select;

            const visible = names.find(name => {
                const panel = $(prefix + name);
                return panel && !panel.hidden;
            }) || names[0];

            select(
                visible,
                buttons[names.indexOf(visible)]
            );
        });
    }

    function table(headers, rows) {
        const head = headers.map(
            heading => '<th>' + esc(heading) + '</th>'
        ).join('');

        const body = rows.length
            ? rows.map(row => {
                return '<tr>' + row.map(
                    cell => '<td>' + cell + '</td>'
                ).join('') + '</tr>';
            }).join('')
            : (
                '<tr><td colspan="' + headers.length + '">' +
                'No hay registros para mostrar.' +
                '</td></tr>'
            );

        return (
            '<div class="kc-table-scroll">' +
                '<table class="kc-data-table">' +
                    '<thead><tr>' + head + '</tr></thead>' +
                    '<tbody>' + body + '</tbody>' +
                '</table>' +
            '</div>'
        );
    }

    function inventory() {
        const host = $('dash-inventario');

        if (!host || $('kc-inventory')) return;

        const area = document.createElement('div');
        area.id = 'kc-inventory';

        /*
         * Este contenido pertenece únicamente a la ampliación.
         * No sustituye el HTML del módulo ni del dashboard.
         */
        area.innerHTML = `
            <div class="kc-toolbar">
                <p>
                    Existencias y valoración del inventario activo.
                </p>

                <button
                    type="button"
                    class="kc-button"
                    id="kc-stock-refresh"
                >
                    Actualizar inventario
                </button>
            </div>

            <p
                id="kc-stock-status"
                role="status"
                aria-live="polite"
            ></p>

            <div class="kc-stock-grid">
                <div class="power-bi-card kc-stat">
                    <p>Productos activos</p>
                    <strong id="kc-stock-products">—</strong>
                </div>

                <div class="power-bi-card kc-stat">
                    <p>Unidades registradas</p>
                    <strong id="kc-stock-units">—</strong>
                </div>

                <div class="power-bi-card kc-stat">
                    <p>Dinero invertido</p>
                    <strong id="kc-stock-invested">—</strong>
                </div>

                <div class="power-bi-card kc-stat">
                    <p>Valor a precio de venta</p>
                    <strong id="kc-stock-retail">—</strong>
                </div>

                <div class="power-bi-card kc-stat">
                    <p>Productos con stock bajo</p>
                    <strong id="kc-stock-low">—</strong>
                </div>
            </div>

            <div class="power-bi-card kc-catalog">
                <div class="kc-toolbar">
                    <h3>Productos y existencias</h3>

                    <label>
                        Buscar producto o SKU

                        <input
                            id="kc-stock-search"
                            type="search"
                            placeholder="Escribe un nombre o código"
                        >
                    </label>

                    <label>
                        Estado

                        <select id="kc-stock-filter">
                            <option value="active">Activos</option>
                            <option value="all">Todos</option>
                            <option value="inactive">Inactivos</option>
                            <option value="low">Stock bajo</option>
                        </select>
                    </label>
                </div>

                <p class="kc-help" id="kc-stock-count"></p>

                <div id="kc-stock-table"></div>
            </div>
        `;

        const placeholder = [
            ...host.querySelectorAll('p')
        ].find(paragraph => {
            return paragraph.textContent.trim() ===
                'Módulo de control de stock en desarrollo.';
        });

        if (placeholder) {
            placeholder.textContent =
                'Consulta productos, existencias, inversión y ' +
                'movimientos de Kardex. Los indicadores incluyen ' +
                'todos los productos activos; la tabla consulta ' +
                'hasta 2,000 productos.';
        }

        host.appendChild(area);

        let products = [];
        let busy = false;
        let loaded = false;
        let showKardexBusy = false;

        function render() {
            const query = $('kc-stock-search')
                .value
                .trim()
                .toLocaleLowerCase('es');

            const filter = $('kc-stock-filter').value;

            const rows = products.filter(product => {
                const match = [
                    product.name,
                    product.sku,
                    product.category_name
                ].some(value => {
                    return String(value ?? '')
                        .toLocaleLowerCase('es')
                        .includes(query);
                });

                const state =
                    filter === 'all' ||
                    (filter === 'active' && product.active) ||
                    (filter === 'inactive' && !product.active) ||
                    (
                        filter === 'low' &&
                        product.active &&
                        Number(product.stock) <=
                            Number(product.min_stock)
                    );

                return match && state;
            });

            $('kc-stock-count').textContent =
                rows.length + ' mostrados de ' +
                products.length + ' consultados. ' +
                'Los filtros no cambian los indicadores globales.';

            $('kc-stock-table').innerHTML = table(
                [
                    'Producto / SKU',
                    'Categoría',
                    'Disponible',
                    'Mínimo',
                    'Costo promedio',
                    'Precio de venta',
                    'Inversión',
                    'Estado',
                    'Kardex'
                ],
                rows.map(product => {
                    const low =
                        product.active &&
                        Number(product.stock) <=
                            Number(product.min_stock);

                    return [
                        '<strong>' + esc(product.name) + '</strong>' +
                        '<small>' + esc(product.sku) + '</small>',

                        esc(product.category_name || 'Sin categoría'),

                        '<span class="' +
                            (low ? 'kc-stock-warning' : '') +
                        '">' +
                            esc(number(product.stock)) + ' ' +
                            esc(product.unit) +
                        '</span>',

                        esc(number(product.min_stock)),
                        esc(currency(product.avg_cost)),
                        esc(currency(product.price)),
                        esc(currency(product.inventory_value)),

                        product.active ? 'Activo' : 'Inactivo',

                        '<button type="button" ' +
                            'class="kc-button kc-button-light" ' +
                            'data-kardex-id="' + esc(product.id) + '">' +
                            'Ver movimientos' +
                        '</button>'
                    ];
                })
            );
        }

        async function load() {
            if (busy) return;

            busy = true;

            $('kc-stock-refresh').disabled = true;

            $('kc-stock-status').textContent =
                'Consultando inventario…';

            $('kc-stock-status').classList.remove('kc-error');
            area.setAttribute('aria-busy', 'true');

            try {
                const results = await Promise.allSettled([
                    api('/inventory/products'),
                    api('/inventory/summary')
                ]);

                const errors = results.filter(
                    result => result.status === 'rejected'
                );

                if (errors.length) {
                    throw new Error(
                        errors.map(result => {
                            return result.reason?.message ||
                                'Error de consulta';
                        }).join(' · ')
                    );
                }

                const list = results[0].value;
                const summary = results[1].value;

                if (
                    !Array.isArray(list) ||
                    !summary ||
                    typeof summary !== 'object'
                ) {
                    throw new Error(
                        'El servidor no devolvió el formato ' +
                        'de inventario esperado.'
                    );
                }

                products = list;

                const indicators = [
                    ['products', 'products'],
                    ['units', 'units'],
                    ['invested', 'invested'],
                    ['retail', 'retail_value'],
                    ['low', 'low_stock']
                ];

                indicators.forEach(([id, key]) => {
                    const isMoney = [
                        'invested',
                        'retail'
                    ].includes(id);

                    $('kc-stock-' + id).textContent = isMoney
                        ? currency(summary[key])
                        : number(summary[key]);
                });

                render();
                loaded = true;

                $('kc-stock-status').textContent =
                    'Actualizado: ' + date(new Date());

            } catch (error) {
                $('kc-stock-status').classList.add('kc-error');

                $('kc-stock-status').textContent = (
                    loaded
                        ? 'No se pudo actualizar. Los datos visibles ' +
                          'corresponden a la consulta anterior. '
                        : 'No se pudo cargar el inventario. '
                ) + error.message;

            } finally {
                busy = false;

                $('kc-stock-refresh').disabled = false;
                area.setAttribute('aria-busy', 'false');
            }
        }

        const dialog = document.createElement('dialog');

        dialog.className = 'kc-kardex-dialog';

        dialog.setAttribute(
            'aria-labelledby',
            'kc-kardex-title'
        );

        dialog.innerHTML = `
            <div class="kc-dialog-header">
                <h3 id="kc-kardex-title">Kardex</h3>

                <button
                    type="button"
                    class="kc-button kc-button-light"
                    id="kc-kardex-close"
                >
                    Cerrar
                </button>
            </div>

            <p class="kc-help">
                Hasta 500 movimientos recientes del producto.
            </p>

            <div
                id="kc-kardex-content"
                aria-live="polite"
            ></div>
        `;

        document.body.appendChild(dialog);

        $('kc-kardex-close').addEventListener('click', () => {
            dialog.close();
        });

        area.addEventListener('click', async event => {
            const button = event.target.closest(
                'button[data-kardex-id]'
            );

            if (!button || showKardexBusy) return;

            const product = products.find(item => {
                return String(item.id) === button.dataset.kardexId;
            });

            if (!product) return;

            showKardexBusy = true;

            $('kc-kardex-title').textContent =
                'Kardex · ' + product.name;

            $('kc-kardex-content').textContent =
                'Consultando movimientos…';

            if (!dialog.open) {
                dialog.showModal();
            }

            try {
                const rows = await api(
                    '/inventory/products/' +
                    encodeURIComponent(product.id) +
                    '/kardex'
                );

                if (!Array.isArray(rows)) {
                    throw new Error('Respuesta de Kardex inválida.');
                }

                $('kc-kardex-content').innerHTML = table(
                    [
                        'Fecha',
                        'Tipo',
                        'Cantidad',
                        'Costo unitario',
                        'Saldo de unidades',
                        'Referencia',
                        'Usuario'
                    ],
                    rows.map(row => [
                        esc(date(row.date)),
                        esc(row.type),
                        esc(number(row.qty)),
                        esc(currency(row.unit_cost)),
                        esc(number(row.balance_qty)),
                        esc(row.reference || '—'),
                        esc(row.user_name || '—')
                    ])
                );

            } catch (error) {
                $('kc-kardex-content').textContent =
                    'No se pudo consultar el Kardex: ' +
                    error.message;

            } finally {
                showKardexBusy = false;
            }
        });

        $('kc-stock-search').addEventListener('input', render);
        $('kc-stock-filter').addEventListener('change', render);
        $('kc-stock-refresh').addEventListener('click', load);

        window.actualizarInventarioDashboard = load;

        window.addEventListener('hashchange', () => {
            if (current() === 'inventario') {
                load();
            }
        });

        if (current() === 'inventario') {
            load();
        }
    }

    function start() {
        if (
            !$('dash-inicio') ||
            typeof api !== 'function'
        ) {
            return;
        }

        document.body.classList.add('kc-dashboard');

        document.querySelectorAll(
            '#main-menu-container .menu-btn'
        ).forEach(button => {
            if (button.matches('button, a')) return;

            button.setAttribute('role', 'button');
            button.tabIndex = 0;

            button.addEventListener('keydown', event => {
                if (
                    event.key === 'Enter' ||
                    event.key === ' '
                ) {
                    event.preventDefault();
                    button.click();
                }
            });
        });

        navigation();
        tabs();
        inventory();

        window.addEventListener('hashchange', navigation);

        /*
         * La sincronización original puede ocultar dash-inicio.
         * Se conserva visible el menú después de esa actualización.
         */
        new MutationObserver(navigation).observe(
            $('dash-inicio'),
            {
                attributes: true,
                attributeFilter: ['hidden']
            }
        );
    }

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            start,
            { once: true }
        );
    } else {
        start();
    }
})();