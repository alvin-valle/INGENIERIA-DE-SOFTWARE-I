'use strict';

(() => {
    if (window.crearGraficoERP) return;

    const instancias = new WeakMap();

    function obtenerLienzo(referencia) {
        const elemento =
            typeof referencia === 'string'
                ? document.getElementById(referencia)
                : referencia?.canvas || referencia;

        if (
            !elemento ||
            elemento.tagName !== 'CANVAS'
        ) {
            throw new Error(
                'No se encontró el lienzo de la gráfica.'
            );
        }

        return elemento;
    }

    function destruir(referencia) {
        const lienzo = obtenerLienzo(referencia);

        const registradas = new Set([
            instancias.get(lienzo),
            window.Chart?.getChart?.(lienzo)
        ]);

        for (const instancia of registradas) {
            if (instancia?.canvas) {
                instancia.destroy();
            }
        }

        instancias.delete(lienzo);
    }

    window.crearGraficoERP = (
        referencia,
        configuracion
    ) => {
        if (typeof window.Chart !== 'function') {
            throw new Error(
                'No se cargó la biblioteca local de gráficas.'
            );
        }

        const lienzo = obtenerLienzo(referencia);

        destruir(lienzo);

        const instancia = new window.Chart(
            lienzo,
            configuracion
        );

        instancias.set(lienzo, instancia);

        return instancia;
    };

    window.destruirGraficoERP = destruir;

    window.redimensionarGraficosERP = contenedor => {
        if (
            !contenedor ||
            typeof window.Chart !== 'function'
        ) {
            return;
        }

        for (
            const lienzo of
            contenedor.querySelectorAll('canvas')
        ) {
            const instancia =
                instancias.get(lienzo) ||
                window.Chart.getChart(lienzo);

            if (
                instancia?.canvas &&
                lienzo.getClientRects().length
            ) {
                instancia.resize();
            }
        }
    };
})();