'use strict';

window.Ops = (() => {
  const actions = new Map();

  let actionSequence = 0;

  const e = value => escapeHtml(
    String(value ?? '')
  );

  const canWrite = () => {
    return ['admin', 'superadmin'].includes(
      Auth.getUser()?.role
    );
  };

  const methodOptions = [
    ['efectivo', 'Efectivo'],
    ['transferencia', 'Transferencia'],
    ['tarjeta', 'Tarjeta']
  ];

  const paymentFields = [
    {
      name: 'payment_method',
      label: 'Forma de pago',
      options: methodOptions
    },
    {
      name: 'payment_reference',
      label: 'Referencia de tarjeta o transferencia',
      required: false,
      max: 120
    }
  ];

  function button(
    label,
    action,
    style = 'btn-outline'
  ) {
    const id = String(++actionSequence);

    actions.set(id, action);

    return `
      <button
        type="button"
        class="btn ${style} btn-sm"
        data-ops-action="${id}"
      >
        ${e(label)}
      </button>
    `;
  }

  document.addEventListener(
    'click',
    async event => {
      const control = event.target.closest(
        '[data-ops-action]'
      );

      if (!control) return;

      const action = actions.get(
        control.dataset.opsAction
      );

      if (!action) return;

      control.disabled = true;

      try {
        await action();
      } catch (error) {
        apiErrorToast(error);
      } finally {
        control.disabled = false;
      }
    }
  );

  function table(headers, rows) {
    const headings = headers
      .map(header => `
        <th scope="col">${e(header)}</th>
      `)
      .join('');

    const content = rows.length
      ? rows.map(row => `
          <tr>
            ${row.map(cell => `
              <td>${cell}</td>
            `).join('')}
          </tr>
        `).join('')
      : `
        <tr>
          <td
            class="ops-empty"
            colspan="${headers.length}"
          >
            Sin registros para mostrar.
          </td>
        </tr>
      `;

    return `
      <div class="ops-table-wrap">
        <table class="ops-table">
          <thead>
            <tr>${headings}</tr>
          </thead>
          <tbody>${content}</tbody>
        </table>
      </div>
    `;
  }

  function panel(title, body, controls = '') {
    return `
      <section class="ops-panel">
        <div class="ops-head">
          <h3>${e(title)}</h3>

          <div class="ops-actions">
            ${controls}
          </div>
        </div>

        ${body}
      </section>
    `;
  }

  function kpis(items) {
    return `
      <div class="ops-grid">
        ${items.map(([label, value]) => `
          <article class="ops-kpi">
            <small>${e(label)}</small>
            <strong>${e(value)}</strong>
          </article>
        `).join('')}
      </div>
    `;
  }

  function link(label, href) {
    return `
      <a
        class="btn btn-outline btn-sm"
        href="${e(href)}"
      >
        ${e(label)}
      </a>
    `;
  }

  function date(value) {
    if (!value) return '—';

    const parsed = new Date(value);

    if (!Number.isFinite(parsed.getTime())) {
      return String(value);
    }

    return parsed.toLocaleString(
      'es-NI',
      {
        timeZone: 'America/Managua'
      }
    );
  }

  function fieldHtml(field, initial) {
    const value =
      initial?.[field.name] ??
      field.value ??
      '';

    const required = field.required === false
      ? ''
      : 'required';

    let input;

    if (field.options) {
      input = `
        <select
          name="${e(field.name)}"
          ${required}
        >
          ${field.options.map(([key, label]) => `
            <option
              value="${e(key)}"
              ${
                String(value) === String(key)
                  ? 'selected'
                  : ''
              }
            >
              ${e(label)}
            </option>
          `).join('')}
        </select>
      `;
    } else if (field.type === 'textarea') {
      input = `
        <textarea
          name="${e(field.name)}"
          maxlength="${field.max || 5000}"
          ${required}
        >${e(value)}</textarea>
      `;
    } else {
      const numericAttributes =
        field.type === 'number'
          ? `
            min="${field.min ?? 0}"
            max="${field.max ?? 99999999}"
            step="${field.step ?? '0.01'}"
          `
          : `maxlength="${field.max || 150}"`;

      input = `
        <input
          name="${e(field.name)}"
          type="${e(field.type || 'text')}"
          value="${e(value)}"
          ${required}
          ${numericAttributes}
        >
      `;
    }

    return `
      <label
        class="ops-field ${
          field.type === 'textarea'
            ? 'full'
            : ''
        }"
      >
        <span>${e(field.label)}</span>
        ${input}
      </label>
    `;
  }

  function form(
    title,
    fields,
    initial,
    onSave,
    help = ''
  ) {
    const dialog = document.createElement(
      'dialog'
    );

    dialog.className = 'ops-dialog';

    dialog.innerHTML = `
      <form>
        <h2>${e(title)}</h2>

        ${
          help
            ? `<p class="ops-help">${e(help)}</p>`
            : ''
        }

        <div class="ops-form-grid">
          ${fields
            .map(field => fieldHtml(field, initial))
            .join('')}
        </div>

        <p
          class="ops-error"
          role="alert"
          hidden
        ></p>

        <div class="ops-actions">
          <button
            type="button"
            class="btn btn-outline"
            data-close
          >
            Cancelar
          </button>

          <button
            type="submit"
            class="btn btn-primary"
          >
            Guardar
          </button>
        </div>
      </form>
    `;

    document.body.append(dialog);

    const formElement = dialog.querySelector(
      'form'
    );

    const saveButton = dialog.querySelector(
      '[type="submit"]'
    );

    const closeButton = dialog.querySelector(
      '[data-close]'
    );

    const errorBox = dialog.querySelector(
      '[role="alert"]'
    );

    let busy = false;

    dialog.addEventListener(
      'close',
      () => dialog.remove()
    );

    dialog.addEventListener(
      'cancel',
      event => {
        if (busy) {
          event.preventDefault();
        }
      }
    );

    closeButton.addEventListener(
      'click',
      () => {
        if (!busy) {
          dialog.close();
        }
      }
    );

    formElement.addEventListener(
      'submit',
      async event => {
        event.preventDefault();

        if (
          busy ||
          !formElement.reportValidity()
        ) {
          return;
        }

        busy = true;

        saveButton.disabled = true;
        closeButton.disabled = true;

        saveButton.textContent = 'Guardando…';

        errorBox.hidden = true;

        try {
          const body = Object.fromEntries(
            new FormData(formElement)
          );

          await onSave(body);

          dialog.close();
        } catch (error) {
          errorBox.textContent = error.message;
          errorBox.hidden = false;
        } finally {
          busy = false;

          saveButton.disabled = false;
          closeButton.disabled = false;

          saveButton.textContent = 'Guardar';
        }
      }
    );

    dialog.showModal();
  }

  function show(title, html) {
    const dialog = document.createElement(
      'dialog'
    );

    dialog.className = 'ops-dialog';

    dialog.innerHTML = `
      <div class="ops-dialog-content">
        <h2>${e(title)}</h2>

        ${html}

        <div class="ops-actions">
          <button
            type="button"
            class="btn btn-outline"
            data-close
          >
            Cerrar
          </button>
        </div>
      </div>
    `;

    document.body.append(dialog);

    dialog.querySelector('[data-close]')
      .addEventListener(
        'click',
        () => dialog.close()
      );

    dialog.addEventListener(
      'close',
      () => dialog.remove()
    );

    dialog.showModal();
  }

  async function postPayment(path, body) {
    const userId = Auth.getUser()?.id;

    const storageKey =
      `kc_pending_${userId}_${path}`;

    let pending = null;

    const stored = sessionStorage.getItem(
      storageKey
    );

    if (stored) {
      try {
        pending = JSON.parse(stored);
      } catch {
        throw new Error(
          'No se pudo leer el intento pendiente. ' +
          'Revisa el historial de caja antes de continuar.'
        );
      }
    }

    if (
      pending &&
      JSON.stringify(pending.body) !==
      JSON.stringify(body)
    ) {
      throw new Error(
        'Hay un intento pendiente con otros datos. ' +
        'Revisa su resultado en caja y reintenta ' +
        'con los datos originales.'
      );
    }

    if (!pending) {
      if (!globalThis.crypto?.randomUUID) {
        throw new Error(
          'Para registrar pagos utiliza HTTPS o localhost.'
        );
      }

      pending = {
        key: crypto.randomUUID(),
        body
      };

      sessionStorage.setItem(
        storageKey,
        JSON.stringify(pending)
      );
    }

    try {
      const result = await api(
        path,
        {
          method: 'POST',

          body: {
            ...pending.body,
            request_key: pending.key
          }
        }
      );

      sessionStorage.removeItem(storageKey);

      return result;
    } catch (error) {
      // Un rechazo conocido permite corregir los datos.
      // Un error de conexión o 5xx conserva la clave.
      if (
        error.status >= 400 &&
        error.status < 500
      ) {
        sessionStorage.removeItem(storageKey);
      }

      throw error;
    }
  }

  async function shift() {
    const result = await api(
      '/finance/cash-shifts/current'
    );

    if (!result.shift) {
      throw new Error(
        'Abre tu turno en Caja chica antes de registrar el pago.'
      );
    }

    if (!result.reconciled) {
      throw new Error(
        'El turno requiere conciliación en Control de caja.'
      );
    }

    return result.shift.id;
  }

  async function loadInto(root, action) {
    root.setAttribute(
      'aria-busy',
      'true'
    );

    try {
      await action();
    } catch (error) {
      root.innerHTML = `
        <div
          class="ops-error"
          role="alert"
        >
          ${e(error.message)}
        </div>

        ${button(
          'Reintentar',
          () => loadInto(root, action)
        )}
      `;
    } finally {
      root.setAttribute(
        'aria-busy',
        'false'
      );
    }
  }

  return {
    e,
    button,
    table,
    panel,
    kpis,
    link,
    date,
    form,
    show,
    paymentFields,
    methodOptions,
    postPayment,
    shift,
    canWrite,
    loadInto
  };
})();