'use strict';

(() => {
    const base = '/sincronizacion/expedientes';
    const $ = id => document.getElementById(id);

    const escapar = valor => String(valor ?? '—').replace(
        /[&<>"']/g,
        caracter => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[caracter])
    );

    const dinero = valor =>
        valor == null || valor === ''
            ? '—'
            : 'C$ ' + Number(valor).toLocaleString(
                'es-NI',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );

    const administrador = () => [
        'admin',
        'superadmin'
    ].includes(Auth.getUser()?.role);

    const estado = {
        pagina: 1,
        buscar: '',
        empleados: [],
        total: 0,
        detalle: null,
        ventana: null,
        publicidades: [],
        preparada: null
    };

    let iniciado = false;
    let consultaLista = 0;
    let consultaDetalle = 0;
    let observadorEmpleados = null;

    function aviso(mensaje, error = false) {
        const nodo =
            $('erp-complementos-aviso') ||
            document.createElement('p');

        nodo.id = 'erp-complementos-aviso';
        nodo.className = 'erp-aviso' + (
            error ? ' erp-aviso-error' : ''
        );

        nodo.setAttribute('role', 'status');
        nodo.textContent = mensaje;

        const destino =
            [...document.querySelectorAll('dialog[open]')].at(-1) ||
            $('page-content') ||
            document.body;

        if (nodo.parentElement !== destino) {
            destino.prepend(nodo);
        }
    }

    function accion(texto, tipo, id = '') {
        return (
            '<button type="button" ' +
            'class="erp-boton" ' +
            'data-exp-accion="' + tipo + '" ' +
            'data-id="' + escapar(id) + '">' +
                escapar(texto) +
            '</button>'
        );
    }

    function tabla(titulos, filas) {
        return (
            '<div class="erp-tabla"><table>' +
                '<thead><tr>' +
                    titulos.map(titulo => {
                        return '<th>' + escapar(titulo) + '</th>';
                    }).join('') +
                '</tr></thead>' +
                '<tbody>' +
                    (
                        filas.length
                            ? filas.map(fila => {
                                return '<tr>' + fila.map(
                                    celda => '<td>' + celda + '</td>'
                                ).join('') + '</tr>';
                            }).join('')
                            : (
                                '<tr><td colspan="' +
                                titulos.length +
                                '">No hay registros guardados.</td></tr>'
                            )
                    ) +
                '</tbody>' +
            '</table></div>'
        );
    }

    async function refrescar(id = null) {
        if (
            typeof window.actualizarERPTrasCambio ===
            'function'
        ) {
            await window.actualizarERPTrasCambio();
        } else {
            await Promise.all([
                cargarEmpleados(),
                cargarPublicidades()
            ]);
        }

        if (
            id &&
            estado.ventana?.open &&
            estado.detalle?.empleado.id === id
        ) {
            await mostrarExpediente(id);
        }
    }

    function modal(
        titulo,
        contenido,
        clase = ''
    ) {
        const ventana = document.createElement('dialog');

        ventana.className = 'erp-dialogo ' + clase;

        ventana.innerHTML =
            '<header class="erp-dialogo-cabecera">' +
                '<h2>' + escapar(titulo) + '</h2>' +
                '<button type="button" ' +
                    'class="erp-boton" data-cerrar>Cerrar</button>' +
            '</header>' +
            contenido;

        document.body.append(ventana);

        ventana.querySelector('[data-cerrar]').onclick = () => {
            ventana.close();
        };

        ventana.addEventListener(
            'close',
            () => ventana.remove(),
            { once: true }
        );

        ventana.showModal();

        return ventana;
    }

    function entrada(campo, valor = '') {
        const atributos =
            'name="' + campo.nombre + '" ' +
            (campo.obligatorio ? 'required ' : '');

        let control;

        if (campo.opciones) {
            control =
                '<select ' + atributos + '>' +
                    campo.opciones.map(([valorOpcion, texto]) => {
                        return (
                            '<option value="' +
                            escapar(valorOpcion) + '" ' +
                            (
                                String(valor) === String(valorOpcion)
                                    ? 'selected'
                                    : ''
                            ) +
                            '>' +
                                escapar(texto) +
                            '</option>'
                        );
                    }).join('') +
                '</select>';

        } else if (campo.tipo === 'textarea') {
            control =
                '<textarea ' + atributos +
                    'maxlength="2000">' +
                    escapar(valor ?? '') +
                '</textarea>';

        } else {
            control =
                '<input ' + atributos +
                'type="' + (campo.tipo || 'text') + '" ' +
                'value="' + escapar(valor ?? '') + '" ' +
                (
                    campo.tipo === 'number'
                        ? 'min="0" step="0.01"'
                        : 'maxlength="2000"'
                ) +
                '>';
        }

        return (
            '<label class="erp-campo">' +
                escapar(campo.etiqueta) +
                control +
            '</label>'
        );
    }

    function formulario(
        titulo,
        campos,
        valores,
        guardar
    ) {
        const ventana = modal(
            titulo,
            '<form class="erp-formulario">' +
                campos.map(campo => {
                    return entrada(
                        campo,
                        valores[campo.nombre] ?? ''
                    );
                }).join('') +
                '<p class="erp-error-formulario" role="alert"></p>' +
                '<button type="submit" ' +
                    'class="erp-boton erp-boton-principal">' +
                    'Guardar' +
                '</button>' +
            '</form>'
        );

        const form = ventana.querySelector('form');
        let ocupado = false;

        ventana.addEventListener('cancel', evento => {
            if (ocupado) evento.preventDefault();
        });

        ventana.querySelector('[data-cerrar]').onclick = () => {
            if (!ocupado) ventana.close();
        };

        form.onsubmit = async evento => {
            evento.preventDefault();

            if (ocupado) return;

            ocupado = true;

            form.querySelector(
                '[type="submit"]'
            ).disabled = true;

            try {
                const resultado = await guardar(
                    Object.fromEntries(
                        new FormData(form)
                    )
                );

                if (resultado !== false) {
                    ventana.close();
                }
            } catch (error) {
                form.querySelector(
                    '[role="alert"]'
                ).textContent = error.message;
            } finally {
                ocupado = false;

                form.querySelector(
                    '[type="submit"]'
                ).disabled = false;
            }
        };

        return ventana;
    }

    function solicitarArchivo(
        aceptados,
        seleccionado
    ) {
        if (!window.confirm(
            '¿Autorizas abrir el selector del dispositivo? ' +
            'Solo se leerá el archivo que selecciones.'
        )) {
            return false;
        }

        const entrada = document.createElement('input');

        entrada.type = 'file';
        entrada.accept = aceptados;
        entrada.hidden = true;

        document.body.append(entrada);

        entrada.addEventListener(
            'cancel',
            () => entrada.remove(),
            { once: true }
        );

        entrada.onchange = () => {
            const archivo = entrada.files?.[0];

            entrada.remove();

            if (!archivo) return;

            if (archivo.size > 10485760) {
                aviso(
                    'El máximo permitido es 10 MB.',
                    true
                );

                return;
            }

            Promise.resolve()
                .then(() => seleccionado(archivo))
                .catch(error => {
                    aviso(error.message, true);
                });
        };

        entrada.click();

        return true;
    }

    async function descargar(id, nombre) {
        const contenido = await api(
            base + '/archivos/' +
            encodeURIComponent(id)
        );

        const url = URL.createObjectURL(contenido);
        const enlace = document.createElement('a');

        enlace.href = url;
        enlace.download = nombre;

        document.body.append(enlace);
        enlace.click();
        enlace.remove();

        setTimeout(() => {
            URL.revokeObjectURL(url);
        }, 1000);
    }

    function prepararEmpleados() {
        const destino = $('rh-empleados');

        if (
            !destino ||
            $('erp-expedientes')
        ) {
            return;
        }

        const seccion = document.createElement('section');

        seccion.id = 'erp-expedientes';
        seccion.className = 'erp-seccion';

        seccion.innerHTML =
            '<header class="erp-encabezado-modulo">' +
                '<div>' +
                    '<span class="erp-etiqueta">' +
                        'RECURSOS HUMANOS' +
                    '</span>' +
                    '<h3>Expedientes digitales</h3>' +
                    '<p>' +
                        'Registros actuales y anteriores. ' +
                        'Vincula los anteriores para completar ' +
                        'su expediente, sin trasladar pagos.' +
                    '</p>' +
                '</div>' +
                '<div>' +
                    (
                        administrador()
                            ? accion('Nuevo expediente', 'crear') +
                              accion(
                                  'Vincular registro anterior',
                                  'vincular'
                              )
                            : ''
                    ) +
                    accion('Actualizar', 'actualizar') +
                '</div>' +
            '</header>' +

            '<form id="erp-busqueda-empleados" class="erp-barra">' +
                '<label>Nombre o cargo' +
                    '<input name="buscar" type="search" ' +
                    'maxlength="100" placeholder="Buscar empleado">' +
                '</label>' +
                '<button class="erp-boton" type="submit">' +
                    'Buscar' +
                '</button>' +
            '</form>' +

            '<p id="erp-estado-empleados" role="status"></p>' +
            '<div id="erp-lista-empleados"></div>' +

            '<div class="erp-barra">' +
                '<button id="erp-empleados-anterior" ' +
                    'class="erp-boton">Anterior</button>' +
                '<span id="erp-empleados-pagina"></span>' +
                '<button id="erp-empleados-siguiente" ' +
                    'class="erp-boton">Siguiente</button>' +
            '</div>';

        destino.prepend(seccion);

        if ($('tbody-emp-activos')) {
            $('erp-lista-empleados').remove();

            observadorEmpleados = new MutationObserver(() => {
                cargarEmpleados().catch(error => {
                    aviso(error.message, true);
                });
            });

            observadorEmpleados.observe(
                $('tbody-emp-activos'),
                { childList: true }
            );
        }

        window.abrirModalEmp = () => administrador()
            ? editarEmpleado()
            : aviso(
                'Esta cuenta tiene acceso de consulta.',
                true
            );

        $('erp-busqueda-empleados').onsubmit = evento => {
            evento.preventDefault();

            estado.buscar = new FormData(
                evento.target
            ).get('buscar');

            estado.pagina = 1;

            cargarEmpleados().catch(error => {
                aviso(error.message, true);
            });
        };

        $('erp-empleados-anterior').onclick = () => {
            estado.pagina = Math.max(
                1,
                estado.pagina - 1
            );

            cargarEmpleados().catch(error => {
                aviso(error.message, true);
            });
        };

        $('erp-empleados-siguiente').onclick = () => {
            estado.pagina++;

            cargarEmpleados().catch(error => {
                aviso(error.message, true);
            });
        };
    }

    async function cargarEmpleados() {
        if (!$('erp-expedientes')) return;

        const turno = ++consultaLista;

        $('erp-estado-empleados').textContent =
            'Consultando empleados…';

        try {
            const datos = await api(
                base + '/empleados?' +
                new URLSearchParams({
                    pagina: String(estado.pagina),
                    buscar: estado.buscar
                })
            );

            if (turno !== consultaLista) return;

            estado.empleados = datos.filas;
            estado.total = Number(datos.total);

            const titulos = [
                'Empleado',
                'Cargo',
                'Ingreso',
                'Salario base',
                'Estado / expediente'
            ];

            const filas = datos.filas.map(empleado => [
                '<strong>' +
                    escapar(empleado.nombre) +
                '</strong>' +
                '<small>' +
                    (
                        empleado.origen === 'anterior'
                            ? 'Registro anterior #'
                            : 'Empleado #'
                    ) +
                    empleado.id +
                '</small>',

                escapar(empleado.cargo),
                escapar(empleado.fecha_ingreso),
                dinero(empleado.salario),

                '<span class="erp-insignia">' +
                    (
                        empleado.activo === null
                            ? 'Sin estado'
                            : empleado.activo
                                ? 'Activo'
                                : 'Inactivo'
                    ) +
                '</span>' +
                (
                    administrador()
                        ? (
                            empleado.origen === 'anterior'
                                ? accion(
                                    'Completar / vincular',
                                    'vincular-uno',
                                    empleado.id
                                )
                                : (
                                    accion(
                                        'Abrir expediente',
                                        'ver',
                                        empleado.id
                                    ) +
                                    accion(
                                        'Editar',
                                        'editar',
                                        empleado.id
                                    ) +
                                    (
                                        empleado.activo
                                            ? accion(
                                                'Desactivar',
                                                'desactivar',
                                                empleado.id
                                            )
                                            : ''
                                    )
                                )
                        )
                        : ''
                )
            ]);

            const cuerpo = $('tbody-emp-activos');

            if (cuerpo) {
                observadorEmpleados?.disconnect();

                const directorio = cuerpo.closest('table');

                const cabecera =
                    directorio.tHead ||
                    directorio.createTHead();

                cabecera.innerHTML =
                    '<tr>' +
                    titulos.map(titulo => {
                        return '<th>' +
                            escapar(titulo) +
                        '</th>';
                    }).join('') +
                    '</tr>';

                cuerpo.innerHTML = filas.length
                    ? filas.map(fila => {
                        return '<tr>' + fila.map(
                            celda => '<td>' + celda + '</td>'
                        ).join('') + '</tr>';
                    }).join('')
                    : (
                        '<tr><td colspan="5">' +
                            'No hay empleados integrados. ' +
                            'Puedes crear uno o vincular ' +
                            'un registro anterior.' +
                        '</td></tr>'
                    );

                if (
                    !directorio.parentElement.classList.contains(
                        'erp-tabla'
                    )
                ) {
                    const contenedor =
                        document.createElement('div');

                    contenedor.className = 'erp-tabla';

                    directorio.before(contenedor);
                    contenedor.append(directorio);
                }

                observadorEmpleados?.observe(
                    cuerpo,
                    { childList: true }
                );
            } else {
                $('erp-lista-empleados').innerHTML =
                    tabla(titulos, filas);
            }

            if ($('rrhh-total')) {
                $('rrhh-total').textContent =
                    datos.resumen.activos;

                $('rrhh-total').previousElementSibling.textContent =
                    'Empleados integrados activos';
            }

            if ($('rrhh-prom')) {
                $('rrhh-prom').textContent = dinero(
                    datos.resumen.salario_promedio
                );

                $('rrhh-prom').previousElementSibling.textContent =
                    'Sueldo base promedio';
            }

            if ($('kpi-pasivo-laboral')) {
                $('kpi-pasivo-laboral').textContent =
                    'Requiere evaluación';
            }

            $('erp-empleados-pagina').textContent =
                'Página ' + datos.pagina +
                ' · ' + datos.total + ' empleados';

            $('erp-empleados-anterior').disabled =
                datos.pagina <= 1;

            $('erp-empleados-siguiente').disabled =
                datos.pagina * 50 >= estado.total;

            $('erp-estado-empleados').textContent =
                'Información actualizada desde la base de datos.';

        } catch (error) {
            if (turno === consultaLista) {
                $('erp-estado-empleados').textContent =
                    'No se pudo actualizar. Se conserva ' +
                    'la última consulta visible.';
            }

            throw error;
        }
    }

    const camposEmpleado = [
        {
            nombre: 'nombre',
            etiqueta: 'Nombre completo',
            obligatorio: true
        },
        {
            nombre: 'cargo',
            etiqueta: 'Puesto / cargo',
            obligatorio: true
        },
        {
            nombre: 'salario',
            etiqueta: 'Sueldo base registrado en Contabilidad',
            tipo: 'number',
            obligatorio: true
        },
        {
            nombre: 'fecha_ingreso',
            etiqueta: 'Fecha de ingreso',
            tipo: 'date'
        },
        {
            nombre: 'activo',
            etiqueta: 'Estado',
            opciones: [
                ['true', 'Activo'],
                ['false', 'Inactivo']
            ]
        },
        {
            nombre: 'fecha_nacimiento',
            etiqueta: 'Fecha de nacimiento',
            tipo: 'date'
        },
        {
            nombre: 'telefono',
            etiqueta: 'Teléfono'
        },
        {
            nombre: 'correo',
            etiqueta: 'Correo electrónico',
            tipo: 'email'
        },
        {
            nombre: 'direccion',
            etiqueta: 'Dirección',
            tipo: 'textarea'
        },
        {
            nombre: 'departamento',
            etiqueta: 'Departamento'
        },
        {
            nombre: 'tipo_contrato',
            etiqueta: 'Tipo de contrato'
        },
        {
            nombre: 'horario',
            etiqueta: 'Horario'
        },
        {
            nombre: 'bono_fijo',
            etiqueta: 'Bono fijo para preparar nómina (opcional)',
            tipo: 'number'
        },
        {
            nombre: 'deduccion_fija',
            etiqueta: 'Deducción fija para preparar nómina (opcional)',
            tipo: 'number'
        },
        {
            nombre: 'observaciones',
            etiqueta: 'Observaciones',
            tipo: 'textarea'
        }
    ];

    async function editarEmpleado(id = null) {
        if ($('erp-formulario-empleado')) {
            aviso(
                'Ya hay un expediente en edición. ' +
                'Guarda o cierra ese formulario.'
            );

            return;
        }

        const detalle = id
            ? await api(
                base + '/empleados/' + id
            )
            : null;

        if ($('erp-formulario-empleado')) {
            aviso(
                'Ya hay un expediente en edición. ' +
                'Guarda o cierra ese formulario.'
            );

            return;
        }

        const valores = {
            ...(detalle?.datos || {}),
            ...(detalle?.empleado || {}),
            activo: String(
                detalle?.empleado.activo ?? true
            )
        };

        const ventana = modal(
            id
                ? 'Editar expediente'
                : 'Nuevo expediente',

            '<form class="erp-formulario" ' +
                'id="erp-formulario-empleado">' +

                '<fieldset class="erp-grupo">' +
                    '<legend>' +
                        'Datos personales y laborales' +
                    '</legend>' +
                    '<div class="erp-cuadricula-formulario">' +
                        camposEmpleado.map(campo => {
                            return entrada(
                                campo,
                                valores[campo.nombre] ?? ''
                            );
                        }).join('') +
                    '</div>' +
                '</fieldset>' +

                '<fieldset class="erp-grupo">' +
                    '<legend>' +
                        'Identificación y cuentas bancarias' +
                    '</legend>' +
                    '<p>' +
                        'Al editar, los datos reservados se ' +
                        'conservan hasta que elijas modificarlos.' +
                    '</p>' +
                    '<button type="button" class="erp-boton" ' +
                        'id="erp-editar-reservados">' +
                        (
                            id
                                ? 'Consultar y editar datos reservados'
                                : 'Agregar identificaciones y cuentas'
                        ) +
                    '</button>' +

                    '<div id="erp-formulario-reservados" hidden>' +
                        entrada({
                            nombre: 'cedula',
                            etiqueta: 'Identificación oficial / cédula'
                        }) +
                        entrada({
                            nombre: 'pasaporte',
                            etiqueta: 'Pasaporte'
                        }) +
                        '<div id="erp-cuentas"></div>' +
                        '<button type="button" class="erp-boton" ' +
                            'id="erp-agregar-cuenta">' +
                            'Agregar cuenta bancaria' +
                        '</button>' +
                    '</div>' +
                '</fieldset>' +

                '<p class="erp-error-formulario" role="alert"></p>' +

                '<button type="submit" ' +
                    'class="erp-boton erp-boton-principal">' +
                    'Guardar expediente' +
                '</button>' +
            '</form>',

            'erp-dialogo-amplio'
        );

        const form = ventana.querySelector('form');

        let editarReservados = false;
        let ocupado = false;

        const agregarCuenta = (cuenta = {}) => {
            const fila = document.createElement('div');

            fila.className = 'erp-cuenta';

            fila.innerHTML =
                '<label>Banco' +
                    '<input data-banco maxlength="120" required>' +
                '</label>' +

                '<label>Titular' +
                    '<input data-titular maxlength="150">' +
                '</label>' +

                '<label>Número de cuenta' +
                    '<input data-numero maxlength="80" ' +
                    'required autocomplete="off">' +
                '</label>' +

                '<button type="button" class="erp-boton">' +
                    'Quitar cuenta' +
                '</button>';

            fila.querySelector(
                '[data-banco]'
            ).value = cuenta.banco || '';

            fila.querySelector(
                '[data-titular]'
            ).value = cuenta.titular || '';

            fila.querySelector(
                '[data-numero]'
            ).value = cuenta.numero || '';

            fila.querySelector('button').onclick = () => {
                fila.remove();
            };

            $('erp-cuentas').append(fila);
        };

        $('erp-agregar-cuenta').onclick = () => {
            if (
                $('erp-cuentas').children.length >= 10
            ) {
                aviso(
                    'Se admiten hasta diez cuentas.',
                    true
                );

                return;
            }

            agregarCuenta();
        };

        $('erp-editar-reservados').onclick = async () => {
            const boton = $('erp-editar-reservados');

            boton.disabled = true;

            try {
                const datos = id
                    ? await api(
                        base + '/empleados/' +
                        id + '/reservados'
                    )
                    : { cuentas: [] };

                form.elements.cedula.value =
                    datos.cedula || '';

                form.elements.pasaporte.value =
                    datos.pasaporte || '';

                $('erp-cuentas').replaceChildren();

                (datos.cuentas || []).forEach(
                    agregarCuenta
                );

                $('erp-formulario-reservados').hidden = false;

                editarReservados = true;
                boton.hidden = true;

            } catch (error) {
                form.querySelector(
                    '[role="alert"]'
                ).textContent = error.message;

            } finally {
                boton.disabled = false;
            }
        };

        ventana.addEventListener('cancel', evento => {
            if (ocupado) evento.preventDefault();
        });

        ventana.querySelector('[data-cerrar]').onclick = () => {
            if (!ocupado) ventana.close();
        };

        form.onsubmit = async evento => {
            evento.preventDefault();

            if (ocupado) return;

            ocupado = true;

            form.querySelector(
                '[type="submit"]'
            ).disabled = true;

            try {
                const campos = Object.fromEntries(
                    new FormData(form)
                );

                const datos = {};

                for (
                    const campo
                    of camposEmpleado.slice(5)
                ) {
                    datos[campo.nombre] =
                        campos[campo.nombre];
                }

                const cuerpo = {
                    nombre: campos.nombre,
                    cargo: campos.cargo,
                    salario: campos.salario,
                    fecha_ingreso: campos.fecha_ingreso,
                    activo: campos.activo === 'true',
                    datos,

                    ...(
                        detalle
                            ? {
                                revision:
                                    detalle.empleado.revision
                            }
                            : {}
                    )
                };

                if (editarReservados) {
                    cuerpo.reservados = {
                        cedula: campos.cedula,
                        pasaporte: campos.pasaporte,

                        cuentas: [
                            ...$('erp-cuentas').children
                        ].map(fila => ({
                            banco: fila.querySelector(
                                '[data-banco]'
                            ).value,

                            titular: fila.querySelector(
                                '[data-titular]'
                            ).value,

                            numero: fila.querySelector(
                                '[data-numero]'
                            ).value
                        }))
                    };
                }

                const resultado = await api(
                    base + '/empleados' +
                    (id ? '/' + id : ''),
                    {
                        method: id
                            ? 'PUT'
                            : 'POST',
                        body: cuerpo
                    }
                );

                ventana.close();

                await refrescar(resultado.id);

                aviso(
                    'Expediente guardado. El sueldo base ' +
                    'se mantiene en la misma fuente de Contabilidad.'
                );

            } catch (error) {
                form.querySelector(
                    '[role="alert"]'
                ).textContent = error.message;

            } finally {
                ocupado = false;

                form.querySelector(
                    '[type="submit"]'
                ).disabled = false;
            }
        };
    }

    async function mostrarExpediente(id) {
        const turno = ++consultaDetalle;

        const detalle = await api(
            base + '/empleados/' + id
        );

        if (turno !== consultaDetalle) return;

        estado.detalle = detalle;

        if (!estado.ventana?.open) {
            estado.ventana = modal(
                'Expediente digital',
                '<div id="erp-contenido-expediente"></div>',
                'erp-dialogo-amplio'
            );

            estado.ventana.addEventListener(
                'close',
                () => {
                    estado.detalle = null;
                    estado.ventana = null;
                },
                { once: true }
            );
        }

        const empleado = detalle.empleado;
        const datos = detalle.datos;

        const campos = [
            ['Nombre', empleado.nombre],
            ['Puesto', empleado.cargo],
            ['Ingreso', empleado.fecha_ingreso],
            ['Departamento', datos.departamento],
            ['Contrato', datos.tipo_contrato],
            ['Horario', datos.horario],
            ['Teléfono', datos.telefono],
            ['Correo', datos.correo],
            ['Dirección', datos.direccion],
            ['Identificación', detalle.mascaras.cedula],
            ['Pasaporte', detalle.mascaras.pasaporte]
        ];

        const pagos = tabla(
            [
                'Período',
                'Concepto',
                'Neto pagado',
                'Método',
                'Gasto / turno'
            ],
            detalle.pagos.map(pago => [
                escapar(pago.period),
                escapar(pago.description),
                dinero(pago.amount),
                escapar(pago.payment_method),
                '#' + pago.expense_id +
                ' / ' +
                escapar(pago.shift_id)
            ])
        );

        const borradores = detalle.expedientes.filter(
            expediente => expediente.kind === 'payroll'
        );

        const contratos = detalle.expedientes.filter(
            expediente => expediente.kind === 'contract'
        );

        const ausencias = detalle.expedientes.filter(
            expediente => expediente.kind === 'leave'
        );

        const incidencias = tabla(
            [
                'Tipo',
                'Desde / hasta',
                'Horas',
                'Estado',
                'Detalle',
                'Acciones'
            ],
            detalle.incidencias.map(incidencia => [
                escapar(incidencia.tipo),
                escapar(incidencia.desde) +
                ' → ' +
                escapar(incidencia.hasta),
                escapar(incidencia.horas),
                escapar(incidencia.estado),
                escapar(incidencia.descripcion),

                accion(
                    'Editar',
                    'editar-incidencia',
                    incidencia.id
                ) +

                accion(
                    'Retirar',
                    'retirar-incidencia',
                    incidencia.id
                )
            ])
        );

        const documentos = tabla(
            [
                'Documento',
                'Categoría',
                'Tamaño',
                'Acciones'
            ],
            detalle.documentos.map(archivo => [
                escapar(archivo.nombre_original),
                escapar(archivo.categoria),
                (archivo.tamanio / 1024).toFixed(1) + ' KB',

                accion(
                    'Descargar',
                    'documento',
                    archivo.id
                ) +

                accion(
                    'Retirar',
                    'retirar-documento',
                    archivo.id
                )
            ])
        );

        $('erp-contenido-expediente').innerHTML =
            '<div class="erp-resumen-persona">' +
                '<div>' +
                    '<span class="erp-etiqueta">' +
                        'EMPLEADO #' + empleado.id +
                    '</span>' +
                    '<h3>' + escapar(empleado.nombre) + '</h3>' +
                    '<p>' +
                        escapar(empleado.cargo) +
                        ' · ' +
                        (
                            empleado.activo
                                ? 'Activo'
                                : 'Inactivo'
                        ) +
                    '</p>' +
                '</div>' +

                '<strong>' +
                    dinero(empleado.salario) +
                    '<small>Sueldo base de Contabilidad</small>' +
                '</strong>' +
            '</div>' +

            '<nav class="erp-pestanas" ' +
                'aria-label="Secciones del expediente">' +
                [
                    ['personal', 'Datos y contrato'],
                    ['nomina', 'Nómina'],
                    ['asistencia', 'Asistencia e incidencias'],
                    ['documentos', 'Documentos']
                ].map(([clave, titulo], indice) => {
                    return (
                        '<button type="button" ' +
                            'class="erp-boton" ' +
                            'data-pestana="' + clave + '" ' +
                            'aria-pressed="' + (indice === 0) + '">' +
                            titulo +
                        '</button>'
                    );
                }).join('') +
            '</nav>' +

            '<section data-panel="personal">' +
                '<div class="erp-ficha">' +
                    campos.map(([titulo, valor]) => {
                        return (
                            '<div>' +
                                '<span>' + titulo + '</span>' +
                                '<strong>' +
                                    escapar(valor) +
                                '</strong>' +
                            '</div>'
                        );
                    }).join('') +
                '</div>' +

                '<h4>Cuentas registradas</h4>' +

                tabla(
                    ['Banco', 'Cuenta'],
                    (detalle.mascaras.cuentas || []).map(
                        cuenta => [
                            escapar(cuenta.banco),
                            escapar(cuenta.numero)
                        ]
                    )
                ) +

                '<h4>Contratos del módulo legal</h4>' +

                tabla(
                    [
                        'Registro',
                        'Tipo',
                        'Vigencia'
                    ],
                    contratos.map(contrato => [
                        '#' + contrato.id,
                        escapar(contrato.data['con-tipo']),
                        escapar(contrato.data['con-start']) +
                        ' → ' +
                        escapar(
                            contrato.data['con-end'] ||
                            'Sin fecha final'
                        )
                    ])
                ) +

                '<a class="erp-boton" href="/dashboard.html#rrhh">' +
                    'Administrar en Marco Legal / Contratos' +
                '</a>' +

                accion(
                    'Editar expediente',
                    'editar',
                    empleado.id
                ) +
            '</section>' +

            '<section data-panel="nomina" hidden>' +
                '<p>' +
                    'Los pagos se consultan en Contabilidad; ' +
                    'no se crean pagos al guardar el expediente.' +
                '</p>' +

                '<div class="erp-ficha">' +
                    '<div>' +
                        '<span>Bono fijo para preparar nómina</span>' +
                        '<strong>' +
                            dinero(datos.bono_fijo) +
                        '</strong>' +
                    '</div>' +
                    '<div>' +
                        '<span>Deducción fija para preparar nómina</span>' +
                        '<strong>' +
                            dinero(datos.deduccion_fija) +
                        '</strong>' +
                    '</div>' +
                '</div>' +

                '<h4>Pagos confirmados</h4>' +
                pagos +

                '<h4>Borradores existentes</h4>' +

                tabla(
                    ['Registro', 'Período', 'Importe'],
                    borradores.map(borrador => [
                        '#' + borrador.id,
                        escapar(
                            borrador.data['nom-period']
                        ),
                        dinero(borrador.amount)
                    ])
                ) +

                '<h4>Nómina anterior vinculada</h4>' +

                tabla(
                    [
                        'Registro',
                        'Bruto',
                        'Deducciones',
                        'Neto',
                        'Fecha'
                    ],
                    detalle.historico.nomina.map(fila => [
                        '#' + fila.id,
                        dinero(fila.bruto),
                        dinero(fila.tot_ded),
                        dinero(fila.neto),
                        escapar(
                            String(fila.fecha || '').slice(0, 10)
                        )
                    ])
                ) +

                '<a class="erp-boton" ' +
                    'href="/dashboard.html#contabilidad">' +
                    'Abrir Contabilidad' +
                '</a>' +
            '</section>' +

            '<section data-panel="asistencia" hidden>' +
                accion(
                    'Registrar incidencia',
                    'nueva-incidencia',
                    empleado.id
                ) +

                incidencias +

                '<h4>' +
                    'Vacaciones y ausencias del módulo existente' +
                '</h4>' +

                tabla(
                    [
                        'Registro',
                        'Tipo',
                        'Fechas',
                        'Estado'
                    ],
                    ausencias.map(ausencia => [
                        '#' + ausencia.id,
                        escapar(ausencia.data['per-tipo']),
                        escapar(ausencia.data['per-start']) +
                        ' → ' +
                        escapar(ausencia.data['per-end']),
                        escapar(ausencia.data['per-status'])
                    ])
                ) +

                '<h4>Permisos anteriores vinculados</h4>' +

                tabla(
                    ['Tipo', 'Fechas', 'Estado'],
                    detalle.historico.permisos.map(permiso => [
                        escapar(permiso.tip),
                        escapar(permiso.fec),
                        escapar(permiso.estado)
                    ])
                ) +

                '<a class="erp-boton" href="/dashboard.html#rrhh">' +
                    'Administrar vacaciones en Ausencias' +
                '</a>' +
            '</section>' +

            '<section data-panel="documentos" hidden>' +
                accion(
                    'Subir documento',
                    'subir-documento',
                    empleado.id
                ) +

                '<p>PDF, PNG o JPG. Máximo 10 MB por archivo.</p>' +

                documentos +

                '<h4>Contratos anteriores vinculados</h4>' +

                tabla(
                    [
                        'Tipo',
                        'Inicio',
                        'Fin',
                        'Estado'
                    ],
                    detalle.historico.contratos.map(contrato => [
                        escapar(contrato.tipo),
                        escapar(
                            String(
                                contrato.fecha_inicio || ''
                            ).slice(0, 10)
                        ),
                        escapar(
                            String(
                                contrato.fecha_fin || ''
                            ).slice(0, 10)
                        ),
                        escapar(contrato.estado)
                    ])
                ) +
            '</section>';

        $('erp-contenido-expediente').querySelectorAll(
            '[data-pestana]'
        ).forEach(boton => {
            boton.onclick = () => {
                $('erp-contenido-expediente').querySelectorAll(
                    '[data-panel]'
                ).forEach(panel => {
                    panel.hidden =
                        panel.dataset.panel !==
                        boton.dataset.pestana;
                });

                $('erp-contenido-expediente').querySelectorAll(
                    '[data-pestana]'
                ).forEach(pestana => {
                    pestana.setAttribute(
                        'aria-pressed',
                        String(pestana === boton)
                    );
                });
            };
        });
    }

    async function vincularAnterior(id = null) {
        const anteriores = await api(
            base + '/anteriores'
        );

        const campos = [
            {
                nombre: 'anterior',
                etiqueta: 'Registro anterior',
                obligatorio: true,
                opciones: [
                    ['', 'Selecciona…'],
                    ...anteriores
                        .filter(
                            anterior => !anterior.empleado_id
                        )
                        .map(anterior => [
                            anterior.id,
                            anterior.nom + ' · ' + anterior.car
                        ])
                ]
            },
            {
                nombre: 'empleado',
                etiqueta:
                    'Destino: crear uno nuevo o vincular ' +
                    'un empleado de la lista consultada',
                obligatorio: true,
                opciones: [
                    ['', 'Selecciona una opción…'],
                    [
                        'nuevo',
                        'Crear expediente desde el registro anterior'
                    ],
                    ...estado.empleados
                        .filter(
                            empleado =>
                                empleado.origen !== 'anterior'
                        )
                        .map(empleado => [
                            empleado.id,
                            empleado.nombre
                        ])
                ]
            },
            {
                nombre: 'activo',
                etiqueta: 'Estado para un expediente nuevo',
                opciones: [
                    ['', 'Selecciona…'],
                    ['true', 'Activo'],
                    ['false', 'Inactivo']
                ]
            }
        ];

        const ventana = formulario(
            'Vincular un registro anterior',
            campos,
            { anterior: id || '' },

            async valores => {
                if (!confirm(
                    '¿Confirmas esta vinculación? ' +
                    'No se trasladarán pagos ni se ' +
                    'crearán movimientos de caja.'
                )) {
                    return false;
                }

                const resultado = await api(
                    base + '/importar/' + valores.anterior,
                    {
                        method: 'POST',
                        body: valores.empleado !== 'nuevo'
                            ? {
                                empleado_id: valores.empleado
                            }
                            : {
                                activo: valores.activo === 'true'
                            }
                    }
                );

                await refrescar();

                await mostrarExpediente(
                    resultado.empleado_id
                );
            }
        );

        const form = ventana.querySelector('form');

        const ajustar = () => {
            form.elements.activo.required =
                form.elements.empleado.value === 'nuevo';

            const origen = anteriores.find(anterior => {
                return String(anterior.id) ===
                    form.elements.anterior.value;
            });

            if (
                form.elements.empleado.value === 'nuevo'
            ) {
                form.elements.activo.value =
                    origen?.est === 'Activo'
                        ? 'true'
                        : origen?.est === 'Inactivo'
                            ? 'false'
                            : '';
            }
        };

        form.elements.empleado.addEventListener(
            'change',
            ajustar
        );

        form.elements.anterior.addEventListener(
            'change',
            ajustar
        );
    }

    function incidencia(id = null) {
        const actual = id
            ? estado.detalle.incidencias.find(fila => {
                return String(fila.id) === String(id);
            })
            : null;

        const empleado = estado.detalle.empleado.id;

        formulario(
            actual
                ? 'Editar incidencia'
                : 'Registrar incidencia',

            [
                {
                    nombre: 'tipo',
                    etiqueta: 'Tipo',
                    opciones: [
                        ['asistencia', 'Asistencia'],
                        ['falta', 'Falta'],
                        ['incapacidad', 'Incapacidad'],
                        ['hora_extra', 'Horas extra']
                    ]
                },
                {
                    nombre: 'desde',
                    etiqueta: 'Desde',
                    tipo: 'date',
                    obligatorio: true
                },
                {
                    nombre: 'hasta',
                    etiqueta: 'Hasta',
                    tipo: 'date',
                    obligatorio: true
                },
                {
                    nombre: 'horas',
                    etiqueta: 'Horas (cero si no corresponde)',
                    tipo: 'number',
                    obligatorio: true
                },
                {
                    nombre: 'descripcion',
                    etiqueta: 'Descripción',
                    tipo: 'textarea',
                    obligatorio: true
                },
                {
                    nombre: 'estado',
                    etiqueta: 'Estado',
                    opciones: [
                        ['pendiente', 'Pendiente'],
                        ['aprobada', 'Aprobada'],
                        ['rechazada', 'Rechazada']
                    ]
                }
            ],

            actual || { horas: '0' },

            async valores => {
                await api(
                    base + '/empleados/' +
                    empleado + '/incidencias' +
                    (actual ? '/' + actual.id : ''),
                    {
                        method: actual
                            ? 'PUT'
                            : 'POST',

                        body: {
                            ...valores,

                            ...(
                                actual
                                    ? {
                                        version:
                                            actual.version
                                    }
                                    : {}
                            )
                        }
                    }
                );

                await mostrarExpediente(empleado);
            }
        );
    }

    function documento(empleado) {
        formulario(
            'Clasificar documento',

            [{
                nombre: 'categoria',
                etiqueta: 'Tipo de documento',
                opciones: [
                    ['contrato_firmado', 'Contrato firmado'],
                    ['identificacion', 'Identificación'],
                    ['certificado_estudio', 'Certificado de estudio'],
                    ['otro', 'Otro']
                ]
            }],

            {},

            async valores => {
                return solicitarArchivo(
                    '.pdf,.png,.jpg,.jpeg',

                    async archivo => {
                        const cuerpo = new FormData();

                        cuerpo.append(
                            'archivo',
                            archivo
                        );

                        cuerpo.append(
                            'categoria',
                            valores.categoria
                        );

                        await api(
                            base + '/empleados/' +
                            empleado + '/documentos',
                            {
                                method: 'POST',
                                isForm: true,
                                body: cuerpo
                            }
                        );

                        await refrescar(empleado);

                        aviso(
                            'Documento guardado en el expediente.'
                        );
                    }
                );
            }
        );
    }

    async function manejarEmpleado(tipo, id) {
        if (tipo === 'actualizar') {
            return cargarEmpleados();
        }

        if (tipo === 'crear') {
            return editarEmpleado();
        }

        if (tipo === 'vincular') {
            return vincularAnterior();
        }

        if (tipo === 'vincular-uno') {
            return vincularAnterior(id);
        }

        if (tipo === 'ver') {
            return mostrarExpediente(Number(id));
        }

        if (tipo === 'editar') {
            return editarEmpleado(Number(id));
        }

        if (tipo === 'desactivar') {
            const empleado = estado.empleados.find(fila => {
                return fila.origen !== 'anterior' &&
                    String(fila.id) === id;
            });

            if (
                !empleado ||
                !confirm(
                    '¿Desactivar a ' +
                    empleado.nombre +
                    ' conservando su historial?'
                )
            ) {
                return;
            }

            await api(
                base + '/empleados/' + id,
                {
                    method: 'DELETE',
                    body: {
                        revision: empleado.revision
                    }
                }
            );

            await refrescar();

            return;
        }

        if (tipo === 'nueva-incidencia') {
            return incidencia();
        }

        if (tipo === 'editar-incidencia') {
            return incidencia(id);
        }

        if (tipo === 'retirar-incidencia') {
            const registro = estado.detalle.incidencias.find(
                fila => String(fila.id) === id
            );

            if (
                !registro ||
                !confirm(
                    '¿Retirar esta incidencia del listado activo?'
                )
            ) {
                return;
            }

            await api(
                base + '/empleados/' +
                estado.detalle.empleado.id +
                '/incidencias/' + id,
                {
                    method: 'DELETE',
                    body: {
                        version: registro.version
                    }
                }
            );

            return mostrarExpediente(
                estado.detalle.empleado.id
            );
        }

        if (tipo === 'subir-documento') {
            return documento(Number(id));
        }

        if (tipo === 'documento') {
            const archivo = estado.detalle.documentos.find(
                fila => fila.id === id
            );

            if (archivo) {
                return descargar(
                    id,
                    archivo.nombre_original
                );
            }
        }

        if (
            tipo === 'retirar-documento' &&
            confirm(
                '¿Retirar el documento del listado activo?'
            )
        ) {
            await api(
                base + '/archivos/' + id,
                { method: 'DELETE' }
            );

            await mostrarExpediente(
                estado.detalle.empleado.id
            );
        }
    }

    let plataformaElegida = null;
    let archivoElegido = null;

    function prepararPublicidad() {
        const destino = $('finanzas-mkt');

        if (
            !destino ||
            $('erp-publicidad')
        ) {
            return;
        }

        const seccion = document.createElement('section');

        seccion.id = 'erp-publicidad';
        seccion.className = 'erp-seccion';

        seccion.innerHTML =
            '<header class="erp-encabezado-modulo">' +
                '<div>' +
                    '<span class="erp-etiqueta">' +
                        'PUBLICIDAD Y REDES' +
                    '</span>' +
                    '<h3>Publicidad desde tu dispositivo</h3>' +
                    '<p>' +
                        'Selecciona una aplicación para autorizar ' +
                        'la selección de un archivo.' +
                    '</p>' +
                '</div>' +
            '</header>' +

            '<div class="erp-barra">' +
                [
                    ['facebook', 'Facebook'],
                    ['instagram', 'Instagram'],
                    ['whatsapp', 'WhatsApp'],
                    ['tiktok', 'TikTok'],
                    ['otra', 'Otra aplicación']
                ].map(([clave, titulo]) => {
                    return (
                        '<button type="button" ' +
                            'class="erp-boton" ' +
                            'data-plataforma="' + clave + '">' +
                            titulo +
                        '</button>'
                    );
                }).join('') +
            '</div>' +

            '<form id="erp-formulario-publicidad" ' +
                'class="erp-formulario">' +
                '<label class="erp-campo">Título' +
                    '<input name="titulo" maxlength="150" required>' +
                '</label>' +

                '<label class="erp-campo">Texto del anuncio' +
                    '<textarea name="texto" maxlength="5000">' +
                    '</textarea>' +
                '</label>' +

                '<p id="erp-archivo-elegido">' +
                    'Selecciona una aplicación y un archivo. ' +
                    'JPG, PNG o MP4, hasta 10 MB.' +
                '</p>' +

                '<button class="erp-boton erp-boton-principal" ' +
                    'type="submit">' +
                    'Guardar publicidad' +
                '</button>' +
            '</form>' +

            '<div id="erp-lista-publicidades"></div>' +

            '<section id="erp-publicidad-preparada" hidden>' +
                '<h4>Archivo preparado para compartir</h4>' +
                '<p id="erp-publicidad-preparada-texto"></p>' +

                '<button type="button" ' +
                    'class="erp-boton erp-boton-principal" ' +
                    'id="erp-compartir-archivo">' +
                    'Compartir archivo' +
                '</button>' +

                '<button type="button" class="erp-boton" ' +
                    'id="erp-descargar-publicidad">' +
                    'Descargar archivo' +
                '</button>' +
            '</section>';

        destino.prepend(seccion);

        seccion.querySelectorAll(
            '[data-plataforma]'
        ).forEach(boton => {
            boton.onclick = () => {
                if (!administrador()) {
                    aviso(
                        'Esta cuenta tiene acceso de consulta.',
                        true
                    );

                    return;
                }

                solicitarArchivo(
                    'image/png,image/jpeg,video/mp4',

                    archivo => {
                        plataformaElegida =
                            boton.dataset.plataforma;

                        archivoElegido = archivo;

                        $('erp-archivo-elegido').textContent =
                            'Aplicación: ' +
                            boton.textContent +
                            ' · ' +
                            archivo.name;

                        seccion.querySelectorAll(
                            '[data-plataforma]'
                        ).forEach(elemento => {
                            elemento.setAttribute(
                                'aria-pressed',
                                String(elemento === boton)
                            );
                        });
                    }
                );
            };
        });

        const formularioPublicidad =
            $('erp-formulario-publicidad');

        let ocupado = false;

        formularioPublicidad.onsubmit = async evento => {
            evento.preventDefault();

            if (ocupado) return;

            if (
                !archivoElegido ||
                !plataformaElegida
            ) {
                aviso(
                    'Selecciona una aplicación y un archivo.',
                    true
                );

                return;
            }

            ocupado = true;

            const boton = formularioPublicidad.querySelector(
                '[type="submit"]'
            );

            boton.disabled = true;

            try {
                const cuerpo = new FormData(
                    formularioPublicidad
                );

                cuerpo.append(
                    'plataforma',
                    plataformaElegida
                );

                cuerpo.append(
                    'archivo',
                    archivoElegido
                );

                const publicidad = await api(
                    base + '/publicidad',
                    {
                        method: 'POST',
                        isForm: true,
                        body: cuerpo
                    }
                );

                estado.preparada = {
                    registro: publicidad,
                    archivo: archivoElegido
                };

                mostrarPreparada();
                await refrescar();

                aviso(
                    'Publicidad guardada. Puedes entregarla ' +
                    'al panel de compartir del dispositivo.'
                );

            } catch (error) {
                aviso(error.message, true);

            } finally {
                ocupado = false;
                boton.disabled = false;
            }
        };

        $('erp-compartir-archivo').onclick = compartir;

        $('erp-descargar-publicidad').onclick = () => {
            const preparada = estado.preparada;

            if (preparada) {
                descargar(
                    preparada.registro.id,
                    preparada.registro.nombre_original
                ).catch(error => {
                    aviso(error.message, true);
                });
            }
        };

        window.abrirModalMktAPI = () => {
            seccion.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });

            seccion.querySelector(
                '[data-plataforma]'
            ).focus();
        };

        $('form-mkt-api')?.addEventListener(
            'submit',
            evento => {
                evento.preventDefault();
                evento.stopImmediatePropagation();

                aviso(
                    'Utiliza la selección de aplicación y archivo ' +
                    'para guardar y compartir la publicidad.'
                );
            },
            true
        );

        destino.querySelectorAll('p').forEach(parrafo => {
            if (
                parrafo.textContent.includes('Tokens OAuth')
            ) {
                parrafo.textContent =
                    'Compartir desde el dispositivo';

                const cifra = parrafo.nextElementSibling;

                if (cifra) {
                    cifra.textContent = 'Según navegador';
                }

                const detalle = cifra?.nextElementSibling;

                if (detalle) {
                    detalle.textContent =
                        'La aplicación de destino se elige ' +
                        'en el panel del dispositivo.';
                }
            }
        });
    }

    async function cargarPublicidades() {
        if (!$('erp-publicidad')) return;

        const filas = await api(
            base + '/publicidad'
        );

        estado.publicidades = filas;

        $('erp-lista-publicidades').innerHTML = tabla(
            [
                'Publicidad',
                'Plataforma',
                'Archivo',
                'Acciones'
            ],

            filas.map(fila => [
                '<strong>' +
                    escapar(fila.datos.titulo) +
                '</strong>' +
                '<small>' +
                    escapar(fila.datos.texto) +
                '</small>',

                escapar(fila.datos.plataforma),
                escapar(fila.nombre_original),

                '<button type="button" class="erp-boton" ' +
                    'data-publicidad="' + fila.id + '">' +
                    'Preparar para compartir' +
                '</button>'
            ])
        );

        $('erp-lista-publicidades').querySelectorAll(
            '[data-publicidad]'
        ).forEach(boton => {
            boton.onclick = async () => {
                boton.disabled = true;

                try {
                    const registro = estado.publicidades.find(
                        fila => fila.id === boton.dataset.publicidad
                    );

                    const contenido = await api(
                        base + '/archivos/' +
                        registro.id
                    );

                    estado.preparada = {
                        registro,
                        archivo: new File(
                            [contenido],
                            registro.nombre_original,
                            { type: registro.tipo }
                        )
                    };

                    mostrarPreparada();

                } catch (error) {
                    aviso(error.message, true);

                } finally {
                    boton.disabled = false;
                }
            };
        });
    }

    function mostrarPreparada() {
        const preparada = estado.preparada;

        $('erp-publicidad-preparada').hidden = false;

        $('erp-publicidad-preparada-texto').textContent =
            (
                preparada.registro.datos?.titulo ||
                preparada.registro.nombre_original
            ) +
            ' · Elige ' +
            (
                preparada.registro.datos?.plataforma ||
                'la aplicación'
            ) +
            ' en el panel del dispositivo. ' +
            'La publicación se completa en esa aplicación.';

        $('erp-publicidad-preparada').scrollIntoView({
            block: 'nearest'
        });
    }

    async function compartir() {
        if (!administrador()) {
            aviso(
                'Esta cuenta tiene acceso de consulta.',
                true
            );

            return;
        }

        const preparada = estado.preparada;

        if (!preparada) return;

        const datos = {
            files: [preparada.archivo],

            title:
                preparada.registro.datos?.titulo ||
                preparada.registro.nombre_original,

            ...(
                preparada.registro.datos?.texto
                    ? {
                        text:
                            preparada.registro.datos.texto
                    }
                    : {}
            )
        };

        if (
            !navigator.share ||
            !navigator.canShare?.({
                files: datos.files
            })
        ) {
            aviso(
                'Este navegador no permite compartir archivos. ' +
                'Descarga el archivo y súbelo desde la aplicación elegida.'
            );

            return;
        }

        let resultado = 'entregado';

        const boton = $('erp-compartir-archivo');
        boton.disabled = true;

        try {
            await navigator.share(datos);

            aviso(
                'Archivo entregado al panel del dispositivo. ' +
                'La publicación no se confirma desde el sistema.'
            );

        } catch (error) {
            resultado = error.name === 'AbortError'
                ? 'cancelado'
                : 'fallido';

            aviso(
                resultado === 'cancelado'
                    ? 'Se canceló la acción de compartir.'
                    : 'No se pudo compartir el archivo.',
                resultado === 'fallido'
            );

        } finally {
            boton.disabled = false;
        }

        try {
            await api(
                base + '/publicidad/' +
                preparada.registro.id +
                '/compartidos',
                {
                    method: 'POST',
                    body: { resultado }
                }
            );
        } catch (error) {
            aviso(
                'Resultado del dispositivo: ' +
                resultado +
                '. No se pudo guardar el registro de la acción.',
                true
            );
        }
    }

    function prepararNomina() {
        const selector = $('nom-empleado');

        if (!selector) return;

        let solicitud = 0;

        const aplicar = async () => {
            const id = selector.value;

            if (!id) return;

            const periodo =
                $('nom-period')?.value || '';

            const turno = ++solicitud;

            try {
                const valores = await api(
                    base + '/empleados/' +
                    id + '/remuneracion?' +
                    new URLSearchParams({
                        periodo
                    })
                );

                if (
                    turno !== solicitud ||
                    selector.value !== id ||
                    (
                        $('nom-period')?.value || ''
                    ) !== periodo
                ) {
                    return;
                }

                $('nom-base').value =
                    valores.salario;

                if ($('nom-bono')) {
                    $('nom-bono').value =
                        valores.bono_fijo ?? '0';
                }

                if ($('nom-oded')) {
                    $('nom-oded').value =
                        valores.deduccion_fija ?? '0';
                }

                if (
                    $('nom-he') &&
                    valores.horas_extra_aprobadas !== null
                ) {
                    $('nom-he').value =
                        valores.horas_extra_aprobadas;
                }

                aviso(
                    'Valores vigentes del expediente cargados. ' +
                    'Revisa las compensaciones del período y los ' +
                    'importes variables antes de guardar.' +
                    (
                        valores.incidencias_cruzadas
                            ? (
                                ' Hay horas extra que cruzan ' +
                                'períodos y requieren revisión.'
                            )
                            : ''
                    )
                );

            } catch (error) {
                aviso(error.message, true);
            }
        };

        selector.addEventListener(
            'change',
            aplicar
        );

        $('nom-period')?.addEventListener(
            'change',
            aplicar
        );
    }

    function prepararBanpro() {
        if (
            !location.pathname.endsWith(
                '/recargas.html'
            ) ||
            $('erp-banpro-pendiente')
        ) {
            return;
        }

        const panel = document.createElement('section');

        panel.id = 'erp-banpro-pendiente';
        panel.className = 'erp-seccion';

        panel.innerHTML =
            '<h3>Billetera móvil BanPro</h3>' +
            '<p>' +
                'Estructura preparada para una integración posterior. ' +
                'No realiza cargos ni consultas de cuenta.' +
            '</p>' +
            '<button type="button" class="erp-boton" disabled>' +
                'Integración pendiente' +
            '</button>';

        (
            $('page-content') ||
            document.body
        ).append(panel);
    }

    function iniciar() {
        if (iniciado) return;

        iniciado = true;

        if (
            [
                'admin',
                'superadmin',
                'auditor'
            ].includes(Auth.getUser()?.role)
        ) {
            prepararEmpleados();
            prepararPublicidad();
            prepararNomina();
        }

        prepararBanpro();

        document.addEventListener(
            'click',
            async evento => {
                const boton = evento.target.closest(
                    '[data-exp-accion]'
                );

                if (!boton || boton.disabled) return;

                evento.preventDefault();

                if (
                    !administrador() &&
                    boton.dataset.expAccion !== 'actualizar'
                ) {
                    aviso(
                        'Esta cuenta tiene acceso de consulta.',
                        true
                    );

                    return;
                }

                boton.disabled = true;

                try {
                    await manejarEmpleado(
                        boton.dataset.expAccion,
                        boton.dataset.id
                    );
                } catch (error) {
                    aviso(error.message, true);
                } finally {
                    boton.disabled = false;
                }
            }
        );
    }

    async function recargar() {
        const resultados = await Promise.allSettled([
            cargarEmpleados(),
            cargarPublicidades()
        ]);

        const errores = resultados.filter(
            resultado => resultado.status === 'rejected'
        );

        if (errores.length) {
            throw new Error(
                errores.map(
                    resultado => resultado.reason.message
                ).join(' · ')
            );
        }
    }

    window.ComplementosERP = {
        iniciar,
        recargar
    };
})();