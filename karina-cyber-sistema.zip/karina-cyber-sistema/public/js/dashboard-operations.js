'use strict';

window.startOperationsDashboard = async () => {
  const {
    e,
    button,
    table,
    panel,
    kpis,
    form,
    link,
    canWrite,
    loadInto,
    date
  } = Ops;

  const sections = [
    'inicio',
    'produccion',
    'proveedores',
    'contabilidad',
    'finanzas',
    'inventario',
    'rrhh'
  ];

  let generation = 0;

  function syncNavigation() {
    document
      .querySelectorAll('.sidebar-nav a[href]')
      .forEach(anchor => {
        const target = new URL(
          anchor.href,
          location.origin
        );

        const selected =
          target.pathname === location.pathname &&
          target.hash === location.hash;

        anchor.classList.toggle(
          'active',
          selected
        );

        if (selected) {
          anchor.setAttribute(
            'aria-current',
            'page'
          );
        } else {
          anchor.removeAttribute(
            'aria-current'
          );
        }
      });

    document
      .querySelectorAll('[data-section]')
      .forEach(anchor => {
        const key =
          location.hash.slice(1) ||
          'inicio';

        const selected =
          anchor.dataset.section === key;

        anchor.classList.toggle(
          'selected',
          selected
        );

        if (selected) {
          anchor.setAttribute(
            'aria-current',
            'page'
          );
        } else {
          anchor.removeAttribute(
            'aria-current'
          );
        }
      });
  }

  function toolbar(
    title,
    subtitle,
    extra = ''
  ) {
    return `
      <div class="ops-head">
        <div>
          <h2>${e(title)}</h2>
          <p class="ops-help">${e(subtitle)}</p>
        </div>

        <div class="ops-actions">
          ${button('Actualizar', activate)}
          ${extra}
        </div>
      </div>
    `;
  }

  function supplierForm(item = {}) {
    form(
      item.id
        ? 'Editar proveedor'
        : 'Nuevo proveedor',

      [
        {
          name: 'nombre',
          label: 'Razón social'
        },
        {
          name: 'ruc',
          label: 'RUC',
          max: 40,
          required: false
        },
        {
          name: 'tel',
          label: 'Teléfono',
          max: 40,
          required: false
        },
        {
          name: 'email',
          label: 'Correo',
          type: 'email',
          required: false
        },
        {
          name: 'categoria',
          label: 'Categoría',
          max: 120,
          required: false
        },
        {
          name: 'service_type',
          label: 'Producto o servicio que ofrece'
        },
        {
          name: 'metodo_pago_pref',
          label: 'Forma de pago preferida',
          options: Ops.methodOptions
        },
        {
          name: 'estado',
          label: 'Estado',
          options: [
            ['Activo', 'Activo'],
            ['Inactivo', 'Inactivo']
          ]
        }
      ],

      item,

      async body => {
        await api(
          '/operations/suppliers' +
          (item.id ? '/' + item.id : ''),
          {
            method: item.id
              ? 'PATCH'
              : 'POST',
            body
          }
        );

        await activate();
      }
    );
  }

  function employeeForm(item = {}) {
    form(
      item.id
        ? 'Editar empleado'
        : 'Nuevo empleado',

      [
        {
          name: 'full_name',
          label: 'Nombre completo'
        },
        {
          name: 'position',
          label: 'Cargo',
          max: 100
        },
        {
          name: 'salary',
          label: 'Salario base (C$)',
          type: 'number',
          value: 0
        },
        {
          name: 'active',
          label: 'Estado',
          value: 'true',
          options: [
            ['true', 'Activo'],
            ['false', 'Inactivo']
          ]
        }
      ],

      item,

      async body => {
        body.active = body.active === 'true';

        await api(
          '/operations/employees' +
          (item.id ? '/' + item.id : ''),
          {
            method: item.id
              ? 'PATCH'
              : 'POST',
            body
          }
        );

        await activate();
      }
    );
  }

  async function purchaseForm(suppliers) {
    const activeSuppliers = suppliers.filter(
      supplier => supplier.estado === 'Activo'
    );

    if (!activeSuppliers.length) {
      throw new Error(
        'Registra un proveedor activo antes de crear una compra.'
      );
    }

    const products = (
      await api('/inventory/products')
    ).filter(product => product.active);

    form(
      'Registrar compra y pago',

      [
        {
          name: 'supplier_id',
          label: 'Proveedor',
          options: activeSuppliers.map(
            supplier => [
              supplier.id,
              supplier.nombre
            ]
          )
        },
        {
          name: 'description',
          label: 'Concepto',
          max: 255
        },
        {
          name: 'invoice_number',
          label: 'Factura o referencia del proveedor',
          max: 80,
          required: false
        },
        {
          name: 'product_id',
          label: 'Producto o servicio',
          required: false,
          options: [
            ['', 'Servicio sin entrada de inventario'],
            ...products.map(product => [
              product.id,
              product.name
            ])
          ]
        },
        {
          name: 'qty',
          label: 'Cantidad de producto',
          type: 'number',
          min: 1,
          max: 1000000,
          step: 1,
          value: 1
        },
        {
          name: 'unit_cost',
          label: 'Costo unitario del producto (C$)',
          type: 'number',
          min: 0.01,
          required: false
        },
        {
          name: 'amount',
          label: 'Importe si es un servicio (C$)',
          type: 'number',
          min: 0.01,
          required: false
        },
        ...Ops.paymentFields
      ],

      {},

      async values => {
        if (
          values.product_id &&
          !values.unit_cost
        ) {
          throw new Error(
            'Indica el costo unitario del producto.'
          );
        }

        if (
          !values.product_id &&
          !values.amount
        ) {
          throw new Error(
            'Indica el importe del servicio.'
          );
        }

        const shiftId = await Ops.shift();

        const body = {
          supplier_id: values.supplier_id,
          description: values.description,
          invoice_number: values.invoice_number,

          shift_id: shiftId,

          payment_method: values.payment_method,
          payment_reference: values.payment_reference,

          items: values.product_id
            ? [
                {
                  product_id: values.product_id,
                  qty: values.qty,
                  unit_cost: values.unit_cost
                }
              ]
            : [],

          amount: values.amount
        };

        await Ops.postPayment(
          '/operations/purchases',
          body
        );

        await activate();
        await refreshShiftBadge();
      },

      'Registra una compra recibida y pagada. ' +
      'Si seleccionas un producto, su cantidad ingresa a Kardex. ' +
      'El pago requiere un turno abierto y conciliado.'
    );
  }

  function payrollForm(employees) {
    const activeEmployees = employees.filter(
      employee => employee.active
    );

    if (!activeEmployees.length) {
      throw new Error(
        'Registra un empleado activo antes de crear un pago.'
      );
    }

    form(
      'Registrar pago al empleado',

      [
        {
          name: 'employee_id',
          label: 'Empleado',
          options: activeEmployees.map(
            employee => [
              employee.id,
              employee.full_name
            ]
          )
        },
        {
          name: 'period',
          label: 'Período mensual',
          type: 'month'
        },
        {
          name: 'description',
          label: 'Concepto del pago',
          max: 255
        },
        {
          name: 'amount',
          label: 'Importe neto aprobado (C$)',
          type: 'number',
          min: 0.01
        },
        ...Ops.paymentFields
      ],

      {},

      async body => {
        body.shift_id = await Ops.shift();

        await Ops.postPayment(
          '/operations/payroll',
          body
        );

        await activate();
        await refreshShiftBadge();
      },

      'Registra el importe neto aprobado. ' +
      'Se admite un pago mensual por empleado. ' +
      'Este formulario no calcula retenciones ni prestaciones.'
    );
  }

  function createRate() {
    const services = [
      'Impresión',
      'Fotocopia',
      'Cédula',
      'Encolochado',
      'Laminado',
      'Escaneo'
    ];

    form(
      'Nueva tarifa de servicio',

      [
        {
          name: 'name',
          label: 'Nombre de la tarifa',
          max: 120
        },
        {
          name: 'service',
          label: 'Servicio',
          options: services.map(
            service => [service, service]
          )
        },
        {
          name: 'billing',
          label: 'Unidad de cobro',
          options: [
            ['cara', 'Por cara'],
            ['documento', 'Por documento']
          ]
        },
        {
          name: 'sides',
          label: 'Caras',
          options: [
            ['1', 'Una cara'],
            ['2', 'Doble cara']
          ]
        },
        {
          name: 'paper',
          label: 'Papel o tamaño',
          max: 120
        },
        {
          name: 'color',
          label: 'Modo de tinta',
          options: [
            ['B/N', 'B/N'],
            ['Color', 'Color'],
            ['No aplica', 'No aplica']
          ]
        },
        {
          name: 'price',
          label: 'Precio por unidad (C$)',
          type: 'number',
          min: 0.01
        }
      ],

      {},

      async values => {
        const {
          price,
          ...body
        } = values;

        body.sides = Number(body.sides);

        body.tiers = [
          {
            up_to: null,
            price
          }
        ];

        await api(
          '/printing-services/rates',
          {
            method: 'POST',
            body
          }
        );

        await activate();
      },

      'Cédula, encolochado y laminado se cobran por documento. ' +
      'Esta tarifa utiliza un precio único.'
    );
  }

  async function materialsForm() {
    const results = await Promise.all([
      api('/printing-services/rates'),
      api('/inventory/products')
    ]);

    const rates = results[0].filter(
      rate => rate.active
    );

    const products = results[1].filter(
      product => product.active
    );

    if (!rates.length || !products.length) {
      throw new Error(
        'Necesitas una tarifa y un producto activos para configurar insumos.'
      );
    }

    form(
      'Configurar consumo por orden',

      [
        {
          name: 'rate_id',
          label: 'Tarifa o servicio',
          options: rates.map(
            rate => [rate.id, rate.name]
          )
        },
        {
          name: 'product_id',
          label: 'Insumo del inventario',
          options: products.map(
            product => [
              product.id,
              product.name
            ]
          )
        },
        {
          name: 'qty_per_order',
          label: 'Cantidad fija por orden completa',
          type: 'number',
          step: '0.000001',
          min: 0.000001,
          max: 999999
        }
      ],

      {},

      async body => {
        await api(
          '/operations/production-materials',
          {
            method: 'POST',
            body
          }
        );

        await activate();
      },

      'Configura el consumo de toda la orden. ' +
      'El descuento se realiza al iniciar producción ' +
      'cuando esté instalada esa integración.'
    );
  }

  async function legacyRecords(
    endpoint,
    title
  ) {
    const rows = await api('/' + endpoint);

    const columns = [
      ...new Set(
        rows.flatMap(
          row => Object.keys(row)
        )
      )
    ];

    if (!columns.length) {
      Ops.show(
        title,
        '<p class="ops-help">Sin registros anteriores.</p>'
      );

      return;
    }

    Ops.show(
      title,

      table(
        columns,

        rows.map(row =>
          columns.map(key =>
            e(
              typeof row[key] === 'object'
                ? JSON.stringify(row[key])
                : row[key]
            )
          )
        )
      )
    );
  }

  async function shareCampaign(
    campaign,
    channel
  ) {
    const payload = {
      title: campaign.title,
      text: campaign.content,

      ...(campaign.url
        ? {
            url: campaign.url
          }
        : {})
    };

    let outcome = 'opened';

    if (channel === 'device') {
      if (!navigator.share) {
        throw new Error(
          'Este navegador no ofrece el panel de compartir. ' +
          'Utiliza WhatsApp, Facebook o Copiar.'
        );
      }

      try {
        await navigator.share(payload);
        outcome = 'handed_off';
      } catch (error) {
        outcome = error.name === 'AbortError'
          ? 'cancelled'
          : 'failed';

        await api(
          `/marketing/campaigns/${campaign.id}/shares`,
          {
            method: 'POST',
            body: {
              channel,
              outcome
            }
          }
        );

        if (outcome === 'failed') {
          throw error;
        }

        return;
      }
    } else if (channel === 'copy') {
      if (!navigator.clipboard?.writeText) {
        throw new Error(
          'El portapapeles no está disponible. ' +
          'Utiliza HTTPS o localhost.'
        );
      }

      await navigator.clipboard.writeText(
        [
          campaign.title,
          campaign.content,
          campaign.url
        ]
          .filter(Boolean)
          .join('\n')
      );

      outcome = 'copied';
    } else {
      if (
        channel === 'facebook' &&
        !campaign.url
      ) {
        throw new Error(
          'Agrega un enlace público para compartir en Facebook. ' +
          'También puedes copiar el texto del anuncio.'
        );
      }

      const target = channel === 'whatsapp'
        ? 'https://wa.me/?text=' +
          encodeURIComponent(
            [
              campaign.title,
              campaign.content,
              campaign.url
            ]
              .filter(Boolean)
              .join('\n')
          )
        : 'https://www.facebook.com/sharer/sharer.php?u=' +
          encodeURIComponent(campaign.url);

      const opened = window.open(
        target,
        '_blank'
      );

      if (!opened) {
        throw new Error(
          'El navegador bloqueó la ventana para compartir.'
        );
      }

      opened.opener = null;
    }

    await api(
      `/marketing/campaigns/${campaign.id}/shares`,
      {
        method: 'POST',
        body: {
          channel,
          outcome
        }
      }
    );

    toast(
      outcome === 'copied'
        ? 'Texto copiado.'
        : 'Solicitud de compartir enviada.'
    );
  }

  function campaignForm() {
    form(
      'Nuevo anuncio',

      [
        {
          name: 'title',
          label: 'Título'
        },
        {
          name: 'content',
          label: 'Contenido',
          type: 'textarea',
          max: 5000
        },
        {
          name: 'url',
          label: 'Enlace público',
          type: 'url',
          max: 1000,
          required: false
        }
      ],

      {},

      async body => {
        await api(
          '/marketing/campaigns',
          {
            method: 'POST',
            body
          }
        );

        await activate();
      }
    );
  }

  async function renderMarketing(
    root,
    requestGeneration
  ) {
    const campaigns = await api(
      '/marketing/campaigns'
    );

    if (
      requestGeneration !== generation ||
      !root.isConnected
    ) {
      return;
    }

    const rows = campaigns.map(campaign => [
      `
        <strong>${e(campaign.title)}</strong>
        <small>${e(campaign.author)}</small>
      `,

      `
        <div class="ops-announcement">
          ${e(campaign.content)}
        </div>
        ${
          campaign.url
            ? `<small>${e(campaign.url)}</small>`
            : ''
        }
      `,

      e(date(campaign.created_at)),

      canWrite()
        ? `
          <div class="ops-actions">
            ${button(
              'Desde el dispositivo',
              () => shareCampaign(campaign, 'device')
            )}

            ${button(
              'WhatsApp',
              () => shareCampaign(campaign, 'whatsapp')
            )}

            ${button(
              'Facebook',
              () => shareCampaign(campaign, 'facebook')
            )}

            ${button(
              'Copiar',
              () => shareCampaign(campaign, 'copy')
            )}
          </div>
        `
        : 'Solo lectura'
    ]);

    root.innerHTML = panel(
      'Mercadotecnia / Marketing',

      `
        <p class="ops-help">
          Comparte desde tu cuenta personal utilizando
          las aplicaciones que ofrezca el dispositivo.
          El registro de compartir no confirma que
          el anuncio haya sido publicado.
        </p>
      ` +

      table(
        [
          'Anuncio',
          'Contenido',
          'Fecha',
          'Compartir'
        ],
        rows
      ),

      canWrite()
        ? button(
            'Crear anuncio',
            campaignForm,
            'btn-primary'
          )
        : ''
    );
  }

  async function renderHome(root, token) {
    const data = await api(
      '/operations/overview'
    );

    if (token !== generation) return;

    root.innerHTML = kpis([
      [
        'Órdenes pendientes',
        data.production_pending
      ],
      [
        'Proveedores activos',
        data.active_suppliers
      ],
      [
        'Empleados activos',
        data.active_employees
      ],
      [
        'Inversión en inventario',
        money(data.inventory_value)
      ],
      [
        'Productos con stock bajo',
        data.low_stock
      ],
      [
        'Turnos abiertos',
        data.open_shifts
      ]
    ]) +

    panel(
      'Operación conectada',

      `
        <p class="ops-help">
          Consulta órdenes, compras, pagos, existencias
          y movimientos de caja desde el mismo sistema.
        </p>

        <div class="ops-actions">
          ${link(
            'Control de caja',
            '/caja-chica.html'
          )}

          ${link(
            'Reportes',
            '/reportes.html'
          )}

          ${link(
            'Inventario',
            '/inventario.html'
          )}
        </div>
      `
    );
  }

  async function renderProduction(root, token) {
    const [jobs, materials] = await Promise.all([
      api('/printing-services/orders?page=1'),
      api('/operations/production-materials')
    ]);

    if (token !== generation) return;

    const orderRows = jobs.items.map(job => {
      let paymentStatus = 'Sin cobro registrado';

      if (job.payment === undefined) {
        paymentStatus = 'Consulta de cobro pendiente de integrar';
      } else if (job.payment) {
        paymentStatus =
          job.payment.status === 'restricted'
            ? 'Restringido'
            : job.payment.reconciled
              ? 'Conciliado'
              : 'Pendiente de conciliación';
      }

      return [
        '#' + e(job.id),
        e(job.customer_name || job.file_name),
        e(money(job.quoted_total)),
        e(job.status),
        e(paymentStatus)
      ];
    });

    const materialRows = materials.map(material => [
      e(material.rate_name),
      e(material.product_name),
      e(material.qty_per_order),

      canWrite()
        ? button(
            'Quitar',
            async () => {
              if (
                !confirm(
                  '¿Quitar esta configuración para futuras órdenes?'
                )
              ) {
                return;
              }

              await api(
                '/operations/production-materials/' +
                material.rate_id +
                '/' +
                material.product_id,
                {
                  method: 'DELETE'
                }
              );

              await activate();
            }
          )
        : 'Solo lectura'
    ]);

    root.innerHTML =
      toolbar(
        'Producción',
        'Órdenes compartidas con Producción y servicios',
        link(
          'Abrir operaciones',
          '/impresiones.html'
        )
      ) +

      panel(
        'Órdenes recientes',

        table(
          [
            'Orden',
            'Cliente / documento',
            'Cotizado',
            'Estado',
            'Cobro'
          ],
          orderRows
        )
      ) +

      panel(
        'Insumos por servicio',

        table(
          [
            'Servicio',
            'Insumo',
            'Cantidad por orden',
            'Acción'
          ],
          materialRows
        ),

        canWrite()
          ? button(
              'Configurar insumo',
              materialsForm,
              'btn-primary'
            ) +
            button(
              'Nueva tarifa',
              createRate
            )
          : ''
      );
  }

  async function renderSuppliers(root, token) {
    const [suppliers, purchases] =
      await Promise.all([
        api('/operations/suppliers'),
        api('/operations/purchases')
      ]);

    if (token !== generation) return;

    const supplierRows = suppliers.map(supplier => [
      `
        <strong>${e(supplier.nombre)}</strong>
        <small>${e(supplier.ruc)}</small>
      `,

      `
        ${e(supplier.tel)}
        <small>${e(supplier.email)}</small>
      `,

      e(
        supplier.service_type ||
        supplier.categoria ||
        'Por completar'
      ),

      e(
        supplier.metodo_pago_pref ||
        'Por completar'
      ),

      e(supplier.estado),

      canWrite()
        ? `
          <div class="ops-actions">
            ${button(
              'Editar',
              () => supplierForm(supplier)
            )}

            ${button(
              'Desactivar',
              async () => {
                if (
                  !confirm(
                    '¿Desactivar al proveedor conservando su historial?'
                  )
                ) {
                  return;
                }

                await api(
                  '/operations/suppliers/' +
                  supplier.id,
                  {
                    method: 'DELETE'
                  }
                );

                await activate();
              }
            )}
          </div>
        `
        : 'Solo lectura'
    ]);

    const purchaseRows = purchases.map(purchase => [
      '#' + e(purchase.id),

      `
        ${e(purchase.supplier_name)}
        <small>${e(purchase.description)}</small>
      `,

      e(money(purchase.amount)),

      `
        ${e(purchase.payment_method)}
        <small>
          ${e(purchase.payment_reference || '—')}
        </small>
      `,

      `${e(purchase.shift_id)} / #${e(purchase.expense_id)}`
    ]);

    root.innerHTML =
      toolbar(
        'Proveedores y compras',
        'Servicios, formas de pago y compras recibidas',
        link(
          'Inventario y Kardex',
          '/inventario.html'
        )
      ) +

      panel(
        'Directorio de proveedores',

        table(
          [
            'Proveedor',
            'Contacto',
            'Servicio',
            'Pago preferido',
            'Estado',
            'Acciones'
          ],
          supplierRows
        ),

        canWrite()
          ? button(
              'Nuevo proveedor',
              () => supplierForm(),
              'btn-primary'
            )
          : ''
      ) +

      panel(
        'Compras pagadas',

        table(
          [
            'Compra',
            'Proveedor / concepto',
            'Importe',
            'Pago',
            'Turno / gasto'
          ],
          purchaseRows
        ),

        canWrite()
          ? button(
              'Registrar compra y pago',
              () => purchaseForm(suppliers),
              'btn-primary'
            )
          : ''
      );
  }

  async function renderEmployees(root, token) {
    const [employees, payroll] =
      await Promise.all([
        api('/operations/employees'),
        api('/operations/payroll')
      ]);

    if (token !== generation) return;

    const employeeRows = employees.map(employee => [
      e(employee.full_name),
      e(employee.position),
      e(money(employee.salary)),
      employee.active ? 'Activo' : 'Inactivo',

      canWrite()
        ? `
          <div class="ops-actions">
            ${button(
              'Editar',
              () => employeeForm(employee)
            )}

            ${button(
              'Desactivar',
              async () => {
                if (
                  !confirm('¿Desactivar empleado?')
                ) {
                  return;
                }

                await api(
                  '/operations/employees/' +
                  employee.id,
                  {
                    method: 'DELETE'
                  }
                );

                await activate();
              }
            )}
          </div>
        `
        : 'Solo lectura'
    ]);

    const paymentRows = payroll.map(payment => [
      e(payment.employee_name),
      e(payment.period),
      e(money(payment.amount)),

      `
        ${e(payment.payment_method)}
        <small>
          ${e(payment.payment_reference || '—')}
        </small>
      `,

      `${e(payment.shift_id)} / #${e(payment.expense_id)}`
    ]);

    root.innerHTML =
      toolbar(
        'Recursos humanos',
        'Empleados y pagos vinculados a caja'
      ) +

      panel(
        'Empleados',

        table(
          [
            'Nombre',
            'Cargo',
            'Salario base',
            'Estado',
            'Acciones'
          ],
          employeeRows
        ),

        canWrite()
          ? button(
              'Nuevo empleado',
              () => employeeForm(),
              'btn-primary'
            )
          : ''
      ) +

      panel(
        'Pagos mensuales',

        table(
          [
            'Empleado',
            'Período',
            'Importe',
            'Forma de pago',
            'Turno / gasto'
          ],
          paymentRows
        ),

        canWrite()
          ? button(
              'Registrar pago',
              () => payrollForm(employees),
              'btn-primary'
            )
          : ''
      ) +

      panel(
        'Expedientes anteriores',

        `
          <p class="ops-help">
            Consulta los registros anteriores del sistema.
          </p>

          <div class="ops-actions">
            ${button(
              'Empleados anteriores',
              () => legacyRecords(
                'empleados',
                'Empleados anteriores'
              )
            )}

            ${button(
              'Nómina anterior',
              () => legacyRecords(
                'nomina',
                'Nómina anterior'
              )
            )}

            ${button(
              'Liquidaciones',
              () => legacyRecords(
                'liquidaciones',
                'Liquidaciones anteriores'
              )
            )}

            ${button(
              'Permisos',
              () => legacyRecords(
                'permisos',
                'Permisos anteriores'
              )
            )}
          </div>
        `
      );
  }

  async function renderAccounting(root, token) {
    const [movements, journal] =
      await Promise.all([
        api('/operations/ledger'),
        api('/accounting/ledger')
      ]);

    if (token !== generation) return;

    const journalRows = journal.items.map(entry => [
      '#' + e(entry.id),
      e(entry.description),

      entry.lines.map(line => `
        <div>
          ${e(line.account)}
          <small>
            Debe: ${e(money(line.debit))}
            · Haber: ${e(money(line.credit))}
          </small>
        </div>
      `).join(''),

      e(money(entry.debit)),
      e(money(entry.credit))
    ]);

    const movementRows = movements.map(movement => {
      const document = movement.sale_id
        ? 'Venta #' + movement.sale_id

        : movement.recarga_id
          ? 'Recarga #' + movement.recarga_id

          : movement.print_payment_id
            ? 'Pago de impresión #' +
              movement.print_payment_id

            : movement.expense_id
              ? 'Gasto #' + movement.expense_id

              : 'Sin documento';

      return [
        e(
          String(movement.fec || '')
            .slice(0, 10)
        ),

        e(movement.con),
        e(movement.tip),
        e(money(movement.mon)),

        e(
          movement.metodo_pago ||
          'Sin especificar'
        ),

        `
          ${e(movement.cashier_name || 'Histórico')}
          <small>
            Turno: ${e(movement.shift_id ?? '—')}
          </small>
        `,

        e(document)
      ];
    });

    root.innerHTML =
      toolbar(
        'Contabilidad financiera',
        'Asientos contables y movimientos operativos',
        link(
          'Reportes',
          '/reportes.html'
        )
      ) +

      panel(
        'Asientos por partida doble',

        `<p class="ops-help">${e(journal.scope)}</p>` +

        table(
          [
            'Asiento',
            'Concepto',
            'Cuentas',
            'Debe',
            'Haber'
          ],
          journalRows
        )
      ) +

      panel(
        'Últimos movimientos de caja',

        table(
          [
            'Fecha',
            'Concepto',
            'Dirección',
            'Importe',
            'Método',
            'Cajero / turno',
            'Documento'
          ],
          movementRows
        )
      );
  }

  async function renderFinance(root, token) {
    root.innerHTML =
      toolbar(
        'Finanzas y Marketing',
        'Control de caja y campañas del negocio'
      ) +

      panel(
        'Control financiero',

        `
          <div class="ops-actions">
            ${link(
              'Control de caja y caja chica',
              '/caja-chica.html'
            )}

            ${link(
              'Finanzas avanzadas',
              '/finanzas.html'
            )}

            ${link(
              'Compras',
              '#proveedores'
            )}

            ${link(
              'Pagos a empleados',
              '#rrhh'
            )}

            ${link(
              'Reportes',
              '/reportes.html'
            )}
          </div>
        `
      ) +

      '<div id="ops-marketing"></div>';

    await renderMarketing(
      document.getElementById('ops-marketing'),
      token
    );
  }

  async function renderInventory(root, token) {
    const summary = await api(
      '/inventory/summary'
    );

    if (token !== generation) return;

    root.innerHTML =
      toolbar(
        'Inventario',
        'Existencias y valoración a costo promedio',
        link(
          'Administrar inventario y Kardex',
          '/inventario.html'
        )
      ) +

      kpis([
        [
          'Productos activos',
          summary.products
        ],
        [
          'Existencias',
          summary.units
        ],
        [
          'Dinero invertido',
          money(summary.invested)
        ],
        [
          'Valor de venta',
          money(summary.retail_value)
        ],
        [
          'Stock bajo',
          summary.low_stock
        ]
      ]);
  }

  async function activate() {
    const token = ++generation;

    let key =
      location.hash.slice(1) ||
      'inicio';

    if (!sections.includes(key)) {
      key = 'inicio';
    }

    sections.forEach(section => {
      const element = document.getElementById(
        'dash-' + section
      );

      if (element) {
        element.hidden = section !== key;
      }
    });

    syncNavigation();

    const target = document.getElementById(
      'dash-' + key
    );

    if (!target) return;

    const root = key === 'inicio'
      ? document.getElementById('ops-overview')
      : target;

    root.innerHTML = `
      <p class="ops-help" role="status">
        Consultando información…
      </p>
    `;

    await loadInto(
      root,
      async () => {
        const role = Auth.getUser()?.role;

        if (
          !['admin', 'superadmin', 'auditor']
            .includes(role)
        ) {
          root.innerHTML = panel(
            'Operación diaria',

            `
              <div class="ops-actions">
                ${link(
                  'Punto de venta',
                  '/pos.html'
                )}

                ${
                  role !== 'invitado'
                    ? link(
                        'Producción y servicios',
                        '/impresiones.html'
                      )
                    : ''
                }

                ${link(
                  'Recargas',
                  '/recargas.html'
                )}

                ${link(
                  'Mi caja',
                  '/caja-chica.html'
                )}
              </div>
            `
          );

          return;
        }

        const renderers = {
          inicio: renderHome,
          produccion: renderProduction,
          proveedores: renderSuppliers,
          contabilidad: renderAccounting,
          finanzas: renderFinance,
          inventario: renderInventory,
          rrhh: renderEmployees
        };

        await renderers[key](root, token);
      }
    );
  }

  window.sincronizarBaseDatos = activate;

  window.addEventListener(
    'hashchange',
    activate
  );

  await activate();
};