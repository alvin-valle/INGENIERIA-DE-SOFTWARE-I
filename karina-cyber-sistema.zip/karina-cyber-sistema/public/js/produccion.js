(() => {
  'use strict';

  // ==========================================================
  // 1. INICIO Y PERMISOS
  // ==========================================================

  if (!requireAuthOrRedirect()) return;

  renderShell({
    title: 'Producción y servicios',
    subtitle: 'Tarifas y órdenes de trabajo',
    active: 'impresiones'
  });

  document.getElementById('page-content').innerHTML =
    document.getElementById('productionTemplate').innerHTML;

  const $ = id => document.getElementById(id);
  const e = escapeHtml;
  const base = '/printing-services';

  const role = (Auth.getUser() || {}).role;

  const canWrite = [
    'superadmin',
    'admin',
    'cajero'
  ].includes(role);

  const canAdmin = [
    'superadmin',
    'admin'
  ].includes(role);

  const transitions = {
    Pendiente: ['En proceso', 'Cancelado'],
    'En proceso': ['Listo', 'Cancelado'],
    Listo: ['Entregado']
  };

  const actionLabels = {
    'En proceso': 'Iniciar trabajo',
    Listo: 'Marcar listo',
    Entregado: 'Marcar entregado',
    Cancelado: 'Cancelar'
  };

  let rates = [];
  let orders = [];
  let daily = [];

  let page = 1;
  let total = 0;
  let pageSize = 25;
  let activeTab = 'new';

  let chart = null;
  let chartDirty = false;

  let quoteVersion = 0;
  let historyVersion = 0;
  let tierNumber = 0;
  let quoteTimer;

  let lastQuote = null;

  // Se conserva el mismo FormData durante un reintento.
  let submission = null;

  let sending = false;
  let refreshing = false;
  let rateSaving = false;
  let historyLoading = false;

  const jobsBusy = new Set();

  // Estilos de los elementos generados dinámicamente.
  const dynamicStyles = document.createElement('style');

  dynamicStyles.textContent = `
    .prod .generated-rate {
      padding: 20px 0;
      border-bottom: 1px solid var(--border);
    }

    .prod .generated-rate:first-child {
      padding-top: 0;
    }

    .prod .generated-rate:last-child {
      padding-bottom: 0;
      border-bottom: 0;
    }

    .prod .generated-rate-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 14px;
      margin-bottom: 8px;
    }

    .prod .generated-rate-head h3 {
      margin: 0;
      font-size: 15px;
      overflow-wrap: anywhere;
    }

    .prod .generated-rate-prices {
      margin: 12px 0;
      padding: 0;
      list-style: none;
    }

    .prod .generated-rate-prices li {
      display: flex;
      justify-content: space-between;
      gap: 14px;
      padding: 7px 0;
      color: var(--ink-soft);
      font-size: 12px;
    }

    .prod .generated-rate-prices strong {
      color: var(--ink);
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
    }

    .prod .generated-order-id {
      display: block;
      color: var(--teal-dark);
      font-weight: 600;
      white-space: nowrap;
    }

    .prod .generated-file {
      display: block;
      margin-top: 8px;
      font-size: 12px;
      overflow-wrap: anywhere;
    }

    .prod .generated-notes {
      white-space: pre-wrap;
      overflow-wrap: anywhere;
    }

    .prod .generated-order-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 7px;
      margin-top: 12px;
      min-width: 150px;
    }

    .prod .generated-order-actions .btn {
      margin: 0;
    }

    .prod .generated-money {
      font-family: var(--font-mono);
      font-size: 12px;
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
    }

    .prod .generated-metric-label {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }

    .prod .generated-metric-label i {
      color: var(--teal);
      font-size: 18px;
    }

    .prod .generated-chart-message {
      padding: 28px 12px;
      color: var(--ink-soft);
      font-size: 12px;
      line-height: 1.7;
      text-align: center;
    }
  `;

  document.head.appendChild(dynamicStyles);

  $('orderFields').disabled = !canWrite;
  $('saveOrder').hidden = !canWrite;
  $('newOrder').hidden = !canWrite;
  $('rateEditor').hidden = !canAdmin;

  // ==========================================================
  // 2. UTILIDADES Y NAVEGACIÓN
  // ==========================================================

  function requestKey() {
    const bytes = crypto.getRandomValues(new Uint8Array(16));

    bytes[6] = (bytes[6] & 15) | 64;
    bytes[8] = (bytes[8] & 63) | 128;

    const hex = Array.from(
      bytes,
      value => value.toString(16).padStart(2, '0')
    ).join('');

    return [
      hex.slice(0, 8),
      hex.slice(8, 12),
      hex.slice(12, 16),
      hex.slice(16, 20),
      hex.slice(20)
    ].join('-');
  }

  function numberValue(value) {
    if (
      value === null ||
      value === undefined ||
      typeof value === 'boolean' ||
      (typeof value === 'string' && !value.trim())
    ) {
      return null;
    }

    const result = Number(value);
    return Number.isFinite(result) ? result : null;
  }

  function numberText(value) {
    const result = numberValue(value);

    return result === null
      ? 'No disponible'
      : result.toLocaleString('es-NI', {
          maximumFractionDigits: 2
        });
  }

  function amount(value) {
    const result = numberValue(value);
    return result === null ? 'No disponible' : money(result);
  }

  function dayLabel(value) {
    const raw = String(value || '');

    if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw || '—';

    const date = new Date(raw + 'T12:00:00');

    return date.toLocaleDateString('es-NI', {
      day: '2-digit',
      month: 'short'
    });
  }

  function messageOf(err) {
    return err?.message || 'No se pudo completar la operación.';
  }

  function notice(message, isError = false) {
    $('productionNotice').textContent = message;
    $('productionNotice').className =
      'notice' + (isError ? ' error' : '');
  }

  function error(err) {
    notice(messageOf(err), true);
    toast(messageOf(err), 'error');
  }

  function empty(message, icon = 'bi-inbox') {
    return `
      <div class="empty-state">
        <i class="bi ${icon}" aria-hidden="true"></i>
        ${e(message)}
      </div>
    `;
  }

  function tab(key) {
    activeTab = ['new', 'orders', 'rates'].includes(key)
      ? key
      : 'new';

    document.querySelectorAll('.prod [data-tab]').forEach(button => {
      const active = button.dataset.tab === activeTab;

      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });

    ['new', 'orders', 'rates'].forEach(name => {
      $('view-' + name).hidden = name !== activeTab;
    });

    if (activeTab === 'new') {
      requestAnimationFrame(drawOverviewChart);
    }
  }

  document.querySelector('.prod .tabs').addEventListener('click', event => {
    const button = event.target.closest('button[data-tab]');

    if (button) tab(button.dataset.tab);
  });

  function syncOrderButtons() {
    $('saveOrder').disabled = sending || !canWrite;
    $('newOrder').disabled = sending || !canWrite;

    $('saveOrder').textContent = sending
      ? 'Guardando…'
      : submission
        ? 'Reintentar misma orden'
        : 'Guardar orden';
  }

  function syncPagination() {
    $('previousPage').disabled = historyLoading || page <= 1;

    $('nextPage').disabled =
      historyLoading || page * pageSize >= total;
  }

  // ==========================================================
  // 3. COTIZACIÓN
  // ==========================================================

  async function refreshQuote() {
    const version = ++quoteVersion;
    lastQuote = null;

    const rate = rates.find(
      row => String(row.id) === $('rateId').value
    );

    const pages = Number($('pages').value);
    const copies = Number($('copies').value);

    $('rateInfo').textContent = rate
      ? [
          rate.service,
          rate.paper,
          rate.color,
          Number(rate.sides) === 2 ? 'Dúplex' : 'Simplex',
          'Cobro por ' + rate.billing
        ].filter(Boolean).join(' · ')
      : '';

    const validQuantities =
      Number.isInteger(pages) &&
      pages >= 1 &&
      pages <= 100000 &&
      Number.isInteger(copies) &&
      copies >= 1 &&
      copies <= 100000;

    if (!rate || !validQuantities) {
      $('quoteBox').textContent =
        'Selecciona una tarifa y cantidades válidas.';

      $('quoteBox').setAttribute('aria-busy', 'false');
      return;
    }

    $('quoteBox').textContent = 'Calculando cotización…';
    $('quoteBox').setAttribute('aria-busy', 'true');

    try {
      const q = await api(base + '/quote', {
        method: 'POST',
        body: {
          tariff_id: rate.id,
          pages: $('pages').value,
          copies: $('copies').value
        }
      });

      if (version !== quoteVersion) return;

      if (
        !q ||
        numberValue(q.total) === null ||
        numberValue(q.unit_price) === null ||
        numberValue(q.units) === null ||
        typeof q.quote_key !== 'string' ||
        !q.quote_key
      ) {
        throw new Error('El servidor devolvió una cotización incompleta.');
      }

      lastQuote = q;

      $('quoteBox').innerHTML = `
        <span>Cotización del trabajo</span>

        <strong>${e(amount(q.total))}</strong>

        <span>
          ${e(numberText(q.units))}
          × ${e(amount(q.unit_price))}
          por ${e(q.billing)}
        </span>

        ${q.sheets == null ? '' : `
          <p class="muted">
            ${e(numberText(q.faces))} caras ·
            ${e(numberText(q.sheets))} hojas estimadas.
            Consumo aún no descontado.
          </p>
        `}
      `;
    } catch (err) {
      if (version === quoteVersion) {
        $('quoteBox').textContent = messageOf(err);
      }
    } finally {
      if (version === quoteVersion) {
        $('quoteBox').setAttribute('aria-busy', 'false');
      }
    }
  }

  ['rateId', 'pages', 'copies'].forEach(name => {
    $(name).addEventListener('input', () => {
      lastQuote = null;
      ++quoteVersion;

      clearTimeout(quoteTimer);

      $('quoteBox').textContent = 'Actualizando cotización…';
      quoteTimer = setTimeout(refreshQuote, 250);
    });
  });

  // ==========================================================
  // 4. CATÁLOGO DE TARIFAS
  // ==========================================================

  async function loadRates() {
    const selected = $('rateId').value;
    const response = await api(base + '/rates');

    if (
      !Array.isArray(response) ||
      response.some(rate => !Array.isArray(rate.tiers))
    ) {
      throw new Error('Respuesta inválida al consultar tarifas.');
    }

    rates = response;

    /*
     * No modifica el formulario si hay una orden enviándose
     * o una solicitud pendiente de confirmar.
     */
    if (!submission && !sending) {
      $('rateId').innerHTML = `
        <option value="">Selecciona una tarifa</option>

        ${rates.filter(rate => rate.active).map(rate => `
          <option value="${e(rate.id)}">${e(rate.name)}</option>
        `).join('')}
      `;

      if (
        rates.some(rate =>
          rate.active && String(rate.id) === selected
        )
      ) {
        $('rateId').value = selected;
      }

      await refreshQuote();
    }

    if (!rates.length) {
      $('ratesList').innerHTML = empty(
        'Sin tarifas. Un administrador debe registrar los precios reales para comenzar.',
        'bi-tags'
      );
      return;
    }

    $('ratesList').innerHTML = rates.map(rate => {
      const description = [
        rate.service,
        rate.paper,
        rate.color,
        Number(rate.sides) === 2 ? 'Dúplex' : 'Simplex',
        'Por ' + rate.billing
      ].filter(Boolean).join(' · ');

      return `
        <article class="generated-rate">
          <div class="generated-rate-head">
            <h3>${e(rate.name)}</h3>

            <span class="badge ${rate.active ? 'badge-green' : 'badge-gray'}">
              ${rate.active ? 'Activa' : 'Inactiva'}
            </span>
          </div>

          <p class="muted">${e(description)}</p>

          <ul class="generated-rate-prices">
            ${rate.tiers.map(tier => {
              const label = tier.up_to == null
                ? rate.tiers.length === 1
                  ? 'Tarifa fija'
                  : 'Resto de páginas'
                : 'Hasta ' + numberText(tier.up_to) + ' páginas';

              return `
                <li>
                  <span>${e(label)}</span>
                  <strong>${e(amount(tier.price))}</strong>
                </li>
              `;
            }).join('')}
          </ul>

          ${canAdmin ? `
            <button
              type="button"
              class="btn btn-outline btn-sm"
              data-edit-rate="${e(rate.id)}"
              aria-label="${e('Editar tarifa: ' + rate.name)}"
              ${rateSaving ? 'disabled' : ''}
            >
              <i class="bi bi-pencil" aria-hidden="true"></i>
              Editar
            </button>
          ` : ''}
        </article>
      `;
    }).join('');
  }

  // ==========================================================
  // 5. INDICADORES Y GRÁFICA
  // ==========================================================

  const chartMessage = document.createElement('p');
  chartMessage.className = 'generated-chart-message';
  chartMessage.hidden = true;

  $('chartContainer').insertAdjacentElement('beforebegin', chartMessage);

  function showChartMessage(message) {
    $('chartContainer').hidden = true;
    chartMessage.textContent = message;
    chartMessage.hidden = false;
    $('dailyTable').parentElement.open = true;
  }

  function drawOverviewChart() {
    if (activeTab !== 'new') return;

    if (!chartDirty) {
      if (chart) chart.resize();
      return;
    }

    if (chart) {
      chart.destroy();
      chart = null;
    }

    if (!daily.length) {
      showChartMessage('No hay datos disponibles para la gráfica.');
      chartDirty = false;
      return;
    }

    if (typeof Chart === 'undefined') {
      showChartMessage(
        'No se pudo cargar la gráfica. Consulta la tabla de datos inferior.'
      );
      return;
    }

    $('chartContainer').hidden = false;
    chartMessage.hidden = true;

    try {
      chart = window.crearGraficoERP($('productionChart'), {
        type: 'bar',

        data: {
          labels: daily.map(row => dayLabel(row.date)),
          datasets: [{
            label: 'Órdenes recibidas',
            data: daily.map(row => Number(row.count)),
            backgroundColor: '#0a6b66',
            hoverBackgroundColor: '#085651',
            borderRadius: 5,
            maxBarThickness: 46
          }]
        },

        options: {
          responsive: true,
          maintainAspectRatio: false,

          animation: window.matchMedia(
            '(prefers-reduced-motion: reduce)'
          ).matches ? false : { duration: 250 },

          plugins: {
            legend: { display: false },

            tooltip: {
              backgroundColor: '#182b32',
              titleColor: '#ffffff',
              bodyColor: '#e0eaec',
              padding: 12,
              cornerRadius: 8,
              callbacks: {
                label(context) {
                  return 'Órdenes recibidas: ' +
                    numberText(context.parsed.y);
                }
              }
            }
          },

          scales: {
            y: {
              beginAtZero: true,
              border: { display: false },
              grid: { color: '#e8eeeb' },
              ticks: {
                precision: 0,
                color: '#53636a',
                font: {
                  family: 'Inter, Segoe UI, sans-serif',
                  size: 11
                }
              }
            },

            x: {
              border: { display: false },
              grid: { display: false },
              ticks: {
                color: '#53636a',
                maxRotation: 0,
                font: {
                  family: 'Inter, Segoe UI, sans-serif',
                  size: 11
                }
              }
            }
          }
        }
      });

      chartDirty = false;
    } catch (err) {
      showChartMessage(
        'No se pudo representar la gráfica. La tabla conserva los datos recibidos.'
      );
    }
  }

  async function loadOverview() {
    const data = await api(base + '/overview');

    if (
      !data ||
      !Array.isArray(data.states) ||
      !Array.isArray(data.daily) ||
      data.states.some(row => numberValue(row.count) === null) ||
      data.daily.some(row => numberValue(row.count) === null)
    ) {
      throw new Error('Respuesta inválida al consultar los indicadores.');
    }

    const states = [
      ['Pendiente', 'bi-clock'],
      ['En proceso', 'bi-printer'],
      ['Listo', 'bi-check2-circle'],
      ['Entregado', 'bi-box-seam']
    ];

    $('metrics').innerHTML = states.map(([state, icon]) => {
      const record = data.states.find(item => item.status === state);
      const count = record ? record.count : 0;

      return `
        <div class="metric">
          <div class="generated-metric-label">
            <span>${e(state)}</span>
            <i class="bi ${icon}" aria-hidden="true"></i>
          </div>

          <strong>${e(numberText(count))}</strong>
          <span class="muted">Total histórico</span>
        </div>
      `;
    }).join('');

    daily = data.daily;

    $('dailyTable').innerHTML = daily.length
      ? `
        <table>
          <thead>
            <tr>
              <th scope="col">Fecha</th>
              <th scope="col">Órdenes recibidas</th>
            </tr>
          </thead>

          <tbody>
            ${daily.map(row => `
              <tr>
                <td>${e(dayLabel(row.date))}</td>
                <td class="mono">${e(numberText(row.count))}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `
      : empty('Sin datos disponibles para este período.');

    chartDirty = true;
    drawOverviewChart();
  }

  // ==========================================================
  // 6. ÓRDENES E HISTORIAL
  // ==========================================================

  function renderOrders() {
    $('ordersBody').innerHTML = orders.length
      ? orders.map(job => {
          const details = job.production_details;

          const serviceName = details
            ? details.name
            : [job.print_type, job.paper_size].filter(Boolean).join(' · ');

          const quantity = details
            ? `${numberText(details.pages)} páginas × ` +
              `${numberText(details.copies)} ejemplares`
            : `${numberText(job.copies)} ejemplares`;

          const statusButtons = canWrite
            ? (transitions[job.status] || []).map(status => `
                <button
                  type="button"
                  class="btn ${
                    status === 'Cancelado'
                      ? 'btn-danger'
                      : 'btn-outline'
                  } btn-sm"
                  data-job="${e(job.id)}"
                  data-status="${e(status)}"
                  ${jobsBusy.has(String(job.id)) ? 'disabled' : ''}
                >
                  ${e(actionLabels[status] || status)}
                </button>
              `).join('')
            : '';

          return `
            <tr>
              <td>
                <span class="generated-order-id">#${e(job.id)}</span>

                <p class="muted">
                  ${e(fmtDateTime(job.created_at))}
                </p>
              </td>

              <td class="wrap">
                <strong>
                  ${e(job.customer_name || 'Cliente de mostrador')}
                </strong>

                ${job.customer_contact ? `
                  <p class="muted">${e(job.customer_contact)}</p>
                ` : ''}

                ${job.file_name ? `
                  <span class="generated-file">${e(job.file_name)}</span>
                ` : ''}

                ${job.notes ? `
                  <p class="muted generated-notes">${e(job.notes)}</p>
                ` : ''}

                ${job.has_file ? `
                  <button
                    type="button"
                    class="btn btn-outline btn-sm"
                    data-download="${e(job.id)}"
                    ${jobsBusy.has(String(job.id)) ? 'disabled' : ''}
                  >
                    <i class="bi bi-download" aria-hidden="true"></i>
                    Descargar adjunto
                  </button>
                ` : ''}
              </td>

              <td class="wrap">
                ${e(serviceName || 'Servicio no disponible')}
                <p class="muted">${e(quantity)}</p>
              </td>

              <td class="generated-money">
                ${e(
                  job.quoted_total == null
                    ? 'No registrada'
                    : amount(job.quoted_total)
                )}
              </td>

              <td>
                <span
                  class="badge"
                  data-status="${e(job.status || '')}"
                >
                  ${e(job.status || 'Sin estado')}
                </span>

                ${statusButtons ? `
                  <div class="generated-order-actions">
                    ${statusButtons}
                  </div>
                ` : ''}
              </td>
            </tr>
          `;
        }).join('')
      : `
        <tr>
          <td colspan="5">
            ${empty(
              'No hay órdenes que coincidan con la búsqueda.',
              'bi-search'
            )}
          </td>
        </tr>
      `;

    const pages = Math.max(1, Math.ceil(total / pageSize));

    $('pageInfo').textContent =
      `Página ${page} de ${pages} · ${numberText(total)} órdenes`;

    syncPagination();
  }

  async function loadOrders(targetPage = page) {
    const version = ++historyVersion;
    historyLoading = true;

    $('ordersBody').setAttribute('aria-busy', 'true');
    syncPagination();

    const qs = new URLSearchParams({
      page: targetPage,
      q: $('search').value.trim(),
      status: $('filterStatus').value
    });

    try {
      const data = await api(base + '/orders?' + qs);

      if (version !== historyVersion) return;

      if (
        !data ||
        !Array.isArray(data.items) ||
        numberValue(data.total) === null ||
        Number(data.total) < 0 ||
        !Number.isInteger(Number(data.page_size)) ||
        Number(data.page_size) < 1
      ) {
        throw new Error('Respuesta inválida al consultar las órdenes.');
      }

      const lastPage = Math.max(
        1,
        Math.ceil(Number(data.total) / Number(data.page_size))
      );

      if (targetPage > lastPage) {
        return await loadOrders(lastPage);
      }

      orders = data.items;
      total = Number(data.total);
      pageSize = Number(data.page_size);
      page = targetPage;

      renderOrders();
    } catch (err) {
      if (version === historyVersion) throw err;
    } finally {
      if (version === historyVersion) {
        historyLoading = false;
        $('ordersBody').setAttribute('aria-busy', 'false');
        syncPagination();
      }
    }
  }

  $('searchForm').addEventListener('submit', event => {
    event.preventDefault();
    loadOrders(1).catch(error);
  });

  $('previousPage').addEventListener('click', () => {
    if (!historyLoading && page > 1) {
      loadOrders(page - 1).catch(error);
    }
  });

  $('nextPage').addEventListener('click', () => {
    if (!historyLoading && page * pageSize < total) {
      loadOrders(page + 1).catch(error);
    }
  });

  // ==========================================================
  // 7. ACTUALIZACIÓN GENERAL
  // ==========================================================

  async function refresh() {
    if (refreshing) return;

    refreshing = true;
    $('refreshProduction').disabled = true;
    $('refreshProduction').textContent = 'Actualizando…';

    notice('Actualizando tarifas, órdenes e indicadores…');

    try {
      const tasks = [
        ['Tarifas', loadRates()],
        ['Órdenes', loadOrders()],
        ['Indicadores', loadOverview()]
      ];

      const results = await Promise.allSettled(
        tasks.map(([, promise]) => promise)
      );

      const failures = results.flatMap((result, index) => {
        return result.status === 'rejected'
          ? [tasks[index][0] + ': ' + messageOf(result.reason)]
          : [];
      });

      if (failures.length) {
        notice(
          'Actualización incompleta. ' + failures.join(' ') +
          ' Los apartados que fallaron pueden conservar datos anteriores.',
          true
        );
        return;
      }

      if (submission) {
        notice(
          'Historial actualizado. Hay una orden pendiente de confirmar. ' +
          'Puedes reintentar la misma solicitud desde Nueva orden.',
          true
        );
        return;
      }

      notice(
        'Información actualizada. Las cotizaciones muestran el precio ' +
        'del trabajo; el cobro se registra por separado.' +
        (!canWrite ? ' Tu perfil tiene acceso de consulta.' : '')
      );
    } finally {
      refreshing = false;
      $('refreshProduction').disabled = false;
      $('refreshProduction').textContent = 'Actualizar';
    }
  }

  $('refreshProduction').addEventListener('click', () => {
    refresh().catch(error);
  });

  // ==========================================================
  // 8. REGISTRAR UNA ORDEN
  // ==========================================================

  function resetOrder() {
    submission = null;
    lastQuote = null;

    clearTimeout(quoteTimer);
    ++quoteVersion;

    $('orderForm').reset();
    $('orderFields').disabled = !canWrite;

    syncOrderButtons();
    refreshQuote();
  }

  $('newOrder').addEventListener('click', () => {
    if (sending || !canWrite) return;

    if (
      submission &&
      !confirm(
        'Hay una solicitud sin confirmar. Revisa el historial ' +
        'antes de crear otra para evitar duplicados. ' +
        '¿Quieres limpiar el formulario?'
      )
    ) {
      return;
    }

    resetOrder();
  });

  $('orderForm').addEventListener('submit', async event => {
    event.preventDefault();

    if (sending || !canWrite) return;

    if (!submission && !$('orderForm').reportValidity()) return;

    sending = true;
    syncOrderButtons();

    try {
      if (!submission) {
        $('orderFields').disabled = true;
        clearTimeout(quoteTimer);

        await refreshQuote();

        if (!lastQuote) {
          throw new Error(
            'Revisa la tarifa y las cantidades para cotizar.'
          );
        }

        const file = $('jobFile').files[0];

        if (file && file.size > 20 * 1024 * 1024) {
          throw new Error('El archivo supera los 20 MB.');
        }

        const form = new FormData();

        const values = {
          tariff_id: $('rateId').value,
          pages: $('pages').value,
          copies: $('copies').value,
          customer_name: $('customerName').value,
          customer_contact: $('customerContact').value,
          notes: $('notes').value,
          orientation: $('orientation').value,
          request_key: requestKey(),
          quote_key: lastQuote.quote_key
        };

        Object.entries(values).forEach(([key, value]) => {
          form.append(key, value);
        });

        if (file) form.append('file', file);

        submission = form;
      }

      const result = await api(base + '/upload', {
        method: 'POST',
        body: submission,
        isForm: true
      });

      /*
       * Si la respuesta llega incompleta, conservamos la solicitud.
       * Reenviarla con la misma request_key permite confirmar
       * la orden sin crear otra.
       */
      if (!result?.job?.id) {
        throw new Error(
          'No se recibió la confirmación completa de la orden.'
        );
      }

      resetOrder();

      toast(
        'Orden #' + result.job.id +
        ' guardada. Cotización: ' +
        amount(result.job.quoted_total),
        'success'
      );

      page = 1;
      tab('orders');

      await refresh();
    } catch (err) {
      /*
       * Los errores de validación permiten corregir el formulario.
       * Ante un error de red o servidor se conserva el FormData.
       */
      if (err.status >= 400 && err.status < 500) {
        submission = null;
      }

      if (submission) {
        notice(
          messageOf(err) +
          ' Puedes reintentar la misma orden o consultar el historial.',
          true
        );

        toast(
          'No se pudo confirmar el registro. Se conserva la solicitud.',
          'error'
        );
      } else {
        $('orderFields').disabled = !canWrite;
        error(err);
      }
    } finally {
      sending = false;
      syncOrderButtons();
    }
  });

  // ==========================================================
  // 9. ESTADOS Y DESCARGA DE ADJUNTOS
  // ==========================================================

  $('ordersBody').addEventListener('click', async event => {
    const button = event.target.closest('button');

    if (!button || button.disabled) return;

    const selectedId =
      button.dataset.job || button.dataset.download;

    const job = orders.find(
      row => String(row.id) === selectedId
    );

    if (!job || jobsBusy.has(String(job.id))) return;

    const downloading = Boolean(button.dataset.download);

    if (!downloading && !canWrite) return;

    if (
      button.dataset.status === 'Cancelado' &&
      !confirm(
        '¿Cancelar la orden #' + job.id +
        '? El historial se conservará.'
      )
    ) {
      return;
    }

    const key = String(job.id);
    jobsBusy.add(key);

    const relatedButtons = Array.from(
      $('ordersBody').querySelectorAll('button')
    ).filter(item =>
      item.dataset.job === key ||
      item.dataset.download === key
    );

    relatedButtons.forEach(item => {
      item.disabled = true;
    });

    const originalContent = button.innerHTML;
    button.textContent = downloading ? 'Descargando…' : 'Actualizando…';

    try {
      if (downloading) {
        const blob = await api(
          base + '/orders/' + encodeURIComponent(job.id) + '/file'
        );

        if (!(blob instanceof Blob)) {
          throw new Error('El servidor no devolvió un archivo válido.');
        }

        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');

        link.href = url;
        link.download = job.file_name || 'archivo-orden-' + job.id;

        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(() => URL.revokeObjectURL(url), 10000);
      } else {
        await api(
          base + '/orders/' + encodeURIComponent(job.id) + '/status',
          {
            method: 'PATCH',
            body: {
              status: button.dataset.status,
              expected_status: job.status
            }
          }
        );

        toast('Estado actualizado.', 'success');
        await refresh();
      }
    } catch (err) {
      error(err);
    } finally {
      jobsBusy.delete(key);

      if (button.isConnected) {
        button.innerHTML = originalContent;
      }

      $('ordersBody').querySelectorAll('button').forEach(item => {
        if (
          item.dataset.job === key ||
          item.dataset.download === key
        ) {
          item.disabled = false;
        }
      });
    }
  });

  // ==========================================================
  // 10. TRAMOS DE PRECIOS
  // ==========================================================

  function addTier(tier = { up_to: null, price: '' }) {
    const n = ++tierNumber;
    const div = document.createElement('div');

    div.className = 'tier';

    div.innerHTML = `
      <div>
        <label for="limit-${n}">Hasta páginas</label>

        <input
          id="limit-${n}"
          data-limit
          type="number"
          min="1"
          max="100000"
          step="1"
          placeholder="Sin límite"
          value="${e(tier.up_to ?? '')}"
        >
      </div>

      <div>
        <label for="price-${n}">Precio C$</label>

        <input
          id="price-${n}"
          data-price
          type="number"
          min="0.01"
          max="999999.99"
          step="0.01"
          placeholder="0.00"
          required
          value="${e(tier.price ?? '')}"
        >
      </div>

      <button
        type="button"
        class="btn btn-outline"
        aria-label="Quitar este tramo de precio"
        title="Quitar tramo"
      >
        <i class="bi bi-trash" aria-hidden="true"></i>
      </button>
    `;

    div.querySelector('button').addEventListener('click', () => {
      if (rateSaving) return;

      if ($('tiers').children.length <= 1) {
        toast('La tarifa debe conservar al menos un tramo.', 'info');
        return;
      }

      const nextFocus = div.nextElementSibling || div.previousElementSibling;

      div.remove();
      nextFocus?.querySelector('input')?.focus();
    });

    $('tiers').appendChild(div);
  }

  $('addTier').addEventListener('click', () => {
    if (!canAdmin || rateSaving) return;

    if ($('tiers').children.length >= 20) {
      toast('Puedes agregar hasta 20 tramos por tarifa.', 'info');
      return;
    }

    addTier();
    $('tiers').lastElementChild.querySelector('input').focus();
  });

  // ==========================================================
  // 11. EDITAR Y GUARDAR TARIFAS
  // ==========================================================

  function resetRate() {
    $('rateForm').reset();
    $('editRateId').value = '';
    $('rateTitle').textContent = 'Nueva tarifa';
    $('tiers').innerHTML = '';

    addTier();

    $('rateActive').checked = true;
    $('rateActive').disabled = true;
  }

  $('clearRate').addEventListener('click', () => {
    if (!rateSaving && canAdmin) resetRate();
  });

  $('service').addEventListener('change', () => {
    const service = $('service').value;

    if (['Cédula', 'Encolochado', 'Laminado'].includes(service)) {
      $('billing').value = 'documento';
    }

    if (['Encolochado', 'Laminado', 'Escaneo'].includes(service)) {
      $('color').value = 'No aplica';
    }
  });

  $('ratesList').addEventListener('click', event => {
    const button = event.target.closest('[data-edit-rate]');

    if (!button || !canAdmin || rateSaving) return;

    const rate = rates.find(
      row => String(row.id) === button.dataset.editRate
    );

    if (!rate) {
      toast('La tarifa ya no está disponible. Actualiza el catálogo.', 'error');
      return;
    }

    $('editRateId').value = rate.id;
    $('rateName').value = rate.name;

    ['service', 'billing', 'sides', 'color', 'paper'].forEach(key => {
      $(key).value = rate[key] ?? '';
    });

    $('rateActive').checked = Boolean(rate.active);
    $('rateActive').disabled = false;
    $('rateTitle').textContent = 'Editar tarifa';
    $('tiers').innerHTML = '';

    rate.tiers.forEach(tier => addTier(tier));
    $('rateName').focus();
  });

  $('rateForm').addEventListener('submit', async event => {
    event.preventDefault();

    if (!canAdmin || rateSaving) return;
    if (!$('rateForm').reportValidity()) return;

    const tierElements = Array.from($('tiers').children);

    if (!tierElements.length) {
      toast('Agrega al menos un tramo de precio.', 'error');
      return;
    }

    const body = {
      name: $('rateName').value,
      active: $('rateActive').checked,

      tiers: tierElements.map(div => {
        const limit = div.querySelector('[data-limit]').value;
        const price = div.querySelector('[data-price]').value;

        return {
          up_to: limit === '' ? null : Number(limit),
          price
        };
      })
    };

    ['service', 'billing', 'sides', 'color', 'paper'].forEach(key => {
      body[key] = $(key).value;
    });

    const id = $('editRateId').value;

    // Evita cambios en el editor durante el guardado.
    const controls = Array.from(
      $('rateForm').querySelectorAll('input, select, textarea, button')
    );

    const disabledBefore = controls.map(control => control.disabled);
    let saved = false;

    rateSaving = true;

    controls.forEach(control => {
      control.disabled = true;
    });

    $('saveRate').textContent = 'Guardando…';
    $('rateForm').setAttribute('aria-busy', 'true');

    try {
      await api(
        base + '/rates' + (id ? '/' + encodeURIComponent(id) : ''),
        {
          method: id ? 'PUT' : 'POST',
          body
        }
      );

      saved = true;

      toast(
        'Tarifa guardada. Las órdenes anteriores conservan sus precios.',
        'success'
      );
    } catch (err) {
      error(err);
    } finally {
      controls.forEach((control, index) => {
        control.disabled = disabledBefore[index];
      });

      rateSaving = false;
      $('saveRate').textContent = 'Guardar tarifa';
      $('rateForm').setAttribute('aria-busy', 'false');
    }

    if (saved) {
      resetRate();

      try {
        await loadRates();
      } catch (err) {
        notice(
          'La tarifa se guardó, pero no se pudo actualizar el catálogo. ' +
          'Pulsa Actualizar para volver a consultarlo.',
          true
        );
      }
    }
  });

  // ==========================================================
  // 12. CARGA INICIAL
  // ==========================================================

  $('ordersBody').innerHTML = `
    <tr>
      <td colspan="5">
        ${empty('Cargando órdenes…', 'bi-hourglass-split')}
      </td>
    </tr>
  `;

  $('ratesList').innerHTML = empty(
    'Cargando tarifas…',
    'bi-hourglass-split'
  );

  resetRate();
  syncOrderButtons();
  tab(canWrite ? 'new' : 'orders');
  refresh().catch(error);

  // GET: Obtener todas las órdenes para la tabla y gráficas
app.get('/api/produccion', async (req, res) => {
    try {
        // Ordenadas de las más recientes a las más antiguas
        const { rows } = await pool.query('SELECT * FROM ordenes_produccion ORDER BY id_orden DESC');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).send("Error del servidor");
    }
});

// POST: Crear una nueva orden
app.post('/api/produccion', async (req, res) => {
    const { cliente, descripcion_trabajo, costo_estimado, fecha_entrega, responsable } = req.body;
    try {
        const nuevaOrden = await pool.query(
            `INSERT INTO ordenes_produccion (cliente, descripcion_trabajo, costo_estimado, fecha_entrega, responsable, estado) 
             VALUES ($1, $2, $3, $4, $5, 'Pendiente') RETURNING *`,
            [cliente, descripcion_trabajo, costo_estimado, fecha_entrega || null, responsable]
        );
        res.json(nuevaOrden.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).send("Error al crear la orden");
    }
});
})();