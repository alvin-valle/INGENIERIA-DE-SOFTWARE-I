'use strict';

(() => {
    const MODULES = [
        'inicio',
        'produccion',
        'proveedores',
        'contabilidad',
        'finanzas',
        'inventario',
        'rrhh'
    ];

    const TAB_GROUPS = [
        {
            functionName: 'cambiarSubConta',
            sectionId: 'dash-contabilidad',
            prefix: 'conta-',
            names: [
                'nomina',
                'compras',
                'balance',
                'resultados',
                'flujo'
            ]
        },
        {
            functionName: 'cambiarSubFinanzas',
            sectionId: 'dash-finanzas',
            prefix: 'finanzas-',
            names: [
                'caja',
                'facturas',
                'estadistica',
                'mkt'
            ]
        },
        {
            functionName: 'cambiarSubRH',
            sectionId: 'dash-rrhh',
            prefix: 'rh-',
            names: [
                'empleados',
                'contratos',
                'permisos',
                'seguridad',
                'cumplimiento'
            ]
        }
    ];

    function currentModule() {
        const value = window.location.hash.slice(1);
        return MODULES.includes(value) ? value : 'inicio';
    }

    function updateNavigation() {
        const selected = currentModule();

        document.querySelectorAll(
            '#main-menu-container .menu-btn[data-target]'
        ).forEach(button => {
            const active = button.dataset.target === selected;

            if (active) {
                button.setAttribute('aria-current', 'page');
            } else {
                button.removeAttribute('aria-current');
            }
        });

        document.querySelectorAll('.sidebar-nav a[href]').forEach(link => {
            let url;

            try {
                url = new URL(link.getAttribute('href'), location.href);
            } catch {
                return;
            }

            if (
                url.origin !== location.origin ||
                url.pathname !== location.pathname
            ) {
                return;
            }

            link.setAttribute('data-kc-dashboard-link', '');

            const target = url.hash.slice(1) || 'inicio';
            const active = target === selected;

            link.classList.toggle('active', active);

            if (active) {
                link.setAttribute('aria-current', 'page');
            } else {
                link.removeAttribute('aria-current');
            }
        });
    }

    function keepOriginalMenuVisible() {
        /*
         * En el original, el menú de módulos está dentro de dash-inicio.
         * Lo mantenemos visible al entrar en otro módulo para que
         * pueda verse cuál está seleccionado y cambiar directamente.
         */
        const home = document.getElementById('dash-inicio');

        if (home && home.hidden) {
            home.hidden = false;
        }
    }

    function improveMenuAccessibility() {
        document.querySelectorAll(
            '#main-menu-container .menu-btn[data-target]'
        ).forEach(button => {
            if (button.matches('button, a')) {
                return;
            }

            button.setAttribute('role', 'button');
            button.setAttribute('tabindex', '0');

            button.addEventListener('keydown', event => {
                if (event.key !== 'Enter' && event.key !== ' ') {
                    return;
                }

                event.preventDefault();
                button.click();
            });
        });
    }

    function selectSubTab(group, tabName, button) {
        if (!group.names.includes(tabName)) {
            return;
        }

        const section = document.getElementById(group.sectionId);

        if (!section) {
            return;
        }

        group.names.forEach(name => {
            const panel = document.getElementById(group.prefix + name);

            if (panel) {
                panel.hidden = name !== tabName;
            }
        });

        section.querySelectorAll('.sub-tab-btn').forEach(item => {
            const active = item === button;

            item.classList.toggle('kc-sub-selected', active);
            item.setAttribute('aria-pressed', String(active));
        });

        /*
         * Conserva las funciones de gráficos existentes.
         * El siguiente frame permite que el panel ya sea visible
         * antes de que Chart.js mida su espacio.
         */
        requestAnimationFrame(() => {
            if (
                group.prefix === 'finanzas-' &&
                tabName === 'estadistica' &&
                typeof window.renderChartsFinanzas === 'function'
            ) {
                window.renderChartsFinanzas();
            }

            if (
                group.prefix === 'rh-' &&
                tabName === 'cumplimiento' &&
                typeof window.renderChartsCumplimiento === 'function'
            ) {
                window.renderChartsCumplimiento();
            }
        });
    }

    function improveSubTabs() {
        TAB_GROUPS.forEach(group => {
            const section = document.getElementById(group.sectionId);

            if (!section) {
                return;
            }

            /*
             * Los botones originales ya llaman a estos nombres.
             * Se conservan los mismos botones y todos sus paneles.
             */
            window[group.functionName] = (tabName, button) => {
                selectSubTab(group, tabName, button);
            };

            const buttons = section.querySelectorAll('.sub-tab-btn');

            buttons.forEach((button, index) => {
                button.classList.toggle('kc-sub-selected', index === 0);
                button.setAttribute(
                    'aria-pressed',
                    String(index === 0)
                );
            });
        });
    }

    function improveTables() {
        document.querySelectorAll(
            '#page-content .dash-panel table'
        ).forEach(table => {
            if (table.parentElement?.classList.contains('kc-table-scroll')) {
                return;
            }

            const wrapper = document.createElement('div');
            wrapper.className = 'kc-table-scroll';

            table.before(wrapper);
            wrapper.appendChild(table);
        });
    }

    function start() {
        const root = document.getElementById('page-content');
        const home = document.getElementById('dash-inicio');

        if (!root || !home) {
            console.error(
                'No se encontró la estructura del dashboard original.'
            );
            return;
        }

        document.body.classList.add('kc-dashboard-original');

        improveMenuAccessibility();
        improveSubTabs();
        improveTables();
        keepOriginalMenuVisible();
        updateNavigation();

        window.addEventListener('hashchange', () => {
            keepOriginalMenuVisible();
            updateNavigation();
        });

        /*
         * La sincronización original vuelve a activar el módulo.
         * Este observador conserva visible el menú después de ella.
         */
        const observer = new MutationObserver(() => {
            keepOriginalMenuVisible();
            updateNavigation();
        });

        observer.observe(home, {
            attributes: true,
            attributeFilter: ['hidden']
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, {
            once: true
        });
    } else {
        start();
    }
})();